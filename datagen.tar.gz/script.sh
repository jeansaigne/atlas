#!/bin/sh

COM1 = `/var/www/html/atlas/Slicer3-3.6.3-2011-03-04-linux-x86_64/Slicer3 --launch /var/www/html/atlas/Slicer3-3.6.3-2011-03-04-linux-x86_64/lib/Slicer3/Plugins/ImageLabelCombine `
DOS0=`/var/www/html/atlas/data/Scene0/`
DOS1=`/var/www/html/atlas/datagen/`
FIL1=`IIG_Contour_IndexedLabelmap.nii.gz `
FIL2=`IbG_Contour_IndexedLabelmap.nii.gz `
FIL3=`test.nii.gz`


if $8
then
	if $7
	then
		if $6
		then
			if $5
			then
				if $4
				then
					if $3
					then
						if $2
						then
							if $1
							then
								echo "ok"
								#./Slicer3-3.6.3-2011-03-04-linux-x86_64/Slicer3 --launch ./Slicer3-3.6.3-2011-03-04-linux-x86_64/lib/Slicer3/Plugins/ImageLabelCombine /var/www/html/atlas/data/Scene0/IIG_Contour_IndexedLabelmap.nii.gz /var/www/html/atlas/data/Scene0/IbG_Contour_IndexedLabelmap.nii.gz /var/www/html/atlas/datagen/test.nii.gz
								COM2 = $COM1$DOS0$FIL1$DOS0$FIL2$DOS1$FIL3
								$COM2
							fi
						fi
					fi
				fi
			fi
		fi
	fi
fi
#	sh /var/www/html/atlas/Slicer3-3.6.3-2011-03-04-linux-x86_64/Slicer3 --launch /var/www/html/atlas/Slicer3-3.6.3-2011-03-04-linux-x86_64/lib/Slicer3/Plugins/ImageLabelCombine /var/www/html/atlas/data/output1.nii.gz /home/lardtiste/Programmes/Slicer3-3.6.3-2011-03-04-linux-x86_64/output2.nii.gz ./../../../Programmes/Slicer3-3.6.3-2011-03-04-linux-x86_64/0-output3.nii.gz
#	$COM1 $DOS1 





#./Slicer3-3.6.3-2011-03-04-linux-x86_64/Slicer3 --launch ./Slicer3-3.6.3-2011-03-04-linux-x86_64/lib/Slicer3/Plugins/ImageLabelCombine /var/www/html/atlas/data/Scene0/IIG_Contour_IndexedLabelmap.nii.gz /var/www/html/atlas/data/Scene0/IbG_Contour_IndexedLabelmap.nii.gz /var/www/html/atlas/datagen/test.nii.gz