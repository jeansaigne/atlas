<?php
//print_r($_GET["query"]);
// copy("oropharynx_amygdale_B_T1_N0_false_false_false_false_false.nii.gz", "input1.nii.gz");
 //if(echo file_get_contents("input1.nii.gz")){

  //system('./../../../Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/Slicer3 --launch ./../../../Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/lib/Slicer3/Plugins/ImageLabelCombine /home/lardtiste/Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/output1.nii.gz /home/lardtiste/Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/output2.nii.gz ./../../../Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/0-output3.nii.gz');
 system('/bin/sh script.sh');
 // sleep(10);

//  echo file_get_contents("./../../../Programmes/Slicer3-3.6.1-2010-08-23-linux-x86_64/0-output3.nii.gz");
 //};

?>