PAPAYA_VERSION_ID = "0.6.4";
PAPAYA_BUILD_NUM = "566";
"use strict";



var globalCoord;
var globalCoordTmp;
var mystruct;
var vol;
var canvasready = false;
var ROISelectedForTim=[];
var ROISelected=[
    {
        id: 0,
        nom: 'roi1',
        isSelected: false,
        tableau:[
            1, 2, 3, 4
        ]
    },
    {
        id: 1,
        nom: 'roi2',
        isSelected: false,
        tableau:[
            11, 12, 13, 14
        ]
    }
];


var papaya = papaya || {};
papaya.data = papaya.data || {};
papaya.data.Atlas = papaya.data.Atlas || {};


/*
papaya.data.Atlas.labels = {
    atlas: {
        data: {
            label: ["0:  1 : 2 : 3 :", "Aire ID: 12 : 13 : 14 ", "Aire Ib: 21 : 22 : 23 ", "moelle: 31 : 32 : 33 ", "Trachée: 41 : 42 : 43 ", "Aire ID: 51 : 52 : 53 ", "Aire Ib: 61 : 62 : 63 ", "moelle: : : ", "Trachée: : : ", "Aire ID: : : ", "Aire Ib: : : ", "moelle: : : ", "Trachée: : : ", "Aire ID: : : ", "Aire Ib: : : ", "moelle: : : ", "Trachée: : : "]
        },
        header: {
            //transform: "0.9357 0.0029 -0.0072 -1.0423 -0.0065",
            name: "CRONOR2",
            images: {
                imagefile: "/CRONOR",
                summaryimagefile: "/CRONOR"
            },
            display: "*.*.*. .*",
            //transformedname: "MNI (Nearest Grey Matter)",
            type: "Label"
        },
        version: 1
    }
};
*/
papaya.data.Atlas.labels = {
    atlas: {
        data: {
            label: [": : : :", ": : : :", " : : Bouche :Gray Matter:oesophagienne", " : :CTV glottique:Gray Matter:Droit", " : :CTV Glotique:Gray Matter:Gauche",
                " : : CTV paroi pharyngée:Gray Matter:LAT Gauche", " : :CTV paroi pharyngée:Gray Matter:LAT Droite ", " : :CTV paroi phariyngée:Gray Matter:Post Droit ",
                " : :CTV paroi phariyngée:Gray Matter:Post Gauche", " : :CTV retrocricoide:Gray Matter:", " : :CTV sinus piriforme:Gray Matter:Droite ",
                " : :CTV sinus piriforme:Gray Matter:Gauche ", " : :CTV sous glottique:Gray Matter:Droite ", " : :CTV sous glottique:Gray Matter:Gauche ",
                " : :CTV supraglottique sous hydoidien:Gray Matter:Droit", " : :CTV supraglottique sous hydoidien:Gray Matter:Gauche ",
                " : :CTV supraglottique sus hydoidien:Gray Matter:Droit", " : :CTV supraglottique sus hydoidien:Gray Matter:Gauche",
                " : :Aire II:Gray Matter:Droite", " : :Aire II:Gray Matter:Gauche ", " : :Aire III:Gray Matter:Droite ",
                " : :Aire III:Gray Matter:Gauche ", " : :Aire IVa:Gray Matter:Droite ", " : :Aire IVa:Gray Matter:Gauche ",
                " : :Aire IVb:Gray Matter:Droite ", " : :Aire IVb:Gray Matter:Gauche ", " : :Aire Ia:Gray Matter:",
                " : :Aire Ib:Gray Matter:Droite", " : :Aire Ib:Gray Matter:Gauche", " : :Thyroide:Gray Matter:Lobe Droit",
                " : :Thyroide:Gray Matter:Lobe Gauche ", " : :Aire VIa:Gray Matter:", " : :Aire VIb:Gray Matter:",
                " : :Aire VIIa:Gray Matter:Droite", " : :Aire VIIa:Gray Matter:Gauche ", " : :Aire VIIb:Gray Matter:Droite", " : :Aire VIIb:Gray Matter:Gauche",
                " : :Aire VIII:Gray Matter:Droite", " : :Aire VII:Gray Matter:Gauche ", " : :Aire Vab:Gray Matter:Droite", " : :Aire Vab:Gray Matter:Gauche",
                " : :Aire Vc:Gray Matter:Droite", " : :Aire Vc:Gray Matter:Gauche", " : :Amygdale:Gray Matter:Droite", " : :Amygdale:Gray Matter:Gauche",
                " : :Arc Dentaire + gencive:Gray Matter:Droit", " : :Arc Dentaire + gencive:Gray Matter:Gauche", " : :Base de Langue:Gray Matter:Droit",
                " : :Base de langue:Gray Matter:Gauche", " : :Cartilage thyroide:Gray Matter:", " : :Cavum:Gray Matter:Droit",
                " : :Cavum:Gray Matter:Gauche", " : :Corde Vocale+bv:Gray Matter:Gauche", " : :Corde vocale+bv:Gray Matter:Droit", " : :Epiglote:Gray Matter:",
                " : :Esp adipeux infratemp:Gray Matter:droit", " : :Esp adipeux infratemp:Gray Matter:Gauche ", " : :Esp adipeux buccal:Gray Matter:droit",
                " : :Esp adipeux buccal:Gray Matter:Gauche", " : :Esp carotidien:Gray Matter:Droit"," : :Esp carotidien:Gray Matter:Gauche",
                " : :Esp para pharyngé:Gray Matter:DGauche"," : :Esp para pharyngé:Gray Matter:Droit "," : :Foramen oval:Gray Matter:Droit",
                " : :Foramen oval:Gray Matter:Gauche"," : :Fosse pterygo palatine:Gray Matter:Droite"," : :Fosse pterygo palatine:Gray Matter:Gauche"," : :Gencive inf: Gray Matter:Droite",
                " : :Gencive inf:Gray Matter:Gauche"," : :Ganglion Gasser:Gray Matter:Droit"," : :Ganglion Gasser:Gray Matter:Gauche",
                " : :Joue:Gray Matter:Droite "," : :Joue:Gray Matter:Gauche"," : :Langue:Gray Matter:Droite"," : :Langue:Gray Matter:Gauche",
                " : :Loge HTE:Gray Matter:"," : :Luette:Gray Matter:"," : :Os hyoide:Gray Matter:",
                " : :Palais dur:Gray Matter:Gauche"," : :Palais dur:Gray Matter:Droit"," : :Paroi pharyngée post:Gray Matter:Droite"," : :Paroi pharyngée post:Gray Matter:Gauche",
                " : :Pilier ant:Gray Matter:Droit"," : :Pilier ant:Gray Matter:Gauche"," : :Pilier post:Gray Matter:Droit"," : :Pilier post:Gray Matter:Gauche",
                " : :Plancher:Gray Matter:Droit"," : :Plancher:Gray Matter:Gauche"," : :Repli ary epiglottique:Gray Matter:Gauche"," : :Repli ary epiglottique:Gray Matter:Droit",
                " : :SAG:Gray Matter:Droit"," : :SAG:Gray Matter:Gauche"," : :Sinus caverneux:Gray Matter:Droit"," : :Sinus caverneux:Gray Matter:Gauche",
                " : :Sinus piriforme:Gray Matter:Droit"," : :Sinus piriforme:Gray Matter:Gauche"," : :Sinus sphenoidal:Gray Matter:Gauche"," : :Sinus sphenoidal:Gray Matter:Droit",
                " : :Trigone retro molaire:Gray Matter:Droit"," : :Trigone retro molaire:Gray Matter:Gauche"," : :Trois replis:Gray Matter:Droit",
                " : :Trois replis:Gray Matter:Gauche"," : :Vallecule:Gray Matter:Droite"," : :Vallecule:Gray Matter:Gauche",
                " : :Voile:Gray Matter:Droit"," : :Voile:Gray Matter:Gauche",]
        },
        header: {
            //transform: "0.9357 0.0029 -0.0072 -1.0423 -0.0065 0.9396 -0.0726 -1.3940 0.0103 0.0752 0.8967 3.6475 0.0000 0.0000 0.0000 1.0000",
            name: "CRONOR ORL",
            images: {
                summaryimagefile: "CRONOR"
            },
            display: "*.*.*. .*",
            //transformedname: "MNI (Nearest Grey Matter)",
            type: "Label"
        },
        version: 1
    }
};


var papayaLoadableImages = [{
    name: "ATLAS4",
    nicename: "ATLAS4",
    url: "ATLAS4.nii"
},
{
  //  hide: true,
    name: "CRONOR",
    nicename: "Atlas",
    url: "CRONOR.nii"
}];
/*!
 * jQuery JavaScript Library v1.9.1
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2012 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2013-2-4
 */
(function (a5, aJ) {
    var ak, x, aF = typeof aJ,
        l = a5.document,
        aO = a5.location,
        bl = a5.jQuery,
        I = a5.$,
        ac = {},
        a9 = [],
        s = "1.9.1",
        aL = a9.concat,
        aq = a9.push,
        a7 = a9.slice,
        aP = a9.indexOf,
        A = ac.toString,
        X = ac.hasOwnProperty,
        aT = s.trim,
        bM = function (e, b6) {
            return new bM.fn.init(e, b6, x)
        },
        bD = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        ae = /\S+/g,
        D = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        bu = /^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,
        a = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        bk = /^[\],:{}\s]*$/,
        bn = /(?:^|:|,)(?:\s*\[)+/g,
        bJ = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
        a2 = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,
        bV = /^-ms-/,
        aY = /-([\da-z])/gi,
        N = function (e, b6) {
            return b6.toUpperCase()
        },
        bZ = function (e) {
            if (l.addEventListener || e.type === "load" || l.readyState === "complete") {
                bo();
                bM.ready()
            }
        },
        bo = function () {
            if (l.addEventListener) {
                l.removeEventListener("DOMContentLoaded", bZ, false);
                a5.removeEventListener("load", bZ, false)
            } else {
                l.detachEvent("onreadystatechange", bZ);
                a5.detachEvent("onload", bZ)
            }
        };
    bM.fn = bM.prototype = {
        jquery: s,
        constructor: bM,
        init: function (e, b8, b7) {
            var b6, b9;
            if (!e) {
                return this
            }
            if (typeof e === "string") {
                if (e.charAt(0) === "<" && e.charAt(e.length - 1) === ">" && e.length >= 3) {
                    b6 = [null, e, null]
                } else {
                    b6 = bu.exec(e)
                }
                if (b6 && (b6[1] || !b8)) {
                    if (b6[1]) {
                        b8 = b8 instanceof bM ? b8[0] : b8;
                        bM.merge(this, bM.parseHTML(b6[1], b8 && b8.nodeType ? b8.ownerDocument || b8 : l, true));
                        if (a.test(b6[1]) && bM.isPlainObject(b8)) {
                            for (b6 in b8) {
                                if (bM.isFunction(this[b6])) {
                                    this[b6](b8[b6])
                                } else {
                                    this.attr(b6, b8[b6])
                                }
                            }
                        }
                        return this
                    } else {
                        b9 = l.getElementById(b6[2]);
                        if (b9 && b9.parentNode) {
                            if (b9.id !== b6[2]) {
                                return b7.find(e)
                            }
                            this.length = 1;
                            this[0] = b9
                        }
                        this.context = l;
                        this.selector = e;
                        return this
                    }
                } else {
                    if (!b8 || b8.jquery) {
                        return (b8 || b7).find(e)
                    } else {
                        return this.constructor(b8).find(e)
                    }
                }
            } else {
                if (e.nodeType) {
                    this.context = this[0] = e;
                    this.length = 1;
                    return this
                } else {
                    if (bM.isFunction(e)) {
                        return b7.ready(e)
                    }
                }
            }
            if (e.selector !== aJ) {
                this.selector = e.selector;
                this.context = e.context
            }
            return bM.makeArray(e, this)
        },
        selector: "",
        length: 0,
        size: function () {
            return this.length
        },
        toArray: function () {
            return a7.call(this)
        },
        get: function (e) {
            return e == null ? this.toArray() : (e < 0 ? this[this.length + e] : this[e])
        },
        pushStack: function (e) {
            var b6 = bM.merge(this.constructor(), e);
            b6.prevObject = this;
            b6.context = this.context;
            return b6
        },
        each: function (b6, e) {
            return bM.each(this, b6, e)
        },
        ready: function (e) {
            bM.ready.promise().done(e);
            return this
        },
        slice: function () {
            return this.pushStack(a7.apply(this, arguments))
        },
        first: function () {
            return this.eq(0)
        },
        last: function () {
            return this.eq(-1)
        },
        eq: function (b7) {
            var e = this.length,
                b6 = +b7 + (b7 < 0 ? e : 0);
            return this.pushStack(b6 >= 0 && b6 < e ? [this[b6]] : [])
        },
        map: function (e) {
            return this.pushStack(bM.map(this, function (b7, b6) {
                return e.call(b7, b6, b7)
            }))
        },
        end: function () {
            return this.prevObject || this.constructor(null)
        },
        push: aq,
        sort: [].sort,
        splice: [].splice
    };
    bM.fn.init.prototype = bM.fn;
    bM.extend = bM.fn.extend = function () {
        var e, cb, b6, b7, ce, cc, ca = arguments[0] || {},
            b9 = 1,
            b8 = arguments.length,
            cd = false;
        if (typeof ca === "boolean") {
            cd = ca;
            ca = arguments[1] || {};
            b9 = 2
        }
        if (typeof ca !== "object" && !bM.isFunction(ca)) {
            ca = {}
        }
        if (b8 === b9) {
            ca = this;
            --b9
        }
        for (; b9 < b8; b9++) {
            if ((ce = arguments[b9]) != null) {
                for (b7 in ce) {
                    e = ca[b7];
                    b6 = ce[b7];
                    if (ca === b6) {
                        continue
                    }
                    if (cd && b6 && (bM.isPlainObject(b6) || (cb = bM.isArray(b6)))) {
                        if (cb) {
                            cb = false;
                            cc = e && bM.isArray(e) ? e : []
                        } else {
                            cc = e && bM.isPlainObject(e) ? e : {}
                        }
                        ca[b7] = bM.extend(cd, cc, b6)
                    } else {
                        if (b6 !== aJ) {
                            ca[b7] = b6
                        }
                    }
                }
            }
        }
        return ca
    };
    bM.extend({
        noConflict: function (e) {
            if (a5.$ === bM) {
                a5.$ = I
            }
            if (e && a5.jQuery === bM) {
                a5.jQuery = bl
            }
            return bM
        },
        isReady: false,
        readyWait: 1,
        holdReady: function (e) {
            if (e) {
                bM.readyWait++
            } else {
                bM.ready(true)
            }
        },
        ready: function (e) {
            if (e === true ? --bM.readyWait : bM.isReady) {
                return
            }
            if (!l.body) {
                return setTimeout(bM.ready)
            }
            bM.isReady = true;
            if (e !== true && --bM.readyWait > 0) {
                return
            }
            ak.resolveWith(l, [bM]);
            if (bM.fn.trigger) {
                bM(l).trigger("ready").off("ready")
            }
        },
        isFunction: function (e) {
            return bM.type(e) === "function"
        },
        isArray: Array.isArray ||
        function (e) {
            return bM.type(e) === "array"
        },
        isWindow: function (e) {
            return e != null && e == e.window
        },
        isNumeric: function (e) {
            return !isNaN(parseFloat(e)) && isFinite(e)
        },
        type: function (e) {
            if (e == null) {
                return String(e)
            }
            return typeof e === "object" || typeof e === "function" ? ac[A.call(e)] || "object" : typeof e
        },
        isPlainObject: function (b8) {
            if (!b8 || bM.type(b8) !== "object" || b8.nodeType || bM.isWindow(b8)) {
                return false
            }
            try {
                if (b8.constructor && !X.call(b8, "constructor") && !X.call(b8.constructor.prototype, "isPrototypeOf")) {
                    return false
                }
            } catch (b7) {
                return false
            }
            var b6;
            for (b6 in b8) {}
            return b6 === aJ || X.call(b8, b6)
        },
        isEmptyObject: function (b6) {
            var e;
            for (e in b6) {
                return false
            }
            return true
        },
        error: function (e) {
            throw new Error(e)
        },
        parseHTML: function (b9, b7, b8) {
            if (!b9 || typeof b9 !== "string") {
                return null
            }
            if (typeof b7 === "boolean") {
                b8 = b7;
                b7 = false
            }
            b7 = b7 || l;
            var b6 = a.exec(b9),
                e = !b8 && [];
            if (b6) {
                return [b7.createElement(b6[1])]
            }
            b6 = bM.buildFragment([b9], b7, e);
            if (e) {
                bM(e).remove()
            }
            return bM.merge([], b6.childNodes)
        },
        parseJSON: function (e) {
            if (a5.JSON && a5.JSON.parse) {
                return a5.JSON.parse(e)
            }
            if (e === null) {
                return e
            }
            if (typeof e === "string") {
                e = bM.trim(e);
                if (e) {
                    if (bk.test(e.replace(bJ, "@").replace(a2, "]").replace(bn, ""))) {
                        return (new Function("return " + e))()
                    }
                }
            }
            bM.error("Invalid JSON: " + e)
        },
        parseXML: function (b8) {
            var b6, b7;
            if (!b8 || typeof b8 !== "string") {
                return null
            }
            try {
                if (a5.DOMParser) {
                    b7 = new DOMParser();
                    b6 = b7.parseFromString(b8, "text/xml")
                } else {
                    b6 = new ActiveXObject("Microsoft.XMLDOM");
                    b6.async = "false";
                    b6.loadXML(b8)
                }
            } catch (b9) {
                b6 = aJ
            }
            if (!b6 || !b6.documentElement || b6.getElementsByTagName("parsererror").length) {
                bM.error("Invalid XML: " + b8)
            }
            return b6
        },
        noop: function () {},
        globalEval: function (e) {
            if (e && bM.trim(e)) {
                (a5.execScript ||
                function (b6) {
                    a5["eval"].call(a5, b6)
                })(e)
            }
        },
        camelCase: function (e) {
            return e.replace(bV, "ms-").replace(aY, N)
        },
        nodeName: function (b6, e) {
            return b6.nodeName && b6.nodeName.toLowerCase() === e.toLowerCase()
        },
        each: function (ca, cb, b6) {
            var b9, b7 = 0,
                b8 = ca.length,
                e = ad(ca);
            if (b6) {
                if (e) {
                    for (; b7 < b8; b7++) {
                        b9 = cb.apply(ca[b7], b6);
                        if (b9 === false) {
                            break
                        }
                    }
                } else {
                    for (b7 in ca) {
                        b9 = cb.apply(ca[b7], b6);
                        if (b9 === false) {
                            break
                        }
                    }
                }
            } else {
                if (e) {
                    for (; b7 < b8; b7++) {
                        b9 = cb.call(ca[b7], b7, ca[b7]);
                        if (b9 === false) {
                            break
                        }
                    }
                } else {
                    for (b7 in ca) {
                        b9 = cb.call(ca[b7], b7, ca[b7]);
                        if (b9 === false) {
                            break
                        }
                    }
                }
            }
            return ca
        },
        trim: aT && !aT.call("\uFEFF\xA0") ?
        function (e) {
            return e == null ? "" : aT.call(e)
        } : function (e) {
            return e == null ? "" : (e + "").replace(D, "")
        },
        makeArray: function (e, b7) {
            var b6 = b7 || [];
            if (e != null) {
                if (ad(Object(e))) {
                    bM.merge(b6, typeof e === "string" ? [e] : e)
                } else {
                    aq.call(b6, e)
                }
            }
            return b6
        },
        inArray: function (b8, b6, b7) {
            var e;
            if (b6) {
                if (aP) {
                    return aP.call(b6, b8, b7)
                }
                e = b6.length;
                b7 = b7 ? b7 < 0 ? Math.max(0, e + b7) : b7 : 0;
                for (; b7 < e; b7++) {
                    if (b7 in b6 && b6[b7] === b8) {
                        return b7
                    }
                }
            }
            return -1
        },
        merge: function (b9, b7) {
            var e = b7.length,
                b8 = b9.length,
                b6 = 0;
            if (typeof e === "number") {
                for (; b6 < e; b6++) {
                    b9[b8++] = b7[b6]
                }
            } else {
                while (b7[b6] !== aJ) {
                    b9[b8++] = b7[b6++]
                }
            }
            b9.length = b8;
            return b9
        },
        grep: function (b6, cb, e) {
            var ca, b7 = [],
                b8 = 0,
                b9 = b6.length;
            e = !! e;
            for (; b8 < b9; b8++) {
                ca = !! cb(b6[b8], b8);
                if (e !== ca) {
                    b7.push(b6[b8])
                }
            }
            return b7
        },
        map: function (b7, cc, e) {
            var cb, b9 = 0,
                ca = b7.length,
                b6 = ad(b7),
                b8 = [];
            if (b6) {
                for (; b9 < ca; b9++) {
                    cb = cc(b7[b9], b9, e);
                    if (cb != null) {
                        b8[b8.length] = cb
                    }
                }
            } else {
                for (b9 in b7) {
                    cb = cc(b7[b9], b9, e);
                    if (cb != null) {
                        b8[b8.length] = cb
                    }
                }
            }
            return aL.apply([], b8)
        },
        guid: 1,
        proxy: function (b9, b8) {
            var e, b7, b6;
            if (typeof b8 === "string") {
                b6 = b9[b8];
                b8 = b9;
                b9 = b6
            }
            if (!bM.isFunction(b9)) {
                return aJ
            }
            e = a7.call(arguments, 2);
            b7 = function () {
                return b9.apply(b8 || this, e.concat(a7.call(arguments)))
            };
            b7.guid = b9.guid = b9.guid || bM.guid++;
            return b7
        },
        access: function (e, ca, cc, cb, b8, ce, cd) {
            var b7 = 0,
                b6 = e.length,
                b9 = cc == null;
            if (bM.type(cc) === "object") {
                b8 = true;
                for (b7 in cc) {
                    bM.access(e, ca, b7, cc[b7], true, ce, cd)
                }
            } else {
                if (cb !== aJ) {
                    b8 = true;
                    if (!bM.isFunction(cb)) {
                        cd = true
                    }
                    if (b9) {
                        if (cd) {
                            ca.call(e, cb);
                            ca = null
                        } else {
                            b9 = ca;
                            ca = function (cg, cf, ch) {
                                return b9.call(bM(cg), ch)
                            }
                        }
                    }
                    if (ca) {
                        for (; b7 < b6; b7++) {
                            ca(e[b7], cc, cd ? cb : cb.call(e[b7], b7, ca(e[b7], cc)))
                        }
                    }
                }
            }
            return b8 ? e : b9 ? ca.call(e) : b6 ? ca(e[0], cc) : ce
        },
        now: function () {
            return (new Date()).getTime()
        }
    });
    bM.ready.promise = function (b9) {
        if (!ak) {
            ak = bM.Deferred();
            if (l.readyState === "complete") {
                setTimeout(bM.ready)
            } else {
                if (l.addEventListener) {
                    l.addEventListener("DOMContentLoaded", bZ, false);
                    a5.addEventListener("load", bZ, false)
                } else {
                    l.attachEvent("onreadystatechange", bZ);
                    a5.attachEvent("onload", bZ);
                    var b8 = false;
                    try {
                        b8 = a5.frameElement == null && l.documentElement
                    } catch (b7) {}
                    if (b8 && b8.doScroll) {
                        (function b6() {
                            if (!bM.isReady) {
                                try {
                                    b8.doScroll("left")
                                } catch (ca) {
                                    return setTimeout(b6, 50)
                                }
                                bo();
                                bM.ready()
                            }
                        })()
                    }
                }
            }
        }
        return ak.promise(b9)
    };
    bM.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function (b6, e) {
        ac["[object " + e + "]"] = e.toLowerCase()
    });

    function ad(b7) {
        var b6 = b7.length,
            e = bM.type(b7);
        if (bM.isWindow(b7)) {
            return false
        }
        if (b7.nodeType === 1 && b6) {
            return true
        }
        return e === "array" || e !== "function" && (b6 === 0 || typeof b6 === "number" && b6 > 0 && (b6 - 1) in b7)
    }
    x = bM(l);
    var b1 = {};

    function ag(b6) {
        var e = b1[b6] = {};
        bM.each(b6.match(ae) || [], function (b8, b7) {
            e[b7] = true
        });
        return e
    }
    bM.Callbacks = function (cf) {
        cf = typeof cf === "string" ? (b1[cf] || ag(cf)) : bM.extend({}, cf);
        var b9, b8, e, ca, cb, b7, cc = [],
            cd = !cf.once && [],
            b6 = function (cg) {
                b8 = cf.memory && cg;
                e = true;
                cb = b7 || 0;
                b7 = 0;
                ca = cc.length;
                b9 = true;
                for (; cc && cb < ca; cb++) {
                    if (cc[cb].apply(cg[0], cg[1]) === false && cf.stopOnFalse) {
                        b8 = false;
                        break
                    }
                }
                b9 = false;
                if (cc) {
                    if (cd) {
                        if (cd.length) {
                            b6(cd.shift())
                        }
                    } else {
                        if (b8) {
                            cc = []
                        } else {
                            ce.disable()
                        }
                    }
                }
            },
            ce = {
                add: function () {
                    if (cc) {
                        var ch = cc.length;
                        (function cg(ci) {
                            bM.each(ci, function (ck, cj) {
                                var cl = bM.type(cj);
                                if (cl === "function") {
                                    if (!cf.unique || !ce.has(cj)) {
                                        cc.push(cj)
                                    }
                                } else {
                                    if (cj && cj.length && cl !== "string") {
                                        cg(cj)
                                    }
                                }
                            })
                        })(arguments);
                        if (b9) {
                            ca = cc.length
                        } else {
                            if (b8) {
                                b7 = ch;
                                b6(b8)
                            }
                        }
                    }
                    return this
                },
                remove: function () {
                    if (cc) {
                        bM.each(arguments, function (ci, cg) {
                            var ch;
                            while ((ch = bM.inArray(cg, cc, ch)) > -1) {
                                cc.splice(ch, 1);
                                if (b9) {
                                    if (ch <= ca) {
                                        ca--
                                    }
                                    if (ch <= cb) {
                                        cb--
                                    }
                                }
                            }
                        })
                    }
                    return this
                },
                has: function (cg) {
                    return cg ? bM.inArray(cg, cc) > -1 : !! (cc && cc.length)
                },
                empty: function () {
                    cc = [];
                    return this
                },
                disable: function () {
                    cc = cd = b8 = aJ;
                    return this
                },
                disabled: function () {
                    return !cc
                },
                lock: function () {
                    cd = aJ;
                    if (!b8) {
                        ce.disable()
                    }
                    return this
                },
                locked: function () {
                    return !cd
                },
                fireWith: function (ch, cg) {
                    cg = cg || [];
                    cg = [ch, cg.slice ? cg.slice() : cg];
                    if (cc && (!e || cd)) {
                        if (b9) {
                            cd.push(cg)
                        } else {
                            b6(cg)
                        }
                    }
                    return this
                },
                fire: function () {
                    ce.fireWith(this, arguments);
                    return this
                },
                fired: function () {
                    return !!e
                }
            };
        return ce
    };
    bM.extend({
        Deferred: function (b7) {
            var b6 = [
                ["resolve", "done", bM.Callbacks("once memory"), "resolved"],
                ["reject", "fail", bM.Callbacks("once memory"), "rejected"],
                ["notify", "progress", bM.Callbacks("memory")]
            ],
                b8 = "pending",
                b9 = {
                    state: function () {
                        return b8
                    },
                    always: function () {
                        e.done(arguments).fail(arguments);
                        return this
                    },
                    then: function () {
                        var ca = arguments;
                        return bM.Deferred(function (cb) {
                            bM.each(b6, function (cd, cc) {
                                var cf = cc[0],
                                    ce = bM.isFunction(ca[cd]) && ca[cd];
                                e[cc[1]](function () {
                                    var cg = ce && ce.apply(this, arguments);
                                    if (cg && bM.isFunction(cg.promise)) {
                                        cg.promise().done(cb.resolve).fail(cb.reject).progress(cb.notify)
                                    } else {
                                        cb[cf + "With"](this === b9 ? cb.promise() : this, ce ? [cg] : arguments)
                                    }
                                })
                            });
                            ca = null
                        }).promise()
                    },
                    promise: function (ca) {
                        return ca != null ? bM.extend(ca, b9) : b9
                    }
                },
                e = {};
            b9.pipe = b9.then;
            bM.each(b6, function (cb, ca) {
                var cd = ca[2],
                    cc = ca[3];
                b9[ca[1]] = cd.add;
                if (cc) {
                    cd.add(function () {
                        b8 = cc
                    }, b6[cb ^ 1][2].disable, b6[2][2].lock)
                }
                e[ca[0]] = function () {
                    e[ca[0] + "With"](this === e ? b9 : this, arguments);
                    return this
                };
                e[ca[0] + "With"] = cd.fireWith
            });
            b9.promise(e);
            if (b7) {
                b7.call(e, e)
            }
            return e
        },
        when: function (b9) {
            var b7 = 0,
                cb = a7.call(arguments),
                e = cb.length,
                b6 = e !== 1 || (b9 && bM.isFunction(b9.promise)) ? e : 0,
                ce = b6 === 1 ? b9 : bM.Deferred(),
                b8 = function (cg, ch, cf) {
                    return function (ci) {
                        ch[cg] = this;
                        cf[cg] = arguments.length > 1 ? a7.call(arguments) : ci;
                        if (cf === cd) {
                            ce.notifyWith(ch, cf)
                        } else {
                            if (!(--b6)) {
                                ce.resolveWith(ch, cf)
                            }
                        }
                    }
                },
                cd, ca, cc;
            if (e > 1) {
                cd = new Array(e);
                ca = new Array(e);
                cc = new Array(e);
                for (; b7 < e; b7++) {
                    if (cb[b7] && bM.isFunction(cb[b7].promise)) {
                        cb[b7].promise().done(b8(b7, cc, cb)).fail(ce.reject).progress(b8(b7, ca, cd))
                    } else {
                        --b6
                    }
                }
            }
            if (!b6) {
                ce.resolveWith(cc, cb)
            }
            return ce.promise()
        }
    });
    bM.support = (function () {
        var ch, cg, ce, cd, cf, cc, b8, ca, b7, b9, b6 = l.createElement("div");
        b6.setAttribute("className", "t");
        b6.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>";
        cg = b6.getElementsByTagName("*");
        ce = b6.getElementsByTagName("a")[0];
        if (!cg || !ce || !cg.length) {
            return {}
        }
        cf = l.createElement("select");
        b8 = cf.appendChild(l.createElement("option"));
        cd = b6.getElementsByTagName("input")[0];
        ce.style.cssText = "top:1px;float:left;opacity:.5";
        ch = {
            getSetAttribute: b6.className !== "t",
            leadingWhitespace: b6.firstChild.nodeType === 3,
            tbody: !b6.getElementsByTagName("tbody").length,
            htmlSerialize: !! b6.getElementsByTagName("link").length,
            style: /top/.test(ce.getAttribute("style")),
            hrefNormalized: ce.getAttribute("href") === "/a",
            opacity: /^0.5/.test(ce.style.opacity),
            cssFloat: !! ce.style.cssFloat,
            checkOn: !! cd.value,
            optSelected: b8.selected,
            enctype: !! l.createElement("form").enctype,
            html5Clone: l.createElement("nav").cloneNode(true).outerHTML !== "<:nav></:nav>",
            boxModel: l.compatMode === "CSS1Compat",
            deleteExpando: true,
            noCloneEvent: true,
            inlineBlockNeedsLayout: false,
            shrinkWrapBlocks: false,
            reliableMarginRight: true,
            boxSizingReliable: true,
            pixelPosition: false
        };
        cd.checked = true;
        ch.noCloneChecked = cd.cloneNode(true).checked;
        cf.disabled = true;
        ch.optDisabled = !b8.disabled;
        try {
            delete b6.test
        } catch (cb) {
            ch.deleteExpando = false
        }
        cd = l.createElement("input");
        cd.setAttribute("value", "");
        ch.input = cd.getAttribute("value") === "";
        cd.value = "t";
        cd.setAttribute("type", "radio");
        ch.radioValue = cd.value === "t";
        cd.setAttribute("checked", "t");
        cd.setAttribute("name", "t");
        cc = l.createDocumentFragment();
        cc.appendChild(cd);
        ch.appendChecked = cd.checked;
        ch.checkClone = cc.cloneNode(true).cloneNode(true).lastChild.checked;
        if (b6.attachEvent) {
            b6.attachEvent("onclick", function () {
                ch.noCloneEvent = false
            });
            b6.cloneNode(true).click()
        }
        for (b9 in {
            submit: true,
            change: true,
            focusin: true
        }) {
            b6.setAttribute(ca = "on" + b9, "t");
            ch[b9 + "Bubbles"] = ca in a5 || b6.attributes[ca].expando === false
        }
        b6.style.backgroundClip = "content-box";
        b6.cloneNode(true).style.backgroundClip = "";
        ch.clearCloneStyle = b6.style.backgroundClip === "content-box";
        bM(function () {
            var ci, cl, ck, cj = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",
                e = l.getElementsByTagName("body")[0];
            if (!e) {
                return
            }
            ci = l.createElement("div");
            ci.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px";
            e.appendChild(ci).appendChild(b6);
            b6.innerHTML = "<table><tr><td></td><td>t</td></tr></table>";
            ck = b6.getElementsByTagName("td");
            ck[0].style.cssText = "padding:0;margin:0;border:0;display:none";
            b7 = (ck[0].offsetHeight === 0);
            ck[0].style.display = "";
            ck[1].style.display = "none";
            ch.reliableHiddenOffsets = b7 && (ck[0].offsetHeight === 0);
            b6.innerHTML = "";
            b6.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;";
            ch.boxSizing = (b6.offsetWidth === 4);
            ch.doesNotIncludeMarginInBodyOffset = (e.offsetTop !== 1);
            if (a5.getComputedStyle) {
                ch.pixelPosition = (a5.getComputedStyle(b6, null) || {}).top !== "1%";
                ch.boxSizingReliable = (a5.getComputedStyle(b6, null) || {
                    width: "4px"
                }).width === "4px";
                cl = b6.appendChild(l.createElement("div"));
                cl.style.cssText = b6.style.cssText = cj;
                cl.style.marginRight = cl.style.width = "0";
                b6.style.width = "1px";
                ch.reliableMarginRight = !parseFloat((a5.getComputedStyle(cl, null) || {}).marginRight)
            }
            if (typeof b6.style.zoom !== aF) {
                b6.innerHTML = "";
                b6.style.cssText = cj + "width:1px;padding:1px;display:inline;zoom:1";
                ch.inlineBlockNeedsLayout = (b6.offsetWidth === 3);
                b6.style.display = "block";
                b6.innerHTML = "<div></div>";
                b6.firstChild.style.width = "5px";
                ch.shrinkWrapBlocks = (b6.offsetWidth !== 3);
                if (ch.inlineBlockNeedsLayout) {
                    e.style.zoom = 1
                }
            }
            e.removeChild(ci);
            ci = b6 = ck = cl = null
        });
        cg = cf = cc = b8 = ce = cd = null;
        return ch
    })();
    var bz = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
        aQ = /([A-Z])/g;

    function bd(b8, b6, ca, b9) {
        if (!bM.acceptData(b8)) {
            return
        }
        var cb, cd, ce = bM.expando,
            cc = typeof b6 === "string",
            cf = b8.nodeType,
            e = cf ? bM.cache : b8,
            b7 = cf ? b8[ce] : b8[ce] && ce;
        if ((!b7 || !e[b7] || (!b9 && !e[b7].data)) && cc && ca === aJ) {
            return
        }
        if (!b7) {
            if (cf) {
                b8[ce] = b7 = a9.pop() || bM.guid++
            } else {
                b7 = ce
            }
        }
        if (!e[b7]) {
            e[b7] = {};
            if (!cf) {
                e[b7].toJSON = bM.noop
            }
        }
        if (typeof b6 === "object" || typeof b6 === "function") {
            if (b9) {
                e[b7] = bM.extend(e[b7], b6)
            } else {
                e[b7].data = bM.extend(e[b7].data, b6)
            }
        }
        cb = e[b7];
        if (!b9) {
            if (!cb.data) {
                cb.data = {}
            }
            cb = cb.data
        }
        if (ca !== aJ) {
            cb[bM.camelCase(b6)] = ca
        }
        if (cc) {
            cd = cb[b6];
            if (cd == null) {
                cd = cb[bM.camelCase(b6)]
            }
        } else {
            cd = cb
        }
        return cd
    }
    function ab(b8, b6, b9) {
        if (!bM.acceptData(b8)) {
            return
        }
        var cb, ca, cc, cd = b8.nodeType,
            e = cd ? bM.cache : b8,
            b7 = cd ? b8[bM.expando] : bM.expando;
        if (!e[b7]) {
            return
        }
        if (b6) {
            cc = b9 ? e[b7] : e[b7].data;
            if (cc) {
                if (!bM.isArray(b6)) {
                    if (b6 in cc) {
                        b6 = [b6]
                    } else {
                        b6 = bM.camelCase(b6);
                        if (b6 in cc) {
                            b6 = [b6]
                        } else {
                            b6 = b6.split(" ")
                        }
                    }
                } else {
                    b6 = b6.concat(bM.map(b6, bM.camelCase))
                }
                for (cb = 0, ca = b6.length; cb < ca; cb++) {
                    delete cc[b6[cb]]
                }
                if (!(b9 ? O : bM.isEmptyObject)(cc)) {
                    return
                }
            }
        }
        if (!b9) {
            delete e[b7].data;
            if (!O(e[b7])) {
                return
            }
        }
        if (cd) {
            bM.cleanData([b8], true)
        } else {
            if (bM.support.deleteExpando || e != e.window) {
                delete e[b7]
            } else {
                e[b7] = null
            }
        }
    }
    bM.extend({
        cache: {},
        expando: "jQuery" + (s + Math.random()).replace(/\D/g, ""),
        noData: {
            embed: true,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: true
        },
        hasData: function (e) {
            e = e.nodeType ? bM.cache[e[bM.expando]] : e[bM.expando];
            return !!e && !O(e)
        },
        data: function (b6, e, b7) {
            return bd(b6, e, b7)
        },
        removeData: function (b6, e) {
            return ab(b6, e)
        },
        _data: function (b6, e, b7) {
            return bd(b6, e, b7, true)
        },
        _removeData: function (b6, e) {
            return ab(b6, e, true)
        },
        acceptData: function (b6) {
            if (b6.nodeType && b6.nodeType !== 1 && b6.nodeType !== 9) {
                return false
            }
            var e = b6.nodeName && bM.noData[b6.nodeName.toLowerCase()];
            return !e || e !== true && b6.getAttribute("classid") === e
        }
    });
    bM.fn.extend({
        data: function (b8, cb) {
            var b6, e, b9 = this[0],
                b7 = 0,
                ca = null;
            if (b8 === aJ) {
                if (this.length) {
                    ca = bM.data(b9);
                    if (b9.nodeType === 1 && !bM._data(b9, "parsedAttrs")) {
                        b6 = b9.attributes;
                        for (; b7 < b6.length; b7++) {
                            e = b6[b7].name;
                            if (!e.indexOf("data-")) {
                                e = bM.camelCase(e.slice(5));
                                bB(b9, e, ca[e])
                            }
                        }
                        bM._data(b9, "parsedAttrs", true)
                    }
                }
                return ca
            }
            if (typeof b8 === "object") {
                return this.each(function () {
                    bM.data(this, b8)
                })
            }
            return bM.access(this, function (cc) {
                if (cc === aJ) {
                    return b9 ? bB(b9, b8, bM.data(b9, b8)) : null
                }
                this.each(function () {
                    bM.data(this, b8, cc)
                })
            }, null, cb, arguments.length > 1, null, true)
        },
        removeData: function (e) {
            return this.each(function () {
                bM.removeData(this, e)
            })
        }
    });

    function bB(b8, b7, b9) {
        if (b9 === aJ && b8.nodeType === 1) {
            var b6 = "data-" + b7.replace(aQ, "-$1").toLowerCase();
            b9 = b8.getAttribute(b6);
            if (typeof b9 === "string") {
                try {
                    b9 = b9 === "true" ? true : b9 === "false" ? false : b9 === "null" ? null : +b9 + "" === b9 ? +b9 : bz.test(b9) ? bM.parseJSON(b9) : b9
                } catch (ca) {}
                bM.data(b8, b7, b9)
            } else {
                b9 = aJ
            }
        }
        return b9
    }
    function O(b6) {
        var e;
        for (e in b6) {
            if (e === "data" && bM.isEmptyObject(b6[e])) {
                continue
            }
            if (e !== "toJSON") {
                return false
            }
        }
        return true
    }
    bM.extend({
        queue: function (b7, b6, b8) {
            var e;
            if (b7) {
                b6 = (b6 || "fx") + "queue";
                e = bM._data(b7, b6);
                if (b8) {
                    if (!e || bM.isArray(b8)) {
                        e = bM._data(b7, b6, bM.makeArray(b8))
                    } else {
                        e.push(b8)
                    }
                }
                return e || []
            }
        },
        dequeue: function (ca, b9) {
            b9 = b9 || "fx";
            var b6 = bM.queue(ca, b9),
                cb = b6.length,
                b8 = b6.shift(),
                e = bM._queueHooks(ca, b9),
                b7 = function () {
                    bM.dequeue(ca, b9)
                };
            if (b8 === "inprogress") {
                b8 = b6.shift();
                cb--
            }
            e.cur = b8;
            if (b8) {
                if (b9 === "fx") {
                    b6.unshift("inprogress")
                }
                delete e.stop;
                b8.call(ca, b7, e)
            }
            if (!cb && e) {
                e.empty.fire()
            }
        },
        _queueHooks: function (b7, b6) {
            var e = b6 + "queueHooks";
            return bM._data(b7, e) || bM._data(b7, e, {
                empty: bM.Callbacks("once memory").add(function () {
                    bM._removeData(b7, b6 + "queue");
                    bM._removeData(b7, e)
                })
            })
        }
    });
    bM.fn.extend({
        queue: function (e, b6) {
            var b7 = 2;
            if (typeof e !== "string") {
                b6 = e;
                e = "fx";
                b7--
            }
            if (arguments.length < b7) {
                return bM.queue(this[0], e)
            }
            return b6 === aJ ? this : this.each(function () {
                var b8 = bM.queue(this, e, b6);
                bM._queueHooks(this, e);
                if (e === "fx" && b8[0] !== "inprogress") {
                    bM.dequeue(this, e)
                }
            })
        },
        dequeue: function (e) {
            return this.each(function () {
                bM.dequeue(this, e)
            })
        },
        delay: function (b6, e) {
            b6 = bM.fx ? bM.fx.speeds[b6] || b6 : b6;
            e = e || "fx";
            return this.queue(e, function (b8, b7) {
                var b9 = setTimeout(b8, b6);
                b7.stop = function () {
                    clearTimeout(b9)
                }
            })
        },
        clearQueue: function (e) {
            return this.queue(e || "fx", [])
        },
        promise: function (b7, cb) {
            var b6, b8 = 1,
                cc = bM.Deferred(),
                ca = this,
                e = this.length,
                b9 = function () {
                    if (!(--b8)) {
                        cc.resolveWith(ca, [ca])
                    }
                };
            if (typeof b7 !== "string") {
                cb = b7;
                b7 = aJ
            }
            b7 = b7 || "fx";
            while (e--) {
                b6 = bM._data(ca[e], b7 + "queueHooks");
                if (b6 && b6.empty) {
                    b8++;
                    b6.empty.add(b9)
                }
            }
            b9();
            return cc.promise(cb)
        }
    });
    var bb, b2, bP = /[\t\r\n]/g,
        am = /\r/g,
        aI = /^(?:input|select|textarea|button|object)$/i,
        E = /^(?:a|area)$/i,
        M = /^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,
        au = /^(?:checked|selected)$/i,
        bS = bM.support.getSetAttribute,
        bI = bM.support.input;
    bM.fn.extend({
        attr: function (e, b6) {
            return bM.access(this, bM.attr, e, b6, arguments.length > 1)
        },
        removeAttr: function (e) {
            return this.each(function () {
                bM.removeAttr(this, e)
            })
        },
        prop: function (e, b6) {
            return bM.access(this, bM.prop, e, b6, arguments.length > 1)
        },
        removeProp: function (e) {
            e = bM.propFix[e] || e;
            return this.each(function () {
                try {
                    this[e] = aJ;
                    delete this[e]
                } catch (b6) {}
            })
        },
        addClass: function (cc) {
            var b6, e, cd, b9, b7, b8 = 0,
                ca = this.length,
                cb = typeof cc === "string" && cc;
            if (bM.isFunction(cc)) {
                return this.each(function (ce) {
                    bM(this).addClass(cc.call(this, ce, this.className))
                })
            }
            if (cb) {
                b6 = (cc || "").match(ae) || [];
                for (; b8 < ca; b8++) {
                    e = this[b8];
                    cd = e.nodeType === 1 && (e.className ? (" " + e.className + " ").replace(bP, " ") : " ");
                    if (cd) {
                        b7 = 0;
                        while ((b9 = b6[b7++])) {
                            if (cd.indexOf(" " + b9 + " ") < 0) {
                                cd += b9 + " "
                            }
                        }
                        e.className = bM.trim(cd)
                    }
                }
            }
            return this
        },
        removeClass: function (cc) {
            var b6, e, cd, b9, b7, b8 = 0,
                ca = this.length,
                cb = arguments.length === 0 || typeof cc === "string" && cc;
            if (bM.isFunction(cc)) {
                return this.each(function (ce) {
                    bM(this).removeClass(cc.call(this, ce, this.className))
                })
            }
            if (cb) {
                b6 = (cc || "").match(ae) || [];
                for (; b8 < ca; b8++) {
                    e = this[b8];
                    cd = e.nodeType === 1 && (e.className ? (" " + e.className + " ").replace(bP, " ") : "");
                    if (cd) {
                        b7 = 0;
                        while ((b9 = b6[b7++])) {
                            while (cd.indexOf(" " + b9 + " ") >= 0) {
                                cd = cd.replace(" " + b9 + " ", " ")
                            }
                        }
                        e.className = cc ? bM.trim(cd) : ""
                    }
                }
            }
            return this
        },
        toggleClass: function (b8, b6) {
            var b7 = typeof b8,
                e = typeof b6 === "boolean";
            if (bM.isFunction(b8)) {
                return this.each(function (b9) {
                    bM(this).toggleClass(b8.call(this, b9, this.className, b6), b6)
                })
            }
            return this.each(function () {
                if (b7 === "string") {
                    var cb, ca = 0,
                        b9 = bM(this),
                        cc = b6,
                        cd = b8.match(ae) || [];
                    while ((cb = cd[ca++])) {
                        cc = e ? cc : !b9.hasClass(cb);
                        b9[cc ? "addClass" : "removeClass"](cb)
                    }
                } else {
                    if (b7 === aF || b7 === "boolean") {
                        if (this.className) {
                            bM._data(this, "__className__", this.className)
                        }
                        this.className = this.className || b8 === false ? "" : bM._data(this, "__className__") || ""
                    }
                }
            })
        },
        hasClass: function (e) {
            var b8 = " " + e + " ",
                b7 = 0,
                b6 = this.length;
            for (; b7 < b6; b7++) {
                if (this[b7].nodeType === 1 && (" " + this[b7].className + " ").replace(bP, " ").indexOf(b8) >= 0) {
                    return true
                }
            }
            return false
        },
        val: function (b8) {
            var b6, e, b9, b7 = this[0];
            if (!arguments.length) {
                if (b7) {
                    e = bM.valHooks[b7.type] || bM.valHooks[b7.nodeName.toLowerCase()];
                    if (e && "get" in e && (b6 = e.get(b7, "value")) !== aJ) {
                        return b6
                    }
                    b6 = b7.value;
                    return typeof b6 === "string" ? b6.replace(am, "") : b6 == null ? "" : b6
                }
                return
            }
            b9 = bM.isFunction(b8);
            return this.each(function (cb) {
                var cc, ca = bM(this);
                if (this.nodeType !== 1) {
                    return
                }
                if (b9) {
                    cc = b8.call(this, cb, ca.val())
                } else {
                    cc = b8
                }
                if (cc == null) {
                    cc = ""
                } else {
                    if (typeof cc === "number") {
                        cc += ""
                    } else {
                        if (bM.isArray(cc)) {
                            cc = bM.map(cc, function (cd) {
                                return cd == null ? "" : cd + ""
                            })
                        }
                    }
                }
                e = bM.valHooks[this.type] || bM.valHooks[this.nodeName.toLowerCase()];
                if (!e || !("set" in e) || e.set(this, cc, "value") === aJ) {
                    this.value = cc
                }
            })
        }
    });
    bM.extend({
        valHooks: {
            option: {
                get: function (e) {
                    var b6 = e.attributes.value;
                    return !b6 || b6.specified ? e.value : e.text
                }
            },
            select: {
                get: function (e) {
                    var cb, b7, cd = e.options,
                        b9 = e.selectedIndex,
                        b8 = e.type === "select-one" || b9 < 0,
                        cc = b8 ? null : [],
                        ca = b8 ? b9 + 1 : cd.length,
                        b6 = b9 < 0 ? ca : b8 ? b9 : 0;
                    for (; b6 < ca; b6++) {
                        b7 = cd[b6];
                        if ((b7.selected || b6 === b9) && (bM.support.optDisabled ? !b7.disabled : b7.getAttribute("disabled") === null) && (!b7.parentNode.disabled || !bM.nodeName(b7.parentNode, "optgroup"))) {
                            cb = bM(b7).val();
                            if (b8) {
                                return cb
                            }
                            cc.push(cb)
                        }
                    }
                    return cc
                },
                set: function (b6, b7) {
                    var e = bM.makeArray(b7);
                    bM(b6).find("option").each(function () {
                        this.selected = bM.inArray(bM(this).val(), e) >= 0
                    });
                    if (!e.length) {
                        b6.selectedIndex = -1
                    }
                    return e
                }
            }
        },
        attr: function (ca, b8, cb) {
            var e, b9, b7, b6 = ca.nodeType;
            if (!ca || b6 === 3 || b6 === 8 || b6 === 2) {
                return
            }
            if (typeof ca.getAttribute === aF) {
                return bM.prop(ca, b8, cb)
            }
            b9 = b6 !== 1 || !bM.isXMLDoc(ca);
            if (b9) {
                b8 = b8.toLowerCase();
                e = bM.attrHooks[b8] || (M.test(b8) ? b2 : bb)
            }
            if (cb !== aJ) {
                if (cb === null) {
                    bM.removeAttr(ca, b8)
                } else {
                    if (e && b9 && "set" in e && (b7 = e.set(ca, cb, b8)) !== aJ) {
                        return b7
                    } else {
                        ca.setAttribute(b8, cb + "");
                        return cb
                    }
                }
            } else {
                if (e && b9 && "get" in e && (b7 = e.get(ca, b8)) !== null) {
                    return b7
                } else {
                    if (typeof ca.getAttribute !== aF) {
                        b7 = ca.getAttribute(b8)
                    }
                    return b7 == null ? aJ : b7
                }
            }
        },
        removeAttr: function (b7, b9) {
            var e, b8, b6 = 0,
                ca = b9 && b9.match(ae);
            if (ca && b7.nodeType === 1) {
                while ((e = ca[b6++])) {
                    b8 = bM.propFix[e] || e;
                    if (M.test(e)) {
                        if (!bS && au.test(e)) {
                            b7[bM.camelCase("default-" + e)] = b7[b8] = false
                        } else {
                            b7[b8] = false
                        }
                    } else {
                        bM.attr(b7, e, "")
                    }
                    b7.removeAttribute(bS ? e : b8)
                }
            }
        },
        attrHooks: {
            type: {
                set: function (e, b6) {
                    if (!bM.support.radioValue && b6 === "radio" && bM.nodeName(e, "input")) {
                        var b7 = e.value;
                        e.setAttribute("type", b6);
                        if (b7) {
                            e.value = b7
                        }
                        return b6
                    }
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            "for": "htmlFor",
            "class": "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function (ca, b8, cb) {
            var b7, e, b9, b6 = ca.nodeType;
            if (!ca || b6 === 3 || b6 === 8 || b6 === 2) {
                return
            }
            b9 = b6 !== 1 || !bM.isXMLDoc(ca);
            if (b9) {
                b8 = bM.propFix[b8] || b8;
                e = bM.propHooks[b8]
            }
            if (cb !== aJ) {
                if (e && "set" in e && (b7 = e.set(ca, cb, b8)) !== aJ) {
                    return b7
                } else {
                    return (ca[b8] = cb)
                }
            } else {
                if (e && "get" in e && (b7 = e.get(ca, b8)) !== null) {
                    return b7
                } else {
                    return ca[b8]
                }
            }
        },
        propHooks: {
            tabIndex: {
                get: function (b6) {
                    var e = b6.getAttributeNode("tabindex");
                    return e && e.specified ? parseInt(e.value, 10) : aI.test(b6.nodeName) || E.test(b6.nodeName) && b6.href ? 0 : aJ
                }
            }
        }
    });
    b2 = {
        get: function (b8, b6) {
            var b9 = bM.prop(b8, b6),
                e = typeof b9 === "boolean" && b8.getAttribute(b6),
                b7 = typeof b9 === "boolean" ? bI && bS ? e != null : au.test(b6) ? b8[bM.camelCase("default-" + b6)] : !! e : b8.getAttributeNode(b6);
            return b7 && b7.value !== false ? b6.toLowerCase() : aJ
        },
        set: function (b6, b7, e) {
            if (b7 === false) {
                bM.removeAttr(b6, e)
            } else {
                if (bI && bS || !au.test(e)) {
                    b6.setAttribute(!bS && bM.propFix[e] || e, e)
                } else {
                    b6[bM.camelCase("default-" + e)] = b6[e] = true
                }
            }
            return e
        }
    };
    if (!bI || !bS) {
        bM.attrHooks.value = {
            get: function (b7, b6) {
                var e = b7.getAttributeNode(b6);
                return bM.nodeName(b7, "input") ? b7.defaultValue : e && e.specified ? e.value : aJ
            },
            set: function (b6, b7, e) {
                if (bM.nodeName(b6, "input")) {
                    b6.defaultValue = b7
                } else {
                    return bb && bb.set(b6, b7, e)
                }
            }
        }
    }
    if (!bS) {
        bb = bM.valHooks.button = {
            get: function (b7, b6) {
                var e = b7.getAttributeNode(b6);
                return e && (b6 === "id" || b6 === "name" || b6 === "coords" ? e.value !== "" : e.specified) ? e.value : aJ
            },
            set: function (b7, b8, b6) {
                var e = b7.getAttributeNode(b6);
                if (!e) {
                    b7.setAttributeNode((e = b7.ownerDocument.createAttribute(b6)))
                }
                e.value = b8 += "";
                return b6 === "value" || b8 === b7.getAttribute(b6) ? b8 : aJ
            }
        };
        bM.attrHooks.contenteditable = {
            get: bb.get,
            set: function (b6, b7, e) {
                bb.set(b6, b7 === "" ? false : b7, e)
            }
        };
        bM.each(["width", "height"], function (b6, e) {
            bM.attrHooks[e] = bM.extend(bM.attrHooks[e], {
                set: function (b7, b8) {
                    if (b8 === "") {
                        b7.setAttribute(e, "auto");
                        return b8
                    }
                }
            })
        })
    }
    if (!bM.support.hrefNormalized) {
        bM.each(["href", "src", "width", "height"], function (b6, e) {
            bM.attrHooks[e] = bM.extend(bM.attrHooks[e], {
                get: function (b8) {
                    var b7 = b8.getAttribute(e, 2);
                    return b7 == null ? aJ : b7
                }
            })
        });
        bM.each(["href", "src"], function (b6, e) {
            bM.propHooks[e] = {
                get: function (b7) {
                    return b7.getAttribute(e, 4)
                }
            }
        })
    }
    if (!bM.support.style) {
        bM.attrHooks.style = {
            get: function (e) {
                return e.style.cssText || aJ
            },
            set: function (e, b6) {
                return (e.style.cssText = b6 + "")
            }
        }
    }
    if (!bM.support.optSelected) {
        bM.propHooks.selected = bM.extend(bM.propHooks.selected, {
            get: function (b6) {
                var e = b6.parentNode;
                if (e) {
                    e.selectedIndex;
                    if (e.parentNode) {
                        e.parentNode.selectedIndex
                    }
                }
                return null
            }
        })
    }
    if (!bM.support.enctype) {
        bM.propFix.enctype = "encoding"
    }
    if (!bM.support.checkOn) {
        bM.each(["radio", "checkbox"], function () {
            bM.valHooks[this] = {
                get: function (e) {
                    return e.getAttribute("value") === null ? "on" : e.value
                }
            }
        })
    }
    bM.each(["radio", "checkbox"], function () {
        bM.valHooks[this] = bM.extend(bM.valHooks[this], {
            set: function (e, b6) {
                if (bM.isArray(b6)) {
                    return (e.checked = bM.inArray(bM(e).val(), b6) >= 0)
                }
            }
        })
    });
    var bK = /^(?:input|select|textarea)$/i,
        a6 = /^key/,
        bQ = /^(?:mouse|contextmenu)|click/,
        bE = /^(?:focusinfocus|focusoutblur)$/,
        bx = /^([^.]*)(?:\.(.+)|)$/;

    function S() {
        return true
    }
    function Z() {
        return false
    }
    bM.event = {
        global: {},
        add: function (b9, ce, cj, cb, ca) {
            var cc, ck, cl, b7, cg, cd, ci, b8, ch, e, b6, cf = bM._data(b9);
            if (!cf) {
                return
            }
            if (cj.handler) {
                b7 = cj;
                cj = b7.handler;
                ca = b7.selector
            }
            if (!cj.guid) {
                cj.guid = bM.guid++
            }
            if (!(ck = cf.events)) {
                ck = cf.events = {}
            }
            if (!(cd = cf.handle)) {
                cd = cf.handle = function (cm) {
                    return typeof bM !== aF && (!cm || bM.event.triggered !== cm.type) ? bM.event.dispatch.apply(cd.elem, arguments) : aJ
                };
                cd.elem = b9
            }
            ce = (ce || "").match(ae) || [""];
            cl = ce.length;
            while (cl--) {
                cc = bx.exec(ce[cl]) || [];
                ch = b6 = cc[1];
                e = (cc[2] || "").split(".").sort();
                cg = bM.event.special[ch] || {};
                ch = (ca ? cg.delegateType : cg.bindType) || ch;
                cg = bM.event.special[ch] || {};
                ci = bM.extend({
                    type: ch,
                    origType: b6,
                    data: cb,
                    handler: cj,
                    guid: cj.guid,
                    selector: ca,
                    needsContext: ca && bM.expr.match.needsContext.test(ca),
                    namespace: e.join(".")
                }, b7);
                if (!(b8 = ck[ch])) {
                    b8 = ck[ch] = [];
                    b8.delegateCount = 0;
                    if (!cg.setup || cg.setup.call(b9, cb, e, cd) === false) {
                        if (b9.addEventListener) {
                            b9.addEventListener(ch, cd, false)
                        } else {
                            if (b9.attachEvent) {
                                b9.attachEvent("on" + ch, cd)
                            }
                        }
                    }
                }
                if (cg.add) {
                    cg.add.call(b9, ci);
                    if (!ci.handler.guid) {
                        ci.handler.guid = cj.guid
                    }
                }
                if (ca) {
                    b8.splice(b8.delegateCount++, 0, ci)
                } else {
                    b8.push(ci)
                }
                bM.event.global[ch] = true
            }
            b9 = null
        },
        remove: function (b8, ce, cl, b9, cd) {
            var cb, ci, cc, ca, ck, cj, cg, b7, ch, e, b6, cf = bM.hasData(b8) && bM._data(b8);
            if (!cf || !(cj = cf.events)) {
                return
            }
            ce = (ce || "").match(ae) || [""];
            ck = ce.length;
            while (ck--) {
                cc = bx.exec(ce[ck]) || [];
                ch = b6 = cc[1];
                e = (cc[2] || "").split(".").sort();
                if (!ch) {
                    for (ch in cj) {
                        bM.event.remove(b8, ch + ce[ck], cl, b9, true)
                    }
                    continue
                }
                cg = bM.event.special[ch] || {};
                ch = (b9 ? cg.delegateType : cg.bindType) || ch;
                b7 = cj[ch] || [];
                cc = cc[2] && new RegExp("(^|\\.)" + e.join("\\.(?:.*\\.|)") + "(\\.|$)");
                ca = cb = b7.length;
                while (cb--) {
                    ci = b7[cb];
                    if ((cd || b6 === ci.origType) && (!cl || cl.guid === ci.guid) && (!cc || cc.test(ci.namespace)) && (!b9 || b9 === ci.selector || b9 === "**" && ci.selector)) {
                        b7.splice(cb, 1);
                        if (ci.selector) {
                            b7.delegateCount--
                        }
                        if (cg.remove) {
                            cg.remove.call(b8, ci)
                        }
                    }
                }
                if (ca && !b7.length) {
                    if (!cg.teardown || cg.teardown.call(b8, e, cf.handle) === false) {
                        bM.removeEvent(b8, ch, cf.handle)
                    }
                    delete cj[ch]
                }
            }
            if (bM.isEmptyObject(cj)) {
                delete cf.handle;
                bM._removeData(b8, "events")
            }
        },
        trigger: function (b6, cd, b9, ck) {
            var ce, b8, ci, cj, cg, cc, cb, ca = [b9 || l],
                ch = X.call(b6, "type") ? b6.type : b6,
                b7 = X.call(b6, "namespace") ? b6.namespace.split(".") : [];
            ci = cc = b9 = b9 || l;
            if (b9.nodeType === 3 || b9.nodeType === 8) {
                return
            }
            if (bE.test(ch + bM.event.triggered)) {
                return
            }
            if (ch.indexOf(".") >= 0) {
                b7 = ch.split(".");
                ch = b7.shift();
                b7.sort()
            }
            b8 = ch.indexOf(":") < 0 && "on" + ch;
            b6 = b6[bM.expando] ? b6 : new bM.Event(ch, typeof b6 === "object" && b6);
            b6.isTrigger = true;
            b6.namespace = b7.join(".");
            b6.namespace_re = b6.namespace ? new RegExp("(^|\\.)" + b7.join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
            b6.result = aJ;
            if (!b6.target) {
                b6.target = b9
            }
            cd = cd == null ? [b6] : bM.makeArray(cd, [b6]);
            cg = bM.event.special[ch] || {};
            if (!ck && cg.trigger && cg.trigger.apply(b9, cd) === false) {
                return
            }
            if (!ck && !cg.noBubble && !bM.isWindow(b9)) {
                cj = cg.delegateType || ch;
                if (!bE.test(cj + ch)) {
                    ci = ci.parentNode
                }
                for (; ci; ci = ci.parentNode) {
                    ca.push(ci);
                    cc = ci
                }
                if (cc === (b9.ownerDocument || l)) {
                    ca.push(cc.defaultView || cc.parentWindow || a5)
                }
            }
            cb = 0;
            while ((ci = ca[cb++]) && !b6.isPropagationStopped()) {
                b6.type = cb > 1 ? cj : cg.bindType || ch;
                ce = (bM._data(ci, "events") || {})[b6.type] && bM._data(ci, "handle");
                if (ce) {
                    ce.apply(ci, cd)
                }
                ce = b8 && ci[b8];
                if (ce && bM.acceptData(ci) && ce.apply && ce.apply(ci, cd) === false) {
                    b6.preventDefault()
                }
            }
            b6.type = ch;
            if (!ck && !b6.isDefaultPrevented()) {
                if ((!cg._default || cg._default.apply(b9.ownerDocument, cd) === false) && !(ch === "click" && bM.nodeName(b9, "a")) && bM.acceptData(b9)) {
                    if (b8 && b9[ch] && !bM.isWindow(b9)) {
                        cc = b9[b8];
                        if (cc) {
                            b9[b8] = null
                        }
                        bM.event.triggered = ch;
                        try {
                            b9[ch]()
                        } catch (cf) {}
                        bM.event.triggered = aJ;
                        if (cc) {
                            b9[b8] = cc
                        }
                    }
                }
            }
            return b6.result
        },
        dispatch: function (e) {
            e = bM.event.fix(e);
            var b9, ca, ce, b6, b8, cd = [],
                cc = a7.call(arguments),
                b7 = (bM._data(this, "events") || {})[e.type] || [],
                cb = bM.event.special[e.type] || {};
            cc[0] = e;
            e.delegateTarget = this;
            if (cb.preDispatch && cb.preDispatch.call(this, e) === false) {
                return
            }
            cd = bM.event.handlers.call(this, e, b7);
            b9 = 0;
            while ((b6 = cd[b9++]) && !e.isPropagationStopped()) {
                e.currentTarget = b6.elem;
                b8 = 0;
                while ((ce = b6.handlers[b8++]) && !e.isImmediatePropagationStopped()) {
                    if (!e.namespace_re || e.namespace_re.test(ce.namespace)) {
                        e.handleObj = ce;
                        e.data = ce.data;
                        ca = ((bM.event.special[ce.origType] || {}).handle || ce.handler).apply(b6.elem, cc);
                        if (ca !== aJ) {
                            if ((e.result = ca) === false) {
                                e.preventDefault();
                                e.stopPropagation()
                            }
                        }
                    }
                }
            }
            if (cb.postDispatch) {
                cb.postDispatch.call(this, e)
            }
            return e.result
        },
        handlers: function (e, b7) {
            var b6, cc, ca, b9, cb = [],
                b8 = b7.delegateCount,
                cd = e.target;
            if (b8 && cd.nodeType && (!e.button || e.type !== "click")) {
                for (; cd != this; cd = cd.parentNode || this) {
                    if (cd.nodeType === 1 && (cd.disabled !== true || e.type !== "click")) {
                        ca = [];
                        for (b9 = 0; b9 < b8; b9++) {
                            cc = b7[b9];
                            b6 = cc.selector + " ";
                            if (ca[b6] === aJ) {
                                ca[b6] = cc.needsContext ? bM(b6, this).index(cd) >= 0 : bM.find(b6, this, null, [cd]).length
                            }
                            if (ca[b6]) {
                                ca.push(cc)
                            }
                        }
                        if (ca.length) {
                            cb.push({
                                elem: cd,
                                handlers: ca
                            })
                        }
                    }
                }
            }
            if (b8 < b7.length) {
                cb.push({
                    elem: this,
                    handlers: b7.slice(b8)
                })
            }
            return cb
        },
        fix: function (b8) {
            if (b8[bM.expando]) {
                return b8
            }
            var b6, cb, ca, b7 = b8.type,
                e = b8,
                b9 = this.fixHooks[b7];
            if (!b9) {
                this.fixHooks[b7] = b9 = bQ.test(b7) ? this.mouseHooks : a6.test(b7) ? this.keyHooks : {}
            }
            ca = b9.props ? this.props.concat(b9.props) : this.props;
            b8 = new bM.Event(e);
            b6 = ca.length;
            while (b6--) {
                cb = ca[b6];
                b8[cb] = e[cb]
            }
            if (!b8.target) {
                b8.target = e.srcElement || l
            }
            if (b8.target.nodeType === 3) {
                b8.target = b8.target.parentNode
            }
            b8.metaKey = !! b8.metaKey;
            return b9.filter ? b9.filter(b8, e) : b8
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function (b6, e) {
                if (b6.which == null) {
                    b6.which = e.charCode != null ? e.charCode : e.keyCode
                }
                return b6
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (b8, b7) {
                var e, b9, ca, b6 = b7.button,
                    cb = b7.fromElement;
                if (b8.pageX == null && b7.clientX != null) {
                    b9 = b8.target.ownerDocument || l;
                    ca = b9.documentElement;
                    e = b9.body;
                    b8.pageX = b7.clientX + (ca && ca.scrollLeft || e && e.scrollLeft || 0) - (ca && ca.clientLeft || e && e.clientLeft || 0);
                    b8.pageY = b7.clientY + (ca && ca.scrollTop || e && e.scrollTop || 0) - (ca && ca.clientTop || e && e.clientTop || 0)
                }
                if (!b8.relatedTarget && cb) {
                    b8.relatedTarget = cb === b8.target ? b7.toElement : cb
                }
                if (!b8.which && b6 !== aJ) {
                    b8.which = (b6 & 1 ? 1 : (b6 & 2 ? 3 : (b6 & 4 ? 2 : 0)))
                }
                return b8
            }
        },
        special: {
            load: {
                noBubble: true
            },
            click: {
                trigger: function () {
                    if (bM.nodeName(this, "input") && this.type === "checkbox" && this.click) {
                        this.click();
                        return false
                    }
                }
            },
            focus: {
                trigger: function () {
                    if (this !== l.activeElement && this.focus) {
                        try {
                            this.focus();
                            return false
                        } catch (b6) {}
                    }
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function () {
                    if (this === l.activeElement && this.blur) {
                        this.blur();
                        return false
                    }
                },
                delegateType: "focusout"
            },
            beforeunload: {
                postDispatch: function (e) {
                    if (e.result !== aJ) {
                        e.originalEvent.returnValue = e.result
                    }
                }
            }
        },
        simulate: function (b7, b9, b8, b6) {
            var ca = bM.extend(new bM.Event(), b8, {
                type: b7,
                isSimulated: true,
                originalEvent: {}
            });
            if (b6) {
                bM.event.trigger(ca, null, b9)
            } else {
                bM.event.dispatch.call(b9, ca)
            }
            if (ca.isDefaultPrevented()) {
                b8.preventDefault()
            }
        }
    };
    bM.removeEvent = l.removeEventListener ?
    function (b6, e, b7) {
        if (b6.removeEventListener) {
            b6.removeEventListener(e, b7, false)
        }
    } : function (b7, b6, b8) {
        var e = "on" + b6;
        if (b7.detachEvent) {
            if (typeof b7[e] === aF) {
                b7[e] = null
            }
            b7.detachEvent(e, b8)
        }
    };
    bM.Event = function (b6, e) {
        if (!(this instanceof bM.Event)) {
            return new bM.Event(b6, e)
        }
        if (b6 && b6.type) {
            this.originalEvent = b6;
            this.type = b6.type;
            this.isDefaultPrevented = (b6.defaultPrevented || b6.returnValue === false || b6.getPreventDefault && b6.getPreventDefault()) ? S : Z
        } else {
            this.type = b6
        }
        if (e) {
            bM.extend(this, e)
        }
        this.timeStamp = b6 && b6.timeStamp || bM.now();
        this[bM.expando] = true
    };
    bM.Event.prototype = {
        isDefaultPrevented: Z,
        isPropagationStopped: Z,
        isImmediatePropagationStopped: Z,
        preventDefault: function () {
            var b6 = this.originalEvent;
            this.isDefaultPrevented = S;
            if (!b6) {
                return
            }
            if (b6.preventDefault) {
                b6.preventDefault()
            } else {
                b6.returnValue = false
            }
        },
        stopPropagation: function () {
            var b6 = this.originalEvent;
            this.isPropagationStopped = S;
            if (!b6) {
                return
            }
            if (b6.stopPropagation) {
                b6.stopPropagation()
            }
            b6.cancelBubble = true
        },
        stopImmediatePropagation: function () {
            this.isImmediatePropagationStopped = S;
            this.stopPropagation()
        }
    };
    bM.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function (b6, e) {
        bM.event.special[b6] = {
            delegateType: e,
            bindType: e,
            handle: function (b9) {
                var b7, cb = this,
                    ca = b9.relatedTarget,
                    b8 = b9.handleObj;
                if (!ca || (ca !== cb && !bM.contains(cb, ca))) {
                    b9.type = b8.origType;
                    b7 = b8.handler.apply(this, arguments);
                    b9.type = e
                }
                return b7
            }
        }
    });
    if (!bM.support.submitBubbles) {
        bM.event.special.submit = {
            setup: function () {
                if (bM.nodeName(this, "form")) {
                    return false
                }
                bM.event.add(this, "click._submit keypress._submit", function (b8) {
                    var b7 = b8.target,
                        b6 = bM.nodeName(b7, "input") || bM.nodeName(b7, "button") ? b7.form : aJ;
                    if (b6 && !bM._data(b6, "submitBubbles")) {
                        bM.event.add(b6, "submit._submit", function (e) {
                            e._submit_bubble = true
                        });
                        bM._data(b6, "submitBubbles", true)
                    }
                })
            },
            postDispatch: function (e) {
                if (e._submit_bubble) {
                    delete e._submit_bubble;
                    if (this.parentNode && !e.isTrigger) {
                        bM.event.simulate("submit", this.parentNode, e, true)
                    }
                }
            },
            teardown: function () {
                if (bM.nodeName(this, "form")) {
                    return false
                }
                bM.event.remove(this, "._submit")
            }
        }
    }
    if (!bM.support.changeBubbles) {
        bM.event.special.change = {
            setup: function () {
                if (bK.test(this.nodeName)) {
                    if (this.type === "checkbox" || this.type === "radio") {
                        bM.event.add(this, "propertychange._change", function (e) {
                            if (e.originalEvent.propertyName === "checked") {
                                this._just_changed = true
                            }
                        });
                        bM.event.add(this, "click._change", function (e) {
                            if (this._just_changed && !e.isTrigger) {
                                this._just_changed = false
                            }
                            bM.event.simulate("change", this, e, true)
                        })
                    }
                    return false
                }
                bM.event.add(this, "beforeactivate._change", function (b7) {
                    var b6 = b7.target;
                    if (bK.test(b6.nodeName) && !bM._data(b6, "changeBubbles")) {
                        bM.event.add(b6, "change._change", function (e) {
                            if (this.parentNode && !e.isSimulated && !e.isTrigger) {
                                bM.event.simulate("change", this.parentNode, e, true)
                            }
                        });
                        bM._data(b6, "changeBubbles", true)
                    }
                })
            },
            handle: function (b6) {
                var e = b6.target;
                if (this !== e || b6.isSimulated || b6.isTrigger || (e.type !== "radio" && e.type !== "checkbox")) {
                    return b6.handleObj.handler.apply(this, arguments)
                }
            },
            teardown: function () {
                bM.event.remove(this, "._change");
                return !bK.test(this.nodeName)
            }
        }
    }
    if (!bM.support.focusinBubbles) {
        bM.each({
            focus: "focusin",
            blur: "focusout"
        }, function (b8, e) {
            var b6 = 0,
                b7 = function (b9) {
                    bM.event.simulate(e, b9.target, bM.event.fix(b9), true)
                };
            bM.event.special[e] = {
                setup: function () {
                    if (b6++ === 0) {
                        l.addEventListener(b8, b7, true)
                    }
                },
                teardown: function () {
                    if (--b6 === 0) {
                        l.removeEventListener(b8, b7, true)
                    }
                }
            }
        })
    }
    bM.fn.extend({
        on: function (b7, e, ca, b9, b6) {
            var b8, cb;
            if (typeof b7 === "object") {
                if (typeof e !== "string") {
                    ca = ca || e;
                    e = aJ
                }
                for (b8 in b7) {
                    this.on(b8, e, ca, b7[b8], b6)
                }
                return this
            }
            if (ca == null && b9 == null) {
                b9 = e;
                ca = e = aJ
            } else {
                if (b9 == null) {
                    if (typeof e === "string") {
                        b9 = ca;
                        ca = aJ
                    } else {
                        b9 = ca;
                        ca = e;
                        e = aJ
                    }
                }
            }
            if (b9 === false) {
                b9 = Z
            } else {
                if (!b9) {
                    return this
                }
            }
            if (b6 === 1) {
                cb = b9;
                b9 = function (cc) {
                    bM().off(cc);
                    return cb.apply(this, arguments)
                };
                b9.guid = cb.guid || (cb.guid = bM.guid++)
            }
            return this.each(function () {
                bM.event.add(this, b7, b9, ca, e)
            })
        },
        one: function (b6, e, b8, b7) {
            return this.on(b6, e, b8, b7, 1)
        },
        off: function (b7, e, b9) {
            var b6, b8;
            if (b7 && b7.preventDefault && b7.handleObj) {
                b6 = b7.handleObj;
                bM(b7.delegateTarget).off(b6.namespace ? b6.origType + "." + b6.namespace : b6.origType, b6.selector, b6.handler);
                return this
            }
            if (typeof b7 === "object") {
                for (b8 in b7) {
                    this.off(b8, e, b7[b8])
                }
                return this
            }
            if (e === false || typeof e === "function") {
                b9 = e;
                e = aJ
            }
            if (b9 === false) {
                b9 = Z
            }
            return this.each(function () {
                bM.event.remove(this, b7, b9, e)
            })
        },
        bind: function (e, b7, b6) {
            return this.on(e, null, b7, b6)
        },
        unbind: function (e, b6) {
            return this.off(e, null, b6)
        },
        delegate: function (e, b6, b8, b7) {
            return this.on(b6, e, b8, b7)
        },
        undelegate: function (e, b6, b7) {
            return arguments.length === 1 ? this.off(e, "**") : this.off(b6, e || "**", b7)
        },
        trigger: function (e, b6) {
            return this.each(function () {
                bM.event.trigger(e, b6, this)
            })
        },
        triggerHandler: function (e, b7) {
            var b6 = this[0];
            if (b6) {
                return bM.event.trigger(e, b7, b6, true)
            }
        }
    });
/*!
 * Sizzle CSS Selector Engine
 * Copyright 2012 jQuery Foundation and other contributors
 * Released under the MIT license
 * http://sizzlejs.com/
 */
    (function (dd, ck) {
        var cA, ce, cq, cK, cM, cV, cW, dj, cY, cE, cr, cg, c2, de, cd, cI, cG, c8 = "sizzle" + -(new Date()),
            cL = dd.document,
            dg = {},
            dh = 0,
            c3 = 0,
            b8 = cC(),
            c7 = cC(),
            cJ = cC(),
            dc = typeof ck,
            cQ = 1 << 31,
            da = [],
            db = da.pop,
            b7 = da.push,
            cp = da.slice,
            cc = da.indexOf ||
            function (dl) {
                var dk = 0,
                    e = this.length;
                for (; dk < e; dk++) {
                    if (this[dk] === dl) {
                        return dk
                    }
                }
                return -1
            },
            cs = "[\\x20\\t\\r\\n\\f]",
            b6 = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
            cN = b6.replace("w", "w#"),
            cl = "([*^$|!~]?=)",
            c5 = "\\[" + cs + "*(" + b6 + ")" + cs + "*(?:" + cl + cs + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + cN + ")|)|)" + cs + "*\\]",
            cn = ":(" + b6 + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + c5.replace(3, 8) + ")*)|.*)\\)|)",
            cu = new RegExp("^" + cs + "+|((?:^|[^\\\\])(?:\\\\.)*)" + cs + "+$", "g"),
            cx = new RegExp("^" + cs + "*," + cs + "*"),
            cD = new RegExp("^" + cs + "*([\\x20\\t\\r\\n\\f>+~])" + cs + "*"),
            cS = new RegExp(cn),
            cT = new RegExp("^" + cN + "$"),
            c1 = {
                ID: new RegExp("^#(" + b6 + ")"),
                CLASS: new RegExp("^\\.(" + b6 + ")"),
                NAME: new RegExp("^\\[name=['\"]?(" + b6 + ")['\"]?\\]"),
                TAG: new RegExp("^(" + b6.replace("w", "w*") + ")"),
                ATTR: new RegExp("^" + c5),
                PSEUDO: new RegExp("^" + cn),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + cs + "*(even|odd|(([+-]|)(\\d*)n|)" + cs + "*(?:([+-]|)" + cs + "*(\\d+)|))" + cs + "*\\)|)", "i"),
                needsContext: new RegExp("^" + cs + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + cs + "*((?:-\\d)?\\d*)" + cs + "*\\)|)(?=[^-]|$)", "i")
            },
            cZ = /[\x20\t\r\n\f]*[+~]/,
            cP = /^[^{]+\{\s*\[native code/,
            cR = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            cb = /^(?:input|select|textarea|button)$/i,
            co = /^h\d$/i,
            cO = /'|\\/g,
            cw = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,
            cv = /\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,
            c4 = function (e, dl) {
                var dk = "0x" + dl - 65536;
                return dk !== dk ? dl : dk < 0 ? String.fromCharCode(dk + 65536) : String.fromCharCode(dk >> 10 | 55296, dk & 1023 | 56320)
            };
        try {
            cp.call(cL.documentElement.childNodes, 0)[0].nodeType
        } catch (cF) {
            cp = function (dk) {
                var dl, e = [];
                while ((dl = this[dk++])) {
                    e.push(dl)
                }
                return e
            }
        }
        function cH(e) {
            return cP.test(e + "")
        }
        function cC() {
            var e, dk = [];
            return (e = function (dl, dm) {
                if (dk.push(dl += " ") > cq.cacheLength) {
                    delete e[dk.shift()]
                }
                return (e[dl] = dm)
            })
        }
        function cm(e) {
            e[c8] = true;
            return e
        }
        function cf(dk) {
            var dm = cE.createElement("div");
            try {
                return dk(dm)
            } catch (dl) {
                return false
            } finally {
                dm = null
            }
        }
        function cy(ds, dk, dw, dy) {
            var dx, dp, dq, du, dv, dn, dm, e, dl, dt;
            if ((dk ? dk.ownerDocument || dk : cL) !== cE) {
                cY(dk)
            }
            dk = dk || cE;
            dw = dw || [];
            if (!ds || typeof ds !== "string") {
                return dw
            }
            if ((du = dk.nodeType) !== 1 && du !== 9) {
                return []
            }
            if (!cg && !dy) {
                if ((dx = cR.exec(ds))) {
                    if ((dq = dx[1])) {
                        if (du === 9) {
                            dp = dk.getElementById(dq);
                            if (dp && dp.parentNode) {
                                if (dp.id === dq) {
                                    dw.push(dp);
                                    return dw
                                }
                            } else {
                                return dw
                            }
                        } else {
                            if (dk.ownerDocument && (dp = dk.ownerDocument.getElementById(dq)) && cI(dk, dp) && dp.id === dq) {
                                dw.push(dp);
                                return dw
                            }
                        }
                    } else {
                        if (dx[2]) {
                            b7.apply(dw, cp.call(dk.getElementsByTagName(ds), 0));
                            return dw
                        } else {
                            if ((dq = dx[3]) && dg.getByClassName && dk.getElementsByClassName) {
                                b7.apply(dw, cp.call(dk.getElementsByClassName(dq), 0));
                                return dw
                            }
                        }
                    }
                }
                if (dg.qsa && !c2.test(ds)) {
                    dm = true;
                    e = c8;
                    dl = dk;
                    dt = du === 9 && ds;
                    if (du === 1 && dk.nodeName.toLowerCase() !== "object") {
                        dn = ci(ds);
                        if ((dm = dk.getAttribute("id"))) {
                            e = dm.replace(cO, "\\$&")
                        } else {
                            dk.setAttribute("id", e)
                        }
                        e = "[id='" + e + "'] ";
                        dv = dn.length;
                        while (dv--) {
                            dn[dv] = e + cj(dn[dv])
                        }
                        dl = cZ.test(ds) && dk.parentNode || dk;
                        dt = dn.join(",")
                    }
                    if (dt) {
                        try {
                            b7.apply(dw, cp.call(dl.querySelectorAll(dt), 0));
                            return dw
                        } catch (dr) {} finally {
                            if (!dm) {
                                dk.removeAttribute("id")
                            }
                        }
                    }
                }
            }
            return df(ds.replace(cu, "$1"), dk, dw, dy)
        }
        cM = cy.isXML = function (e) {
            var dk = e && (e.ownerDocument || e).documentElement;
            return dk ? dk.nodeName !== "HTML" : false
        };
        cY = cy.setDocument = function (e) {
            var dk = e ? e.ownerDocument || e : cL;
            if (dk === cE || dk.nodeType !== 9 || !dk.documentElement) {
                return cE
            }
            cE = dk;
            cr = dk.documentElement;
            cg = cM(dk);
            dg.tagNameNoComments = cf(function (dl) {
                dl.appendChild(dk.createComment(""));
                return !dl.getElementsByTagName("*").length
            });
            dg.attributes = cf(function (dm) {
                dm.innerHTML = "<select></select>";
                var dl = typeof dm.lastChild.getAttribute("multiple");
                return dl !== "boolean" && dl !== "string"
            });
            dg.getByClassName = cf(function (dl) {
                dl.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>";
                if (!dl.getElementsByClassName || !dl.getElementsByClassName("e").length) {
                    return false
                }
                dl.lastChild.className = "e";
                return dl.getElementsByClassName("e").length === 2
            });
            dg.getByName = cf(function (dm) {
                dm.id = c8 + 0;
                dm.innerHTML = "<a name='" + c8 + "'></a><div name='" + c8 + "'></div>";
                cr.insertBefore(dm, cr.firstChild);
                var dl = dk.getElementsByName && dk.getElementsByName(c8).length === 2 + dk.getElementsByName(c8 + 0).length;
                dg.getIdNotName = !dk.getElementById(c8);
                cr.removeChild(dm);
                return dl
            });
            cq.attrHandle = cf(function (dl) {
                dl.innerHTML = "<a href='#'></a>";
                return dl.firstChild && typeof dl.firstChild.getAttribute !== dc && dl.firstChild.getAttribute("href") === "#"
            }) ? {} : {
                href: function (dl) {
                    return dl.getAttribute("href", 2)
                },
                type: function (dl) {
                    return dl.getAttribute("type")
                }
            };
            if (dg.getIdNotName) {
                cq.find.ID = function (dn, dm) {
                    if (typeof dm.getElementById !== dc && !cg) {
                        var dl = dm.getElementById(dn);
                        return dl && dl.parentNode ? [dl] : []
                    }
                };
                cq.filter.ID = function (dm) {
                    var dl = dm.replace(cv, c4);
                    return function (dn) {
                        return dn.getAttribute("id") === dl
                    }
                }
            } else {
                cq.find.ID = function (dn, dm) {
                    if (typeof dm.getElementById !== dc && !cg) {
                        var dl = dm.getElementById(dn);
                        return dl ? dl.id === dn || typeof dl.getAttributeNode !== dc && dl.getAttributeNode("id").value === dn ? [dl] : ck : []
                    }
                };
                cq.filter.ID = function (dm) {
                    var dl = dm.replace(cv, c4);
                    return function (dp) {
                        var dn = typeof dp.getAttributeNode !== dc && dp.getAttributeNode("id");
                        return dn && dn.value === dl
                    }
                }
            }
            cq.find.TAG = dg.tagNameNoComments ?
            function (dl, dm) {
                if (typeof dm.getElementsByTagName !== dc) {
                    return dm.getElementsByTagName(dl)
                }
            } : function (dl, dq) {
                var dr, dp = [],
                    dn = 0,
                    dm = dq.getElementsByTagName(dl);
                if (dl === "*") {
                    while ((dr = dm[dn++])) {
                        if (dr.nodeType === 1) {
                            dp.push(dr)
                        }
                    }
                    return dp
                }
                return dm
            };
            cq.find.NAME = dg.getByName &&
            function (dl, dm) {
                if (typeof dm.getElementsByName !== dc) {
                    return dm.getElementsByName(name)
                }
            };
            cq.find.CLASS = dg.getByClassName &&
            function (dm, dl) {
                if (typeof dl.getElementsByClassName !== dc && !cg) {
                    return dl.getElementsByClassName(dm)
                }
            };
            de = [];
            c2 = [":focus"];
            if ((dg.qsa = cH(dk.querySelectorAll))) {
                cf(function (dl) {
                    dl.innerHTML = "<select><option selected=''></option></select>";
                    if (!dl.querySelectorAll("[selected]").length) {
                        c2.push("\\[" + cs + "*(?:checked|disabled|ismap|multiple|readonly|selected|value)")
                    }
                    if (!dl.querySelectorAll(":checked").length) {
                        c2.push(":checked")
                    }
                });
                cf(function (dl) {
                    dl.innerHTML = "<input type='hidden' i=''/>";
                    if (dl.querySelectorAll("[i^='']").length) {
                        c2.push("[*^$]=" + cs + "*(?:\"\"|'')")
                    }
                    if (!dl.querySelectorAll(":enabled").length) {
                        c2.push(":enabled", ":disabled")
                    }
                    dl.querySelectorAll("*,:x");
                    c2.push(",.*:")
                })
            }
            if ((dg.matchesSelector = cH((cd = cr.matchesSelector || cr.mozMatchesSelector || cr.webkitMatchesSelector || cr.oMatchesSelector || cr.msMatchesSelector)))) {
                cf(function (dl) {
                    dg.disconnectedMatch = cd.call(dl, "div");
                    cd.call(dl, "[s!='']:x");
                    de.push("!=", cn)
                })
            }
            c2 = new RegExp(c2.join("|"));
            de = new RegExp(de.join("|"));
            cI = cH(cr.contains) || cr.compareDocumentPosition ?
            function (dm, dl) {
                var dp = dm.nodeType === 9 ? dm.documentElement : dm,
                    dn = dl && dl.parentNode;
                return dm === dn || !! (dn && dn.nodeType === 1 && (dp.contains ? dp.contains(dn) : dm.compareDocumentPosition && dm.compareDocumentPosition(dn) & 16))
            } : function (dm, dl) {
                if (dl) {
                    while ((dl = dl.parentNode)) {
                        if (dl === dm) {
                            return true
                        }
                    }
                }
                return false
            };
            cG = cr.compareDocumentPosition ?
            function (dm, dl) {
                var dn;
                if (dm === dl) {
                    cW = true;
                    return 0
                }
                if ((dn = dl.compareDocumentPosition && dm.compareDocumentPosition && dm.compareDocumentPosition(dl))) {
                    if (dn & 1 || dm.parentNode && dm.parentNode.nodeType === 11) {
                        if (dm === dk || cI(cL, dm)) {
                            return -1
                        }
                        if (dl === dk || cI(cL, dl)) {
                            return 1
                        }
                        return 0
                    }
                    return dn & 4 ? -1 : 1
                }
                return dm.compareDocumentPosition ? -1 : 1
            } : function (dm, dl) {
                var dt, dq = 0,
                    ds = dm.parentNode,
                    dp = dl.parentNode,
                    dn = [dm],
                    dr = [dl];
                if (dm === dl) {
                    cW = true;
                    return 0
                } else {
                    if (!ds || !dp) {
                        return dm === dk ? -1 : dl === dk ? 1 : ds ? -1 : dp ? 1 : 0
                    } else {
                        if (ds === dp) {
                            return b9(dm, dl)
                        }
                    }
                }
                dt = dm;
                while ((dt = dt.parentNode)) {
                    dn.unshift(dt)
                }
                dt = dl;
                while ((dt = dt.parentNode)) {
                    dr.unshift(dt)
                }
                while (dn[dq] === dr[dq]) {
                    dq++
                }
                return dq ? b9(dn[dq], dr[dq]) : dn[dq] === cL ? -1 : dr[dq] === cL ? 1 : 0
            };
            cW = false;
            [0, 0].sort(cG);
            dg.detectDuplicates = cW;
            return cE
        };
        cy.matches = function (dk, e) {
            return cy(dk, null, null, e)
        };
        cy.matchesSelector = function (dl, dn) {
            if ((dl.ownerDocument || dl) !== cE) {
                cY(dl)
            }
            dn = dn.replace(cw, "='$1']");
            if (dg.matchesSelector && !cg && (!de || !de.test(dn)) && !c2.test(dn)) {
                try {
                    var dk = cd.call(dl, dn);
                    if (dk || dg.disconnectedMatch || dl.document && dl.document.nodeType !== 11) {
                        return dk
                    }
                } catch (dm) {}
            }
            return cy(dn, cE, null, [dl]).length > 0
        };
        cy.contains = function (e, dk) {
            if ((e.ownerDocument || e) !== cE) {
                cY(e)
            }
            return cI(e, dk)
        };
        cy.attr = function (dk, e) {
            var dl;
            if ((dk.ownerDocument || dk) !== cE) {
                cY(dk)
            }
            if (!cg) {
                e = e.toLowerCase()
            }
            if ((dl = cq.attrHandle[e])) {
                return dl(dk)
            }
            if (cg || dg.attributes) {
                return dk.getAttribute(e)
            }
            return ((dl = dk.getAttributeNode(e)) || dk.getAttribute(e)) && dk[e] === true ? e : dl && dl.specified ? dl.value : null
        };
        cy.error = function (e) {
            throw new Error("Syntax error, unrecognized expression: " + e)
        };
        cy.uniqueSort = function (dl) {
            var dm, dn = [],
                dk = 1,
                e = 0;
            cW = !dg.detectDuplicates;
            dl.sort(cG);
            if (cW) {
                for (;
                (dm = dl[dk]); dk++) {
                    if (dm === dl[dk - 1]) {
                        e = dn.push(dk)
                    }
                }
                while (e--) {
                    dl.splice(dn[e], 1)
                }
            }
            return dl
        };

        function b9(dk, e) {
            var dm = e && dk,
                dl = dm && (~e.sourceIndex || cQ) - (~dk.sourceIndex || cQ);
            if (dl) {
                return dl
            }
            if (dm) {
                while ((dm = dm.nextSibling)) {
                    if (dm === e) {
                        return -1
                    }
                }
            }
            return dk ? 1 : -1
        }
        function cz(e) {
            return function (dl) {
                var dk = dl.nodeName.toLowerCase();
                return dk === "input" && dl.type === e
            }
        }
        function ca(e) {
            return function (dl) {
                var dk = dl.nodeName.toLowerCase();
                return (dk === "input" || dk === "button") && dl.type === e
            }
        }
        function c6(e) {
            return cm(function (dk) {
                dk = +dk;
                return cm(function (dl, dq) {
                    var dn, dm = e([], dl.length, dk),
                        dp = dm.length;
                    while (dp--) {
                        if (dl[(dn = dm[dp])]) {
                            dl[dn] = !(dq[dn] = dl[dn])
                        }
                    }
                })
            })
        }
        cK = cy.getText = function (dn) {
            var dm, dk = "",
                dl = 0,
                e = dn.nodeType;
            if (!e) {
                for (;
                (dm = dn[dl]); dl++) {
                    dk += cK(dm)
                }
            } else {
                if (e === 1 || e === 9 || e === 11) {
                    if (typeof dn.textContent === "string") {
                        return dn.textContent
                    } else {
                        for (dn = dn.firstChild; dn; dn = dn.nextSibling) {
                            dk += cK(dn)
                        }
                    }
                } else {
                    if (e === 3 || e === 4) {
                        return dn.nodeValue
                    }
                }
            }
            return dk
        };
        cq = cy.selectors = {
            cacheLength: 50,
            createPseudo: cm,
            match: c1,
            find: {},
            relative: {
                ">": {
                    dir: "parentNode",
                    first: true
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: true
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function (e) {
                    e[1] = e[1].replace(cv, c4);
                    e[3] = (e[4] || e[5] || "").replace(cv, c4);
                    if (e[2] === "~=") {
                        e[3] = " " + e[3] + " "
                    }
                    return e.slice(0, 4)
                },
                CHILD: function (e) {
                    e[1] = e[1].toLowerCase();
                    if (e[1].slice(0, 3) === "nth") {
                        if (!e[3]) {
                            cy.error(e[0])
                        }
                        e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * (e[3] === "even" || e[3] === "odd"));
                        e[5] = +((e[7] + e[8]) || e[3] === "odd")
                    } else {
                        if (e[3]) {
                            cy.error(e[0])
                        }
                    }
                    return e
                },
                PSEUDO: function (dk) {
                    var e, dl = !dk[5] && dk[2];
                    if (c1.CHILD.test(dk[0])) {
                        return null
                    }
                    if (dk[4]) {
                        dk[2] = dk[4]
                    } else {
                        if (dl && cS.test(dl) && (e = ci(dl, true)) && (e = dl.indexOf(")", dl.length - e) - dl.length)) {
                            dk[0] = dk[0].slice(0, e);
                            dk[2] = dl.slice(0, e)
                        }
                    }
                    return dk.slice(0, 3)
                }
            },
            filter: {
                TAG: function (e) {
                    if (e === "*") {
                        return function () {
                            return true
                        }
                    }
                    e = e.replace(cv, c4).toLowerCase();
                    return function (dk) {
                        return dk.nodeName && dk.nodeName.toLowerCase() === e
                    }
                },
                CLASS: function (e) {
                    var dk = b8[e + " "];
                    return dk || (dk = new RegExp("(^|" + cs + ")" + e + "(" + cs + "|$)")) && b8(e, function (dl) {
                        return dk.test(dl.className || (typeof dl.getAttribute !== dc && dl.getAttribute("class")) || "")
                    })
                },
                ATTR: function (dl, dk, e) {
                    return function (dn) {
                        var dm = cy.attr(dn, dl);
                        if (dm == null) {
                            return dk === "!="
                        }
                        if (!dk) {
                            return true
                        }
                        dm += "";
                        return dk === "=" ? dm === e : dk === "!=" ? dm !== e : dk === "^=" ? e && dm.indexOf(e) === 0 : dk === "*=" ? e && dm.indexOf(e) > -1 : dk === "$=" ? e && dm.slice(-e.length) === e : dk === "~=" ? (" " + dm + " ").indexOf(e) > -1 : dk === "|=" ? dm === e || dm.slice(0, e.length + 1) === e + "-" : false
                    }
                },
                CHILD: function (dk, dn, dm, dp, dl) {
                    var dr = dk.slice(0, 3) !== "nth",
                        e = dk.slice(-4) !== "last",
                        dq = dn === "of-type";
                    return dp === 1 && dl === 0 ?
                    function (ds) {
                        return !!ds.parentNode
                    } : function (dy, dw, dB) {
                        var ds, dE, dz, dD, dA, dv, dx = dr !== e ? "nextSibling" : "previousSibling",
                            dC = dy.parentNode,
                            du = dq && dy.nodeName.toLowerCase(),
                            dt = !dB && !dq;
                        if (dC) {
                            if (dr) {
                                while (dx) {
                                    dz = dy;
                                    while ((dz = dz[dx])) {
                                        if (dq ? dz.nodeName.toLowerCase() === du : dz.nodeType === 1) {
                                            return false
                                        }
                                    }
                                    dv = dx = dk === "only" && !dv && "nextSibling"
                                }
                                return true
                            }
                            dv = [e ? dC.firstChild : dC.lastChild];
                            if (e && dt) {
                                dE = dC[c8] || (dC[c8] = {});
                                ds = dE[dk] || [];
                                dA = ds[0] === dh && ds[1];
                                dD = ds[0] === dh && ds[2];
                                dz = dA && dC.childNodes[dA];
                                while ((dz = ++dA && dz && dz[dx] || (dD = dA = 0) || dv.pop())) {
                                    if (dz.nodeType === 1 && ++dD && dz === dy) {
                                        dE[dk] = [dh, dA, dD];
                                        break
                                    }
                                }
                            } else {
                                if (dt && (ds = (dy[c8] || (dy[c8] = {}))[dk]) && ds[0] === dh) {
                                    dD = ds[1]
                                } else {
                                    while ((dz = ++dA && dz && dz[dx] || (dD = dA = 0) || dv.pop())) {
                                        if ((dq ? dz.nodeName.toLowerCase() === du : dz.nodeType === 1) && ++dD) {
                                            if (dt) {
                                                (dz[c8] || (dz[c8] = {}))[dk] = [dh, dD]
                                            }
                                            if (dz === dy) {
                                                break
                                            }
                                        }
                                    }
                                }
                            }
                            dD -= dl;
                            return dD === dp || (dD % dp === 0 && dD / dp >= 0)
                        }
                    }
                },
                PSEUDO: function (dm, dl) {
                    var e, dk = cq.pseudos[dm] || cq.setFilters[dm.toLowerCase()] || cy.error("unsupported pseudo: " + dm);
                    if (dk[c8]) {
                        return dk(dl)
                    }
                    if (dk.length > 1) {
                        e = [dm, dm, "", dl];
                        return cq.setFilters.hasOwnProperty(dm.toLowerCase()) ? cm(function (dq, ds) {
                            var dp, dn = dk(dq, dl),
                                dr = dn.length;
                            while (dr--) {
                                dp = cc.call(dq, dn[dr]);
                                dq[dp] = !(ds[dp] = dn[dr])
                            }
                        }) : function (dn) {
                            return dk(dn, 0, e)
                        }
                    }
                    return dk
                }
            },
            pseudos: {
                not: cm(function (e) {
                    var dk = [],
                        dl = [],
                        dm = cV(e.replace(cu, "$1"));
                    return dm[c8] ? cm(function (dp, du, ds, dq) {
                        var dt, dn = dm(dp, null, dq, []),
                            dr = dp.length;
                        while (dr--) {
                            if ((dt = dn[dr])) {
                                dp[dr] = !(du[dr] = dt)
                            }
                        }
                    }) : function (dq, dp, dn) {
                        dk[0] = dq;
                        dm(dk, null, dn, dl);
                        return !dl.pop()
                    }
                }),
                has: cm(function (e) {
                    return function (dk) {
                        return cy(e, dk).length > 0
                    }
                }),
                contains: cm(function (e) {
                    return function (dk) {
                        return (dk.textContent || dk.innerText || cK(dk)).indexOf(e) > -1
                    }
                }),
                lang: cm(function (e) {
                    if (!cT.test(e || "")) {
                        cy.error("unsupported lang: " + e)
                    }
                    e = e.replace(cv, c4).toLowerCase();
                    return function (dl) {
                        var dk;
                        do {
                            if ((dk = cg ? dl.getAttribute("xml:lang") || dl.getAttribute("lang") : dl.lang)) {
                                dk = dk.toLowerCase();
                                return dk === e || dk.indexOf(e + "-") === 0
                            }
                        } while ((dl = dl.parentNode) && dl.nodeType === 1);
                        return false
                    }
                }),
                target: function (e) {
                    var dk = dd.location && dd.location.hash;
                    return dk && dk.slice(1) === e.id
                },
                root: function (e) {
                    return e === cr
                },
                focus: function (e) {
                    return e === cE.activeElement && (!cE.hasFocus || cE.hasFocus()) && !! (e.type || e.href || ~e.tabIndex)
                },
                enabled: function (e) {
                    return e.disabled === false
                },
                disabled: function (e) {
                    return e.disabled === true
                },
                checked: function (e) {
                    var dk = e.nodeName.toLowerCase();
                    return (dk === "input" && !! e.checked) || (dk === "option" && !! e.selected)
                },
                selected: function (e) {
                    if (e.parentNode) {
                        e.parentNode.selectedIndex
                    }
                    return e.selected === true
                },
                empty: function (e) {
                    for (e = e.firstChild; e; e = e.nextSibling) {
                        if (e.nodeName > "@" || e.nodeType === 3 || e.nodeType === 4) {
                            return false
                        }
                    }
                    return true
                },
                parent: function (e) {
                    return !cq.pseudos.empty(e)
                },
                header: function (e) {
                    return co.test(e.nodeName)
                },
                input: function (e) {
                    return cb.test(e.nodeName)
                },
                button: function (dk) {
                    var e = dk.nodeName.toLowerCase();
                    return e === "input" && dk.type === "button" || e === "button"
                },
                text: function (dk) {
                    var e;
                    return dk.nodeName.toLowerCase() === "input" && dk.type === "text" && ((e = dk.getAttribute("type")) == null || e.toLowerCase() === dk.type)
                },
                first: c6(function () {
                    return [0]
                }),
                last: c6(function (e, dk) {
                    return [dk - 1]
                }),
                eq: c6(function (e, dl, dk) {
                    return [dk < 0 ? dk + dl : dk]
                }),
                even: c6(function (e, dl) {
                    var dk = 0;
                    for (; dk < dl; dk += 2) {
                        e.push(dk)
                    }
                    return e
                }),
                odd: c6(function (e, dl) {
                    var dk = 1;
                    for (; dk < dl; dk += 2) {
                        e.push(dk)
                    }
                    return e
                }),
                lt: c6(function (e, dm, dl) {
                    var dk = dl < 0 ? dl + dm : dl;
                    for (; --dk >= 0;) {
                        e.push(dk)
                    }
                    return e
                }),
                gt: c6(function (e, dm, dl) {
                    var dk = dl < 0 ? dl + dm : dl;
                    for (; ++dk < dm;) {
                        e.push(dk)
                    }
                    return e
                })
            }
        };
        for (cA in {
            radio: true,
            checkbox: true,
            file: true,
            password: true,
            image: true
        }) {
            cq.pseudos[cA] = cz(cA)
        }
        for (cA in {
            submit: true,
            reset: true
        }) {
            cq.pseudos[cA] = ca(cA)
        }
        function ci(dn, dt) {
            var dk, dp, dr, ds, dq, dl, e, dm = c7[dn + " "];
            if (dm) {
                return dt ? 0 : dm.slice(0)
            }
            dq = dn;
            dl = [];
            e = cq.preFilter;
            while (dq) {
                if (!dk || (dp = cx.exec(dq))) {
                    if (dp) {
                        dq = dq.slice(dp[0].length) || dq
                    }
                    dl.push(dr = [])
                }
                dk = false;
                if ((dp = cD.exec(dq))) {
                    dk = dp.shift();
                    dr.push({
                        value: dk,
                        type: dp[0].replace(cu, " ")
                    });
                    dq = dq.slice(dk.length)
                }
                for (ds in cq.filter) {
                    if ((dp = c1[ds].exec(dq)) && (!e[ds] || (dp = e[ds](dp)))) {
                        dk = dp.shift();
                        dr.push({
                            value: dk,
                            type: ds,
                            matches: dp
                        });
                        dq = dq.slice(dk.length)
                    }
                }
                if (!dk) {
                    break
                }
            }
            return dt ? dq.length : dq ? cy.error(dn) : c7(dn, dl).slice(0)
        }
        function cj(dm) {
            var dl = 0,
                dk = dm.length,
                e = "";
            for (; dl < dk; dl++) {
                e += dm[dl].value
            }
            return e
        }
        function ct(dn, dl, dm) {
            var e = dl.dir,
                dp = dm && e === "parentNode",
                dk = c3++;
            return dl.first ?
            function (ds, dr, dq) {
                while ((ds = ds[e])) {
                    if (ds.nodeType === 1 || dp) {
                        return dn(ds, dr, dq)
                    }
                }
            } : function (du, ds, dr) {
                var dw, dq, dt, dv = dh + " " + dk;
                if (dr) {
                    while ((du = du[e])) {
                        if (du.nodeType === 1 || dp) {
                            if (dn(du, ds, dr)) {
                                return true
                            }
                        }
                    }
                } else {
                    while ((du = du[e])) {
                        if (du.nodeType === 1 || dp) {
                            dt = du[c8] || (du[c8] = {});
                            if ((dq = dt[e]) && dq[0] === dv) {
                                if ((dw = dq[1]) === true || dw === ce) {
                                    return dw === true
                                }
                            } else {
                                dq = dt[e] = [dv];
                                dq[1] = dn(du, ds, dr) || ce;
                                if (dq[1] === true) {
                                    return true
                                }
                            }
                        }
                    }
                }
            }
        }
        function di(e) {
            return e.length > 1 ?
            function (dn, dm, dk) {
                var dl = e.length;
                while (dl--) {
                    if (!e[dl](dn, dm, dk)) {
                        return false
                    }
                }
                return true
            } : e[0]
        }
        function c0(e, dk, dl, dm, dq) {
            var dn, dt = [],
                dp = 0,
                dr = e.length,
                ds = dk != null;
            for (; dp < dr; dp++) {
                if ((dn = e[dp])) {
                    if (!dl || dl(dn, dm, dq)) {
                        dt.push(dn);
                        if (ds) {
                            dk.push(dp)
                        }
                    }
                }
            }
            return dt
        }
        function ch(dl, dk, dn, dm, dp, e) {
            if (dm && !dm[c8]) {
                dm = ch(dm)
            }
            if (dp && !dp[c8]) {
                dp = ch(dp, e)
            }
            return cm(function (dA, dx, ds, dz) {
                var dC, dy, du, dt = [],
                    dB = [],
                    dr = dx.length,
                    dq = dA || cB(dk || "*", ds.nodeType ? [ds] : ds, []),
                    dv = dl && (dA || !dk) ? c0(dq, dt, dl, ds, dz) : dq,
                    dw = dn ? dp || (dA ? dl : dr || dm) ? [] : dx : dv;
                if (dn) {
                    dn(dv, dw, ds, dz)
                }
                if (dm) {
                    dC = c0(dw, dB);
                    dm(dC, [], ds, dz);
                    dy = dC.length;
                    while (dy--) {
                        if ((du = dC[dy])) {
                            dw[dB[dy]] = !(dv[dB[dy]] = du)
                        }
                    }
                }
                if (dA) {
                    if (dp || dl) {
                        if (dp) {
                            dC = [];
                            dy = dw.length;
                            while (dy--) {
                                if ((du = dw[dy])) {
                                    dC.push((dv[dy] = du))
                                }
                            }
                            dp(null, (dw = []), dC, dz)
                        }
                        dy = dw.length;
                        while (dy--) {
                            if ((du = dw[dy]) && (dC = dp ? cc.call(dA, du) : dt[dy]) > -1) {
                                dA[dC] = !(dx[dC] = du)
                            }
                        }
                    }
                } else {
                    dw = c0(dw === dx ? dw.splice(dr, dw.length) : dw);
                    if (dp) {
                        dp(null, dx, dw, dz)
                    } else {
                        b7.apply(dx, dw)
                    }
                }
            })
        }
        function c9(dq) {
            var dk, dn, dl, dp = dq.length,
                dt = cq.relative[dq[0].type],
                du = dt || cq.relative[" "],
                dm = dt ? 1 : 0,
                dr = ct(function (dv) {
                    return dv === dk
                }, du, true),
                ds = ct(function (dv) {
                    return cc.call(dk, dv) > -1
                }, du, true),
                e = [function (dx, dw, dv) {
                    return (!dt && (dv || dw !== dj)) || ((dk = dw).nodeType ? dr(dx, dw, dv) : ds(dx, dw, dv))
                }];
            for (; dm < dp; dm++) {
                if ((dn = cq.relative[dq[dm].type])) {
                    e = [ct(di(e), dn)]
                } else {
                    dn = cq.filter[dq[dm].type].apply(null, dq[dm].matches);
                    if (dn[c8]) {
                        dl = ++dm;
                        for (; dl < dp; dl++) {
                            if (cq.relative[dq[dl].type]) {
                                break
                            }
                        }
                        return ch(dm > 1 && di(e), dm > 1 && cj(dq.slice(0, dm - 1)).replace(cu, "$1"), dn, dm < dl && c9(dq.slice(dm, dl)), dl < dp && c9((dq = dq.slice(dl))), dl < dp && cj(dq))
                    }
                    e.push(dn)
                }
            }
            return di(e)
        }
        function cX(dm, dl) {
            var dp = 0,
                e = dl.length > 0,
                dn = dm.length > 0,
                dk = function (dz, dt, dy, dx, dF) {
                    var du, dv, dA, dE = [],
                        dD = 0,
                        dw = "0",
                        dq = dz && [],
                        dB = dF != null,
                        dC = dj,
                        ds = dz || dn && cq.find.TAG("*", dF && dt.parentNode || dt),
                        dr = (dh += dC == null ? 1 : Math.random() || 0.1);
                    if (dB) {
                        dj = dt !== cE && dt;
                        ce = dp
                    }
                    for (;
                    (du = ds[dw]) != null; dw++) {
                        if (dn && du) {
                            dv = 0;
                            while ((dA = dm[dv++])) {
                                if (dA(du, dt, dy)) {
                                    dx.push(du);
                                    break
                                }
                            }
                            if (dB) {
                                dh = dr;
                                ce = ++dp
                            }
                        }
                        if (e) {
                            if ((du = !dA && du)) {
                                dD--
                            }
                            if (dz) {
                                dq.push(du)
                            }
                        }
                    }
                    dD += dw;
                    if (e && dw !== dD) {
                        dv = 0;
                        while ((dA = dl[dv++])) {
                            dA(dq, dE, dt, dy)
                        }
                        if (dz) {
                            if (dD > 0) {
                                while (dw--) {
                                    if (!(dq[dw] || dE[dw])) {
                                        dE[dw] = db.call(dx)
                                    }
                                }
                            }
                            dE = c0(dE)
                        }
                        b7.apply(dx, dE);
                        if (dB && !dz && dE.length > 0 && (dD + dl.length) > 1) {
                            cy.uniqueSort(dx)
                        }
                    }
                    if (dB) {
                        dh = dr;
                        dj = dC
                    }
                    return dq
                };
            return e ? cm(dk) : dk
        }
        cV = cy.compile = function (e, dp) {
            var dl, dk = [],
                dn = [],
                dm = cJ[e + " "];
            if (!dm) {
                if (!dp) {
                    dp = ci(e)
                }
                dl = dp.length;
                while (dl--) {
                    dm = c9(dp[dl]);
                    if (dm[c8]) {
                        dk.push(dm)
                    } else {
                        dn.push(dm)
                    }
                }
                dm = cJ(e, cX(dn, dk))
            }
            return dm
        };

        function cB(dk, dn, dm) {
            var dl = 0,
                e = dn.length;
            for (; dl < e; dl++) {
                cy(dk, dn[dl], dm)
            }
            return dm
        }
        function df(dl, e, dm, dq) {
            var dn, ds, dk, dt, dr, dp = ci(dl);
            if (!dq) {
                if (dp.length === 1) {
                    ds = dp[0] = dp[0].slice(0);
                    if (ds.length > 2 && (dk = ds[0]).type === "ID" && e.nodeType === 9 && !cg && cq.relative[ds[1].type]) {
                        e = cq.find.ID(dk.matches[0].replace(cv, c4), e)[0];
                        if (!e) {
                            return dm
                        }
                        dl = dl.slice(ds.shift().value.length)
                    }
                    dn = c1.needsContext.test(dl) ? 0 : ds.length;
                    while (dn--) {
                        dk = ds[dn];
                        if (cq.relative[(dt = dk.type)]) {
                            break
                        }
                        if ((dr = cq.find[dt])) {
                            if ((dq = dr(dk.matches[0].replace(cv, c4), cZ.test(ds[0].type) && e.parentNode || e))) {
                                ds.splice(dn, 1);
                                dl = dq.length && cj(ds);
                                if (!dl) {
                                    b7.apply(dm, cp.call(dq, 0));
                                    return dm
                                }
                                break
                            }
                        }
                    }
                }
            }
            cV(dl, dp)(dq, e, cg, dm, cZ.test(dl));
            return dm
        }
        cq.pseudos.nth = cq.pseudos.eq;

        function cU() {}
        cq.filters = cU.prototype = cq.pseudos;
        cq.setFilters = new cU();
        cY();
        cy.attr = bM.attr;
        bM.find = cy;
        bM.expr = cy.selectors;
        bM.expr[":"] = bM.expr.pseudos;
        bM.unique = cy.uniqueSort;
        bM.text = cy.getText;
        bM.isXMLDoc = cy.isXML;
        bM.contains = cy.contains
    })(a5);
    var al = /Until$/,
        bw = /^(?:parents|prev(?:Until|All))/,
        ap = /^.[^:#\[\.,]*$/,
        z = bM.expr.match.needsContext,
        bA = {
            children: true,
            contents: true,
            next: true,
            prev: true
        };
    bM.fn.extend({
        find: function (b6) {
            var b9, b8, b7, e = this.length;
            if (typeof b6 !== "string") {
                b7 = this;
                return this.pushStack(bM(b6).filter(function () {
                    for (b9 = 0; b9 < e; b9++) {
                        if (bM.contains(b7[b9], this)) {
                            return true
                        }
                    }
                }))
            }
            b8 = [];
            for (b9 = 0; b9 < e; b9++) {
                bM.find(b6, this[b9], b8)
            }
            b8 = this.pushStack(e > 1 ? bM.unique(b8) : b8);
            b8.selector = (this.selector ? this.selector + " " : "") + b6;
            return b8
        },
        has: function (b8) {
            var b7, b6 = bM(b8, this),
                e = b6.length;
            return this.filter(function () {
                for (b7 = 0; b7 < e; b7++) {
                    if (bM.contains(this, b6[b7])) {
                        return true
                    }
                }
            })
        },
        not: function (e) {
            return this.pushStack(aR(this, e, false))
        },
        filter: function (e) {
            return this.pushStack(aR(this, e, true))
        },
        is: function (e) {
            return !!e && (typeof e === "string" ? z.test(e) ? bM(e, this.context).index(this[0]) >= 0 : bM.filter(e, this).length > 0 : this.filter(e).length > 0)
        },
        closest: function (b9, b8) {
            var ca, b7 = 0,
                e = this.length,
                b6 = [],
                cb = z.test(b9) || typeof b9 !== "string" ? bM(b9, b8 || this.context) : 0;
            for (; b7 < e; b7++) {
                ca = this[b7];
                while (ca && ca.ownerDocument && ca !== b8 && ca.nodeType !== 11) {
                    if (cb ? cb.index(ca) > -1 : bM.find.matchesSelector(ca, b9)) {
                        b6.push(ca);
                        break
                    }
                    ca = ca.parentNode
                }
            }
            return this.pushStack(b6.length > 1 ? bM.unique(b6) : b6)
        },
        index: function (e) {
            if (!e) {
                return (this[0] && this[0].parentNode) ? this.first().prevAll().length : -1
            }
            if (typeof e === "string") {
                return bM.inArray(this[0], bM(e))
            }
            return bM.inArray(e.jquery ? e[0] : e, this)
        },
        add: function (e, b6) {
            var b8 = typeof e === "string" ? bM(e, b6) : bM.makeArray(e && e.nodeType ? [e] : e),
                b7 = bM.merge(this.get(), b8);
            return this.pushStack(bM.unique(b7))
        },
        addBack: function (e) {
            return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
        }
    });
    bM.fn.andSelf = bM.fn.addBack;

    function a0(b6, e) {
        do {
            b6 = b6[e]
        } while (b6 && b6.nodeType !== 1);
        return b6
    }
    bM.each({
        parent: function (b6) {
            var e = b6.parentNode;
            return e && e.nodeType !== 11 ? e : null
        },
        parents: function (e) {
            return bM.dir(e, "parentNode")
        },
        parentsUntil: function (b6, e, b7) {
            return bM.dir(b6, "parentNode", b7)
        },
        next: function (e) {
            return a0(e, "nextSibling")
        },
        prev: function (e) {
            return a0(e, "previousSibling")
        },
        nextAll: function (e) {
            return bM.dir(e, "nextSibling")
        },
        prevAll: function (e) {
            return bM.dir(e, "previousSibling")
        },
        nextUntil: function (b6, e, b7) {
            return bM.dir(b6, "nextSibling", b7)
        },
        prevUntil: function (b6, e, b7) {
            return bM.dir(b6, "previousSibling", b7)
        },
        siblings: function (e) {
            return bM.sibling((e.parentNode || {}).firstChild, e)
        },
        children: function (e) {
            return bM.sibling(e.firstChild)
        },
        contents: function (e) {
            return bM.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : bM.merge([], e.childNodes)
        }
    }, function (e, b6) {
        bM.fn[e] = function (b9, b7) {
            var b8 = bM.map(this, b6, b9);
            if (!al.test(e)) {
                b7 = b9
            }
            if (b7 && typeof b7 === "string") {
                b8 = bM.filter(b7, b8)
            }
            b8 = this.length > 1 && !bA[e] ? bM.unique(b8) : b8;
            if (this.length > 1 && bw.test(e)) {
                b8 = b8.reverse()
            }
            return this.pushStack(b8)
        }
    });
    bM.extend({
        filter: function (b7, e, b6) {
            if (b6) {
                b7 = ":not(" + b7 + ")"
            }
            return e.length === 1 ? bM.find.matchesSelector(e[0], b7) ? [e[0]] : [] : bM.find.matches(b7, e)
        },
        dir: function (b7, b6, b9) {
            var e = [],
                b8 = b7[b6];
            while (b8 && b8.nodeType !== 9 && (b9 === aJ || b8.nodeType !== 1 || !bM(b8).is(b9))) {
                if (b8.nodeType === 1) {
                    e.push(b8)
                }
                b8 = b8[b6]
            }
            return e
        },
        sibling: function (b7, b6) {
            var e = [];
            for (; b7; b7 = b7.nextSibling) {
                if (b7.nodeType === 1 && b7 !== b6) {
                    e.push(b7)
                }
            }
            return e
        }
    });

    function aR(b8, b7, e) {
        b7 = b7 || 0;
        if (bM.isFunction(b7)) {
            return bM.grep(b8, function (ca, b9) {
                var cb = !! b7.call(ca, b9, ca);
                return cb === e
            })
        } else {
            if (b7.nodeType) {
                return bM.grep(b8, function (b9) {
                    return (b9 === b7) === e
                })
            } else {
                if (typeof b7 === "string") {
                    var b6 = bM.grep(b8, function (b9) {
                        return b9.nodeType === 1
                    });
                    if (ap.test(b7)) {
                        return bM.filter(b7, b6, !e)
                    } else {
                        b7 = bM.filter(b7, b6)
                    }
                }
            }
        }
        return bM.grep(b8, function (b9) {
            return (bM.inArray(b9, b7) >= 0) === e
        })
    }
    function B(e) {
        var b7 = d.split("|"),
            b6 = e.createDocumentFragment();
        if (b6.createElement) {
            while (b7.length) {
                b6.createElement(b7.pop())
            }
        }
        return b6
    }
    var d = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
        aD = / jQuery\d+="(?:null|\d+)"/g,
        K = new RegExp("<(?:" + d + ")[\\s/>]", "i"),
        b5 = /^\s+/,
        aG = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        m = /<([\w:]+)/,
        b0 = /<tbody/i,
        J = /<|&#?\w+;/,
        an = /<(?:script|style|link)/i,
        q = /^(?:checkbox|radio)$/i,
        bX = /checked\s*(?:[^=]|=\s*.checked.)/i,
        bC = /^$|\/(?:java|ecma)script/i,
        av = /^true\/(.*)/,
        aN = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
        V = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            area: [1, "<map>", "</map>"],
            param: [1, "<object>", "</object>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: bM.support.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
        },
        aV = B(l),
        j = aV.appendChild(l.createElement("div"));
    V.optgroup = V.option;
    V.tbody = V.tfoot = V.colgroup = V.caption = V.thead;
    V.th = V.td;
    bM.fn.extend({
        text: function (e) {
            return bM.access(this, function (b6) {
                return b6 === aJ ? bM.text(this) : this.empty().append((this[0] && this[0].ownerDocument || l).createTextNode(b6))
            }, null, e, arguments.length)
        },
        wrapAll: function (e) {
            if (bM.isFunction(e)) {
                return this.each(function (b7) {
                    bM(this).wrapAll(e.call(this, b7))
                })
            }
            if (this[0]) {
                var b6 = bM(e, this[0].ownerDocument).eq(0).clone(true);
                if (this[0].parentNode) {
                    b6.insertBefore(this[0])
                }
                b6.map(function () {
                    var b7 = this;
                    while (b7.firstChild && b7.firstChild.nodeType === 1) {
                        b7 = b7.firstChild
                    }
                    return b7
                }).append(this)
            }
            return this
        },
        wrapInner: function (e) {
            if (bM.isFunction(e)) {
                return this.each(function (b6) {
                    bM(this).wrapInner(e.call(this, b6))
                })
            }
            return this.each(function () {
                var b6 = bM(this),
                    b7 = b6.contents();
                if (b7.length) {
                    b7.wrapAll(e)
                } else {
                    b6.append(e)
                }
            })
        },
        wrap: function (e) {
            var b6 = bM.isFunction(e);
            return this.each(function (b7) {
                bM(this).wrapAll(b6 ? e.call(this, b7) : e)
            })
        },
        unwrap: function () {
            return this.parent().each(function () {
                if (!bM.nodeName(this, "body")) {
                    bM(this).replaceWith(this.childNodes)
                }
            }).end()
        },
        append: function () {
            return this.domManip(arguments, true, function (e) {
                if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                    this.appendChild(e)
                }
            })
        },
        prepend: function () {
            return this.domManip(arguments, true, function (e) {
                if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
                    this.insertBefore(e, this.firstChild)
                }
            })
        },
        before: function () {
            return this.domManip(arguments, false, function (e) {
                if (this.parentNode) {
                    this.parentNode.insertBefore(e, this)
                }
            })
        },
        after: function () {
            return this.domManip(arguments, false, function (e) {
                if (this.parentNode) {
                    this.parentNode.insertBefore(e, this.nextSibling)
                }
            })
        },
        remove: function (e, b8) {
            var b7, b6 = 0;
            for (;
            (b7 = this[b6]) != null; b6++) {
                if (!e || bM.filter(e, [b7]).length > 0) {
                    if (!b8 && b7.nodeType === 1) {
                        bM.cleanData(k(b7))
                    }
                    if (b7.parentNode) {
                        if (b8 && bM.contains(b7.ownerDocument, b7)) {
                            bv(k(b7, "script"))
                        }
                        b7.parentNode.removeChild(b7)
                    }
                }
            }
            return this
        },
        empty: function () {
            var b6, e = 0;
            for (;
            (b6 = this[e]) != null; e++) {
                if (b6.nodeType === 1) {
                    bM.cleanData(k(b6, false))
                }
                while (b6.firstChild) {
                    b6.removeChild(b6.firstChild)
                }
                if (b6.options && bM.nodeName(b6, "select")) {
                    b6.options.length = 0
                }
            }
            return this
        },
        clone: function (b6, e) {
            b6 = b6 == null ? false : b6;
            e = e == null ? b6 : e;
            return this.map(function () {
                return bM.clone(this, b6, e)
            })
        },
        html: function (e) {
            return bM.access(this, function (b9) {
                var b8 = this[0] || {},
                    b7 = 0,
                    b6 = this.length;
                if (b9 === aJ) {
                    return b8.nodeType === 1 ? b8.innerHTML.replace(aD, "") : aJ
                }
                if (typeof b9 === "string" && !an.test(b9) && (bM.support.htmlSerialize || !K.test(b9)) && (bM.support.leadingWhitespace || !b5.test(b9)) && !V[(m.exec(b9) || ["", ""])[1].toLowerCase()]) {
                    b9 = b9.replace(aG, "<$1></$2>");
                    try {
                        for (; b7 < b6; b7++) {
                            b8 = this[b7] || {};
                            if (b8.nodeType === 1) {
                                bM.cleanData(k(b8, false));
                                b8.innerHTML = b9
                            }
                        }
                        b8 = 0
                    } catch (ca) {}
                }
                if (b8) {
                    this.empty().append(b9)
                }
            }, null, e, arguments.length)
        },
        replaceWith: function (b6) {
            var e = bM.isFunction(b6);
            if (!e && typeof b6 !== "string") {
                b6 = bM(b6).not(this).detach()
            }
            return this.domManip([b6], true, function (b9) {
                var b8 = this.nextSibling,
                    b7 = this.parentNode;
                if (b7) {
                    bM(this).remove();
                    b7.insertBefore(b9, b8)
                }
            })
        },
        detach: function (e) {
            return this.remove(e, true)
        },
        domManip: function (cd, cj, ci) {
            cd = aL.apply([], cd);
            var cb, b7, e, b9, cg, cc, ca = 0,
                b8 = this.length,
                cf = this,
                ch = b8 - 1,
                ce = cd[0],
                b6 = bM.isFunction(ce);
            if (b6 || !(b8 <= 1 || typeof ce !== "string" || bM.support.checkClone || !bX.test(ce))) {
                return this.each(function (cl) {
                    var ck = cf.eq(cl);
                    if (b6) {
                        cd[0] = ce.call(this, cl, cj ? ck.html() : aJ)
                    }
                    ck.domManip(cd, cj, ci)
                })
            }
            if (b8) {
                cc = bM.buildFragment(cd, this[0].ownerDocument, false, this);
                cb = cc.firstChild;
                if (cc.childNodes.length === 1) {
                    cc = cb
                }
                if (cb) {
                    cj = cj && bM.nodeName(cb, "tr");
                    b9 = bM.map(k(cc, "script"), u);
                    e = b9.length;
                    for (; ca < b8; ca++) {
                        b7 = cc;
                        if (ca !== ch) {
                            b7 = bM.clone(b7, true, true);
                            if (e) {
                                bM.merge(b9, k(b7, "script"))
                            }
                        }
                        ci.call(cj && bM.nodeName(this[ca], "table") ? y(this[ca], "tbody") : this[ca], b7, ca)
                    }
                    if (e) {
                        cg = b9[b9.length - 1].ownerDocument;
                        bM.map(b9, bf);
                        for (ca = 0; ca < e; ca++) {
                            b7 = b9[ca];
                            if (bC.test(b7.type || "") && !bM._data(b7, "globalEval") && bM.contains(cg, b7)) {
                                if (b7.src) {
                                    bM.ajax({
                                        url: b7.src,
                                        type: "GET",
                                        dataType: "script",
                                        async: false,
                                        global: false,
                                        "throws": true
                                    })
                                } else {
                                    bM.globalEval((b7.text || b7.textContent || b7.innerHTML || "").replace(aN, ""))
                                }
                            }
                        }
                    }
                    cc = cb = null
                }
            }
            return this
        }
    });

    function y(b6, e) {
        return b6.getElementsByTagName(e)[0] || b6.appendChild(b6.ownerDocument.createElement(e))
    }
    function u(b6) {
        var e = b6.getAttributeNode("type");
        b6.type = (e && e.specified) + "/" + b6.type;
        return b6
    }
    function bf(b6) {
        var e = av.exec(b6.type);
        if (e) {
            b6.type = e[1]
        } else {
            b6.removeAttribute("type")
        }
        return b6
    }
    function bv(e, b7) {
        var b8, b6 = 0;
        for (;
        (b8 = e[b6]) != null; b6++) {
            bM._data(b8, "globalEval", !b7 || bM._data(b7[b6], "globalEval"))
        }
    }
    function aw(cc, b6) {
        if (b6.nodeType !== 1 || !bM.hasData(cc)) {
            return
        }
        var b9, b8, e, cb = bM._data(cc),
            ca = bM._data(b6, cb),
            b7 = cb.events;
        if (b7) {
            delete ca.handle;
            ca.events = {};
            for (b9 in b7) {
                for (b8 = 0, e = b7[b9].length; b8 < e; b8++) {
                    bM.event.add(b6, b9, b7[b9][b8])
                }
            }
        }
        if (ca.data) {
            ca.data = bM.extend({}, ca.data)
        }
    }
    function R(b9, b6) {
        var ca, b8, b7;
        if (b6.nodeType !== 1) {
            return
        }
        ca = b6.nodeName.toLowerCase();
        if (!bM.support.noCloneEvent && b6[bM.expando]) {
            b7 = bM._data(b6);
            for (b8 in b7.events) {
                bM.removeEvent(b6, b8, b7.handle)
            }
            b6.removeAttribute(bM.expando)
        }
        if (ca === "script" && b6.text !== b9.text) {
            u(b6).text = b9.text;
            bf(b6)
        } else {
            if (ca === "object") {
                if (b6.parentNode) {
                    b6.outerHTML = b9.outerHTML
                }
                if (bM.support.html5Clone && (b9.innerHTML && !bM.trim(b6.innerHTML))) {
                    b6.innerHTML = b9.innerHTML
                }
            } else {
                if (ca === "input" && q.test(b9.type)) {
                    b6.defaultChecked = b6.checked = b9.checked;
                    if (b6.value !== b9.value) {
                        b6.value = b9.value
                    }
                } else {
                    if (ca === "option") {
                        b6.defaultSelected = b6.selected = b9.defaultSelected
                    } else {
                        if (ca === "input" || ca === "textarea") {
                            b6.defaultValue = b9.defaultValue
                        }
                    }
                }
            }
        }
    }
    bM.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (e, b6) {
        bM.fn[e] = function (b7) {
            var b8, ca = 0,
                b9 = [],
                cc = bM(b7),
                cb = cc.length - 1;
            for (; ca <= cb; ca++) {
                b8 = ca === cb ? this : this.clone(true);
                bM(cc[ca])[b6](b8);
                aq.apply(b9, b8.get())
            }
            return this.pushStack(b9)
        }
    });

    function k(b8, e) {
        var b6, b9, b7 = 0,
            ca = typeof b8.getElementsByTagName !== aF ? b8.getElementsByTagName(e || "*") : typeof b8.querySelectorAll !== aF ? b8.querySelectorAll(e || "*") : aJ;
        if (!ca) {
            for (ca = [], b6 = b8.childNodes || b8;
            (b9 = b6[b7]) != null; b7++) {
                if (!e || bM.nodeName(b9, e)) {
                    ca.push(b9)
                } else {
                    bM.merge(ca, k(b9, e))
                }
            }
        }
        return e === aJ || e && bM.nodeName(b8, e) ? bM.merge([b8], ca) : ca
    }
    function bY(e) {
        if (q.test(e.type)) {
            e.defaultChecked = e.checked
        }
    }
    bM.extend({
        clone: function (b6, b8, e) {
            var ca, b7, cd, b9, cb, cc = bM.contains(b6.ownerDocument, b6);
            if (bM.support.html5Clone || bM.isXMLDoc(b6) || !K.test("<" + b6.nodeName + ">")) {
                cd = b6.cloneNode(true)
            } else {
                j.innerHTML = b6.outerHTML;
                j.removeChild(cd = j.firstChild)
            }
            if ((!bM.support.noCloneEvent || !bM.support.noCloneChecked) && (b6.nodeType === 1 || b6.nodeType === 11) && !bM.isXMLDoc(b6)) {
                ca = k(cd);
                cb = k(b6);
                for (b9 = 0;
                (b7 = cb[b9]) != null; ++b9) {
                    if (ca[b9]) {
                        R(b7, ca[b9])
                    }
                }
            }
            if (b8) {
                if (e) {
                    cb = cb || k(b6);
                    ca = ca || k(cd);
                    for (b9 = 0;
                    (b7 = cb[b9]) != null; b9++) {
                        aw(b7, ca[b9])
                    }
                } else {
                    aw(b6, cd)
                }
            }
            ca = k(cd, "script");
            if (ca.length > 0) {
                bv(ca, !cc && k(b6, "script"))
            }
            ca = cb = b7 = null;
            return cd
        },
        buildFragment: function (b6, b8, cd, ci) {
            var ce, ca, cc, ch, cj, cg, b7, cb = b6.length,
                b9 = B(b8),
                e = [],
                cf = 0;
            for (; cf < cb; cf++) {
                ca = b6[cf];
                if (ca || ca === 0) {
                    if (bM.type(ca) === "object") {
                        bM.merge(e, ca.nodeType ? [ca] : ca)
                    } else {
                        if (!J.test(ca)) {
                            e.push(b8.createTextNode(ca))
                        } else {
                            ch = ch || b9.appendChild(b8.createElement("div"));
                            cj = (m.exec(ca) || ["", ""])[1].toLowerCase();
                            b7 = V[cj] || V._default;
                            ch.innerHTML = b7[1] + ca.replace(aG, "<$1></$2>") + b7[2];
                            ce = b7[0];
                            while (ce--) {
                                ch = ch.lastChild
                            }
                            if (!bM.support.leadingWhitespace && b5.test(ca)) {
                                e.push(b8.createTextNode(b5.exec(ca)[0]))
                            }
                            if (!bM.support.tbody) {
                                ca = cj === "table" && !b0.test(ca) ? ch.firstChild : b7[1] === "<table>" && !b0.test(ca) ? ch : 0;
                                ce = ca && ca.childNodes.length;
                                while (ce--) {
                                    if (bM.nodeName((cg = ca.childNodes[ce]), "tbody") && !cg.childNodes.length) {
                                        ca.removeChild(cg)
                                    }
                                }
                            }
                            bM.merge(e, ch.childNodes);
                            ch.textContent = "";
                            while (ch.firstChild) {
                                ch.removeChild(ch.firstChild)
                            }
                            ch = b9.lastChild
                        }
                    }
                }
            }
            if (ch) {
                b9.removeChild(ch)
            }
            if (!bM.support.appendChecked) {
                bM.grep(k(e, "input"), bY)
            }
            cf = 0;
            while ((ca = e[cf++])) {
                if (ci && bM.inArray(ca, ci) !== -1) {
                    continue
                }
                cc = bM.contains(ca.ownerDocument, ca);
                ch = k(b9.appendChild(ca), "script");
                if (cc) {
                    bv(ch)
                }
                if (cd) {
                    ce = 0;
                    while ((ca = ch[ce++])) {
                        if (bC.test(ca.type || "")) {
                            cd.push(ca)
                        }
                    }
                }
            }
            ch = null;
            return b9
        },
        cleanData: function (b6, ce) {
            var b8, cd, b7, b9, ca = 0,
                cf = bM.expando,
                e = bM.cache,
                cb = bM.support.deleteExpando,
                cc = bM.event.special;
            for (;
            (b8 = b6[ca]) != null; ca++) {
                if (ce || bM.acceptData(b8)) {
                    b7 = b8[cf];
                    b9 = b7 && e[b7];
                    if (b9) {
                        if (b9.events) {
                            for (cd in b9.events) {
                                if (cc[cd]) {
                                    bM.event.remove(b8, cd)
                                } else {
                                    bM.removeEvent(b8, cd, b9.handle)
                                }
                            }
                        }
                        if (e[b7]) {
                            delete e[b7];
                            if (cb) {
                                delete b8[cf]
                            } else {
                                if (typeof b8.removeAttribute !== aF) {
                                    b8.removeAttribute(cf)
                                } else {
                                    b8[cf] = null
                                }
                            }
                            a9.push(b7)
                        }
                    }
                }
            }
        }
    });
    var aH, br, F, bj = /alpha\([^)]*\)/i,
        aW = /opacity\s*=\s*([^)]*)/,
        bq = /^(top|right|bottom|left)$/,
        G = /^(none|table(?!-c[ea]).+)/,
        a1 = /^margin/,
        bc = new RegExp("^(" + bD + ")(.*)$", "i"),
        Y = new RegExp("^(" + bD + ")(?!px)[a-z%]+$", "i"),
        U = new RegExp("^([+-])=(" + bD + ")", "i"),
        bm = {
            BODY: "block"
        },
        be = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        bF = {
            letterSpacing: 0,
            fontWeight: 400
        },
        bW = ["Top", "Right", "Bottom", "Left"],
        ay = ["Webkit", "O", "Moz", "ms"];

    function b(b8, b6) {
        if (b6 in b8) {
            return b6
        }
        var b9 = b6.charAt(0).toUpperCase() + b6.slice(1),
            e = b6,
            b7 = ay.length;
        while (b7--) {
            b6 = ay[b7] + b9;
            if (b6 in b8) {
                return b6
            }
        }
        return e
    }
    function Q(b6, e) {
        b6 = e || b6;
        return bM.css(b6, "display") === "none" || !bM.contains(b6.ownerDocument, b6)
    }
    function p(cb, e) {
        var cc, b9, ca, b6 = [],
            b7 = 0,
            b8 = cb.length;
        for (; b7 < b8; b7++) {
            b9 = cb[b7];
            if (!b9.style) {
                continue
            }
            b6[b7] = bM._data(b9, "olddisplay");
            cc = b9.style.display;
            if (e) {
                if (!b6[b7] && cc === "none") {
                    b9.style.display = ""
                }
                if (b9.style.display === "" && Q(b9)) {
                    b6[b7] = bM._data(b9, "olddisplay", bH(b9.nodeName))
                }
            } else {
                if (!b6[b7]) {
                    ca = Q(b9);
                    if (cc && cc !== "none" || !ca) {
                        bM._data(b9, "olddisplay", ca ? cc : bM.css(b9, "display"))
                    }
                }
            }
        }
        for (b7 = 0; b7 < b8; b7++) {
            b9 = cb[b7];
            if (!b9.style) {
                continue
            }
            if (!e || b9.style.display === "none" || b9.style.display === "") {
                b9.style.display = e ? b6[b7] || "" : "none"
            }
        }
        return cb
    }
    bM.fn.extend({
        css: function (e, b6) {
            return bM.access(this, function (cb, b8, cc) {
                var b7, ca, cd = {},
                    b9 = 0;
                if (bM.isArray(b8)) {
                    ca = br(cb);
                    b7 = b8.length;
                    for (; b9 < b7; b9++) {
                        cd[b8[b9]] = bM.css(cb, b8[b9], false, ca)
                    }
                    return cd
                }
                return cc !== aJ ? bM.style(cb, b8, cc) : bM.css(cb, b8)
            }, e, b6, arguments.length > 1)
        },
        show: function () {
            return p(this, true)
        },
        hide: function () {
            return p(this)
        },
        toggle: function (b6) {
            var e = typeof b6 === "boolean";
            return this.each(function () {
                if (e ? b6 : Q(this)) {
                    bM(this).show()
                } else {
                    bM(this).hide()
                }
            })
        }
    });
    bM.extend({
        cssHooks: {
            opacity: {
                get: function (b7, b6) {
                    if (b6) {
                        var e = F(b7, "opacity");
                        return e === "" ? "1" : e
                    }
                }
            }
        },
        cssNumber: {
            columnCount: true,
            fillOpacity: true,
            fontWeight: true,
            lineHeight: true,
            opacity: true,
            orphans: true,
            widows: true,
            zIndex: true,
            zoom: true
        },
        cssProps: {
            "float": bM.support.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function (b8, b7, ce, b9) {
            if (!b8 || b8.nodeType === 3 || b8.nodeType === 8 || !b8.style) {
                return
            }
            var cc, cd, cf, ca = bM.camelCase(b7),
                b6 = b8.style;
            b7 = bM.cssProps[ca] || (bM.cssProps[ca] = b(b6, ca));
            cf = bM.cssHooks[b7] || bM.cssHooks[ca];
            if (ce !== aJ) {
                cd = typeof ce;
                if (cd === "string" && (cc = U.exec(ce))) {
                    ce = (cc[1] + 1) * cc[2] + parseFloat(bM.css(b8, b7));
                    cd = "number"
                }
                if (ce == null || cd === "number" && isNaN(ce)) {
                    return
                }
                if (cd === "number" && !bM.cssNumber[ca]) {
                    ce += "px"
                }
                if (!bM.support.clearCloneStyle && ce === "" && b7.indexOf("background") === 0) {
                    b6[b7] = "inherit"
                }
                if (!cf || !("set" in cf) || (ce = cf.set(b8, ce, b9)) !== aJ) {
                    try {
                        b6[b7] = ce
                    } catch (cb) {}
                }
            } else {
                if (cf && "get" in cf && (cc = cf.get(b8, false, b9)) !== aJ) {
                    return cc
                }
                return b6[b7]
            }
        },
        css: function (cb, b9, b6, ca) {
            var b8, cc, e, b7 = bM.camelCase(b9);
            b9 = bM.cssProps[b7] || (bM.cssProps[b7] = b(cb.style, b7));
            e = bM.cssHooks[b9] || bM.cssHooks[b7];
            if (e && "get" in e) {
                cc = e.get(cb, true, b6)
            }
            if (cc === aJ) {
                cc = F(cb, b9, ca)
            }
            if (cc === "normal" && b9 in bF) {
                cc = bF[b9]
            }
            if (b6 === "" || b6) {
                b8 = parseFloat(cc);
                return b6 === true || bM.isNumeric(b8) ? b8 || 0 : cc
            }
            return cc
        },
        swap: function (ca, b9, cb, b8) {
            var b7, b6, e = {};
            for (b6 in b9) {
                e[b6] = ca.style[b6];
                ca.style[b6] = b9[b6]
            }
            b7 = cb.apply(ca, b8 || []);
            for (b6 in b9) {
                ca.style[b6] = e[b6]
            }
            return b7
        }
    });
    if (a5.getComputedStyle) {
        br = function (e) {
            return a5.getComputedStyle(e, null)
        };
        F = function (b9, b7, cb) {
            var b8, b6, cd, ca = cb || br(b9),
                cc = ca ? ca.getPropertyValue(b7) || ca[b7] : aJ,
                e = b9.style;
            if (ca) {
                if (cc === "" && !bM.contains(b9.ownerDocument, b9)) {
                    cc = bM.style(b9, b7)
                }
                if (Y.test(cc) && a1.test(b7)) {
                    b8 = e.width;
                    b6 = e.minWidth;
                    cd = e.maxWidth;
                    e.minWidth = e.maxWidth = e.width = cc;
                    cc = ca.width;
                    e.width = b8;
                    e.minWidth = b6;
                    e.maxWidth = cd
                }
            }
            return cc
        }
    } else {
        if (l.documentElement.currentStyle) {
            br = function (e) {
                return e.currentStyle
            };
            F = function (b8, b6, cb) {
                var b7, ca, cc, b9 = cb || br(b8),
                    cd = b9 ? b9[b6] : aJ,
                    e = b8.style;
                if (cd == null && e && e[b6]) {
                    cd = e[b6]
                }
                if (Y.test(cd) && !bq.test(b6)) {
                    b7 = e.left;
                    ca = b8.runtimeStyle;
                    cc = ca && ca.left;
                    if (cc) {
                        ca.left = b8.currentStyle.left
                    }
                    e.left = b6 === "fontSize" ? "1em" : cd;
                    cd = e.pixelLeft + "px";
                    e.left = b7;
                    if (cc) {
                        ca.left = cc
                    }
                }
                return cd === "" ? "auto" : cd
            }
        }
    }
    function aM(e, b7, b8) {
        var b6 = bc.exec(b7);
        return b6 ? Math.max(0, b6[1] - (b8 || 0)) + (b6[2] || "px") : b7
    }
    function az(b9, b6, e, cb, b8) {
        var b7 = e === (cb ? "border" : "content") ? 4 : b6 === "width" ? 1 : 0,
            ca = 0;
        for (; b7 < 4; b7 += 2) {
            if (e === "margin") {
                ca += bM.css(b9, e + bW[b7], true, b8)
            }
            if (cb) {
                if (e === "content") {
                    ca -= bM.css(b9, "padding" + bW[b7], true, b8)
                }
                if (e !== "margin") {
                    ca -= bM.css(b9, "border" + bW[b7] + "Width", true, b8)
                }
            } else {
                ca += bM.css(b9, "padding" + bW[b7], true, b8);
                if (e !== "padding") {
                    ca += bM.css(b9, "border" + bW[b7] + "Width", true, b8)
                }
            }
        }
        return ca
    }
    function v(b9, b6, e) {
        var b8 = true,
            ca = b6 === "width" ? b9.offsetWidth : b9.offsetHeight,
            b7 = br(b9),
            cb = bM.support.boxSizing && bM.css(b9, "boxSizing", false, b7) === "border-box";
        if (ca <= 0 || ca == null) {
            ca = F(b9, b6, b7);
            if (ca < 0 || ca == null) {
                ca = b9.style[b6]
            }
            if (Y.test(ca)) {
                return ca
            }
            b8 = cb && (bM.support.boxSizingReliable || ca === b9.style[b6]);
            ca = parseFloat(ca) || 0
        }
        return (ca + az(b9, b6, e || (cb ? "border" : "content"), b8, b7)) + "px"
    }
    function bH(b7) {
        var b6 = l,
            e = bm[b7];
        if (!e) {
            e = a4(b7, b6);
            if (e === "none" || !e) {
                aH = (aH || bM("<iframe frameborder='0' width='0' height='0'/>").css("cssText", "display:block !important")).appendTo(b6.documentElement);
                b6 = (aH[0].contentWindow || aH[0].contentDocument).document;
                b6.write("<!doctype html><html><body>");
                b6.close();
                e = a4(b7, b6);
                aH.detach()
            }
            bm[b7] = e
        }
        return e
    }
    function a4(e, b8) {
        var b6 = bM(b8.createElement(e)).appendTo(b8.body),
            b7 = bM.css(b6[0], "display");
        b6.remove();
        return b7
    }
    bM.each(["height", "width"], function (b6, e) {
        bM.cssHooks[e] = {
            get: function (b9, b8, b7) {
                if (b8) {
                    return b9.offsetWidth === 0 && G.test(bM.css(b9, "display")) ? bM.swap(b9, be, function () {
                        return v(b9, e, b7)
                    }) : v(b9, e, b7)
                }
            },
            set: function (b9, ca, b7) {
                var b8 = b7 && br(b9);
                return aM(b9, ca, b7 ? az(b9, e, b7, bM.support.boxSizing && bM.css(b9, "boxSizing", false, b8) === "border-box", b8) : 0)
            }
        }
    });
    if (!bM.support.opacity) {
        bM.cssHooks.opacity = {
            get: function (b6, e) {
                return aW.test((e && b6.currentStyle ? b6.currentStyle.filter : b6.style.filter) || "") ? (0.01 * parseFloat(RegExp.$1)) + "" : e ? "1" : ""
            },
            set: function (b9, ca) {
                var b8 = b9.style,
                    b6 = b9.currentStyle,
                    e = bM.isNumeric(ca) ? "alpha(opacity=" + ca * 100 + ")" : "",
                    b7 = b6 && b6.filter || b8.filter || "";
                b8.zoom = 1;
                if ((ca >= 1 || ca === "") && bM.trim(b7.replace(bj, "")) === "" && b8.removeAttribute) {
                    b8.removeAttribute("filter");
                    if (ca === "" || b6 && !b6.filter) {
                        return
                    }
                }
                b8.filter = bj.test(b7) ? b7.replace(bj, e) : b7 + " " + e
            }
        }
    }
    bM(function () {
        if (!bM.support.reliableMarginRight) {
            bM.cssHooks.marginRight = {
                get: function (b6, e) {
                    if (e) {
                        return bM.swap(b6, {
                            display: "inline-block"
                        }, F, [b6, "marginRight"])
                    }
                }
            }
        }
        if (!bM.support.pixelPosition && bM.fn.position) {
            bM.each(["top", "left"], function (e, b6) {
                bM.cssHooks[b6] = {
                    get: function (b8, b7) {
                        if (b7) {
                            b7 = F(b8, b6);
                            return Y.test(b7) ? bM(b8).position()[b6] + "px" : b7
                        }
                    }
                }
            })
        }
    });
    if (bM.expr && bM.expr.filters) {
        bM.expr.filters.hidden = function (e) {
            return e.offsetWidth <= 0 && e.offsetHeight <= 0 || (!bM.support.reliableHiddenOffsets && ((e.style && e.style.display) || bM.css(e, "display")) === "none")
        };
        bM.expr.filters.visible = function (e) {
            return !bM.expr.filters.hidden(e)
        }
    }
    bM.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function (e, b6) {
        bM.cssHooks[e + b6] = {
            expand: function (b9) {
                var b8 = 0,
                    b7 = {},
                    ca = typeof b9 === "string" ? b9.split(" ") : [b9];
                for (; b8 < 4; b8++) {
                    b7[e + bW[b8] + b6] = ca[b8] || ca[b8 - 2] || ca[0]
                }
                return b7
            }
        };
        if (!a1.test(e)) {
            bM.cssHooks[e + b6].set = aM
        }
    });
    var by = /%20/g,
        aU = /\[\]$/,
        W = /\r?\n/g,
        c = /^(?:submit|button|image|reset|file)$/i,
        ax = /^(?:input|select|textarea|keygen)/i;
    bM.fn.extend({
        serialize: function () {
            return bM.param(this.serializeArray())
        },
        serializeArray: function () {
            return this.map(function () {
                var e = bM.prop(this, "elements");
                return e ? bM.makeArray(e) : this
            }).filter(function () {
                var e = this.type;
                return this.name && !bM(this).is(":disabled") && ax.test(this.nodeName) && !c.test(e) && (this.checked || !q.test(e))
            }).map(function (e, b6) {
                var b7 = bM(this).val();
                return b7 == null ? null : bM.isArray(b7) ? bM.map(b7, function (b8) {
                    return {
                        name: b6.name,
                        value: b8.replace(W, "\r\n")
                    }
                }) : {
                    name: b6.name,
                    value: b7.replace(W, "\r\n")
                }
            }).get()
        }
    });
    bM.param = function (e, b7) {
        var b8, b6 = [],
            b9 = function (ca, cb) {
                cb = bM.isFunction(cb) ? cb() : (cb == null ? "" : cb);
                b6[b6.length] = encodeURIComponent(ca) + "=" + encodeURIComponent(cb)
            };
        if (b7 === aJ) {
            b7 = bM.ajaxSettings && bM.ajaxSettings.traditional
        }
        if (bM.isArray(e) || (e.jquery && !bM.isPlainObject(e))) {
            bM.each(e, function () {
                b9(this.name, this.value)
            })
        } else {
            for (b8 in e) {
                i(b8, e[b8], b7, b9)
            }
        }
        return b6.join("&").replace(by, "+")
    };

    function i(b7, b9, b6, b8) {
        var e;
        if (bM.isArray(b9)) {
            bM.each(b9, function (cb, ca) {
                if (b6 || aU.test(b7)) {
                    b8(b7, ca)
                } else {
                    i(b7 + "[" + (typeof ca === "object" ? cb : "") + "]", ca, b6, b8)
                }
            })
        } else {
            if (!b6 && bM.type(b9) === "object") {
                for (e in b9) {
                    i(b7 + "[" + e + "]", b9[e], b6, b8)
                }
            } else {
                b8(b7, b9)
            }
        }
    }
    bM.each(("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu").split(" "), function (b6, e) {
        bM.fn[e] = function (b8, b7) {
            return arguments.length > 0 ? this.on(e, null, b8, b7) : this.trigger(e)
        }
    });
    bM.fn.hover = function (e, b6) {
        return this.mouseenter(e).mouseleave(b6 || e)
    };
    var b4, aa, bR = bM.now(),
        aC = /\?/,
        ar = /#.*$/,
        P = /([?&])_=[^&]*/,
        ai = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg,
        C = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
        o = /^(?:GET|HEAD)$/,
        aK = /^\/\//,
        aX = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,
        b3 = bM.fn.load,
        w = {},
        ba = {},
        aZ = "*/".concat("*");
    try {
        aa = aO.href
    } catch (bi) {
        aa = l.createElement("a");
        aa.href = "";
        aa = aa.href
    }
    b4 = aX.exec(aa.toLowerCase()) || [];

    function bO(e) {
        return function (b9, ca) {
            if (typeof b9 !== "string") {
                ca = b9;
                b9 = "*"
            }
            var b6, b7 = 0,
                b8 = b9.toLowerCase().match(ae) || [];
            if (bM.isFunction(ca)) {
                while ((b6 = b8[b7++])) {
                    if (b6[0] === "+") {
                        b6 = b6.slice(1) || "*";
                        (e[b6] = e[b6] || []).unshift(ca)
                    } else {
                        (e[b6] = e[b6] || []).push(ca)
                    }
                }
            }
        }
    }
    function n(e, b7, cb, b8) {
        var b6 = {},
            b9 = (e === ba);

        function ca(cc) {
            var cd;
            b6[cc] = true;
            bM.each(e[cc] || [], function (cf, ce) {
                var cg = ce(b7, cb, b8);
                if (typeof cg === "string" && !b9 && !b6[cg]) {
                    b7.dataTypes.unshift(cg);
                    ca(cg);
                    return false
                } else {
                    if (b9) {
                        return !(cd = cg)
                    }
                }
            });
            return cd
        }
        return ca(b7.dataTypes[0]) || !b6["*"] && ca("*")
    }
    function r(b7, b8) {
        var e, b6, b9 = bM.ajaxSettings.flatOptions || {};
        for (b6 in b8) {
            if (b8[b6] !== aJ) {
                (b9[b6] ? b7 : (e || (e = {})))[b6] = b8[b6]
            }
        }
        if (e) {
            bM.extend(true, b7, e)
        }
        return b7
    }
    bM.fn.load = function (b8, cb, cc) {
        if (typeof b8 !== "string" && b3) {
            return b3.apply(this, arguments)
        }
        var e, b7, b9, b6 = this,
            ca = b8.indexOf(" ");
        if (ca >= 0) {
            e = b8.slice(ca, b8.length);
            b8 = b8.slice(0, ca)
        }
        if (bM.isFunction(cb)) {
            cc = cb;
            cb = aJ
        } else {
            if (cb && typeof cb === "object") {
                b9 = "POST"
            }
        }
        if (b6.length > 0) {
            bM.ajax({
                url: b8,
                type: b9,
                dataType: "html",
                data: cb
            }).done(function (cd) {
                b7 = arguments;
                b6.html(e ? bM("<div>").append(bM.parseHTML(cd)).find(e) : cd)
            }).complete(cc &&
            function (ce, cd) {
                b6.each(cc, b7 || [ce.responseText, cd, ce])
            })
        }
        return this
    };
    bM.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, b6) {
        bM.fn[b6] = function (b7) {
            return this.on(b6, b7)
        }
    });
    bM.each(["get", "post"], function (e, b6) {
        bM[b6] = function (b7, b9, ca, b8) {
            if (bM.isFunction(b9)) {
                b8 = b8 || ca;
                ca = b9;
                b9 = aJ
            }
            return bM.ajax({
                url: b7,
                type: b6,
                dataType: b8,
                data: b9,
                success: ca
            })
        }
    });
    bM.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: aa,
            type: "GET",
            isLocal: C.test(b4[1]),
            global: true,
            processData: true,
            async: true,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": aZ,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText"
            },
            converters: {
                "* text": a5.String,
                "text html": true,
                "text json": bM.parseJSON,
                "text xml": bM.parseXML
            },
            flatOptions: {
                url: true,
                context: true
            }
        },
        ajaxSetup: function (b6, e) {
            return e ? r(r(b6, bM.ajaxSettings), e) : r(bM.ajaxSettings, b6)
        },
        ajaxPrefilter: bO(w),
        ajaxTransport: bO(ba),
        ajax: function (ca, b7) {
            if (typeof ca === "object") {
                b7 = ca;
                ca = aJ
            }
            b7 = b7 || {};
            var cj, cl, cb, cq, cf, b6, cm, b8, ce = bM.ajaxSetup({}, b7),
                cs = ce.context || ce,
                ch = ce.context && (cs.nodeType || cs.jquery) ? bM(cs) : bM.event,
                cr = bM.Deferred(),
                co = bM.Callbacks("once memory"),
                cc = ce.statusCode || {},
                ci = {},
                cp = {},
                b9 = 0,
                cd = "canceled",
                ck = {
                    readyState: 0,
                    getResponseHeader: function (ct) {
                        var e;
                        if (b9 === 2) {
                            if (!b8) {
                                b8 = {};
                                while ((e = ai.exec(cq))) {
                                    b8[e[1].toLowerCase()] = e[2]
                                }
                            }
                            e = b8[ct.toLowerCase()]
                        }
                        return e == null ? null : e
                    },
                    getAllResponseHeaders: function () {
                        return b9 === 2 ? cq : null
                    },
                    setRequestHeader: function (ct, cu) {
                        var e = ct.toLowerCase();
                        if (!b9) {
                            ct = cp[e] = cp[e] || ct;
                            ci[ct] = cu
                        }
                        return this
                    },
                    overrideMimeType: function (e) {
                        if (!b9) {
                            ce.mimeType = e
                        }
                        return this
                    },
                    statusCode: function (ct) {
                        var e;
                        if (ct) {
                            if (b9 < 2) {
                                for (e in ct) {
                                    cc[e] = [cc[e], ct[e]]
                                }
                            } else {
                                ck.always(ct[ck.status])
                            }
                        }
                        return this
                    },
                    abort: function (ct) {
                        var e = ct || cd;
                        if (cm) {
                            cm.abort(e)
                        }
                        cg(0, e);
                        return this
                    }
                };
            cr.promise(ck).complete = co.add;
            ck.success = ck.done;
            ck.error = ck.fail;
            ce.url = ((ca || ce.url || aa) + "").replace(ar, "").replace(aK, b4[1] + "//");
            ce.type = b7.method || b7.type || ce.method || ce.type;
            ce.dataTypes = bM.trim(ce.dataType || "*").toLowerCase().match(ae) || [""];
            if (ce.crossDomain == null) {
                cj = aX.exec(ce.url.toLowerCase());
                ce.crossDomain = !! (cj && (cj[1] !== b4[1] || cj[2] !== b4[2] || (cj[3] || (cj[1] === "http:" ? 80 : 443)) != (b4[3] || (b4[1] === "http:" ? 80 : 443))))
            }
            if (ce.data && ce.processData && typeof ce.data !== "string") {
                ce.data = bM.param(ce.data, ce.traditional)
            }
            n(w, ce, b7, ck);
            if (b9 === 2) {
                return ck
            }
            b6 = ce.global;
            if (b6 && bM.active++ === 0) {
                bM.event.trigger("ajaxStart")
            }
            ce.type = ce.type.toUpperCase();
            ce.hasContent = !o.test(ce.type);
            cb = ce.url;
            if (!ce.hasContent) {
                if (ce.data) {
                    cb = (ce.url += (aC.test(cb) ? "&" : "?") + ce.data);
                    delete ce.data
                }
                if (ce.cache === false) {
                    ce.url = P.test(cb) ? cb.replace(P, "$1_=" + bR++) : cb + (aC.test(cb) ? "&" : "?") + "_=" + bR++
                }
            }
            if (ce.ifModified) {
                if (bM.lastModified[cb]) {
                    ck.setRequestHeader("If-Modified-Since", bM.lastModified[cb])
                }
                if (bM.etag[cb]) {
                    ck.setRequestHeader("If-None-Match", bM.etag[cb])
                }
            }
            if (ce.data && ce.hasContent && ce.contentType !== false || b7.contentType) {
                ck.setRequestHeader("Content-Type", ce.contentType)
            }
            ck.setRequestHeader("Accept", ce.dataTypes[0] && ce.accepts[ce.dataTypes[0]] ? ce.accepts[ce.dataTypes[0]] + (ce.dataTypes[0] !== "*" ? ", " + aZ + "; q=0.01" : "") : ce.accepts["*"]);
            for (cl in ce.headers) {
                ck.setRequestHeader(cl, ce.headers[cl])
            }
            if (ce.beforeSend && (ce.beforeSend.call(cs, ck, ce) === false || b9 === 2)) {
                return ck.abort()
            }
            cd = "abort";
            for (cl in {
                success: 1,
                error: 1,
                complete: 1
            }) {
                ck[cl](ce[cl])
            }
            cm = n(ba, ce, b7, ck);
            if (!cm) {
                cg(-1, "No Transport")
            } else {
                ck.readyState = 1;
                if (b6) {
                    ch.trigger("ajaxSend", [ck, ce])
                }
                if (ce.async && ce.timeout > 0) {
                    cf = setTimeout(function () {
                        ck.abort("timeout")
                    }, ce.timeout)
                }
                try {
                    b9 = 1;
                    cm.send(ci, cg)
                } catch (cn) {
                    if (b9 < 2) {
                        cg(-1, cn)
                    } else {
                        throw cn
                    }
                }
            }
            function cg(cx, ct, cy, cv) {
                var e, cB, cz, cw, cA, cu = ct;
                if (b9 === 2) {
                    return
                }
                b9 = 2;
                if (cf) {
                    clearTimeout(cf)
                }
                cm = aJ;
                cq = cv || "";
                ck.readyState = cx > 0 ? 4 : 0;
                if (cy) {
                    cw = g(ce, ck, cy)
                }
                if (cx >= 200 && cx < 300 || cx === 304) {
                    if (ce.ifModified) {
                        cA = ck.getResponseHeader("Last-Modified");
                        if (cA) {
                            bM.lastModified[cb] = cA
                        }
                        cA = ck.getResponseHeader("etag");
                        if (cA) {
                            bM.etag[cb] = cA
                        }
                    }
                    if (cx === 204) {
                        e = true;
                        cu = "nocontent"
                    } else {
                        if (cx === 304) {
                            e = true;
                            cu = "notmodified"
                        } else {
                            e = ah(ce, cw);
                            cu = e.state;
                            cB = e.data;
                            cz = e.error;
                            e = !cz
                        }
                    }
                } else {
                    cz = cu;
                    if (cx || !cu) {
                        cu = "error";
                        if (cx < 0) {
                            cx = 0
                        }
                    }
                }
                ck.status = cx;
                ck.statusText = (ct || cu) + "";
                if (e) {
                    cr.resolveWith(cs, [cB, cu, ck])
                } else {
                    cr.rejectWith(cs, [ck, cu, cz])
                }
                ck.statusCode(cc);
                cc = aJ;
                if (b6) {
                    ch.trigger(e ? "ajaxSuccess" : "ajaxError", [ck, ce, e ? cB : cz])
                }
                co.fireWith(cs, [ck, cu]);
                if (b6) {
                    ch.trigger("ajaxComplete", [ck, ce]);
                    if (!(--bM.active)) {
                        bM.event.trigger("ajaxStop")
                    }
                }
            }
            return ck
        },
        getScript: function (e, b6) {
            return bM.get(e, aJ, b6, "script")
        },
        getJSON: function (e, b6, b7) {
            return bM.get(e, b6, b7, "json")
        }
    });

    function g(ce, cd, ca) {
        var e, b9, b8, cb, b6 = ce.contents,
            cc = ce.dataTypes,
            b7 = ce.responseFields;
        for (cb in b7) {
            if (cb in ca) {
                cd[b7[cb]] = ca[cb]
            }
        }
        while (cc[0] === "*") {
            cc.shift();
            if (b9 === aJ) {
                b9 = ce.mimeType || cd.getResponseHeader("Content-Type")
            }
        }
        if (b9) {
            for (cb in b6) {
                if (b6[cb] && b6[cb].test(b9)) {
                    cc.unshift(cb);
                    break
                }
            }
        }
        if (cc[0] in ca) {
            b8 = cc[0]
        } else {
            for (cb in ca) {
                if (!cc[0] || ce.converters[cb + " " + cc[0]]) {
                    b8 = cb;
                    break
                }
                if (!e) {
                    e = cb
                }
            }
            b8 = b8 || e
        }
        if (b8) {
            if (b8 !== cc[0]) {
                cc.unshift(b8)
            }
            return ca[b8]
        }
    }
    function ah(cg, b8) {
        var b6, cc, ce, b9, cf = {},
            ca = 0,
            cd = cg.dataTypes.slice(),
            b7 = cd[0];
        if (cg.dataFilter) {
            b8 = cg.dataFilter(b8, cg.dataType)
        }
        if (cd[1]) {
            for (ce in cg.converters) {
                cf[ce.toLowerCase()] = cg.converters[ce]
            }
        }
        for (;
        (cc = cd[++ca]);) {
            if (cc !== "*") {
                if (b7 !== "*" && b7 !== cc) {
                    ce = cf[b7 + " " + cc] || cf["* " + cc];
                    if (!ce) {
                        for (b6 in cf) {
                            b9 = b6.split(" ");
                            if (b9[1] === cc) {
                                ce = cf[b7 + " " + b9[0]] || cf["* " + b9[0]];
                                if (ce) {
                                    if (ce === true) {
                                        ce = cf[b6]
                                    } else {
                                        if (cf[b6] !== true) {
                                            cc = b9[0];
                                            cd.splice(ca--, 0, cc)
                                        }
                                    }
                                    break
                                }
                            }
                        }
                    }
                    if (ce !== true) {
                        if (ce && cg["throws"]) {
                            b8 = ce(b8)
                        } else {
                            try {
                                b8 = ce(b8)
                            } catch (cb) {
                                return {
                                    state: "parsererror",
                                    error: ce ? cb : "No conversion from " + b7 + " to " + cc
                                }
                            }
                        }
                    }
                }
                b7 = cc
            }
        }
        return {
            state: "success",
            data: b8
        }
    }
    bM.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /(?:java|ecma)script/
        },
        converters: {
            "text script": function (e) {
                bM.globalEval(e);
                return e
            }
        }
    });
    bM.ajaxPrefilter("script", function (e) {
        if (e.cache === aJ) {
            e.cache = false
        }
        if (e.crossDomain) {
            e.type = "GET";
            e.global = false
        }
    });
    bM.ajaxTransport("script", function (b7) {
        if (b7.crossDomain) {
            var e, b6 = l.head || bM("head")[0] || l.documentElement;
            return {
                send: function (b8, b9) {
                    e = l.createElement("script");
                    e.async = true;
                    if (b7.scriptCharset) {
                        e.charset = b7.scriptCharset
                    }
                    e.src = b7.url;
                    e.onload = e.onreadystatechange = function (cb, ca) {
                        if (ca || !e.readyState || /loaded|complete/.test(e.readyState)) {
                            e.onload = e.onreadystatechange = null;
                            if (e.parentNode) {
                                e.parentNode.removeChild(e)
                            }
                            e = null;
                            if (!ca) {
                                b9(200, "success")
                            }
                        }
                    };
                    b6.insertBefore(e, b6.firstChild)
                },
                abort: function () {
                    if (e) {
                        e.onload(aJ, true)
                    }
                }
            }
        }
    });
    var bt = [],
        a8 = /(=)\?(?=&|$)|\?\?/;
    bM.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function () {
            var e = bt.pop() || (bM.expando + "_" + (bR++));
            this[e] = true;
            return e
        }
    });
    bM.ajaxPrefilter("json jsonp", function (b8, e, b9) {
        var cb, b6, b7, ca = b8.jsonp !== false && (a8.test(b8.url) ? "url" : typeof b8.data === "string" && !(b8.contentType || "").indexOf("application/x-www-form-urlencoded") && a8.test(b8.data) && "data");
        if (ca || b8.dataTypes[0] === "jsonp") {
            cb = b8.jsonpCallback = bM.isFunction(b8.jsonpCallback) ? b8.jsonpCallback() : b8.jsonpCallback;
            if (ca) {
                b8[ca] = b8[ca].replace(a8, "$1" + cb)
            } else {
                if (b8.jsonp !== false) {
                    b8.url += (aC.test(b8.url) ? "&" : "?") + b8.jsonp + "=" + cb
                }
            }
            b8.converters["script json"] = function () {
                if (!b7) {
                    bM.error(cb + " was not called")
                }
                return b7[0]
            };
            b8.dataTypes[0] = "json";
            b6 = a5[cb];
            a5[cb] = function () {
                b7 = arguments
            };
            b9.always(function () {
                a5[cb] = b6;
                if (b8[cb]) {
                    b8.jsonpCallback = e.jsonpCallback;
                    bt.push(cb)
                }
                if (b7 && bM.isFunction(b6)) {
                    b6(b7[0])
                }
                b7 = b6 = aJ
            });
            return "script"
        }
    });
    var aj, aA, aB = 0,
        aS = a5.ActiveXObject &&
        function () {
            var e;
            for (e in aj) {
                aj[e](aJ, true)
            }
        };

    function bG() {
        try {
            return new a5.XMLHttpRequest()
        } catch (b6) {}
    }
    function bg() {
        try {
            return new a5.ActiveXObject("Microsoft.XMLHTTP")
        } catch (b6) {}
    }
    bM.ajaxSettings.xhr = a5.ActiveXObject ?
    function () {
        return !this.isLocal && bG() || bg()
    } : bG;
    aA = bM.ajaxSettings.xhr();
    bM.support.cors = !! aA && ("withCredentials" in aA);
    aA = bM.support.ajax = !! aA;
    if (aA) {
        bM.ajaxTransport(function (e) {
            if (!e.crossDomain || bM.support.cors) {
                var b6;
                return {
                    send: function (cc, b7) {
                        var ca, b8, cb = e.xhr();
                        if (e.username) {
                            cb.open(e.type, e.url, e.async, e.username, e.password)
                        } else {
                            cb.open(e.type, e.url, e.async)
                        }
                        if (e.xhrFields) {
                            for (b8 in e.xhrFields) {
                                cb[b8] = e.xhrFields[b8]
                            }
                        }
                        if (e.mimeType && cb.overrideMimeType) {
                            cb.overrideMimeType(e.mimeType)
                        }
                        if (!e.crossDomain && !cc["X-Requested-With"]) {
                            cc["X-Requested-With"] = "XMLHttpRequest"
                        }
                        try {
                            for (b8 in cc) {
                                cb.setRequestHeader(b8, cc[b8])
                            }
                        } catch (b9) {}
                        cb.send((e.hasContent && e.data) || null);
                        b6 = function (cf, ce) {
                            var cd, cg, cj, ch;
                            try {
                                if (b6 && (ce || cb.readyState === 4)) {
                                    b6 = aJ;
                                    if (ca) {
                                        cb.onreadystatechange = bM.noop;
                                        if (aS) {
                                            delete aj[ca]
                                        }
                                    }
                                    if (ce) {
                                        if (cb.readyState !== 4) {
                                            cb.abort()
                                        }
                                    } else {
                                        ch = {};
                                        cd = cb.status;
                                        cg = cb.getAllResponseHeaders();
                                        if (typeof cb.responseText === "string") {
                                            ch.text = cb.responseText
                                        }
                                        try {
                                            cj = cb.statusText
                                        } catch (ci) {
                                            cj = ""
                                        }
                                        if (!cd && e.isLocal && !e.crossDomain) {
                                            cd = ch.text ? 200 : 404
                                        } else {
                                            if (cd === 1223) {
                                                cd = 204
                                            }
                                        }
                                    }
                                }
                            } catch (ck) {
                                if (!ce) {
                                    b7(-1, ck)
                                }
                            }
                            if (ch) {
                                b7(cd, cj, ch, cg)
                            }
                        };
                        if (!e.async) {
                            b6()
                        } else {
                            if (cb.readyState === 4) {
                                setTimeout(b6)
                            } else {
                                ca = ++aB;
                                if (aS) {
                                    if (!aj) {
                                        aj = {};
                                        bM(a5).unload(aS)
                                    }
                                    aj[ca] = b6
                                }
                                cb.onreadystatechange = b6
                            }
                        }
                    },
                    abort: function () {
                        if (b6) {
                            b6(aJ, true)
                        }
                    }
                }
            }
        })
    }
    var L, af, bU = /^(?:toggle|show|hide)$/,
        bN = new RegExp("^(?:([+-])=|)(" + bD + ")([a-z%]*)$", "i"),
        bT = /queueHooks$/,
        aE = [h],
        a3 = {
            "*": [function (e, cc) {
                var b8, cd, ce = this.createTween(e, cc),
                    b9 = bN.exec(cc),
                    ca = ce.cur(),
                    b6 = +ca || 0,
                    b7 = 1,
                    cb = 20;
                if (b9) {
                    b8 = +b9[2];
                    cd = b9[3] || (bM.cssNumber[e] ? "" : "px");
                    if (cd !== "px" && b6) {
                        b6 = bM.css(ce.elem, e, true) || b8 || 1;
                        do {
                            b7 = b7 || ".5";
                            b6 = b6 / b7;
                            bM.style(ce.elem, e, b6 + cd)
                        } while (b7 !== (b7 = ce.cur() / ca) && b7 !== 1 && --cb)
                    }
                    ce.unit = cd;
                    ce.start = b6;
                    ce.end = b9[1] ? b6 + (b9[1] + 1) * b8 : b8
                }
                return ce
            }]
        };

    function bp() {
        setTimeout(function () {
            L = aJ
        });
        return (L = bM.now())
    }
    function bh(b6, e) {
        bM.each(e, function (cb, b9) {
            var ca = (a3[cb] || []).concat(a3["*"]),
                b7 = 0,
                b8 = ca.length;
            for (; b7 < b8; b7++) {
                if (ca[b7].call(b6, cb, b9)) {
                    return
                }
            }
        })
    }
    function f(b7, cb, ce) {
        var cf, e, ca = 0,
            b6 = aE.length,
            cd = bM.Deferred().always(function () {
                delete b9.elem
            }),
            b9 = function () {
                if (e) {
                    return false
                }
                var cl = L || bp(),
                    ci = Math.max(0, b8.startTime + b8.duration - cl),
                    cg = ci / b8.duration || 0,
                    ck = 1 - cg,
                    ch = 0,
                    cj = b8.tweens.length;
                for (; ch < cj; ch++) {
                    b8.tweens[ch].run(ck)
                }
                cd.notifyWith(b7, [b8, ck, ci]);
                if (ck < 1 && cj) {
                    return ci
                } else {
                    cd.resolveWith(b7, [b8]);
                    return false
                }
            },
            b8 = cd.promise({
                elem: b7,
                props: bM.extend({}, cb),
                opts: bM.extend(true, {
                    specialEasing: {}
                }, ce),
                originalProperties: cb,
                originalOptions: ce,
                startTime: L || bp(),
                duration: ce.duration,
                tweens: [],
                createTween: function (ci, cg) {
                    var ch = bM.Tween(b7, b8.opts, ci, cg, b8.opts.specialEasing[ci] || b8.opts.easing);
                    b8.tweens.push(ch);
                    return ch
                },
                stop: function (ch) {
                    var cg = 0,
                        ci = ch ? b8.tweens.length : 0;
                    if (e) {
                        return this
                    }
                    e = true;
                    for (; cg < ci; cg++) {
                        b8.tweens[cg].run(1)
                    }
                    if (ch) {
                        cd.resolveWith(b7, [b8, ch])
                    } else {
                        cd.rejectWith(b7, [b8, ch])
                    }
                    return this
                }
            }),
            cc = b8.props;
        ao(cc, b8.opts.specialEasing);
        for (; ca < b6; ca++) {
            cf = aE[ca].call(b8, b7, cc, b8.opts);
            if (cf) {
                return cf
            }
        }
        bh(b8, cc);
        if (bM.isFunction(b8.opts.start)) {
            b8.opts.start.call(b7, b8)
        }
        bM.fx.timer(bM.extend(b9, {
            elem: b7,
            anim: b8,
            queue: b8.opts.queue
        }));
        return b8.progress(b8.opts.progress).done(b8.opts.done, b8.opts.complete).fail(b8.opts.fail).always(b8.opts.always)
    }
    function ao(b8, ca) {
        var b9, b7, b6, cb, e;
        for (b6 in b8) {
            b7 = bM.camelCase(b6);
            cb = ca[b7];
            b9 = b8[b6];
            if (bM.isArray(b9)) {
                cb = b9[1];
                b9 = b8[b6] = b9[0]
            }
            if (b6 !== b7) {
                b8[b7] = b9;
                delete b8[b6]
            }
            e = bM.cssHooks[b7];
            if (e && "expand" in e) {
                b9 = e.expand(b9);
                delete b8[b7];
                for (b6 in b9) {
                    if (!(b6 in b8)) {
                        b8[b6] = b9[b6];
                        ca[b6] = cb
                    }
                }
            } else {
                ca[b7] = cb
            }
        }
    }
    bM.Animation = bM.extend(f, {
        tweener: function (b6, b9) {
            if (bM.isFunction(b6)) {
                b9 = b6;
                b6 = ["*"]
            } else {
                b6 = b6.split(" ")
            }
            var b8, e = 0,
                b7 = b6.length;
            for (; e < b7; e++) {
                b8 = b6[e];
                a3[b8] = a3[b8] || [];
                a3[b8].unshift(b9)
            }
        },
        prefilter: function (b6, e) {
            if (e) {
                aE.unshift(b6)
            } else {
                aE.push(b6)
            }
        }
    });

    function h(b9, cf, e) {
        var b7, ce, b8, ch, cl, cb, ck, cj, ci, ca = this,
            b6 = b9.style,
            cg = {},
            cd = [],
            cc = b9.nodeType && Q(b9);
        if (!e.queue) {
            cj = bM._queueHooks(b9, "fx");
            if (cj.unqueued == null) {
                cj.unqueued = 0;
                ci = cj.empty.fire;
                cj.empty.fire = function () {
                    if (!cj.unqueued) {
                        ci()
                    }
                }
            }
            cj.unqueued++;
            ca.always(function () {
                ca.always(function () {
                    cj.unqueued--;
                    if (!bM.queue(b9, "fx").length) {
                        cj.empty.fire()
                    }
                })
            })
        }
        if (b9.nodeType === 1 && ("height" in cf || "width" in cf)) {
            e.overflow = [b6.overflow, b6.overflowX, b6.overflowY];
            if (bM.css(b9, "display") === "inline" && bM.css(b9, "float") === "none") {
                if (!bM.support.inlineBlockNeedsLayout || bH(b9.nodeName) === "inline") {
                    b6.display = "inline-block"
                } else {
                    b6.zoom = 1
                }
            }
        }
        if (e.overflow) {
            b6.overflow = "hidden";
            if (!bM.support.shrinkWrapBlocks) {
                ca.always(function () {
                    b6.overflow = e.overflow[0];
                    b6.overflowX = e.overflow[1];
                    b6.overflowY = e.overflow[2]
                })
            }
        }
        for (ce in cf) {
            ch = cf[ce];
            if (bU.exec(ch)) {
                delete cf[ce];
                cb = cb || ch === "toggle";
                if (ch === (cc ? "hide" : "show")) {
                    continue
                }
                cd.push(ce)
            }
        }
        b8 = cd.length;
        if (b8) {
            cl = bM._data(b9, "fxshow") || bM._data(b9, "fxshow", {});
            if ("hidden" in cl) {
                cc = cl.hidden
            }
            if (cb) {
                cl.hidden = !cc
            }
            if (cc) {
                bM(b9).show()
            } else {
                ca.done(function () {
                    bM(b9).hide()
                })
            }
            ca.done(function () {
                var cm;
                bM._removeData(b9, "fxshow");
                for (cm in cg) {
                    bM.style(b9, cm, cg[cm])
                }
            });
            for (ce = 0; ce < b8; ce++) {
                b7 = cd[ce];
                ck = ca.createTween(b7, cc ? cl[b7] : 0);
                cg[b7] = cl[b7] || bM.style(b9, b7);
                if (!(b7 in cl)) {
                    cl[b7] = ck.start;
                    if (cc) {
                        ck.end = ck.start;
                        ck.start = b7 === "width" || b7 === "height" ? 1 : 0
                    }
                }
            }
        }
    }
    function H(b7, b6, b9, e, b8) {
        return new H.prototype.init(b7, b6, b9, e, b8)
    }
    bM.Tween = H;
    H.prototype = {
        constructor: H,
        init: function (b8, b6, ca, e, b9, b7) {
            this.elem = b8;
            this.prop = ca;
            this.easing = b9 || "swing";
            this.options = b6;
            this.start = this.now = this.cur();
            this.end = e;
            this.unit = b7 || (bM.cssNumber[ca] ? "" : "px")
        },
        cur: function () {
            var e = H.propHooks[this.prop];
            return e && e.get ? e.get(this) : H.propHooks._default.get(this)
        },
        run: function (b7) {
            var b6, e = H.propHooks[this.prop];
            if (this.options.duration) {
                this.pos = b6 = bM.easing[this.easing](b7, this.options.duration * b7, 0, 1, this.options.duration)
            } else {
                this.pos = b6 = b7
            }
            this.now = (this.end - this.start) * b6 + this.start;
            if (this.options.step) {
                this.options.step.call(this.elem, this.now, this)
            }
            if (e && e.set) {
                e.set(this)
            } else {
                H.propHooks._default.set(this)
            }
            return this
        }
    };
    H.prototype.init.prototype = H.prototype;
    H.propHooks = {
        _default: {
            get: function (b6) {
                var e;
                if (b6.elem[b6.prop] != null && (!b6.elem.style || b6.elem.style[b6.prop] == null)) {
                    return b6.elem[b6.prop]
                }
                e = bM.css(b6.elem, b6.prop, "");
                return !e || e === "auto" ? 0 : e
            },
            set: function (e) {
                if (bM.fx.step[e.prop]) {
                    bM.fx.step[e.prop](e)
                } else {
                    if (e.elem.style && (e.elem.style[bM.cssProps[e.prop]] != null || bM.cssHooks[e.prop])) {
                        bM.style(e.elem, e.prop, e.now + e.unit)
                    } else {
                        e.elem[e.prop] = e.now
                    }
                }
            }
        }
    };
    H.propHooks.scrollTop = H.propHooks.scrollLeft = {
        set: function (e) {
            if (e.elem.nodeType && e.elem.parentNode) {
                e.elem[e.prop] = e.now
            }
        }
    };
    bM.each(["toggle", "show", "hide"], function (b6, e) {
        var b7 = bM.fn[e];
        bM.fn[e] = function (b8, ca, b9) {
            return b8 == null || typeof b8 === "boolean" ? b7.apply(this, arguments) : this.animate(bL(e, true), b8, ca, b9)
        }
    });
    bM.fn.extend({
        fadeTo: function (e, b8, b7, b6) {
            return this.filter(Q).css("opacity", 0).show().end().animate({
                opacity: b8
            }, e, b7, b6)
        },
        animate: function (cb, b8, ca, b9) {
            var b7 = bM.isEmptyObject(cb),
                e = bM.speed(b8, ca, b9),
                b6 = function () {
                    var cc = f(this, bM.extend({}, cb), e);
                    b6.finish = function () {
                        cc.stop(true)
                    };
                    if (b7 || bM._data(this, "finish")) {
                        cc.stop(true)
                    }
                };
            b6.finish = b6;
            return b7 || e.queue === false ? this.each(b6) : this.queue(e.queue, b6)
        },
        stop: function (b7, b6, e) {
            var b8 = function (b9) {
                var ca = b9.stop;
                delete b9.stop;
                ca(e)
            };
            if (typeof b7 !== "string") {
                e = b6;
                b6 = b7;
                b7 = aJ
            }
            if (b6 && b7 !== false) {
                this.queue(b7 || "fx", [])
            }
            return this.each(function () {
                var cc = true,
                    b9 = b7 != null && b7 + "queueHooks",
                    cb = bM.timers,
                    ca = bM._data(this);
                if (b9) {
                    if (ca[b9] && ca[b9].stop) {
                        b8(ca[b9])
                    }
                } else {
                    for (b9 in ca) {
                        if (ca[b9] && ca[b9].stop && bT.test(b9)) {
                            b8(ca[b9])
                        }
                    }
                }
                for (b9 = cb.length; b9--;) {
                    if (cb[b9].elem === this && (b7 == null || cb[b9].queue === b7)) {
                        cb[b9].anim.stop(e);
                        cc = false;
                        cb.splice(b9, 1)
                    }
                }
                if (cc || !e) {
                    bM.dequeue(this, b7)
                }
            })
        },
        finish: function (e) {
            if (e !== false) {
                e = e || "fx"
            }
            return this.each(function () {
                var b8, cb = bM._data(this),
                    b7 = cb[e + "queue"],
                    b6 = cb[e + "queueHooks"],
                    ca = bM.timers,
                    b9 = b7 ? b7.length : 0;
                cb.finish = true;
                bM.queue(this, e, []);
                if (b6 && b6.cur && b6.cur.finish) {
                    b6.cur.finish.call(this)
                }
                for (b8 = ca.length; b8--;) {
                    if (ca[b8].elem === this && ca[b8].queue === e) {
                        ca[b8].anim.stop(true);
                        ca.splice(b8, 1)
                    }
                }
                for (b8 = 0; b8 < b9; b8++) {
                    if (b7[b8] && b7[b8].finish) {
                        b7[b8].finish.call(this)
                    }
                }
                delete cb.finish
            })
        }
    });

    function bL(b7, b9) {
        var b8, e = {
            height: b7
        },
            b6 = 0;
        b9 = b9 ? 1 : 0;
        for (; b6 < 4; b6 += 2 - b9) {
            b8 = bW[b6];
            e["margin" + b8] = e["padding" + b8] = b7
        }
        if (b9) {
            e.opacity = e.width = b7
        }
        return e
    }
    bM.each({
        slideDown: bL("show"),
        slideUp: bL("hide"),
        slideToggle: bL("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function (e, b6) {
        bM.fn[e] = function (b7, b9, b8) {
            return this.animate(b6, b7, b9, b8)
        }
    });
    bM.speed = function (b7, b8, b6) {
        var e = b7 && typeof b7 === "object" ? bM.extend({}, b7) : {
            complete: b6 || !b6 && b8 || bM.isFunction(b7) && b7,
            duration: b7,
            easing: b6 && b8 || b8 && !bM.isFunction(b8) && b8
        };
        e.duration = bM.fx.off ? 0 : typeof e.duration === "number" ? e.duration : e.duration in bM.fx.speeds ? bM.fx.speeds[e.duration] : bM.fx.speeds._default;
        if (e.queue == null || e.queue === true) {
            e.queue = "fx"
        }
        e.old = e.complete;
        e.complete = function () {
            if (bM.isFunction(e.old)) {
                e.old.call(this)
            }
            if (e.queue) {
                bM.dequeue(this, e.queue)
            }
        };
        return e
    };
    bM.easing = {
        linear: function (e) {
            return e
        },
        swing: function (e) {
            return 0.5 - Math.cos(e * Math.PI) / 2
        }
    };
    bM.timers = [];
    bM.fx = H.prototype.init;
    bM.fx.tick = function () {
        var b7, b6 = bM.timers,
            e = 0;
        L = bM.now();
        for (; e < b6.length; e++) {
            b7 = b6[e];
            if (!b7() && b6[e] === b7) {
                b6.splice(e--, 1)
            }
        }
        if (!b6.length) {
            bM.fx.stop()
        }
        L = aJ
    };
    bM.fx.timer = function (e) {
        if (e() && bM.timers.push(e)) {
            bM.fx.start()
        }
    };
    bM.fx.interval = 13;
    bM.fx.start = function () {
        if (!af) {
            af = setInterval(bM.fx.tick, bM.fx.interval)
        }
    };
    bM.fx.stop = function () {
        clearInterval(af);
        af = null
    };
    bM.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    };
    bM.fx.step = {};
    if (bM.expr && bM.expr.filters) {
        bM.expr.filters.animated = function (e) {
            return bM.grep(bM.timers, function (b6) {
                return e === b6.elem
            }).length
        }
    }
    bM.fn.offset = function (b6) {
        if (arguments.length) {
            return b6 === aJ ? this : this.each(function (cb) {
                bM.offset.setOffset(this, b6, cb)
            })
        }
        var e, ca, b8 = {
            top: 0,
            left: 0
        },
            b7 = this[0],
            b9 = b7 && b7.ownerDocument;
        if (!b9) {
            return
        }
        e = b9.documentElement;
        if (!bM.contains(e, b7)) {
            return b8
        }
        if (typeof b7.getBoundingClientRect !== aF) {
            b8 = b7.getBoundingClientRect()
        }
        ca = bs(b9);
        return {
            top: b8.top + (ca.pageYOffset || e.scrollTop) - (e.clientTop || 0),
            left: b8.left + (ca.pageXOffset || e.scrollLeft) - (e.clientLeft || 0)
        }
    };
    bM.offset = {
        setOffset: function (b8, ch, cb) {
            var cc = bM.css(b8, "position");
            if (cc === "static") {
                b8.style.position = "relative"
            }
            var ca = bM(b8),
                b6 = ca.offset(),
                e = bM.css(b8, "top"),
                cf = bM.css(b8, "left"),
                cg = (cc === "absolute" || cc === "fixed") && bM.inArray("auto", [e, cf]) > -1,
                ce = {},
                cd = {},
                b7, b9;
            if (cg) {
                cd = ca.position();
                b7 = cd.top;
                b9 = cd.left
            } else {
                b7 = parseFloat(e) || 0;
                b9 = parseFloat(cf) || 0
            }
            if (bM.isFunction(ch)) {
                ch = ch.call(b8, cb, b6)
            }
            if (ch.top != null) {
                ce.top = (ch.top - b6.top) + b7
            }
            if (ch.left != null) {
                ce.left = (ch.left - b6.left) + b9
            }
            if ("using" in ch) {
                ch.using.call(b8, ce)
            } else {
                ca.css(ce)
            }
        }
    };
    bM.fn.extend({
        position: function () {
            if (!this[0]) {
                return
            }
            var b7, b8, e = {
                top: 0,
                left: 0
            },
                b6 = this[0];
            if (bM.css(b6, "position") === "fixed") {
                b8 = b6.getBoundingClientRect()
            } else {
                b7 = this.offsetParent();
                b8 = this.offset();
                if (!bM.nodeName(b7[0], "html")) {
                    e = b7.offset()
                }
                e.top += bM.css(b7[0], "borderTopWidth", true);
                e.left += bM.css(b7[0], "borderLeftWidth", true)
            }
            return {
                top: b8.top - e.top - bM.css(b6, "marginTop", true),
                left: b8.left - e.left - bM.css(b6, "marginLeft", true)
            }
        },
        offsetParent: function () {
            return this.map(function () {
                var e = this.offsetParent || l.documentElement;
                while (e && (!bM.nodeName(e, "html") && bM.css(e, "position") === "static")) {
                    e = e.offsetParent
                }
                return e || l.documentElement
            })
        }
    });
    bM.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function (b7, b6) {
        var e = /Y/.test(b6);
        bM.fn[b7] = function (b8) {
            return bM.access(this, function (b9, cc, cb) {
                var ca = bs(b9);
                if (cb === aJ) {
                    return ca ? (b6 in ca) ? ca[b6] : ca.document.documentElement[cc] : b9[cc]
                }
                if (ca) {
                    ca.scrollTo(!e ? cb : bM(ca).scrollLeft(), e ? cb : bM(ca).scrollTop())
                } else {
                    b9[cc] = cb
                }
            }, b7, b8, arguments.length, null)
        }
    });

    function bs(e) {
        return bM.isWindow(e) ? e : e.nodeType === 9 ? e.defaultView || e.parentWindow : false
    }
    bM.each({
        Height: "height",
        Width: "width"
    }, function (e, b6) {
        bM.each({
            padding: "inner" + e,
            content: b6,
            "": "outer" + e
        }, function (b7, b8) {
            bM.fn[b8] = function (cc, cb) {
                var ca = arguments.length && (b7 || typeof cc !== "boolean"),
                    b9 = b7 || (cc === true || cb === true ? "margin" : "border");
                return bM.access(this, function (ce, cd, cf) {
                    var cg;
                    if (bM.isWindow(ce)) {
                        return ce.document.documentElement["client" + e]
                    }
                    if (ce.nodeType === 9) {
                        cg = ce.documentElement;
                        return Math.max(ce.body["scroll" + e], cg["scroll" + e], ce.body["offset" + e], cg["offset" + e], cg["client" + e])
                    }
                    return cf === aJ ? bM.css(ce, cd, b9) : bM.style(ce, cd, cf, b9)
                }, b6, ca ? cc : aJ, ca, null)
            }
        })
    });
    a5.jQuery = a5.$ = bM;
    if (typeof define === "function" && define.amd && define.amd.jQuery) {
        define("jquery", [], function () {
            return bM
        })
    }
})(window);
var PAPAYA_CONTAINER_CLASS_NAME = "papaya",
    PAPAYA_CONTAINER_COLLAPSABLE = "papaya-collapsable",
    PAPAYA_CONTAINER_COLLAPSABLE_EXEMPT = "papaya-collapsable-exempt",
    PAPAYA_CONTAINER_FULLSCREEN = "papaya-fullscreen";
var PAPAYA_VIEWER_CSS = "papaya-viewer";
var PAPAYA_TOOLBAR_CSS = "papaya-toolbar",
    PAPAYA_TITLEBAR_CSS = "papaya-titlebar",
    PAPAYA_SLIDER_CSS = "papaya-slider-slice";
var PAPAYA_DISPLAY_CSS = "papaya-display";
var PAPAYA_DIALOG_CSS = "papaya-dialog",
    PAPAYA_DIALOG_CONTENT_CSS = "papaya-dialog-content",
    PAPAYA_DIALOG_CONTENT_LABEL_CSS = "papaya-dialog-content-label",
    PAPAYA_DIALOG_CONTENT_CONTROL_CSS = "papaya-dialog-content-control",
    PAPAYA_DIALOG_TITLE_CSS = "papaya-dialog-title",
    PAPAYA_DIALOG_BUTTON_CSS = "papaya-dialog-button",
    PAPAYA_DIALOG_BACKGROUND = "papaya-dialog-background",
    PAPAYA_DIALOG_STOPSCROLL = "papaya-dialog-stopscroll";
var PAPAYA_MENU_CSS = "papaya-menu",
    PAPAYA_MENU_LABEL_CSS = "papaya-menu-label",
    PAPAYA_MENU_TITLEBAR_CSS = "papaya-menu-titlebar",
    PAPAYA_MENU_ICON_CSS = "papaya-menu-icon",
    PAPAYA_MENU_HOVERING_CSS = "papaya-menu-hovering",
    PAPAYA_MENU_SPACER_CSS = "papaya-menu-spacer",
    PAPAYA_MENU_UNSELECTABLE = "papaya-menu-unselectable",
    PAPAYA_MENU_FILECHOOSER = "papaya-menu-filechooser",
    PAPAYA_MENU_BUTTON_CSS = "papaya-menu-button",
    PAPAYA_MENU_BUTTON_HOVERING_CSS = "papaya-menu-button-hovering",
    PAPAYA_MENU_COLORTABLE_CSS = "papaya-menu-colortable";
var PAPAYA_UTILS_CHECKFORJS_CSS = "checkForJS",
    PAPAYA_UTILS_UNSUPPORTED_CSS = "papaya-utils-unsupported",
    PAPAYA_UTILS_UNSUPPORTED_MESSAGE_CSS = "papaya-utils-unsupported-message";
var PAPAYA_DEFAULT_VIEWER_ID = "papayaViewer",
    PAPAYA_DEFAULT_DISPLAY_ID = "papayaDisplay",
    PAPAYA_DEFAULT_TOOLBAR_ID = "papayaToolbar",
    PAPAYA_DEFAULT_CONTAINER_ID = "papayaContainer",
    PAPAYA_DEFAULT_SLIDER_ID = "papayaSliceSlider";
var PAPAYA_SPACING = 3,
    PAPAYA_SECTION_HEIGHT = 50,
    PAPAYA_CONTAINER_PADDING = 20,
    PAPAYA_CONTAINER_PADDING_TOP = PAPAYA_CONTAINER_PADDING,
    PAPAYA_MINIMUM_SIZE = 500;
"use strict";

function bind(d, c, b, a) {
    if (arguments.length === 2) {
        return function () {
            return c.apply(d, arguments)
        }
    }
    var f = c,
        e = Array.prototype.slice;
    return function () {
        var g = b || arguments;
        if (a === true) {
            g = e.call(arguments, 0);
            g = g.concat(b)
        } else {
            if (typeof a === "number") {
                g = e.call(arguments, 0);
                Ext.Array.insert(g, a, b)
            }
        }
        return f.apply(d || window, g)
    }
}
function roundFast(a) {
    return (0.5 + a) | 0
}
function floorFast(a) {
    return a | 0
}
function validDimBounds(a, b) {
    return (a < b) ? a : b - 1
}
function isString(a) {
    return (typeof a === "string" || a instanceof String)
}
function isStringBlank(a) {
    return ($.trim(a).length === 0)
}
function signum(a) {
    return a ? a < 0 ? -1 : 1 : 0
}
Array.prototype.clone = function () {
    var a, b;
    a = this.slice(0);
    for (b = 0; b < this.length; b += 1) {
        if (this[b].clone) {
            a[b] = this[b].clone()
        }
    }
    return a
};
if (typeof String.prototype.startsWith !== "function") {
    String.prototype.startsWith = function (a) {
        return this.indexOf(a) === 0
    }
}
var showMenu = function (f, b, a, i) {
    var c, h, j, e, d, g;
    c = $(f.canvas).offset();
    h = $(b).offset();
    j = $(b).outerWidth();
    e = $(a).outerWidth();
    d = h.left + (i ? ((-1 * e) + j) : 5) + "px";
    g = (c.top) + "px";
    $(a).css({
        position: "absolute",
        zIndex: 100,
        left: d,
        top: g
    });
    $(a).hide().fadeIn(200)
};
var showModalDialog = function (f, h) {
    var c, g, e, j, d, i;
    var b = document.documentElement;
    var a = window.pageYOffset || b.scrollTop;
    c = $(window).outerWidth();
    g = $(window).outerHeight();
    e = $(h).outerWidth();
    j = $(h).outerHeight();
    d = (c / 2) - (e / 2) + "px";
    i = a + (g / 2) - (j / 2) + "px";
    $(h).css({
        position: "absolute",
        zIndex: 100,
        left: d,
        top: i
    });
    $(h).hide().fadeIn(200)
};

function isControlKey(a) {
    var b = getKeyCode(a);
    if ((OSName === "MacOS") && ((b === 91) || (b === 93) || (b === 224))) {
        return true
    }
    return ((OSName !== "MacOS") && (b === 17))
}
function isAltKey(a) {
    var b = getKeyCode(a);
    return (b === 18)
}
function isShiftKey(a) {
    var b = a.shiftKey ? true : false;
    if (!b && window.event) {
        b = window.event.shiftKey ? true : false
    }
    return b
}
function fullyQualifiedVariableExists(b) {
    var c, a;
    c = window[b[0]];
    for (a = 1; a < b.length; a += 1) {
        if (c === undefined) {
            return false
        }
        c = c[b[a]]
    }
    return (!(c === undefined) && !(c === null))
}
function createCookie(c, d, e) {
    var b, a;
    if (e) {
        b = new Date();
        b.setTime(b.getTime() + (e * 24 * 60 * 60 * 1000));
        a = "; expires=" + b.toGMTString()
    } else {
        a = ""
    }
    document.cookie = c + "=" + d + a + "; path=/"
}
function readCookie(b) {
    var e, a, d, f;
    e = b + "=";
    a = document.cookie.split(";");
    for (d = 0; d < a.length; d += 1) {
        f = a[d];
        while (f.charAt(0) === " ") {
            f = f.substring(1, f.length)
        }
        if (f.indexOf(e) === 0) {
            return f.substring(e.length, f.length)
        }
    }
    return null
}
function formatNumber(b, a) {
    var c = 0;
    if (isString(b)) {
        c = parseFloat(b)
    } else {
        c = b
    }
    if (a) {
        c = c.toPrecision(5)
    } else {
        c = c.toPrecision(7)
    }
    return parseFloat(c)
}
function getSizeString(b) {
    var a = null;
    if (b > 1048576) {
        a = formatNumber(b / 1048576, true) + " Mb"
    } else {
        if (b > 1024) {
            a = formatNumber(b / 1024, true) + " Kb"
        } else {
            a = b + " Bytes"
        }
    }
    return a
}
function wordwrap(e, b, a, d) {
    a = a || "\n";
    b = b || 75;
    d = d || false;
    if (!e) {
        return e
    }
    var c = ".{1," + b + "}(\\s|$)" + (d ? "|.{" + b + "}|.+$" : "|\\S+?(\\s|$)");
    return e.match(new RegExp(c, "g")).join(a)
}
function getQueryParams(d) {
    var c, a, b = /[?&]?([^=]+)=([^&]*)/g;
    if (document.location.href.indexOf("?") !== -1) {
        a = document.location.href.substring(document.location.href.indexOf("?") + 1);
        a = a.split("+").join(" ");
        while (c = b.exec(a)) {
            d[decodeURIComponent(c[1])] = decodeURIComponent(c[2])
        }
    }
}
function deref(a) {
    return derefIn(window, a)
}
function derefIn(b, a) {
    var c, d;
    if (!isString(a)) {
        return null
    }
    d = a.replace(/(^[' "]+|[" ']+$)/g, "").match(/(^[\w\$]+(\.[\w\$]+)*)/);
    if (d) {
        d = d[1].split(".");
        c = b[d.shift()];
        while (c && d.length) {
            c = c[d.shift()]
        }
    }
    return c || null
}
function printStackTrace() {
    var a = new Error();
    console.log(a.stack)
}
function getOffsetRect(d) {
    var g = d.getBoundingClientRect();
    var h = document.body;
    var b = document.documentElement;
    var a = window.pageYOffset || b.scrollTop;
    var e = window.pageXOffset || b.scrollLeft;
    var f = b.clientTop || h.clientTop || 0;
    var i = b.clientLeft || h.clientLeft || 0;
    var j = g.top + a - f;
    var c = g.left + e - i;
    return {
        top: Math.round(j),
        left: Math.round(c)
    }
}
function getColorComponents(a) {
    if (a) {
        return a.match(/\d+/g)
    }
    return [0, 0, 0, 255]
}
function getNiceForegroundColor(c) {
    var a = getColorComponents(c);
    var b = (parseInt(a[0]) + parseInt(a[1]) + parseInt(a[2])) / 3;
    if (b > 127) {
        a[0] = a[1] = a[2] = 0
    } else {
        a[0] = a[1] = a[2] = 255
    }
    return ("rgb(" + a[0] + ", " + a[1] + ", " + a[2] + ")")
}
function getRelativeMousePositionFromParentX(c, b) {
    var a = c.parent().offset();
    return getMousePositionX(b) - a.left
}
function getRelativeMousePositionX(c, b) {
    var a = c.offset();
    return getMousePositionX(b) - a.left
}
function createArray(d) {
    var a = new Array(d || 0),
        c = d;
    if (arguments.length > 1) {
        var b = Array.prototype.slice.call(arguments, 1);
        while (c--) {
            a[d - 1 - c] = createArray.apply(this, b)
        }
    }
    return a
}
var GUNZIP_MAGIC_COOKIE1 = 31;
var GUNZIP_MAGIC_COOKIE2 = 139;
var Gunzip = function (X) {
    var Y = "GZIP flag not supported!";
    var n = "Not a GZIP file!";
    var k = 10;
    var i = 8;
    var h = 1000 * 1024;
    var L = null;
    var H = null;
    var J = null;
    var D = null;
    var I = 0;
    var ae = 0;
    var ac = 0;
    var aa = 0;
    var U = 0;
    var Q = null;
    var r = 32768;
    var A = 0;
    var S = 1;
    var m = 2;
    var aj = 9;
    var j = 6;
    var x = 32768;
    var a = 64;
    var K;
    var o;
    var ah = null;
    var b;
    var ab, M;
    var w;
    var v;
    var al;
    var ad;
    var ak;
    var C;
    var q, s;
    var f, l;
    var G;
    var O;
    var ag = new Array(0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535);
    var c = new Array(3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0);
    var Z = new Array(0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 99, 99);
    var V = new Array(1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577);
    var E = new Array(0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13);
    var u = new Array(16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15);
    var B = function () {
        this.next = null;
        this.list = null
    };
    var R = function () {
        this.e = 0;
        this.b = 0;
        this.n = 0;
        this.t = null
    };
    var p = function (aP, aE, az, aN, aM, aJ) {
        this.BMAX = 16;
        this.N_MAX = 288;
        this.status = 0;
        this.root = null;
        this.m = 0;
        var aQ;
        var aO = new Array(this.BMAX + 1);
        var am;
        var aL;
        var aK;
        var aI;
        var aH;
        var aG;
        var aF;
        var an = new Array(this.BMAX + 1);
        var aC;
        var ao;
        var aB;
        var aA = new R();
        var ay = new Array(this.BMAX);
        var ax = new Array(this.N_MAX);
        var aw;
        var au = new Array(this.BMAX + 1);
        var av;
        var ar;
        var aq;
        var aD;
        var ap;
        ap = this.root = null;
        for (aH = 0; aH < aO.length; aH++) {
            aO[aH] = 0
        }
        for (aH = 0; aH < an.length; aH++) {
            an[aH] = 0
        }
        for (aH = 0; aH < ay.length; aH++) {
            ay[aH] = null
        }
        for (aH = 0; aH < ax.length; aH++) {
            ax[aH] = 0
        }
        for (aH = 0; aH < au.length; aH++) {
            au[aH] = 0
        }
        am = aE > 256 ? aP[256] : this.BMAX;
        aC = aP;
        ao = 0;
        aH = aE;
        do {
            aO[aC[ao]]++;
            ao++
        } while (--aH > 0);
        if (aO[0] == aE) {
            this.root = null;
            this.m = 0;
            this.status = 0;
            return
        }
        for (aG = 1; aG <= this.BMAX; aG++) {
            if (aO[aG] != 0) {
                break
            }
        }
        aF = aG;
        if (aJ < aG) {
            aJ = aG
        }
        for (aH = this.BMAX; aH != 0; aH--) {
            if (aO[aH] != 0) {
                break
            }
        }
        aK = aH;
        if (aJ > aH) {
            aJ = aH
        }
        for (ar = 1 << aG; aG < aH; aG++, ar <<= 1) {
            if ((ar -= aO[aG]) < 0) {
                this.status = 2;
                this.m = aJ;
                return
            }
        }
        if ((ar -= aO[aH]) < 0) {
            this.status = 2;
            this.m = aJ;
            return
        }
        aO[aH] += ar;
        au[1] = aG = 0;
        aC = aO;
        ao = 1;
        av = 2;
        while (--aH > 0) {
            au[av++] = (aG += aC[ao++])
        }
        aC = aP;
        ao = 0;
        aH = 0;
        do {
            if ((aG = aC[ao++]) != 0) {
                ax[au[aG]++] = aH
            }
        } while (++aH < aE);
        aE = au[aK];
        au[0] = aH = 0;
        aC = ax;
        ao = 0;
        aI = -1;
        aw = an[0] = 0;
        aB = null;
        aq = 0;
        for (; aF <= aK; aF++) {
            aQ = aO[aF];
            while (aQ-- > 0) {
                while (aF > aw + an[1 + aI]) {
                    aw += an[1 + aI];
                    aI++;
                    aq = (aq = aK - aw) > aJ ? aJ : aq;
                    if ((aL = 1 << (aG = aF - aw)) > aQ + 1) {
                        aL -= aQ + 1;
                        av = aF;
                        while (++aG < aq) {
                            if ((aL <<= 1) <= aO[++av]) {
                                break
                            }
                            aL -= aO[av]
                        }
                    }
                    if (aw + aG > am && aw < am) {
                        aG = am - aw
                    }
                    aq = 1 << aG;
                    an[1 + aI] = aG;
                    aB = new Array(aq);
                    for (aD = 0; aD < aq; aD++) {
                        aB[aD] = new R()
                    }
                    if (ap == null) {
                        ap = this.root = new B()
                    } else {
                        ap = ap.next = new B()
                    }
                    ap.next = null;
                    ap.list = aB;
                    ay[aI] = aB;
                    if (aI > 0) {
                        au[aI] = aH;
                        aA.b = an[aI];
                        aA.e = 16 + aG;
                        aA.t = aB;
                        aG = (aH & ((1 << aw) - 1)) >> (aw - an[aI]);
                        ay[aI - 1][aG].e = aA.e;
                        ay[aI - 1][aG].b = aA.b;
                        ay[aI - 1][aG].n = aA.n;
                        ay[aI - 1][aG].t = aA.t
                    }
                }
                aA.b = aF - aw;
                if (ao >= aE) {
                    aA.e = 99
                } else {
                    if (aC[ao] < az) {
                        aA.e = (aC[ao] < 256 ? 16 : 15);
                        aA.n = aC[ao++]
                    } else {
                        aA.e = aM[aC[ao] - az];
                        aA.n = aN[aC[ao++] - az]
                    }
                }
                aL = 1 << (aF - aw);
                for (aG = aH >> aw; aG < aq; aG += aL) {
                    aB[aG].e = aA.e;
                    aB[aG].b = aA.b;
                    aB[aG].n = aA.n;
                    aB[aG].t = aA.t
                }
                for (aG = 1 << (aF - 1);
                (aH & aG) != 0; aG >>= 1) {
                    aH ^= aG
                }
                aH ^= aG;
                while ((aH & ((1 << aw) - 1)) != au[aI]) {
                    aw -= an[aI];
                    aI--
                }
            }
        }
        this.m = an[1];
        this.status = ((ar != 0 && aK != 1) ? 1 : 0)
    };
    var e = function () {
        if (ae == O) {
            return -1
        }
        return G.getUint8(O++) & 255
    };
    var ai = function (am) {
        while (v < am) {
            w |= e() << v;
            v += 8
        }
    };
    var y = function (am) {
        return w & ag[am]
    };
    var d = function (am) {
        w >>= am;
        v -= am
    };
    var g = function (ar, ap, an) {
        var ao;
        var am;
        var aq;
        if (an == 0) {
            return 0
        }
        aq = 0;
        for (;;) {
            ai(f);
            am = q.list[y(f)];
            ao = am.e;
            while (ao > 16) {
                if (ao == 99) {
                    return -1
                }
                d(am.b);
                ao -= 16;
                ai(ao);
                am = am.t[y(ao)];
                ao = am.e
            }
            d(am.b);
            if (ao == 16) {
                o &= r - 1;
                ar[ap + aq++] = K[o++] = am.n;
                if (aq == an) {
                    return an
                }
                continue
            }
            if (ao == 15) {
                break
            }
            ai(ao);
            ak = am.n + y(ao);
            d(ao);
            ai(l);
            am = s.list[y(l)];
            ao = am.e;
            while (ao > 16) {
                if (ao == 99) {
                    return -1
                }
                d(am.b);
                ao -= 16;
                ai(ao);
                am = am.t[y(ao)];
                ao = am.e
            }
            d(am.b);
            ai(ao);
            C = o - am.n - y(ao);
            d(ao);
            while (ak > 0 && aq < an) {
                ak--;
                C &= r - 1;
                o &= r - 1;
                ar[ap + aq++] = K[o++] = K[C++]
            }
            if (aq == an) {
                return an
            }
        }
        al = -1;
        return aq
    };
    var z = function (ap, an, am) {
        var ao;
        ao = v & 7;
        d(ao);
        ai(16);
        ao = y(16);
        d(16);
        ai(16);
        if (ao != ((~w) & 65535)) {
            return -1
        }
        d(16);
        ak = ao;
        ao = 0;
        while (ak > 0 && ao < am) {
            ak--;
            o &= r - 1;
            ai(8);
            ap[an + ao++] = K[o++] = y(8);
            d(8)
        }
        if (ak == 0) {
            al = -1
        }
        return ao
    };
    var W = function (ar, aq, ao) {
        if (ah == null) {
            var an;
            var am = new Array(288);
            var ap;
            for (an = 0; an < 144; an++) {
                am[an] = 8
            }
            for (; an < 256; an++) {
                am[an] = 9
            }
            for (; an < 280; an++) {
                am[an] = 7
            }
            for (; an < 288; an++) {
                am[an] = 8
            }
            ab = 7;
            ap = new p(am, 288, 257, c, Z, ab);
            if (ap.status != 0) {
                alert("HufBuild error: " + ap.status);
                return -1
            }
            ah = ap.root;
            ab = ap.m;
            for (an = 0; an < 30; an++) {
                am[an] = 5
            }
            zip_fixed_bd = 5;
            ap = new p(am, 30, 0, V, E, zip_fixed_bd);
            if (ap.status > 1) {
                ah = null;
                alert("HufBuild error: " + ap.status);
                return -1
            }
            b = ap.root;
            zip_fixed_bd = ap.m
        }
        q = ah;
        s = b;
        f = ab;
        l = zip_fixed_bd;
        return g(ar, aq, ao)
    };
    var F = function (ay, ao, aA) {
        var au;
        var ar;
        var ap;
        var an;
        var az;
        var aw;
        var am;
        var aq;
        var ax = new Array(286 + 30);
        var av;
        for (au = 0; au < ax.length; au++) {
            ax[au] = 0
        }
        ai(5);
        am = 257 + y(5);
        d(5);
        ai(5);
        aq = 1 + y(5);
        d(5);
        ai(4);
        aw = 4 + y(4);
        d(4);
        if (am > 286 || aq > 30) {
            return -1
        }
        for (ar = 0; ar < aw; ar++) {
            ai(3);
            ax[u[ar]] = y(3);
            d(3)
        }
        for (; ar < 19; ar++) {
            ax[u[ar]] = 0
        }
        f = 7;
        av = new p(ax, 19, 19, null, null, f);
        if (av.status != 0) {
            return -1
        }
        q = av.root;
        f = av.m;
        an = am + aq;
        au = ap = 0;
        while (au < an) {
            ai(f);
            az = q.list[y(f)];
            ar = az.b;
            d(ar);
            ar = az.n;
            if (ar < 16) {
                ax[au++] = ap = ar
            } else {
                if (ar == 16) {
                    ai(2);
                    ar = 3 + y(2);
                    d(2);
                    if (au + ar > an) {
                        return -1
                    }
                    while (ar-- > 0) {
                        ax[au++] = ap
                    }
                } else {
                    if (ar == 17) {
                        ai(3);
                        ar = 3 + y(3);
                        d(3);
                        if (au + ar > an) {
                            return -1
                        }
                        while (ar-- > 0) {
                            ax[au++] = 0
                        }
                        ap = 0
                    } else {
                        ai(7);
                        ar = 11 + y(7);
                        d(7);
                        if (au + ar > an) {
                            return -1
                        }
                        while (ar-- > 0) {
                            ax[au++] = 0
                        }
                        ap = 0
                    }
                }
            }
        }
        f = aj;
        av = new p(ax, am, 257, c, Z, f);
        if (f == 0) {
            av.status = 1
        }
        if (av.status != 0) {
            if (av.status == 1) {}
            return -1
        }
        q = av.root;
        f = av.m;
        for (au = 0; au < aq; au++) {
            ax[au] = ax[au + am]
        }
        l = j;
        av = new p(ax, aq, 0, V, E, l);
        s = av.root;
        l = av.m;
        if (l == 0 && am > 257) {
            return -1
        }
        if (av.status == 1) {}
        if (av.status != 0) {
            return -1
        }
        return g(ay, ao, aA)
    };
    var af = function () {
        var am;
        if (K == null) {
            K = new Array(2 * r)
        }
        o = 0;
        w = 0;
        v = 0;
        al = -1;
        ad = false;
        ak = C = 0;
        q = null
    };
    var P = function (aq, ao, an) {
        var ap, am;
        ap = 0;
        while (ap < an) {
            if (ad && al == -1) {
                return ap
            }
            if (ak > 0) {
                if (al != A) {
                    while (ak > 0 && ap < an) {
                        ak--;
                        C &= r - 1;
                        o &= r - 1;
                        aq[ao + ap++] = K[o++] = K[C++]
                    }
                } else {
                    while (ak > 0 && ap < an) {
                        ak--;
                        o &= r - 1;
                        ai(8);
                        aq[ao + ap++] = K[o++] = y(8);
                        d(8)
                    }
                    if (ak == 0) {
                        al = -1
                    }
                }
                if (ap == an) {
                    return ap
                }
            }
            if (al == -1) {
                if (ad) {
                    break
                }
                ai(1);
                if (y(1) != 0) {
                    ad = true
                }
                d(1);
                ai(2);
                al = y(2);
                d(2);
                q = null;
                ak = 0
            }
            switch (al) {
            case 0:
                am = z(aq, ao + ap, an - ap);
                break;
            case 1:
                if (q != null) {
                    am = g(aq, ao + ap, an - ap)
                } else {
                    am = W(aq, ao + ap, an - ap)
                }
                break;
            case 2:
                if (q != null) {
                    am = g(aq, ao + ap, an - ap)
                } else {
                    am = F(aq, ao + ap, an - ap)
                }
                break;
            default:
                am = -1;
                break
            }
            if (am == -1) {
                if (ad) {
                    return 0
                }
                return -1
            }
            ap += am
        }
        return ap
    };
    var N = function () {
        var ao, an, aq = 0;
        var ap = false;
        var ar = new Array(1024);
        while ((ao = P(ar, 0, ar.length)) > 0) {
            var am = new Array(ao);
            for (an = 0; an < ao; an++) {
                Q.setUint8(U + an, ar[an])
            }
            U += ao;
            aq += ao;
            if (X) {
                X.drawProgress(U / I)
            }
            if (aq > h) {
                ap = true;
                break
            }
        }
        if (ap) {
            setTimeout(N, 0)
        } else {
            G = null;
            J = null;
            H(D)
        }
    };
    this.gunzip = function (au, av) {
        H = av;
        ae = au.byteLength;
        J = new DataView(au);
        var ar = J.getUint8(0);
        var aq = J.getUint8(1);
        if (ar != GUNZIP_MAGIC_COOKIE1) {
            L = n;
            return null
        } else {
            if (aq != GUNZIP_MAGIC_COOKIE2) {
                L = n;
                return null
            }
        }
        var ao = J.getUint8(3);
        var ay = ((ao & 1) != 0);
        var aw = ((ao & 2) != 0);
        var ap = ((ao & 4) != 0);
        var ax = ((ao & 8) != 0);
        var am = ((ao & 16) != 0);
        if (ay || aw || ap || am) {
            L = Y;
            return null
        }
        ac = k;
        if (ax) {
            for (var an = ac; an < ae; an++) {
                if (J.getUint8(an) == 0) {
                    ac = an + 1;
                    break
                }
            }
        }
        aa = ae - ac - i;
        I = J.getUint32(ae - 4, true);
        J = new DataView(au, ac, aa);
        D = new ArrayBuffer(I);
        Q = new DataView(D);
        af();
        G = J;
        O = 0;
        N()
    };
    this.hasError = function () {
        return (L != null)
    };
    this.getError = function () {
        return L
    }
};
"use strict";
var numeric = (typeof exports === "undefined") ? (function numeric() {}) : (exports);
if (typeof global !== "undefined") {
    global.numeric = numeric
}
numeric.version = "1.2.6";
numeric.bench = function bench(e, a) {
    var d, c, g, b;
    if (typeof a === "undefined") {
        a = 15
    }
    g = 0.5;
    d = new Date();
    while (1) {
        g *= 2;
        for (b = g; b > 3; b -= 4) {
            e();
            e();
            e();
            e()
        }
        while (b > 0) {
            e();
            b--
        }
        c = new Date();
        if (c - d > a) {
            break
        }
    }
    for (b = g; b > 3; b -= 4) {
        e();
        e();
        e();
        e()
    }
    while (b > 0) {
        e();
        b--
    }
    c = new Date();
    return 1000 * (3 * g - 1) / (c - d)
};
numeric._myIndexOf = (function _myIndexOf(a) {
    var c = this.length,
        b;
    for (b = 0; b < c; ++b) {
        if (this[b] === a) {
            return b
        }
    }
    return -1
});
numeric.myIndexOf = (Array.prototype.indexOf) ? Array.prototype.indexOf : numeric._myIndexOf;
numeric.Function = Function;
numeric.precision = 4;
numeric.largeArray = 50;
numeric.prettyPrint = function prettyPrint(b) {
    function a(e) {
        if (e === 0) {
            return "0"
        }
        if (isNaN(e)) {
            return "NaN"
        }
        if (e < 0) {
            return "-" + a(-e)
        }
        if (isFinite(e)) {
            var h = Math.floor(Math.log(e) / Math.log(10));
            var g = e / Math.pow(10, h);
            var f = g.toPrecision(numeric.precision);
            if (parseFloat(f) === 10) {
                h++;
                g = 1;
                f = g.toPrecision(numeric.precision)
            }
            return parseFloat(f).toString() + "e" + h.toString()
        }
        return "Infinity"
    }
    var c = [];

    function d(f) {
        var i;
        if (typeof f === "undefined") {
            c.push(Array(numeric.precision + 8).join(" "));
            return false
        }
        if (typeof f === "string") {
            c.push('"' + f + '"');
            return false
        }
        if (typeof f === "boolean") {
            c.push(f.toString());
            return false
        }
        if (typeof f === "number") {
            var h = a(f);
            var e = f.toPrecision(numeric.precision);
            var l = parseFloat(f.toString()).toString();
            var j = [h, e, l, parseFloat(e).toString(), parseFloat(l).toString()];
            for (i = 1; i < j.length; i++) {
                if (j[i].length < h.length) {
                    h = j[i]
                }
            }
            c.push(Array(numeric.precision + 8 - h.length).join(" ") + h);
            return false
        }
        if (f === null) {
            c.push("null");
            return false
        }
        if (typeof f === "function") {
            c.push(f.toString());
            var g = false;
            for (i in f) {
                if (f.hasOwnProperty(i)) {
                    if (g) {
                        c.push(",\n")
                    } else {
                        c.push("\n{")
                    }
                    g = true;
                    c.push(i);
                    c.push(": \n");
                    d(f[i])
                }
            }
            if (g) {
                c.push("}\n")
            }
            return true
        }
        if (f instanceof Array) {
            if (f.length > numeric.largeArray) {
                c.push("...Large Array...");
                return true
            }
            var g = false;
            c.push("[");
            for (i = 0; i < f.length; i++) {
                if (i > 0) {
                    c.push(",");
                    if (g) {
                        c.push("\n ")
                    }
                }
                g = d(f[i])
            }
            c.push("]");
            return true
        }
        c.push("{");
        var g = false;
        for (i in f) {
            if (f.hasOwnProperty(i)) {
                if (g) {
                    c.push(",\n")
                }
                g = true;
                c.push(i);
                c.push(": \n");
                d(f[i])
            }
        }
        c.push("}");
        return true
    }
    d(b);
    return c.join("")
};
numeric.parseDate = function parseDate(a) {
    function b(f) {
        if (typeof f === "string") {
            return Date.parse(f.replace(/-/g, "/"))
        }
        if (!(f instanceof Array)) {
            throw new Error("parseDate: parameter must be arrays of strings")
        }
        var e = [],
            c;
        for (c = 0; c < f.length; c++) {
            e[c] = b(f[c])
        }
        return e
    }
    return b(a)
};
numeric.parseFloat = function parseFloat_(a) {
    function b(f) {
        if (typeof f === "string") {
            return parseFloat(f)
        }
        if (!(f instanceof Array)) {
            throw new Error("parseFloat: parameter must be arrays of strings")
        }
        var e = [],
            c;
        for (c = 0; c < f.length; c++) {
            e[c] = b(f[c])
        }
        return e
    }
    return b(a)
};
numeric.parseCSV = function parseCSV(m) {
    var l = m.split("\n");
    var e, d;
    var i = [];
    var g = /(([^'",]*)|('[^']*')|("[^"]*")),/g;
    var b = /^\s*(([+-]?[0-9]+(\.[0-9]*)?(e[+-]?[0-9]+)?)|([+-]?[0-9]*(\.[0-9]+)?(e[+-]?[0-9]+)?))\s*$/;
    var a = function (j) {
        return j.substr(0, j.length - 1)
    };
    var f = 0;
    for (d = 0; d < l.length; d++) {
        var h = (l[d] + ",").match(g),
            c;
        if (h.length > 0) {
            i[f] = [];
            for (e = 0; e < h.length; e++) {
                c = a(h[e]);
                if (b.test(c)) {
                    i[f][e] = parseFloat(c)
                } else {
                    i[f][e] = c
                }
            }
            f++
        }
    }
    return i
};
numeric.toCSV = function toCSV(b) {
    var f = numeric.dim(b);
    var e, d, a, h, g, c;
    a = f[0];
    h = f[1];
    c = [];
    for (e = 0; e < a; e++) {
        g = [];
        for (d = 0; d < a; d++) {
            g[d] = b[e][d].toString()
        }
        c[e] = g.join(", ")
    }
    return c.join("\n") + "\n"
};
numeric.getURL = function getURL(b) {
    var a = new XMLHttpRequest();
    a.open("GET", b, false);
    a.send();
    return a
};
numeric.imageURL = function imageURL(m) {
    function p(j) {
        var k = j.length,
            w, E, D, C, h, b, a, G;
        var F = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var B = "";
        for (w = 0; w < k; w += 3) {
            E = j[w];
            D = j[w + 1];
            C = j[w + 2];
            h = E >> 2;
            b = ((E & 3) << 4) + (D >> 4);
            a = ((D & 15) << 2) + (C >> 6);
            G = C & 63;
            if (w + 1 >= k) {
                a = G = 64
            } else {
                if (w + 2 >= k) {
                    G = 64
                }
            }
            B += F.charAt(h) + F.charAt(b) + F.charAt(a) + F.charAt(G)
        }
        return B
    }
    function q(b, B, A) {
        if (typeof B === "undefined") {
            B = 0
        }
        if (typeof A === "undefined") {
            A = b.length
        }
        var j = [0, 1996959894, 3993919788, 2567524794, 124634137, 1886057615, 3915621685, 2657392035, 249268274, 2044508324, 3772115230, 2547177864, 162941995, 2125561021, 3887607047, 2428444049, 498536548, 1789927666, 4089016648, 2227061214, 450548861, 1843258603, 4107580753, 2211677639, 325883990, 1684777152, 4251122042, 2321926636, 335633487, 1661365465, 4195302755, 2366115317, 997073096, 1281953886, 3579855332, 2724688242, 1006888145, 1258607687, 3524101629, 2768942443, 901097722, 1119000684, 3686517206, 2898065728, 853044451, 1172266101, 3705015759, 2882616665, 651767980, 1373503546, 3369554304, 3218104598, 565507253, 1454621731, 3485111705, 3099436303, 671266974, 1594198024, 3322730930, 2970347812, 795835527, 1483230225, 3244367275, 3060149565, 1994146192, 31158534, 2563907772, 4023717930, 1907459465, 112637215, 2680153253, 3904427059, 2013776290, 251722036, 2517215374, 3775830040, 2137656763, 141376813, 2439277719, 3865271297, 1802195444, 476864866, 2238001368, 4066508878, 1812370925, 453092731, 2181625025, 4111451223, 1706088902, 314042704, 2344532202, 4240017532, 1658658271, 366619977, 2362670323, 4224994405, 1303535960, 984961486, 2747007092, 3569037538, 1256170817, 1037604311, 2765210733, 3554079995, 1131014506, 879679996, 2909243462, 3663771856, 1141124467, 855842277, 2852801631, 3708648649, 1342533948, 654459306, 3188396048, 3373015174, 1466479909, 544179635, 3110523913, 3462522015, 1591671054, 702138776, 2966460450, 3352799412, 1504918807, 783551873, 3082640443, 3233442989, 3988292384, 2596254646, 62317068, 1957810842, 3939845945, 2647816111, 81470997, 1943803523, 3814918930, 2489596804, 225274430, 2053790376, 3826175755, 2466906013, 167816743, 2097651377, 4027552580, 2265490386, 503444072, 1762050814, 4150417245, 2154129355, 426522225, 1852507879, 4275313526, 2312317920, 282753626, 1742555852, 4189708143, 2394877945, 397917763, 1622183637, 3604390888, 2714866558, 953729732, 1340076626, 3518719985, 2797360999, 1068828381, 1219638859, 3624741850, 2936675148, 906185462, 1090812512, 3747672003, 2825379669, 829329135, 1181335161, 3412177804, 3160834842, 628085408, 1382605366, 3423369109, 3138078467, 570562233, 1426400815, 3317316542, 2998733608, 733239954, 1555261956, 3268935591, 3050360625, 752459403, 1541320221, 2607071920, 3965973030, 1969922972, 40735498, 2617837225, 3943577151, 1913087877, 83908371, 2512341634, 3803740692, 2075208622, 213261112, 2463272603, 3855990285, 2094854071, 198958881, 2262029012, 4057260610, 1759359992, 534414190, 2176718541, 4139329115, 1873836001, 414664567, 2282248934, 4279200368, 1711684554, 285281116, 2405801727, 4167216745, 1634467795, 376229701, 2685067896, 3608007406, 1308918612, 956543938, 2808555105, 3495958263, 1231636301, 1047427035, 2932959818, 3654703836, 1088359270, 936918000, 2847714899, 3736837829, 1202900863, 817233897, 3183342108, 3401237130, 1404277552, 615818150, 3134207493, 3453421203, 1423857449, 601450431, 3009837614, 3294710456, 1567103746, 711928724, 3020668471, 3272380065, 1510334235, 755167117];
        var k = -1,
            z = 0,
            w = b.length,
            h;
        for (h = B; h < A; h++) {
            z = (k ^ b[h]) & 255;
            k = (k >>> 8) ^ j[z]
        }
        return k ^ (-1)
    }
    var n = m[0].length,
        v = m[0][0].length,
        x, u, o, e, c, s, r, l, f, g, d;
    var y = [137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, (v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255, (n >> 24) & 255, (n >> 16) & 255, (n >> 8) & 255, n & 255, 8, 2, 0, 0, 0, -1, -2, -3, -4, -5, -6, -7, -8, 73, 68, 65, 84, 8, 29];
    d = q(y, 12, 29);
    y[29] = (d >> 24) & 255;
    y[30] = (d >> 16) & 255;
    y[31] = (d >> 8) & 255;
    y[32] = (d) & 255;
    x = 1;
    u = 0;
    for (l = 0; l < n; l++) {
        if (l < n - 1) {
            y.push(0)
        } else {
            y.push(1)
        }
        s = (3 * v + 1 + (l === 0)) & 255;
        r = ((3 * v + 1 + (l === 0)) >> 8) & 255;
        y.push(s);
        y.push(r);
        y.push((~s) & 255);
        y.push((~r) & 255);
        if (l === 0) {
            y.push(0)
        }
        for (f = 0; f < v; f++) {
            for (e = 0; e < 3; e++) {
                s = m[e][l][f];
                if (s > 255) {
                    s = 255
                } else {
                    if (s < 0) {
                        s = 0
                    } else {
                        s = Math.round(s)
                    }
                }
                x = (x + s) % 65521;
                u = (u + x) % 65521;
                y.push(s)
            }
        }
        y.push(0)
    }
    g = (u << 16) + x;
    y.push((g >> 24) & 255);
    y.push((g >> 16) & 255);
    y.push((g >> 8) & 255);
    y.push((g) & 255);
    c = y.length - 41;
    y[33] = (c >> 24) & 255;
    y[34] = (c >> 16) & 255;
    y[35] = (c >> 8) & 255;
    y[36] = (c) & 255;
    d = q(y, 37);
    y.push((d >> 24) & 255);
    y.push((d >> 16) & 255);
    y.push((d >> 8) & 255);
    y.push((d) & 255);
    y.push(0);
    y.push(0);
    y.push(0);
    y.push(0);
    y.push(73);
    y.push(69);
    y.push(78);
    y.push(68);
    y.push(174);
    y.push(66);
    y.push(96);
    y.push(130);
    return "data:image/png;base64," + p(y)
};
numeric._dim = function _dim(a) {
    var b = [];
    while (typeof a === "object") {
        b.push(a.length);
        a = a[0]
    }
    return b
};
numeric.dim = function dim(a) {
    var c, b;
    if (typeof a === "object") {
        c = a[0];
        if (typeof c === "object") {
            b = c[0];
            if (typeof b === "object") {
                return numeric._dim(a)
            }
            return [a.length, c.length]
        }
        return [a.length]
    }
    return []
};
numeric.mapreduce = function mapreduce(a, b) {
    return Function("x", "accum", "_s", "_k", 'if(typeof accum === "undefined") accum = ' + b + ';\nif(typeof x === "number") { var xi = x; ' + a + '; return accum; }\nif(typeof _s === "undefined") _s = numeric.dim(x);\nif(typeof _k === "undefined") _k = 0;\nvar _n = _s[_k];\nvar i,xi;\nif(_k < _s.length-1) {\n    for(i=_n-1;i>=0;i--) {\n        accum = arguments.callee(x[i],accum,_s,_k+1);\n    }    return accum;\n}\nfor(i=_n-1;i>=1;i-=2) { \n    xi = x[i];\n    ' + a + ";\n    xi = x[i-1];\n    " + a + ";\n}\nif(i === 0) {\n    xi = x[i];\n    " + a + "\n}\nreturn accum;")
};
numeric.mapreduce2 = function mapreduce2(b, a) {
    return Function("x", "var n = x.length;\nvar i,xi;\n" + a + ";\nfor(i=n-1;i!==-1;--i) { \n    xi = x[i];\n    " + b + ";\n}\nreturn accum;")
};
numeric.same = function same(a, d) {
    var b, c;
    if (!(a instanceof Array) || !(d instanceof Array)) {
        return false
    }
    c = a.length;
    if (c !== d.length) {
        return false
    }
    for (b = 0; b < c; b++) {
        if (a[b] === d[b]) {
            continue
        }
        if (typeof a[b] === "object") {
            if (!same(a[b], d[b])) {
                return false
            }
        } else {
            return false
        }
    }
    return true
};
numeric.rep = function rep(e, b, a) {
    if (typeof a === "undefined") {
        a = 0
    }
    var f = e[a],
        c = Array(f),
        d;
    if (a === e.length - 1) {
        for (d = f - 2; d >= 0; d -= 2) {
            c[d + 1] = b;
            c[d] = b
        }
        if (d === -1) {
            c[0] = b
        }
        return c
    }
    for (d = f - 1; d >= 0; d--) {
        c[d] = numeric.rep(e, b, a + 1)
    }
    return c
};
numeric.dotMMsmall = function dotMMsmall(v, u) {
    var l, g, e, c, b, a, n, s, m, h, f, o, w, d;
    c = v.length;
    b = u.length;
    a = u[0].length;
    n = Array(c);
    for (l = c - 1; l >= 0; l--) {
        s = Array(a);
        m = v[l];
        for (e = a - 1; e >= 0; e--) {
            h = m[b - 1] * u[b - 1][e];
            for (g = b - 2; g >= 1; g -= 2) {
                f = g - 1;
                h += m[g] * u[g][e] + m[f] * u[f][e]
            }
            if (g === 0) {
                h += m[0] * u[0][e]
            }
            s[e] = h
        }
        n[l] = s
    }
    return n
};
numeric._getCol = function _getCol(b, c, a) {
    var e = b.length,
        d;
    for (d = e - 1; d > 0; --d) {
        a[d] = b[d][c];
        --d;
        a[d] = b[d][c]
    }
    if (d === 0) {
        a[0] = b[0][c]
    }
};
numeric.dotMMbig = function dotMMbig(r, q) {
    var s = numeric._getCol,
        a = q.length,
        u = Array(a);
    var d = r.length,
        c = q[0].length,
        b = new Array(d),
        l;
    var f = numeric.dotVV;
    var h, g, e, o;
    --a;
    --d;
    for (h = d; h !== -1; --h) {
        b[h] = Array(c)
    }--c;
    for (h = c; h !== -1; --h) {
        s(q, h, u);
        for (g = d; g !== -1; --g) {
            o = 0;
            l = r[g];
            b[g][h] = f(l, u)
        }
    }
    return b
};
numeric.dotMV = function dotMV(a, g) {
    var e = a.length,
        d = g.length,
        c;
    var b = Array(e),
        f = numeric.dotVV;
    for (c = e - 1; c >= 0; c--) {
        b[c] = f(a[c], g)
    }
    return b
};
numeric.dotVM = function dotVM(h, g) {
    var w, v, u, n, m, l, D, B, A, e, s, f, c, z, d, b, a, o, C;
    n = h.length;
    m = g[0].length;
    D = Array(m);
    for (u = m - 1; u >= 0; u--) {
        e = h[n - 1] * g[n - 1][u];
        for (v = n - 2; v >= 1; v -= 2) {
            s = v - 1;
            e += h[v] * g[v][u] + h[s] * g[s][u]
        }
        if (v === 0) {
            e += h[0] * g[0][u]
        }
        D[u] = e
    }
    return D
};
numeric.dotVV = function dotVV(a, f) {
    var c, e = a.length,
        d, b = a[e - 1] * f[e - 1];
    for (c = e - 2; c >= 1; c -= 2) {
        d = c - 1;
        b += a[c] * f[c] + a[d] * f[d]
    }
    if (c === 0) {
        b += a[0] * f[0]
    }
    return b
};
numeric.dot = function dot(a, c) {
    var b = numeric.dim;
    switch (b(a).length * 1000 + b(c).length) {
    case 2002:
        if (c.length < 10) {
            return numeric.dotMMsmall(a, c)
        } else {
            return numeric.dotMMbig(a, c)
        }
    case 2001:
        return numeric.dotMV(a, c);
    case 1002:
        return numeric.dotVM(a, c);
    case 1001:
        return numeric.dotVV(a, c);
    case 1000:
        return numeric.mulVS(a, c);
    case 1:
        return numeric.mulSV(a, c);
    case 0:
        return a * c;
    default:
        throw new Error("numeric.dot only works on vectors and matrices")
    }
};
numeric.diag = function diag(g) {
    var e, f, c, h = g.length,
        a = Array(h),
        b;
    for (e = h - 1; e >= 0; e--) {
        b = Array(h);
        f = e + 2;
        for (c = h - 1; c >= f; c -= 2) {
            b[c] = 0;
            b[c - 1] = 0
        }
        if (c > e) {
            b[c] = 0
        }
        b[e] = g[e];
        for (c = e - 1; c >= 1; c -= 2) {
            b[c] = 0;
            b[c - 1] = 0
        }
        if (c === 0) {
            b[0] = 0
        }
        a[e] = b
    }
    return a
};
numeric.getDiag = function (a) {
    var d = Math.min(a.length, a[0].length),
        c, b = Array(d);
    for (c = d - 1; c >= 1; --c) {
        b[c] = a[c][c];
        --c;
        b[c] = a[c][c]
    }
    if (c === 0) {
        b[0] = a[0][0]
    }
    return b
};
numeric.identity = function identity(a) {
    return numeric.diag(numeric.rep([a], 1))
};
numeric.pointwise = function pointwise(d, g, c) {
    if (typeof c === "undefined") {
        c = ""
    }
    var h = [];
    var e;
    var i = /\[i\]$/,
        a, f = "";
    var b = false;
    for (e = 0; e < d.length; e++) {
        if (i.test(d[e])) {
            a = d[e].substring(0, d[e].length - 3);
            f = a
        } else {
            a = d[e]
        }
        if (a === "ret") {
            b = true
        }
        h.push(a)
    }
    h[d.length] = "_s";
    h[d.length + 1] = "_k";
    h[d.length + 2] = ('if(typeof _s === "undefined") _s = numeric.dim(' + f + ');\nif(typeof _k === "undefined") _k = 0;\nvar _n = _s[_k];\nvar i' + (b ? "" : ", ret = Array(_n)") + ";\nif(_k < _s.length-1) {\n    for(i=_n-1;i>=0;i--) ret[i] = arguments.callee(" + d.join(",") + ",_s,_k+1);\n    return ret;\n}\n" + c + "\nfor(i=_n-1;i!==-1;--i) {\n    " + g + "\n}\nreturn ret;");
    return Function.apply(null, h)
};
numeric.pointwise2 = function pointwise2(d, g, c) {
    if (typeof c === "undefined") {
        c = ""
    }
    var h = [];
    var e;
    var i = /\[i\]$/,
        a, f = "";
    var b = false;
    for (e = 0; e < d.length; e++) {
        if (i.test(d[e])) {
            a = d[e].substring(0, d[e].length - 3);
            f = a
        } else {
            a = d[e]
        }
        if (a === "ret") {
            b = true
        }
        h.push(a)
    }
    h[d.length] = ("var _n = " + f + ".length;\nvar i" + (b ? "" : ", ret = Array(_n)") + ";\n" + c + "\nfor(i=_n-1;i!==-1;--i) {\n" + g + "\n}\nreturn ret;");
    return Function.apply(null, h)
};
numeric._biforeach = (function _biforeach(a, h, d, b, e) {
    if (b === d.length - 1) {
        e(a, h);
        return
    }
    var c, g = d[b];
    for (c = g - 1; c >= 0; c--) {
        _biforeach(typeof a === "object" ? a[c] : a, typeof h === "object" ? h[c] : h, d, b + 1, e)
    }
});
numeric._biforeach2 = (function _biforeach2(a, j, e, b, g) {
    if (b === e.length - 1) {
        return g(a, j)
    }
    var d, h = e[b],
        c = Array(h);
    for (d = h - 1; d >= 0; --d) {
        c[d] = _biforeach2(typeof a === "object" ? a[d] : a, typeof j === "object" ? j[d] : j, e, b + 1, g)
    }
    return c
});
numeric._foreach = (function _foreach(a, d, b, e) {
    if (b === d.length - 1) {
        e(a);
        return
    }
    var c, g = d[b];
    for (c = g - 1; c >= 0; c--) {
        _foreach(a[c], d, b + 1, e)
    }
});
numeric._foreach2 = (function _foreach2(a, e, b, g) {
    if (b === e.length - 1) {
        return g(a)
    }
    var d, h = e[b],
        c = Array(h);
    for (d = h - 1; d >= 0; d--) {
        c[d] = _foreach2(a[d], e, b + 1, g)
    }
    return c
});
numeric.ops2 = {
    add: "+",
    sub: "-",
    mul: "*",
    div: "/",
    mod: "%",
    and: "&&",
    or: "||",
    eq: "===",
    neq: "!==",
    lt: "<",
    gt: ">",
    leq: "<=",
    geq: ">=",
    band: "&",
    bor: "|",
    bxor: "^",
    lshift: "<<",
    rshift: ">>",
    rrshift: ">>>"
};
numeric.opseq = {
    addeq: "+=",
    subeq: "-=",
    muleq: "*=",
    diveq: "/=",
    modeq: "%=",
    lshifteq: "<<=",
    rshifteq: ">>=",
    rrshifteq: ">>>=",
    bandeq: "&=",
    boreq: "|=",
    bxoreq: "^="
};
numeric.mathfuns = ["abs", "acos", "asin", "atan", "ceil", "cos", "exp", "floor", "log", "round", "sin", "sqrt", "tan", "isNaN", "isFinite"];
numeric.mathfuns2 = ["atan2", "pow", "max", "min"];
numeric.ops1 = {
    neg: "-",
    not: "!",
    bnot: "~",
    clone: ""
};
numeric.mapreducers = {
    any: ["if(xi) return true;", "var accum = false;"],
    all: ["if(!xi) return false;", "var accum = true;"],
    sum: ["accum += xi;", "var accum = 0;"],
    prod: ["accum *= xi;", "var accum = 1;"],
    norm2Squared: ["accum += xi*xi;", "var accum = 0;"],
    norminf: ["accum = max(accum,abs(xi));", "var accum = 0, max = Math.max, abs = Math.abs;"],
    norm1: ["accum += abs(xi)", "var accum = 0, abs = Math.abs;"],
    sup: ["accum = max(accum,xi);", "var accum = -Infinity, max = Math.max;"],
    inf: ["accum = min(accum,xi);", "var accum = Infinity, min = Math.min;"]
};
(function () {
    var b, e;
    for (b = 0; b < numeric.mathfuns2.length; ++b) {
        e = numeric.mathfuns2[b];
        numeric.ops2[e] = e
    }
    for (b in numeric.ops2) {
        if (numeric.ops2.hasOwnProperty(b)) {
            e = numeric.ops2[b];
            var c, d, a = "";
            if (numeric.myIndexOf.call(numeric.mathfuns2, b) !== -1) {
                a = "var " + e + " = Math." + e + ";\n";
                c = function (g, f, h) {
                    return g + " = " + e + "(" + f + "," + h + ")"
                };
                d = function (f, g) {
                    return f + " = " + e + "(" + f + "," + g + ")"
                }
            } else {
                c = function (g, f, h) {
                    return g + " = " + f + " " + e + " " + h
                };
                if (numeric.opseq.hasOwnProperty(b + "eq")) {
                    d = function (f, g) {
                        return f + " " + e + "= " + g
                    }
                } else {
                    d = function (f, g) {
                        return f + " = " + f + " " + e + " " + g
                    }
                }
            }
            numeric[b + "VV"] = numeric.pointwise2(["x[i]", "y[i]"], c("ret[i]", "x[i]", "y[i]"), a);
            numeric[b + "SV"] = numeric.pointwise2(["x", "y[i]"], c("ret[i]", "x", "y[i]"), a);
            numeric[b + "VS"] = numeric.pointwise2(["x[i]", "y"], c("ret[i]", "x[i]", "y"), a);
            numeric[b] = Function("var n = arguments.length, i, x = arguments[0], y;\nvar VV = numeric." + b + "VV, VS = numeric." + b + "VS, SV = numeric." + b + 'SV;\nvar dim = numeric.dim;\nfor(i=1;i!==n;++i) { \n  y = arguments[i];\n  if(typeof x === "object") {\n      if(typeof y === "object") x = numeric._biforeach2(x,y,dim(x),0,VV);\n      else x = numeric._biforeach2(x,y,dim(x),0,VS);\n  } else if(typeof y === "object") x = numeric._biforeach2(x,y,dim(y),0,SV);\n  else ' + d("x", "y") + "\n}\nreturn x;\n");
            numeric[e] = numeric[b];
            numeric[b + "eqV"] = numeric.pointwise2(["ret[i]", "x[i]"], d("ret[i]", "x[i]"), a);
            numeric[b + "eqS"] = numeric.pointwise2(["ret[i]", "x"], d("ret[i]", "x"), a);
            numeric[b + "eq"] = Function("var n = arguments.length, i, x = arguments[0], y;\nvar V = numeric." + b + "eqV, S = numeric." + b + 'eqS\nvar s = numeric.dim(x);\nfor(i=1;i!==n;++i) { \n  y = arguments[i];\n  if(typeof y === "object") numeric._biforeach(x,y,s,0,V);\n  else numeric._biforeach(x,y,s,0,S);\n}\nreturn x;\n')
        }
    }
    for (b = 0; b < numeric.mathfuns2.length; ++b) {
        e = numeric.mathfuns2[b];
        delete numeric.ops2[e]
    }
    for (b = 0; b < numeric.mathfuns.length; ++b) {
        e = numeric.mathfuns[b];
        numeric.ops1[e] = e
    }
    for (b in numeric.ops1) {
        if (numeric.ops1.hasOwnProperty(b)) {
            a = "";
            e = numeric.ops1[b];
            if (numeric.myIndexOf.call(numeric.mathfuns, b) !== -1) {
                if (Math.hasOwnProperty(e)) {
                    a = "var " + e + " = Math." + e + ";\n"
                }
            }
            numeric[b + "eqV"] = numeric.pointwise2(["ret[i]"], "ret[i] = " + e + "(ret[i]);", a);
            numeric[b + "eq"] = Function("x", 'if(typeof x !== "object") return ' + e + "x\nvar i;\nvar V = numeric." + b + "eqV;\nvar s = numeric.dim(x);\nnumeric._foreach(x,s,0,V);\nreturn x;\n");
            numeric[b + "V"] = numeric.pointwise2(["x[i]"], "ret[i] = " + e + "(x[i]);", a);
            numeric[b] = Function("x", 'if(typeof x !== "object") return ' + e + "(x)\nvar i;\nvar V = numeric." + b + "V;\nvar s = numeric.dim(x);\nreturn numeric._foreach2(x,s,0,V);\n")
        }
    }
    for (b = 0; b < numeric.mathfuns.length; ++b) {
        e = numeric.mathfuns[b];
        delete numeric.ops1[e]
    }
    for (b in numeric.mapreducers) {
        if (numeric.mapreducers.hasOwnProperty(b)) {
            e = numeric.mapreducers[b];
            numeric[b + "V"] = numeric.mapreduce2(e[0], e[1]);
            numeric[b] = Function("x", "s", "k", e[1] + 'if(typeof x !== "object") {    xi = x;\n' + e[0] + ';\n    return accum;\n}if(typeof s === "undefined") s = numeric.dim(x);\nif(typeof k === "undefined") k = 0;\nif(k === s.length-1) return numeric.' + b + "V(x);\nvar xi;\nvar n = x.length, i;\nfor(i=n-1;i!==-1;--i) {\n   xi = arguments.callee(x[i]);\n" + e[0] + ";\n}\nreturn accum;\n")
        }
    }
}());
numeric.truncVV = numeric.pointwise(["x[i]", "y[i]"], "ret[i] = round(x[i]/y[i])*y[i];", "var round = Math.round;");
numeric.truncVS = numeric.pointwise(["x[i]", "y"], "ret[i] = round(x[i]/y)*y;", "var round = Math.round;");
numeric.truncSV = numeric.pointwise(["x", "y[i]"], "ret[i] = round(x/y[i])*y[i];", "var round = Math.round;");
numeric.trunc = function trunc(a, b) {
    if (typeof a === "object") {
        if (typeof b === "object") {
            return numeric.truncVV(a, b)
        }
        return numeric.truncVS(a, b)
    }
    if (typeof b === "object") {
        return numeric.truncSV(a, b)
    }
    return Math.round(a / b) * b
};
numeric.inv = function inv(o) {
    var v = numeric.dim(o),
        w = Math.abs,
        d = v[0],
        c = v[1];
    var b = numeric.clone(o),
        q, l;
    var p = numeric.identity(d),
        a, u;
    var h, g, e, o;
    for (g = 0; g < c; ++g) {
        var f = -1;
        var r = -1;
        for (h = g; h !== d; ++h) {
            e = w(b[h][g]);
            if (e > r) {
                f = h;
                r = e
            }
        }
        l = b[f];
        b[f] = b[g];
        b[g] = l;
        u = p[f];
        p[f] = p[g];
        p[g] = u;
        o = l[g];
        for (e = g; e !== c; ++e) {
            l[e] /= o
        }
        for (e = c - 1; e !== -1; --e) {
            u[e] /= o
        }
        for (h = d - 1; h !== -1; --h) {
            if (h !== g) {
                q = b[h];
                a = p[h];
                o = q[g];
                for (e = g + 1; e !== c; ++e) {
                    q[e] -= l[e] * o
                }
                for (e = c - 1; e > 0; --e) {
                    a[e] -= u[e] * o;
                    --e;
                    a[e] -= u[e] * o
                }
                if (e === 0) {
                    a[0] -= u[0] * o
                }
            }
        }
    }
    return p
};
numeric.det = function det(p) {
    var u = numeric.dim(p);
    if (u.length !== 2 || u[0] !== u[1]) {
        throw new Error("numeric: det() only works on square matrices")
    }
    var b = u[0],
        l = 1,
        f, e, d, a = numeric.clone(p),
        o, q, c, r, m, h, g;
    for (e = 0; e < b - 1; e++) {
        d = e;
        for (f = e + 1; f < b; f++) {
            if (Math.abs(a[f][e]) > Math.abs(a[d][e])) {
                d = f
            }
        }
        if (d !== e) {
            r = a[d];
            a[d] = a[e];
            a[e] = r;
            l *= -1
        }
        o = a[e];
        for (f = e + 1; f < b; f++) {
            q = a[f];
            c = q[e] / o[e];
            for (d = e + 1; d < b - 1; d += 2) {
                m = d + 1;
                q[d] -= o[d] * c;
                q[m] -= o[m] * c
            }
            if (d !== b) {
                q[d] -= o[d] * c
            }
        }
        if (o[e] === 0) {
            return 0
        }
        l *= o[e]
    }
    return l * a[e][e]
};
numeric.transpose = function transpose(k) {
    var g, e, c = k.length,
        a = k[0].length,
        h = Array(a),
        d, b, f;
    for (e = 0; e < a; e++) {
        h[e] = Array(c)
    }
    for (g = c - 1; g >= 1; g -= 2) {
        b = k[g];
        d = k[g - 1];
        for (e = a - 1; e >= 1; --e) {
            f = h[e];
            f[g] = b[e];
            f[g - 1] = d[e];
            --e;
            f = h[e];
            f[g] = b[e];
            f[g - 1] = d[e]
        }
        if (e === 0) {
            f = h[0];
            f[g] = b[0];
            f[g - 1] = d[0]
        }
    }
    if (g === 0) {
        d = k[0];
        for (e = a - 1; e >= 1; --e) {
            h[e][0] = d[e];
            --e;
            h[e][0] = d[e]
        }
        if (e === 0) {
            h[0][0] = d[0]
        }
    }
    return h
};
numeric.negtranspose = function negtranspose(k) {
    var g, e, c = k.length,
        a = k[0].length,
        h = Array(a),
        d, b, f;
    for (e = 0; e < a; e++) {
        h[e] = Array(c)
    }
    for (g = c - 1; g >= 1; g -= 2) {
        b = k[g];
        d = k[g - 1];
        for (e = a - 1; e >= 1; --e) {
            f = h[e];
            f[g] = -b[e];
            f[g - 1] = -d[e];
            --e;
            f = h[e];
            f[g] = -b[e];
            f[g - 1] = -d[e]
        }
        if (e === 0) {
            f = h[0];
            f[g] = -b[0];
            f[g - 1] = -d[0]
        }
    }
    if (g === 0) {
        d = k[0];
        for (e = a - 1; e >= 1; --e) {
            h[e][0] = -d[e];
            --e;
            h[e][0] = -d[e]
        }
        if (e === 0) {
            h[0][0] = -d[0]
        }
    }
    return h
};
numeric._random = function _random(e, a) {
    var d, f = e[a],
        b = Array(f),
        c;
    if (a === e.length - 1) {
        c = Math.random;
        for (d = f - 1; d >= 1; d -= 2) {
            b[d] = c();
            b[d - 1] = c()
        }
        if (d === 0) {
            b[0] = c()
        }
        return b
    }
    for (d = f - 1; d >= 0; d--) {
        b[d] = _random(e, a + 1)
    }
    return b
};
numeric.random = function random(a) {
    return numeric._random(a, 0)
};
numeric.norm2 = function norm2(a) {
    return Math.sqrt(numeric.norm2Squared(a))
};
numeric.linspace = function linspace(d, c, g) {
    if (typeof g === "undefined") {
        g = Math.max(Math.round(c - d) + 1, 1)
    }
    if (g < 2) {
        return g === 1 ? [d] : []
    }
    var f, e = Array(g);
    g--;
    for (f = g; f >= 0; f--) {
        e[f] = (f * c + (g - f) * d) / g
    }
    return e
};
numeric.getBlock = function getBlock(a, e, d) {
    var b = numeric.dim(a);

    function c(f, h) {
        var l, g = e[h],
            m = d[h] - g,
            j = Array(m);
        if (h === b.length - 1) {
            for (l = m; l >= 0; l--) {
                j[l] = f[l + g]
            }
            return j
        }
        for (l = m; l >= 0; l--) {
            j[l] = c(f[l + g], h + 1)
        }
        return j
    }
    return c(a, 0)
};
numeric.setBlock = function setBlock(a, f, e, d) {
    var b = numeric.dim(a);

    function c(g, o, j) {
        var l, h = f[j],
            m = e[j] - h;
        if (j === b.length - 1) {
            for (l = m; l >= 0; l--) {
                g[l + h] = o[l]
            }
        }
        for (l = m; l >= 0; l--) {
            c(g[l + h], o[l], j + 1)
        }
    }
    c(a, d, 0);
    return a
};
numeric.getRange = function getRange(b, l, k) {
    var e = l.length,
        d = k.length;
    var g, f;
    var a = Array(e),
        h, c;
    for (g = e - 1; g !== -1; --g) {
        a[g] = Array(d);
        h = a[g];
        c = b[l[g]];
        for (f = d - 1; f !== -1; --f) {
            h[f] = c[k[f]]
        }
    }
    return a
};
numeric.blockMatrix = function blockMatrix(b) {
    var x = numeric.dim(b);
    if (x.length < 4) {
        return numeric.blockMatrix([b])
    }
    var d = x[0],
        c = x[1],
        r, q, o, h, w;
    r = 0;
    q = 0;
    for (o = 0; o < d; ++o) {
        r += b[o][0].length
    }
    for (h = 0; h < c; ++h) {
        q += b[0][h][0].length
    }
    var a = Array(r);
    for (o = 0; o < r; ++o) {
        a[o] = Array(q)
    }
    var v = 0,
        u, p, g, e, f;
    for (o = 0; o < d; ++o) {
        u = q;
        for (h = c - 1; h !== -1; --h) {
            w = b[o][h];
            u -= w[0].length;
            for (g = w.length - 1; g !== -1; --g) {
                f = w[g];
                p = a[v + g];
                for (e = f.length - 1; e !== -1; --e) {
                    p[u + e] = f[e]
                }
            }
        }
        v += b[o][0].length
    }
    return a
};
numeric.tensor = function tensor(h, g) {
    if (typeof h === "number" || typeof g === "number") {
        return numeric.mul(h, g)
    }
    var o = numeric.dim(h),
        k = numeric.dim(g);
    if (o.length !== 1 || k.length !== 1) {
        throw new Error("numeric: tensor product is only defined for vectors")
    }
    var c = o[0],
        b = k[0],
        a = Array(c),
        l, e, d, f;
    for (e = c - 1; e >= 0; e--) {
        l = Array(b);
        f = h[e];
        for (d = b - 1; d >= 3; --d) {
            l[d] = f * g[d];
            --d;
            l[d] = f * g[d];
            --d;
            l[d] = f * g[d];
            --d;
            l[d] = f * g[d]
        }
        while (d >= 0) {
            l[d] = f * g[d];
            --d
        }
        a[e] = l
    }
    return a
};
numeric.T = function T(a, b) {
    this.x = a;
    this.y = b
};
numeric.t = function t(a, b) {
    return new numeric.T(a, b)
};
numeric.Tbinop = function Tbinop(c, e, d, g, a) {
    var f = numeric.indexOf;
    if (typeof a !== "string") {
        var b;
        a = "";
        for (b in numeric) {
            if (numeric.hasOwnProperty(b) && (c.indexOf(b) >= 0 || e.indexOf(b) >= 0 || d.indexOf(b) >= 0 || g.indexOf(b) >= 0) && b.length > 1) {
                a += "var " + b + " = numeric." + b + ";\n"
            }
        }
    }
    return Function(["y"], "var x = this;\nif(!(y instanceof numeric.T)) { y = new numeric.T(y); }\n" + a + "\nif(x.y) {  if(y.y) {    return new numeric.T(" + g + ");\n  }\n  return new numeric.T(" + d + ");\n}\nif(y.y) {\n  return new numeric.T(" + e + ");\n}\nreturn new numeric.T(" + c + ");\n")
};
numeric.T.prototype.add = numeric.Tbinop("add(x.x,y.x)", "add(x.x,y.x),y.y", "add(x.x,y.x),x.y", "add(x.x,y.x),add(x.y,y.y)");
numeric.T.prototype.sub = numeric.Tbinop("sub(x.x,y.x)", "sub(x.x,y.x),neg(y.y)", "sub(x.x,y.x),x.y", "sub(x.x,y.x),sub(x.y,y.y)");
numeric.T.prototype.mul = numeric.Tbinop("mul(x.x,y.x)", "mul(x.x,y.x),mul(x.x,y.y)", "mul(x.x,y.x),mul(x.y,y.x)", "sub(mul(x.x,y.x),mul(x.y,y.y)),add(mul(x.x,y.y),mul(x.y,y.x))");
numeric.T.prototype.reciprocal = function reciprocal() {
    var a = numeric.mul,
        c = numeric.div;
    if (this.y) {
        var b = numeric.add(a(this.x, this.x), a(this.y, this.y));
        return new numeric.T(c(this.x, b), c(numeric.neg(this.y), b))
    }
    return new T(c(1, this.x))
};
numeric.T.prototype.div = function div(b) {
    if (!(b instanceof numeric.T)) {
        b = new numeric.T(b)
    }
    if (b.y) {
        return this.mul(b.reciprocal())
    }
    var a = numeric.div;
    if (this.y) {
        return new numeric.T(a(this.x, b.x), a(this.y, b.x))
    }
    return new numeric.T(a(this.x, b.x))
};
numeric.T.prototype.dot = numeric.Tbinop("dot(x.x,y.x)", "dot(x.x,y.x),dot(x.x,y.y)", "dot(x.x,y.x),dot(x.y,y.x)", "sub(dot(x.x,y.x),dot(x.y,y.y)),add(dot(x.x,y.y),dot(x.y,y.x))");
numeric.T.prototype.transpose = function transpose() {
    var b = numeric.transpose,
        a = this.x,
        c = this.y;
    if (c) {
        return new numeric.T(b(a), b(c))
    }
    return new numeric.T(b(a))
};
numeric.T.prototype.transjugate = function transjugate() {
    var b = numeric.transpose,
        a = this.x,
        c = this.y;
    if (c) {
        return new numeric.T(b(a), numeric.negtranspose(c))
    }
    return new numeric.T(b(a))
};
numeric.Tunop = function Tunop(b, d, a) {
    if (typeof a !== "string") {
        a = ""
    }
    return Function("var x = this;\n" + a + "\nif(x.y) {  " + d + ";\n}\n" + b + ";\n")
};
numeric.T.prototype.exp = numeric.Tunop("return new numeric.T(ex)", "return new numeric.T(mul(cos(x.y),ex),mul(sin(x.y),ex))", "var ex = numeric.exp(x.x), cos = numeric.cos, sin = numeric.sin, mul = numeric.mul;");
numeric.T.prototype.conj = numeric.Tunop("return new numeric.T(x.x);", "return new numeric.T(x.x,numeric.neg(x.y));");
numeric.T.prototype.neg = numeric.Tunop("return new numeric.T(neg(x.x));", "return new numeric.T(neg(x.x),neg(x.y));", "var neg = numeric.neg;");
numeric.T.prototype.sin = numeric.Tunop("return new numeric.T(numeric.sin(x.x))", "return x.exp().sub(x.neg().exp()).div(new numeric.T(0,2));");
numeric.T.prototype.cos = numeric.Tunop("return new numeric.T(numeric.cos(x.x))", "return x.exp().add(x.neg().exp()).div(2);");
numeric.T.prototype.abs = numeric.Tunop("return new numeric.T(numeric.abs(x.x));", "return new numeric.T(numeric.sqrt(numeric.add(mul(x.x,x.x),mul(x.y,x.y))));", "var mul = numeric.mul;");
numeric.T.prototype.log = numeric.Tunop("return new numeric.T(numeric.log(x.x));", "var theta = new numeric.T(numeric.atan2(x.y,x.x)), r = x.abs();\nreturn new numeric.T(numeric.log(r.x),theta.x);");
numeric.T.prototype.norm2 = numeric.Tunop("return numeric.norm2(x.x);", "var f = numeric.norm2Squared;\nreturn Math.sqrt(f(x.x)+f(x.y));");
numeric.T.prototype.inv = function inv() {
    var r = this;
    if (typeof r.y === "undefined") {
        return new numeric.T(numeric.inv(r.x))
    }
    var s = r.x.length,
        w, v, u;
    var e = numeric.identity(s),
        c = numeric.rep([s, s], 0);
    var q = numeric.clone(r.x),
        o = numeric.clone(r.y);
    var b, a, l, h, p, m, D, C;
    var w, v, u, B, E, g, f, y, x, z;
    for (w = 0; w < s; w++) {
        g = q[w][w];
        f = o[w][w];
        B = g * g + f * f;
        u = w;
        for (v = w + 1; v < s; v++) {
            g = q[v][w];
            f = o[v][w];
            E = g * g + f * f;
            if (E > B) {
                u = v;
                B = E
            }
        }
        if (u !== w) {
            z = q[w];
            q[w] = q[u];
            q[u] = z;
            z = o[w];
            o[w] = o[u];
            o[u] = z;
            z = e[w];
            e[w] = e[u];
            e[u] = z;
            z = c[w];
            c[w] = c[u];
            c[u] = z
        }
        b = q[w];
        a = o[w];
        p = e[w];
        m = c[w];
        g = b[w];
        f = a[w];
        for (v = w + 1; v < s; v++) {
            y = b[v];
            x = a[v];
            b[v] = (y * g + x * f) / B;
            a[v] = (x * g - y * f) / B
        }
        for (v = 0; v < s; v++) {
            y = p[v];
            x = m[v];
            p[v] = (y * g + x * f) / B;
            m[v] = (x * g - y * f) / B
        }
        for (v = w + 1; v < s; v++) {
            l = q[v];
            h = o[v];
            D = e[v];
            C = c[v];
            g = l[w];
            f = h[w];
            for (u = w + 1; u < s; u++) {
                y = b[u];
                x = a[u];
                l[u] -= y * g - x * f;
                h[u] -= x * g + y * f
            }
            for (u = 0; u < s; u++) {
                y = p[u];
                x = m[u];
                D[u] -= y * g - x * f;
                C[u] -= x * g + y * f
            }
        }
    }
    for (w = s - 1; w > 0; w--) {
        p = e[w];
        m = c[w];
        for (v = w - 1; v >= 0; v--) {
            D = e[v];
            C = c[v];
            g = q[v][w];
            f = o[v][w];
            for (u = s - 1; u >= 0; u--) {
                y = p[u];
                x = m[u];
                D[u] -= g * y - f * x;
                C[u] -= g * x + f * y
            }
        }
    }
    return new numeric.T(e, c)
};
numeric.T.prototype.get = function get(d) {
    var a = this.x,
        f = this.y,
        b = 0,
        c, e = d.length;
    if (f) {
        while (b < e) {
            c = d[b];
            a = a[c];
            f = f[c];
            b++
        }
        return new numeric.T(a, f)
    }
    while (b < e) {
        c = d[b];
        a = a[c];
        b++
    }
    return new numeric.T(a)
};
numeric.T.prototype.set = function set(c, j) {
    var g = this.x,
        e = this.y,
        b = 0,
        h, a = c.length,
        f = j.x,
        d = j.y;
    if (a === 0) {
        if (d) {
            this.y = d
        } else {
            if (e) {
                this.y = undefined
            }
        }
        this.x = g;
        return this
    }
    if (d) {
        if (e) {} else {
            e = numeric.rep(numeric.dim(g), 0);
            this.y = e
        }
        while (b < a - 1) {
            h = c[b];
            g = g[h];
            e = e[h];
            b++
        }
        h = c[b];
        g[h] = f;
        e[h] = d;
        return this
    }
    if (e) {
        while (b < a - 1) {
            h = c[b];
            g = g[h];
            e = e[h];
            b++
        }
        h = c[b];
        g[h] = f;
        if (f instanceof Array) {
            e[h] = numeric.rep(numeric.dim(f), 0)
        } else {
            e[h] = 0
        }
        return this
    }
    while (b < a - 1) {
        h = c[b];
        g = g[h];
        b++
    }
    h = c[b];
    g[h] = f;
    return this
};
numeric.T.prototype.getRows = function getRows(e, c) {
    var h = c - e + 1,
        b;
    var f = Array(h),
        d, a = this.x,
        g = this.y;
    for (b = e; b <= c; b++) {
        f[b - e] = a[b]
    }
    if (g) {
        d = Array(h);
        for (b = e; b <= c; b++) {
            d[b - e] = g[b]
        }
        return new numeric.T(f, d)
    }
    return new numeric.T(f)
};
numeric.T.prototype.setRows = function setRows(f, d, b) {
    var c;
    var g = this.x,
        e = this.y,
        a = b.x,
        h = b.y;
    for (c = f; c <= d; c++) {
        g[c] = a[c - f]
    }
    if (h) {
        if (!e) {
            e = numeric.rep(numeric.dim(g), 0);
            this.y = e
        }
        for (c = f; c <= d; c++) {
            e[c] = h[c - f]
        }
    } else {
        if (e) {
            for (c = f; c <= d; c++) {
                e[c] = numeric.rep([a[c - f].length], 0)
            }
        }
    }
    return this
};
numeric.T.prototype.getRow = function getRow(b) {
    var a = this.x,
        c = this.y;
    if (c) {
        return new numeric.T(a[b], c[b])
    }
    return new numeric.T(a[b])
};
numeric.T.prototype.setRow = function setRow(c, b) {
    var e = this.x,
        d = this.y,
        a = b.x,
        f = b.y;
    e[c] = a;
    if (f) {
        if (!d) {
            d = numeric.rep(numeric.dim(e), 0);
            this.y = d
        }
        d[c] = f
    } else {
        if (d) {
            d = numeric.rep([a.length], 0)
        }
    }
    return this
};
numeric.T.prototype.getBlock = function getBlock(f, e) {
    var c = this.x,
        d = this.y,
        a = numeric.getBlock;
    if (d) {
        return new numeric.T(a(c, f, e), a(d, f, e))
    }
    return new numeric.T(a(c, f, e))
};
numeric.T.prototype.setBlock = function setBlock(i, h, d) {
    if (!(d instanceof numeric.T)) {
        d = new numeric.T(d)
    }
    var c = this.x,
        g = this.y,
        a = numeric.setBlock,
        f = d.x,
        e = d.y;
    if (e) {
        if (!g) {
            this.y = numeric.rep(numeric.dim(this), 0);
            g = this.y
        }
        a(c, i, h, f);
        a(g, i, h, e);
        return this
    }
    a(c, i, h, f);
    if (g) {
        a(g, i, h, numeric.rep(numeric.dim(f), 0))
    }
};
numeric.T.rep = function rep(d, b) {
    var c = numeric.T;
    if (!(b instanceof c)) {
        b = new c(b)
    }
    var a = b.x,
        f = b.y,
        e = numeric.rep;
    if (f) {
        return new c(e(d, a), e(d, f))
    }
    return new c(e(d, a))
};
numeric.T.diag = function diag(c) {
    if (!(c instanceof numeric.T)) {
        c = new numeric.T(c)
    }
    var a = c.x,
        e = c.y,
        b = numeric.diag;
    if (e) {
        return new numeric.T(b(a), b(e))
    }
    return new numeric.T(b(a))
};
numeric.T.eig = function eig() {
    if (this.y) {
        throw new Error("eig: not implemented for complex matrices.")
    }
    return numeric.eig(this.x)
};
numeric.T.identity = function identity(a) {
    return new numeric.T(numeric.identity(a))
};
numeric.T.prototype.getDiag = function getDiag() {
    var c = numeric;
    var a = this.x,
        b = this.y;
    if (b) {
        return new c.T(c.getDiag(a), c.getDiag(b))
    }
    return new c.T(c.getDiag(a))
};
numeric.house = function house(a) {
    var b = numeric.clone(a);
    var c = a[0] >= 0 ? 1 : -1;
    var d = c * numeric.norm2(a);
    b[0] += d;
    var e = numeric.norm2(b);
    if (e === 0) {
        throw new Error("eig: internal error")
    }
    return numeric.div(b, e)
};
numeric.toUpperHessenberg = function toUpperHessenberg(o) {
    var u = numeric.dim(o);
    if (u.length !== 2 || u[0] !== u[1]) {
        throw new Error("numeric: toUpperHessenberg() only works on square matrices")
    }
    var f = u[0],
        l, h, g, p, r, d = numeric.clone(o),
        c, a, q, b, n = numeric.identity(f),
        e;
    for (h = 0; h < f - 2; h++) {
        p = Array(f - h - 1);
        for (l = h + 1; l < f; l++) {
            p[l - h - 1] = d[l][h]
        }
        if (numeric.norm2(p) > 0) {
            r = numeric.house(p);
            c = numeric.getBlock(d, [h + 1, h], [f - 1, f - 1]);
            a = numeric.tensor(r, numeric.dot(r, c));
            for (l = h + 1; l < f; l++) {
                q = d[l];
                b = a[l - h - 1];
                for (g = h; g < f; g++) {
                    q[g] -= 2 * b[g - h]
                }
            }
            c = numeric.getBlock(d, [0, h + 1], [f - 1, f - 1]);
            a = numeric.tensor(numeric.dot(c, r), r);
            for (l = 0; l < f; l++) {
                q = d[l];
                b = a[l];
                for (g = h + 1; g < f; g++) {
                    q[g] -= 2 * b[g - h - 1]
                }
            }
            c = Array(f - h - 1);
            for (l = h + 1; l < f; l++) {
                c[l - h - 1] = n[l]
            }
            a = numeric.tensor(r, numeric.dot(r, c));
            for (l = h + 1; l < f; l++) {
                e = n[l];
                b = a[l - h - 1];
                for (g = 0; g < f; g++) {
                    e[g] -= 2 * b[g]
                }
            }
        }
    }
    return {
        H: d,
        Q: n
    }
};
numeric.epsilon = 2.220446049250313e-16;
numeric.QRFrancis = function (z, h) {
    if (typeof h === "undefined") {
        h = 10000
    }
    z = numeric.clone(z);
    var D = numeric.clone(z);
    var E = numeric.dim(z),
        K = E[0],
        y, A, U, S, R, P, n, e, l, q = numeric.identity(K),
        u, r, I, G, F, O, M, L, N;
    if (K < 3) {
        return {
            Q: q,
            B: [
                [0, K - 1]
            ]
        }
    }
    var V = numeric.epsilon;
    for (N = 0; N < h; N++) {
        for (M = 0; M < K - 1; M++) {
            if (Math.abs(z[M + 1][M]) < V * (Math.abs(z[M][M]) + Math.abs(z[M + 1][M + 1]))) {
                var p = numeric.QRFrancis(numeric.getBlock(z, [0, 0], [M, M]), h);
                var o = numeric.QRFrancis(numeric.getBlock(z, [M + 1, M + 1], [K - 1, K - 1]), h);
                I = Array(M + 1);
                for (O = 0; O <= M; O++) {
                    I[O] = q[O]
                }
                G = numeric.dot(p.Q, I);
                for (O = 0; O <= M; O++) {
                    q[O] = G[O]
                }
                I = Array(K - M - 1);
                for (O = M + 1; O < K; O++) {
                    I[O - M - 1] = q[O]
                }
                G = numeric.dot(o.Q, I);
                for (O = M + 1; O < K; O++) {
                    q[O] = G[O - M - 1]
                }
                return {
                    Q: q,
                    B: p.B.concat(numeric.add(o.B, M + 1))
                }
            }
        }
        U = z[K - 2][K - 2];
        S = z[K - 2][K - 1];
        R = z[K - 1][K - 2];
        P = z[K - 1][K - 1];
        e = U + P;
        n = (U * P - S * R);
        l = numeric.getBlock(z, [0, 0], [2, 2]);
        if (e * e >= 4 * n) {
            var g, f;
            g = 0.5 * (e + Math.sqrt(e * e - 4 * n));
            f = 0.5 * (e - Math.sqrt(e * e - 4 * n));
            l = numeric.add(numeric.sub(numeric.dot(l, l), numeric.mul(l, g + f)), numeric.diag(numeric.rep([3], g * f)))
        } else {
            l = numeric.add(numeric.sub(numeric.dot(l, l), numeric.mul(l, e)), numeric.diag(numeric.rep([3], n)))
        }
        y = [l[0][0], l[1][0], l[2][0]];
        A = numeric.house(y);
        I = [z[0], z[1], z[2]];
        G = numeric.tensor(A, numeric.dot(A, I));
        for (O = 0; O < 3; O++) {
            r = z[O];
            F = G[O];
            for (L = 0; L < K; L++) {
                r[L] -= 2 * F[L]
            }
        }
        I = numeric.getBlock(z, [0, 0], [K - 1, 2]);
        G = numeric.tensor(numeric.dot(I, A), A);
        for (O = 0; O < K; O++) {
            r = z[O];
            F = G[O];
            for (L = 0; L < 3; L++) {
                r[L] -= 2 * F[L]
            }
        }
        I = [q[0], q[1], q[2]];
        G = numeric.tensor(A, numeric.dot(A, I));
        for (O = 0; O < 3; O++) {
            u = q[O];
            F = G[O];
            for (L = 0; L < K; L++) {
                u[L] -= 2 * F[L]
            }
        }
        var w;
        for (M = 0; M < K - 2; M++) {
            for (L = M; L <= M + 1; L++) {
                if (Math.abs(z[L + 1][L]) < V * (Math.abs(z[L][L]) + Math.abs(z[L + 1][L + 1]))) {
                    var p = numeric.QRFrancis(numeric.getBlock(z, [0, 0], [L, L]), h);
                    var o = numeric.QRFrancis(numeric.getBlock(z, [L + 1, L + 1], [K - 1, K - 1]), h);
                    I = Array(L + 1);
                    for (O = 0; O <= L; O++) {
                        I[O] = q[O]
                    }
                    G = numeric.dot(p.Q, I);
                    for (O = 0; O <= L; O++) {
                        q[O] = G[O]
                    }
                    I = Array(K - L - 1);
                    for (O = L + 1; O < K; O++) {
                        I[O - L - 1] = q[O]
                    }
                    G = numeric.dot(o.Q, I);
                    for (O = L + 1; O < K; O++) {
                        q[O] = G[O - L - 1]
                    }
                    return {
                        Q: q,
                        B: p.B.concat(numeric.add(o.B, L + 1))
                    }
                }
            }
            w = Math.min(K - 1, M + 3);
            y = Array(w - M);
            for (O = M + 1; O <= w; O++) {
                y[O - M - 1] = z[O][M]
            }
            A = numeric.house(y);
            I = numeric.getBlock(z, [M + 1, M], [w, K - 1]);
            G = numeric.tensor(A, numeric.dot(A, I));
            for (O = M + 1; O <= w; O++) {
                r = z[O];
                F = G[O - M - 1];
                for (L = M; L < K; L++) {
                    r[L] -= 2 * F[L - M]
                }
            }
            I = numeric.getBlock(z, [0, M + 1], [K - 1, w]);
            G = numeric.tensor(numeric.dot(I, A), A);
            for (O = 0; O < K; O++) {
                r = z[O];
                F = G[O];
                for (L = M + 1; L <= w; L++) {
                    r[L] -= 2 * F[L - M - 1]
                }
            }
            I = Array(w - M);
            for (O = M + 1; O <= w; O++) {
                I[O - M - 1] = q[O]
            }
            G = numeric.tensor(A, numeric.dot(A, I));
            for (O = M + 1; O <= w; O++) {
                u = q[O];
                F = G[O - M - 1];
                for (L = 0; L < K; L++) {
                    u[L] -= 2 * F[L]
                }
            }
        }
    }
    throw new Error("numeric: eigenvalue iteration does not converge -- increase maxiter?")
};
numeric.eig = function eig(L, l) {
    var f = numeric.toUpperHessenberg(L);
    var o = numeric.QRFrancis(f.H, l);
    var r = numeric.T;
    var O = L.length,
        W, S, V = false,
        J = o.B,
        D = numeric.dot(o.Q, numeric.dot(f.H, numeric.transpose(o.Q)));
    var u = new r(numeric.dot(o.Q, f.Q)),
        G;
    var P = J.length,
        U;
    var aa, Z, Y, X, h, g, e, C, z, K, I, w, v;
    var ab = Math.sqrt;
    for (S = 0; S < P; S++) {
        W = J[S][0];
        if (W === J[S][1]) {} else {
            U = W + 1;
            aa = D[W][W];
            Z = D[W][U];
            Y = D[U][W];
            X = D[U][U];
            if (Z === 0 && Y === 0) {
                continue
            }
            h = -aa - X;
            g = aa * X - Z * Y;
            e = h * h - 4 * g;
            if (e >= 0) {
                if (h < 0) {
                    C = -0.5 * (h - ab(e))
                } else {
                    C = -0.5 * (h + ab(e))
                }
                w = (aa - C) * (aa - C) + Z * Z;
                v = Y * Y + (X - C) * (X - C);
                if (w > v) {
                    w = ab(w);
                    K = (aa - C) / w;
                    I = Z / w
                } else {
                    v = ab(v);
                    K = Y / v;
                    I = (X - C) / v
                }
                G = new r([
                    [I, -K],
                    [K, I]
                ]);
                u.setRows(W, U, G.dot(u.getRows(W, U)))
            } else {
                C = -0.5 * h;
                z = 0.5 * ab(-e);
                w = (aa - C) * (aa - C) + Z * Z;
                v = Y * Y + (X - C) * (X - C);
                if (w > v) {
                    w = ab(w + z * z);
                    K = (aa - C) / w;
                    I = Z / w;
                    C = 0;
                    z /= w
                } else {
                    v = ab(v + z * z);
                    K = Y / v;
                    I = (X - C) / v;
                    C = z / v;
                    z = 0
                }
                G = new r([
                    [I, -K],
                    [K, I]
                ], [
                    [C, z],
                    [z, -C]
                ]);
                u.setRows(W, U, G.dot(u.getRows(W, U)))
            }
        }
    }
    var s = u.dot(L).dot(u.transjugate()),
        O = L.length,
        F = numeric.T.identity(O);
    for (U = 0; U < O; U++) {
        if (U > 0) {
            for (S = U - 1; S >= 0; S--) {
                var M = s.get([S, S]),
                    N = s.get([U, U]);
                if (numeric.neq(M.x, N.x) || numeric.neq(M.y, N.y)) {
                    C = s.getRow(S).getBlock([S], [U - 1]);
                    z = F.getRow(U).getBlock([S], [U - 1]);
                    F.set([U, S], (s.get([S, U]).neg().sub(C.dot(z))).div(M.sub(N)))
                } else {
                    F.setRow(U, F.getRow(S));
                    continue
                }
            }
        }
    }
    for (U = 0; U < O; U++) {
        C = F.getRow(U);
        F.setRow(U, C.div(C.norm2()))
    }
    F = F.transpose();
    F = u.transjugate().dot(F);
    return {
        lambda: s.getDiag(),
        E: F
    }
};
numeric.ccsSparse = function ccsSparse(a) {
    var d = a.length,
        b, g, f, e, k = [];
    for (f = d - 1; f !== -1; --f) {
        g = a[f];
        for (e in g) {
            e = parseInt(e);
            while (e >= k.length) {
                k[k.length] = 0
            }
            if (g[e] !== 0) {
                k[e]++
            }
        }
    }
    var b = k.length;
    var l = Array(b + 1);
    l[0] = 0;
    for (f = 0; f < b; ++f) {
        l[f + 1] = l[f] + k[f]
    }
    var h = Array(l[b]),
        c = Array(l[b]);
    for (f = d - 1; f !== -1; --f) {
        g = a[f];
        for (e in g) {
            if (g[e] !== 0) {
                k[e]--;
                h[l[e] + k[e]] = f;
                c[l[e] + k[e]] = g[e]
            }
        }
    }
    return [l, h, c]
};
numeric.ccsFull = function ccsFull(c) {
    var p = c[0],
        o = c[1],
        e = c[2],
        r = numeric.ccsDim(c),
        f = r[0],
        d = r[1],
        l, h, a, q, g;
    var b = numeric.rep([f, d], 0);
    for (l = 0; l < d; l++) {
        a = p[l];
        q = p[l + 1];
        for (h = a; h < q; ++h) {
            b[o[h]][l] = e[h]
        }
    }
    return b
};
numeric.ccsTSolve = function ccsTSolve(p, E, f, e, g) {
    var D = p[0],
        C = p[1],
        o = p[2],
        r = D.length - 1,
        z = Math.max,
        q = 0;
    if (typeof e === "undefined") {
        f = numeric.rep([r], 0)
    }
    if (typeof e === "undefined") {
        e = numeric.linspace(0, f.length - 1)
    }
    if (typeof g === "undefined") {
        g = []
    }
    function h(b) {
        var a;
        if (f[b] !== 0) {
            return
        }
        f[b] = 1;
        for (a = D[b]; a < D[b + 1]; ++a) {
            h(C[a])
        }
        g[q] = b;
        ++q
    }
    var B, y, d, c, v, s, w, u, F;
    for (B = e.length - 1; B !== -1; --B) {
        h(e[B])
    }
    g.length = q;
    for (B = g.length - 1; B !== -1; --B) {
        f[g[B]] = 0
    }
    for (B = e.length - 1; B !== -1; --B) {
        y = e[B];
        f[y] = E[y]
    }
    for (B = g.length - 1; B !== -1; --B) {
        y = g[B];
        d = D[y];
        c = z(D[y + 1], d);
        for (v = d; v !== c; ++v) {
            if (C[v] === y) {
                f[y] /= o[v];
                break
            }
        }
        F = f[y];
        for (v = d; v !== c; ++v) {
            s = C[v];
            if (s !== y) {
                f[s] -= F * o[v]
            }
        }
    }
    return f
};
numeric.ccsDFS = function ccsDFS(a) {
    this.k = Array(a);
    this.k1 = Array(a);
    this.j = Array(a)
};
numeric.ccsDFS.prototype.dfs = function dfs(o, r, p, q, i, g) {
    var d = 0,
        l, c = i.length;
    var e = this.k,
        h = this.k1,
        f = this.j,
        a, b;
    if (q[o] !== 0) {
        return
    }
    q[o] = 1;
    f[0] = o;
    e[0] = a = r[o];
    h[0] = b = r[o + 1];
    while (1) {
        if (a >= b) {
            i[c] = f[d];
            if (d === 0) {
                return
            }++c;
            --d;
            a = e[d];
            b = h[d]
        } else {
            l = g[p[a]];
            if (q[l] === 0) {
                q[l] = 1;
                e[d] = a;
                ++d;
                f[d] = l;
                a = r[l];
                h[d] = b = r[l + 1]
            } else {
                ++a
            }
        }
    }
};
numeric.ccsLPSolve = function ccsLPSolve(s, q, h, o, g, M, p) {
    var K = s[0],
        H = s[1],
        r = s[2],
        v = K.length - 1,
        u = 0;
    var e = q[0],
        d = q[1],
        N = q[2];
    var G, D, y, F, f, c, b, C, w, E, z, L;
    D = e[g];
    y = e[g + 1];
    o.length = 0;
    for (G = D; G < y; ++G) {
        p.dfs(M[d[G]], K, H, h, o, M)
    }
    for (G = o.length - 1; G !== -1; --G) {
        h[o[G]] = 0
    }
    for (G = D; G !== y; ++G) {
        F = M[d[G]];
        h[F] = N[G]
    }
    for (G = o.length - 1; G !== -1; --G) {
        F = o[G];
        c = K[F];
        b = K[F + 1];
        for (C = c; C < b; ++C) {
            if (M[H[C]] === F) {
                h[F] /= r[C];
                break
            }
        }
        L = h[F];
        for (C = c; C < b; ++C) {
            w = M[H[C]];
            if (w !== F) {
                h[w] -= L * r[C]
            }
        }
    }
    return h
};
numeric.ccsLUP1 = function ccsLUP1(z, h) {
    var D = z[0].length - 1;
    var p = [numeric.rep([D + 1], 0), [],
        []
    ],
        l = [numeric.rep([D + 1], 0), [],
            []
        ];
    var B = p[0],
        y = p[1],
        o = p[2],
        E = l[0],
        C = l[1],
        r = l[2];
    var s = numeric.rep([D], 0),
        w = numeric.rep([D], 0);
    var I, G, F, f, b, Q, J, N, M, q;
    var g = numeric.ccsLPSolve,
        H = Math.max,
        u = Math.abs;
    var n = numeric.linspace(0, D - 1),
        O = numeric.linspace(0, D - 1);
    var v = new numeric.ccsDFS(D);
    if (typeof h === "undefined") {
        h = 1
    }
    for (I = 0; I < D; ++I) {
        g(p, z, s, w, I, O, v);
        Q = -1;
        J = -1;
        for (G = w.length - 1; G !== -1; --G) {
            F = w[G];
            if (F <= I) {
                continue
            }
            N = u(s[F]);
            if (N > Q) {
                J = F;
                Q = N
            }
        }
        if (u(s[I]) < h * Q) {
            G = n[I];
            Q = n[J];
            n[I] = Q;
            O[Q] = I;
            n[J] = G;
            O[G] = J;
            Q = s[I];
            s[I] = s[J];
            s[J] = Q
        }
        Q = B[I];
        J = E[I];
        M = s[I];
        y[Q] = n[I];
        o[Q] = 1;
        ++Q;
        for (G = w.length - 1; G !== -1; --G) {
            F = w[G];
            N = s[F];
            w[G] = 0;
            s[F] = 0;
            if (F <= I) {
                C[J] = F;
                r[J] = N;
                ++J
            } else {
                y[Q] = n[F];
                o[Q] = N / M;
                ++Q
            }
        }
        B[I + 1] = Q;
        E[I + 1] = J
    }
    for (G = y.length - 1; G !== -1; --G) {
        y[G] = O[y[G]]
    }
    return {
        L: p,
        U: l,
        P: n,
        Pinv: O
    }
};
numeric.ccsDFS0 = function ccsDFS0(a) {
    this.k = Array(a);
    this.k1 = Array(a);
    this.j = Array(a)
};
numeric.ccsDFS0.prototype.dfs = function dfs(p, s, q, r, l, h, g) {
    var d = 0,
        o, c = l.length;
    var e = this.k,
        i = this.k1,
        f = this.j,
        a, b;
    if (r[p] !== 0) {
        return
    }
    r[p] = 1;
    f[0] = p;
    e[0] = a = s[h[p]];
    i[0] = b = s[h[p] + 1];
    while (1) {
        if (isNaN(a)) {
            throw new Error("Ow!")
        }
        if (a >= b) {
            l[c] = h[f[d]];
            if (d === 0) {
                return
            }++c;
            --d;
            a = e[d];
            b = i[d]
        } else {
            o = q[a];
            if (r[o] === 0) {
                r[o] = 1;
                e[d] = a;
                ++d;
                f[d] = o;
                o = h[o];
                a = s[o];
                i[d] = b = s[o + 1]
            } else {
                ++a
            }
        }
    }
};
numeric.ccsLPSolve0 = function ccsLPSolve0(u, r, h, p, o, N, f, q) {
    var L = u[0],
        K = u[1],
        s = u[2],
        w = L.length - 1,
        v = 0;
    var e = r[0],
        d = r[1],
        O = r[2];
    var H, E, z, G, g, c, b, D, x, F, C, M;
    E = e[o];
    z = e[o + 1];
    p.length = 0;
    for (H = E; H < z; ++H) {
        q.dfs(d[H], L, K, h, p, N, f)
    }
    for (H = p.length - 1; H !== -1; --H) {
        G = p[H];
        h[f[G]] = 0
    }
    for (H = E; H !== z; ++H) {
        G = d[H];
        h[G] = O[H]
    }
    for (H = p.length - 1; H !== -1; --H) {
        G = p[H];
        x = f[G];
        c = L[G];
        b = L[G + 1];
        for (D = c; D < b; ++D) {
            if (K[D] === x) {
                h[x] /= s[D];
                break
            }
        }
        M = h[x];
        for (D = c; D < b; ++D) {
            h[K[D]] -= M * s[D]
        }
        h[x] = M
    }
};
numeric.ccsLUP0 = function ccsLUP0(z, h) {
    var D = z[0].length - 1;
    var p = [numeric.rep([D + 1], 0), [],
        []
    ],
        l = [numeric.rep([D + 1], 0), [],
            []
        ];
    var B = p[0],
        x = p[1],
        o = p[2],
        E = l[0],
        C = l[1],
        s = l[2];
    var r = numeric.rep([D], 0),
        w = numeric.rep([D], 0);
    var I, G, F, f, b, Q, J, N, M, q;
    var g = numeric.ccsLPSolve0,
        H = Math.max,
        u = Math.abs;
    var n = numeric.linspace(0, D - 1),
        O = numeric.linspace(0, D - 1);
    var v = new numeric.ccsDFS0(D);
    if (typeof h === "undefined") {
        h = 1
    }
    for (I = 0; I < D; ++I) {
        g(p, z, r, w, I, O, n, v);
        Q = -1;
        J = -1;
        for (G = w.length - 1; G !== -1; --G) {
            F = w[G];
            if (F <= I) {
                continue
            }
            N = u(r[n[F]]);
            if (N > Q) {
                J = F;
                Q = N
            }
        }
        if (u(r[n[I]]) < h * Q) {
            G = n[I];
            Q = n[J];
            n[I] = Q;
            O[Q] = I;
            n[J] = G;
            O[G] = J
        }
        Q = B[I];
        J = E[I];
        M = r[n[I]];
        x[Q] = n[I];
        o[Q] = 1;
        ++Q;
        for (G = w.length - 1; G !== -1; --G) {
            F = w[G];
            N = r[n[F]];
            w[G] = 0;
            r[n[F]] = 0;
            if (F <= I) {
                C[J] = F;
                s[J] = N;
                ++J
            } else {
                x[Q] = n[F];
                o[Q] = N / M;
                ++Q
            }
        }
        B[I + 1] = Q;
        E[I + 1] = J
    }
    for (G = x.length - 1; G !== -1; --G) {
        x[G] = O[x[G]]
    }
    return {
        L: p,
        U: l,
        P: n,
        Pinv: O
    }
};
numeric.ccsLUP = numeric.ccsLUP0;
numeric.ccsDim = function ccsDim(a) {
    return [numeric.sup(a[1]) + 1, a[0].length - 1]
};
numeric.ccsGetBlock = function ccsGetBlock(D, J, I) {
    var v = numeric.ccsDim(D),
        G = v[0],
        F = v[1];
    if (typeof J === "undefined") {
        J = numeric.linspace(0, G - 1)
    } else {
        if (typeof J === "number") {
            J = [J]
        }
    }
    if (typeof I === "undefined") {
        I = numeric.linspace(0, F - 1)
    } else {
        if (typeof I === "number") {
            I = [I]
        }
    }
    var E, b, a, g = J.length,
        z, e = I.length,
        w, H, k;
    var d = numeric.rep([F], 0),
        c = [],
        M = [],
        y = [d, c, M];
    var L = D[0],
        K = D[1],
        C = D[2];
    var u = numeric.rep([G], 0),
        h = 0,
        f = numeric.rep([G], 0);
    for (z = 0; z < e; ++z) {
        H = I[z];
        var o = L[H];
        var l = L[H + 1];
        for (E = o; E < l; ++E) {
            w = K[E];
            f[w] = 1;
            u[w] = C[E]
        }
        for (E = 0; E < g; ++E) {
            k = J[E];
            if (f[k]) {
                c[h] = E;
                M[h] = u[J[E]];
                ++h
            }
        }
        for (E = o; E < l; ++E) {
            w = K[E];
            f[w] = 0
        }
        d[z + 1] = h
    }
    return y
};
numeric.ccsDot = function ccsDot(D, w) {
    var Q = D[0],
        P = D[1],
        z = D[2];
    var f = w[0],
        e = w[1],
        U = w[2];
    var O = numeric.ccsDim(D),
        M = numeric.ccsDim(w);
    var G = O[0],
        F = O[1],
        E = M[1];
    var q = numeric.rep([G], 0),
        h = numeric.rep([G], 0),
        v = Array(G);
    var u = numeric.rep([E], 0),
        r = [],
        g = [],
        s = [u, r, g];
    var N, L, K, d, c, J, I, H, y, S, R;
    for (K = 0; K !== E; ++K) {
        d = f[K];
        c = f[K + 1];
        y = 0;
        for (L = d; L < c; ++L) {
            S = e[L];
            R = U[L];
            J = Q[S];
            I = Q[S + 1];
            for (N = J; N < I; ++N) {
                H = P[N];
                if (h[H] === 0) {
                    v[y] = H;
                    h[H] = 1;
                    y = y + 1
                }
                q[H] = q[H] + z[N] * R
            }
        }
        d = u[K];
        c = d + y;
        u[K + 1] = c;
        for (L = y - 1; L !== -1; --L) {
            R = d + L;
            N = v[L];
            r[R] = N;
            g[R] = q[N];
            h[N] = 0;
            q[N] = 0
        }
        u[K + 1] = u[K] + y
    }
    return s
};
numeric.ccsLUPSolve = function ccsLUPSolve(l, w) {
    var q = l.L,
        f = l.U,
        o = l.P;
    var h = w[0];
    var G = false;
    if (typeof h !== "object") {
        w = [
            [0, w.length], numeric.linspace(0, w.length - 1), w];
        h = w[0];
        G = true
    }
    var g = w[1],
        I = w[2];
    var y = q[0].length - 1,
        z = h.length - 1;
    var u = numeric.rep([y], 0),
        v = Array(y);
    var H = numeric.rep([y], 0),
        e = Array(y);
    var D = numeric.rep([z + 1], 0),
        A = [],
        s = [];
    var d = numeric.ccsTSolve;
    var F, E, c, a, C, r, p = 0;
    for (F = 0; F < z; ++F) {
        C = 0;
        c = h[F];
        a = h[F + 1];
        for (E = c; E < a; ++E) {
            r = l.Pinv[g[E]];
            e[C] = r;
            H[r] = I[E];
            ++C
        }
        e.length = C;
        d(q, H, u, e, v);
        for (E = e.length - 1; E !== -1; --E) {
            H[e[E]] = 0
        }
        d(f, u, H, v, e);
        if (G) {
            return H
        }
        for (E = v.length - 1; E !== -1; --E) {
            u[v[E]] = 0
        }
        for (E = e.length - 1; E !== -1; --E) {
            r = e[E];
            A[p] = r;
            s[p] = H[r];
            H[r] = 0;
            ++p
        }
        D[F + 1] = p
    }
    return [D, A, s]
};
numeric.ccsbinop = function ccsbinop(b, a) {
    if (typeof a === "undefined") {
        a = ""
    }
    return Function("X", "Y", "var Xi = X[0], Xj = X[1], Xv = X[2];\nvar Yi = Y[0], Yj = Y[1], Yv = Y[2];\nvar n = Xi.length-1,m = Math.max(numeric.sup(Xj),numeric.sup(Yj))+1;\nvar Zi = numeric.rep([n+1],0), Zj = [], Zv = [];\nvar x = numeric.rep([m],0),y = numeric.rep([m],0);\nvar xk,yk,zk;\nvar i,j,j0,j1,k,p=0;\n" + a + "for(i=0;i<n;++i) {\n  j0 = Xi[i]; j1 = Xi[i+1];\n  for(j=j0;j!==j1;++j) {\n    k = Xj[j];\n    x[k] = 1;\n    Zj[p] = k;\n    ++p;\n  }\n  j0 = Yi[i]; j1 = Yi[i+1];\n  for(j=j0;j!==j1;++j) {\n    k = Yj[j];\n    y[k] = Yv[j];\n    if(x[k] === 0) {\n      Zj[p] = k;\n      ++p;\n    }\n  }\n  Zi[i+1] = p;\n  j0 = Xi[i]; j1 = Xi[i+1];\n  for(j=j0;j!==j1;++j) x[Xj[j]] = Xv[j];\n  j0 = Zi[i]; j1 = Zi[i+1];\n  for(j=j0;j!==j1;++j) {\n    k = Zj[j];\n    xk = x[k];\n    yk = y[k];\n" + b + "\n    Zv[j] = zk;\n  }\n  j0 = Xi[i]; j1 = Xi[i+1];\n  for(j=j0;j!==j1;++j) x[Xj[j]] = 0;\n  j0 = Yi[i]; j1 = Yi[i+1];\n  for(j=j0;j!==j1;++j) y[Yj[j]] = 0;\n}\nreturn [Zi,Zj,Zv];")
};
(function () {
    var k, A, B, C;
    for (k in numeric.ops2) {
        if (isFinite(eval("1" + numeric.ops2[k] + "0"))) {
            A = "[Y[0],Y[1],numeric." + k + "(X,Y[2])]"
        } else {
            A = "NaN"
        }
        if (isFinite(eval("0" + numeric.ops2[k] + "1"))) {
            B = "[X[0],X[1],numeric." + k + "(X[2],Y)]"
        } else {
            B = "NaN"
        }
        if (isFinite(eval("1" + numeric.ops2[k] + "0")) && isFinite(eval("0" + numeric.ops2[k] + "1"))) {
            C = "numeric.ccs" + k + "MM(X,Y)"
        } else {
            C = "NaN"
        }
        numeric["ccs" + k + "MM"] = numeric.ccsbinop("zk = xk " + numeric.ops2[k] + "yk;");
        numeric["ccs" + k] = Function("X", "Y", 'if(typeof X === "number") return ' + A + ';\nif(typeof Y === "number") return ' + B + ";\nreturn " + C + ";\n")
    }
}());
numeric.ccsScatter = function ccsScatter(c) {
    var p = c[0],
        o = c[1],
        e = c[2];
    var d = numeric.sup(o) + 1,
        f = p.length;
    var r = numeric.rep([d], 0),
        q = Array(f),
        h = Array(f);
    var l = numeric.rep([d], 0),
        j;
    for (j = 0; j < f; ++j) {
        l[o[j]]++
    }
    for (j = 0; j < d; ++j) {
        r[j + 1] = r[j] + l[j]
    }
    var b = r.slice(0),
        g, a;
    for (j = 0; j < f; ++j) {
        a = o[j];
        g = b[a];
        q[g] = p[j];
        h[g] = e[j];
        b[a] = b[a] + 1
    }
    return [r, q, h]
};
numeric.ccsGather = function ccsGather(c) {
    var o = c[0],
        l = c[1],
        e = c[2];
    var d = o.length - 1,
        f = l.length;
    var r = Array(f),
        q = Array(f),
        g = Array(f);
    var k, h, a, s, b;
    b = 0;
    for (k = 0; k < d; ++k) {
        a = o[k];
        s = o[k + 1];
        for (h = a; h !== s; ++h) {
            q[b] = k;
            r[b] = l[h];
            g[b] = e[h];
            ++b
        }
    }
    return [r, q, g]
};
numeric.sdim = function dim(a, c, b) {
    if (typeof c === "undefined") {
        c = []
    }
    if (typeof a !== "object") {
        return c
    }
    if (typeof b === "undefined") {
        b = 0
    }
    if (!(b in c)) {
        c[b] = 0
    }
    if (a.length > c[b]) {
        c[b] = a.length
    }
    var d;
    for (d in a) {
        if (a.hasOwnProperty(d)) {
            dim(a[d], c, b + 1)
        }
    }
    return c
};
numeric.sclone = function clone(a, b, e) {
    if (typeof b === "undefined") {
        b = 0
    }
    if (typeof e === "undefined") {
        e = numeric.sdim(a).length
    }
    var d, c = Array(a.length);
    if (b === e - 1) {
        for (d in a) {
            if (a.hasOwnProperty(d)) {
                c[d] = a[d]
            }
        }
        return c
    }
    for (d in a) {
        if (a.hasOwnProperty(d)) {
            c[d] = clone(a[d], b + 1, e)
        }
    }
    return c
};
numeric.sdiag = function diag(g) {
    var h = g.length,
        c, a = Array(h),
        f, e, b;
    for (c = h - 1; c >= 1; c -= 2) {
        f = c - 1;
        a[c] = [];
        a[c][c] = g[c];
        a[f] = [];
        a[f][f] = g[f]
    }
    if (c === 0) {
        a[0] = [];
        a[0][0] = g[c]
    }
    return a
};
numeric.sidentity = function identity(a) {
    return numeric.sdiag(numeric.rep([a], 1))
};
numeric.stranspose = function transpose(a) {
    var d = [],
        f = a.length,
        e, c, b;
    for (e in a) {
        if (!(a.hasOwnProperty(e))) {
            continue
        }
        b = a[e];
        for (c in b) {
            if (!(b.hasOwnProperty(c))) {
                continue
            }
            if (typeof d[c] !== "object") {
                d[c] = []
            }
            d[c][e] = b[c]
        }
    }
    return d
};
numeric.sLUP = function LUP(a, b) {
    throw new Error("The function numeric.sLUP had a bug in it and has been removed. Please use the new numeric.ccsLUP function instead.")
};
numeric.sdotMM = function dotMM(e, c) {
    var d = e.length,
        b = c.length,
        l = numeric.stranspose(c),
        a = l.length,
        u, n;
    var m, h, g, s;
    var o = Array(d),
        f;
    for (m = d - 1; m >= 0; m--) {
        f = [];
        u = e[m];
        for (g = a - 1; g >= 0; g--) {
            s = 0;
            n = l[g];
            for (h in u) {
                if (!(u.hasOwnProperty(h))) {
                    continue
                }
                if (h in n) {
                    s += u[h] * n[h]
                }
            }
            if (s) {
                f[g] = s
            }
        }
        o[m] = f
    }
    return o
};
numeric.sdotMV = function dotMV(b, a) {
    var h = b.length,
        d, g, f;
    var e = Array(h),
        c;
    for (g = h - 1; g >= 0; g--) {
        d = b[g];
        c = 0;
        for (f in d) {
            if (!(d.hasOwnProperty(f))) {
                continue
            }
            if (a[f]) {
                c += d[f] * a[f]
            }
        }
        if (c) {
            e[g] = c
        }
    }
    return e
};
numeric.sdotVM = function dotMV(b, a) {
    var g, f, d, h;
    var e = [],
        c;
    for (g in b) {
        if (!b.hasOwnProperty(g)) {
            continue
        }
        d = a[g];
        h = b[g];
        for (f in d) {
            if (!d.hasOwnProperty(f)) {
                continue
            }
            if (!e[f]) {
                e[f] = 0
            }
            e[f] += h * d[f]
        }
    }
    return e
};
numeric.sdotVV = function dotVV(a, d) {
    var c, b = 0;
    for (c in a) {
        if (a[c] && d[c]) {
            b += a[c] * d[c]
        }
    }
    return b
};
numeric.sdot = function dot(b, e) {
    var a = numeric.sdim(b).length,
        d = numeric.sdim(e).length;
    var c = a * 1000 + d;
    switch (c) {
    case 0:
        return b * e;
    case 1001:
        return numeric.sdotVV(b, e);
    case 2001:
        return numeric.sdotMV(b, e);
    case 1002:
        return numeric.sdotVM(b, e);
    case 2002:
        return numeric.sdotMM(b, e);
    default:
        throw new Error("numeric.sdot not implemented for tensors of order " + a + " and " + d)
    }
};
numeric.sscatter = function scatter(e) {
    var h = e[0].length,
        d, g, f, b = e.length,
        a = [],
        c;
    for (g = h - 1; g >= 0; --g) {
        if (!e[b - 1][g]) {
            continue
        }
        c = a;
        for (f = 0; f < b - 2; f++) {
            d = e[f][g];
            if (!c[d]) {
                c[d] = []
            }
            c = c[d]
        }
        c[e[f][g]] = e[f + 1][g]
    }
    return a
};
numeric.sgather = function gather(a, d, c) {
    if (typeof d === "undefined") {
        d = []
    }
    if (typeof c === "undefined") {
        c = []
    }
    var f, e, b;
    f = c.length;
    for (e in a) {
        if (a.hasOwnProperty(e)) {
            c[f] = parseInt(e);
            b = a[e];
            if (typeof b === "number") {
                if (b) {
                    if (d.length === 0) {
                        for (e = f + 1; e >= 0; --e) {
                            d[e] = []
                        }
                    }
                    for (e = f; e >= 0; --e) {
                        d[e].push(c[e])
                    }
                    d[f + 1].push(b)
                }
            } else {
                gather(b, d, c)
            }
        }
    }
    if (c.length > f) {
        c.pop()
    }
    return d
};
numeric.cLU = function LU(w) {
    var r = w[0],
        o = w[1],
        d = w[2];
    var x = r.length,
        B = 0,
        G, F, E, O, N, M;
    for (G = 0; G < x; G++) {
        if (r[G] > B) {
            B = r[G]
        }
    }
    B++;
    var l = Array(B),
        e = Array(B),
        f = numeric.rep([B], Infinity),
        K = numeric.rep([B], -Infinity);
    var C, z, g;
    for (E = 0; E < x; E++) {
        G = r[E];
        F = o[E];
        if (F < f[G]) {
            f[G] = F
        }
        if (F > K[G]) {
            K[G] = F
        }
    }
    for (G = 0; G < B - 1; G++) {
        if (K[G] > K[G + 1]) {
            K[G + 1] = K[G]
        }
    }
    for (G = B - 1; G >= 1; G--) {
        if (f[G] < f[G - 1]) {
            f[G - 1] = f[G]
        }
    }
    var D = 0,
        s = 0;
    for (G = 0; G < B; G++) {
        e[G] = numeric.rep([K[G] - f[G] + 1], 0);
        l[G] = numeric.rep([G - f[G]], 0);
        D += G - f[G] + 1;
        s += K[G] - G + 1
    }
    for (E = 0; E < x; E++) {
        G = r[E];
        e[G][o[E] - f[G]] = d[E]
    }
    for (G = 0; G < B - 1; G++) {
        O = G - f[G];
        C = e[G];
        for (F = G + 1; f[F] <= G && F < B; F++) {
            N = G - f[F];
            M = K[G] - G;
            z = e[F];
            g = z[N] / C[O];
            if (g) {
                for (E = 1; E <= M; E++) {
                    z[E + N] -= g * C[E + O]
                }
                l[F][G - f[F]] = g
            }
        }
    }
    var C = [],
        z = [],
        n = [],
        y = [],
        v = [],
        h = [];
    var x, u, H;
    x = 0;
    u = 0;
    for (G = 0; G < B; G++) {
        O = f[G];
        N = K[G];
        H = e[G];
        for (F = G; F <= N; F++) {
            if (H[F - O]) {
                C[x] = G;
                z[x] = F;
                n[x] = H[F - O];
                x++
            }
        }
        H = l[G];
        for (F = O; F < G; F++) {
            if (H[F - O]) {
                y[u] = G;
                v[u] = F;
                h[u] = H[F - O];
                u++
            }
        }
        y[u] = G;
        v[u] = G;
        h[u] = 1;
        u++
    }
    return {
        U: [C, z, n],
        L: [y, v, h]
    }
};
numeric.cLUsolve = function LUsolve(h, u) {
    var s = h.L,
        f = h.U,
        r = numeric.clone(u);
    var y = s[0],
        x = s[1],
        o = s[2];
    var w = f[0],
        v = f[1],
        e = f[2];
    var c = w.length,
        a = y.length;
    var d = r.length,
        n, l, g;
    g = 0;
    for (n = 0; n < d; n++) {
        while (x[g] < n) {
            r[n] -= o[g] * r[x[g]];
            g++
        }
        g++
    }
    g = c - 1;
    for (n = d - 1; n >= 0; n--) {
        while (v[g] > n) {
            r[n] -= e[g] * r[v[g]];
            g--
        }
        r[n] /= e[g];
        g--
    }
    return r
};
numeric.cgrid = function grid(f, a) {
    if (typeof f === "number") {
        f = [f, f]
    }
    var c = numeric.rep(f, -1);
    var d, b, e;
    if (typeof a !== "function") {
        switch (a) {
        case "L":
            a = function (h, g) {
                return (h >= f[0] / 2 || g < f[1] / 2)
            };
            break;
        default:
            a = function (h, g) {
                return true
            };
            break
        }
    }
    e = 0;
    for (d = 1; d < f[0] - 1; d++) {
        for (b = 1; b < f[1] - 1; b++) {
            if (a(d, b)) {
                c[d][b] = e;
                e++
            }
        }
    }
    return c
};
numeric.cdelsq = function delsq(r) {
    var d = [
        [-1, 0],
        [0, -1],
        [0, 1],
        [1, 0]
    ];
    var w = numeric.dim(r),
        e = w[0],
        c = w[1],
        o, h, f, b, a;
    var v = [],
        u = [],
        l = [];
    for (o = 1; o < e - 1; o++) {
        for (h = 1; h < c - 1; h++) {
            if (r[o][h] < 0) {
                continue
            }
            for (f = 0; f < 4; f++) {
                b = o + d[f][0];
                a = h + d[f][1];
                if (r[b][a] < 0) {
                    continue
                }
                v.push(r[o][h]);
                u.push(r[b][a]);
                l.push(-1)
            }
            v.push(r[o][h]);
            u.push(r[o][h]);
            l.push(4)
        }
    }
    return [v, u, l]
};
numeric.cdotMV = function dotMV(b, h) {
    var f, i = b[0],
        g = b[1],
        c = b[2],
        d, a = i.length,
        e;
    e = 0;
    for (d = 0; d < a; d++) {
        if (i[d] > e) {
            e = i[d]
        }
    }
    e++;
    f = numeric.rep([e], 0);
    for (d = 0; d < a; d++) {
        f[i[d]] += c[d] * h[g[d]]
    }
    return f
};
numeric.Spline = function Spline(b, c, e, d, a) {
    this.x = b;
    this.yl = c;
    this.yr = e;
    this.kl = d;
    this.kr = a
};
numeric.Spline.prototype._at = function _at(f, e) {
    var k = this.x;
    var g = this.yl;
    var o = this.yr;
    var d = this.kl;
    var l = this.kr;
    var f, j, i, n;
    var m = numeric.add,
        c = numeric.sub,
        h = numeric.mul;
    j = c(h(d[e], k[e + 1] - k[e]), c(o[e + 1], g[e]));
    i = m(h(l[e + 1], k[e] - k[e + 1]), c(o[e + 1], g[e]));
    n = (f - k[e]) / (k[e + 1] - k[e]);
    var q = n * (1 - n);
    return m(m(m(h(1 - n, g[e]), h(n, o[e + 1])), h(j, q * (1 - n))), h(i, q * n))
};
numeric.Spline.prototype.at = function at(e) {
    if (typeof e === "number") {
        var m = this.x;
        var f = m.length;
        var d, c, o, h = Math.floor,
            l, k, r;
        d = 0;
        c = f - 1;
        while (c - d > 1) {
            o = h((d + c) / 2);
            if (m[o] <= e) {
                d = o
            } else {
                c = o
            }
        }
        return this._at(e, d)
    }
    var f = e.length,
        g, j = Array(f);
    for (g = f - 1; g !== -1; --g) {
        j[g] = this.at(e[g])
    }
    return j
};
numeric.Spline.prototype.diff = function diff() {
    var l = this.x;
    var f = this.yl;
    var r = this.yr;
    var d = this.kl;
    var m = this.kr;
    var e = f.length;
    var j, s, q;
    var o = d,
        k = m,
        h = Array(e),
        c = Array(e);
    var p = numeric.add,
        g = numeric.mul,
        b = numeric.div,
        a = numeric.sub;
    for (j = e - 1; j !== -1; --j) {
        s = l[j + 1] - l[j];
        q = a(r[j + 1], f[j]);
        h[j] = b(p(g(q, 6), g(d[j], -4 * s), g(m[j + 1], -2 * s)), s * s);
        c[j + 1] = b(p(g(q, -6), g(d[j], 2 * s), g(m[j + 1], 4 * s)), s * s)
    }
    return new numeric.Spline(l, o, k, h, c)
};
numeric.Spline.prototype.roots = function roots() {
    function C(i) {
        return i * i
    }
    function u(D, n, m, k, y) {
        var j = m * 2 - (n - D);
        var i = -k * 2 + (n - D);
        var aa = (y + 1) * 0.5;
        var ab = aa * (1 - aa);
        return (1 - aa) * D + aa * n + j * ab * (1 - aa) + i * ab * aa
    }
    var E = [];
    var M = this.x,
        p = this.yl,
        h = this.yr,
        X = this.kl,
        S = this.kr;
    if (typeof p[0] === "number") {
        p = [p];
        h = [h];
        X = [X];
        S = [S]
    }
    var Q = p.length,
        P = M.length - 1,
        V, U, R, L, O, N;
    var d, W, z, e, E = Array(Q),
        J, w, v, a, Z, l, g, f, c, q, r, I, H, b, G, F, Y;
    var K = Math.sqrt;
    for (V = 0; V !== Q; ++V) {
        d = p[V];
        W = h[V];
        z = X[V];
        e = S[V];
        J = [];
        for (U = 0; U !== P; U++) {
            if (U > 0 && W[U] * d[U] < 0) {
                J.push(M[U])
            }
            c = (M[U + 1] - M[U]);
            q = M[U];
            a = d[U];
            Z = W[U + 1];
            w = z[U] / c;
            v = e[U + 1] / c;
            f = C(w - v + 3 * (a - Z)) + 12 * v * a;
            l = v + 3 * a + 2 * w - 3 * Z;
            g = 3 * (v + w + 2 * (a - Z));
            if (f <= 0) {
                I = l / g;
                if (I > M[U] && I < M[U + 1]) {
                    r = [M[U], I, M[U + 1]]
                } else {
                    r = [M[U], M[U + 1]]
                }
            } else {
                I = (l - K(f)) / g;
                H = (l + K(f)) / g;
                r = [M[U]];
                if (I > M[U] && I < M[U + 1]) {
                    r.push(I)
                }
                if (H > M[U] && H < M[U + 1]) {
                    r.push(H)
                }
                r.push(M[U + 1])
            }
            G = r[0];
            I = this._at(G, U);
            for (R = 0; R < r.length - 1; R++) {
                F = r[R + 1];
                H = this._at(F, U);
                if (I === 0) {
                    J.push(G);
                    G = F;
                    I = H;
                    continue
                }
                if (H === 0 || I * H > 0) {
                    G = F;
                    I = H;
                    continue
                }
                var o = 0;
                while (1) {
                    Y = (I * F - H * G) / (I - H);
                    if (Y <= G || Y >= F) {
                        break
                    }
                    b = this._at(Y, U);
                    if (b * H > 0) {
                        F = Y;
                        H = b;
                        if (o === -1) {
                            I *= 0.5
                        }
                        o = -1
                    } else {
                        if (b * I > 0) {
                            G = Y;
                            I = b;
                            if (o === 1) {
                                H *= 0.5
                            }
                            o = 1
                        } else {
                            break
                        }
                    }
                }
                J.push(Y);
                G = r[R + 1];
                I = this._at(G, U)
            }
            if (H === 0) {
                J.push(F)
            }
        }
        E[V] = J
    }
    if (typeof this.yl[0] === "number") {
        return E[0]
    }
    return E
};
numeric.spline = function spline(m, j, h, q) {
    var c = m.length,
        l = [],
        r = [],
        p = [];
    var g;
    var a = numeric.sub,
        d = numeric.mul,
        o = numeric.add;
    for (g = c - 2; g >= 0; g--) {
        r[g] = m[g + 1] - m[g];
        p[g] = a(j[g + 1], j[g])
    }
    if (typeof h === "string" || typeof q === "string") {
        h = q = "periodic"
    }
    var f = [
        [],
        [],
        []
    ];
    switch (typeof h) {
    case "undefined":
        l[0] = d(3 / (r[0] * r[0]), p[0]);
        f[0].push(0, 0);
        f[1].push(0, 1);
        f[2].push(2 / r[0], 1 / r[0]);
        break;
    case "string":
        l[0] = o(d(3 / (r[c - 2] * r[c - 2]), p[c - 2]), d(3 / (r[0] * r[0]), p[0]));
        f[0].push(0, 0, 0);
        f[1].push(c - 2, 0, 1);
        f[2].push(1 / r[c - 2], 2 / r[c - 2] + 2 / r[0], 1 / r[0]);
        break;
    default:
        l[0] = h;
        f[0].push(0);
        f[1].push(0);
        f[2].push(1);
        break
    }
    for (g = 1; g < c - 1; g++) {
        l[g] = o(d(3 / (r[g - 1] * r[g - 1]), p[g - 1]), d(3 / (r[g] * r[g]), p[g]));
        f[0].push(g, g, g);
        f[1].push(g - 1, g, g + 1);
        f[2].push(1 / r[g - 1], 2 / r[g - 1] + 2 / r[g], 1 / r[g])
    }
    switch (typeof q) {
    case "undefined":
        l[c - 1] = d(3 / (r[c - 2] * r[c - 2]), p[c - 2]);
        f[0].push(c - 1, c - 1);
        f[1].push(c - 2, c - 1);
        f[2].push(1 / r[c - 2], 2 / r[c - 2]);
        break;
    case "string":
        f[1][f[1].length - 1] = 0;
        break;
    default:
        l[c - 1] = q;
        f[0].push(c - 1);
        f[1].push(c - 1);
        f[2].push(1);
        break
    }
    if (typeof l[0] !== "number") {
        l = numeric.transpose(l)
    } else {
        l = [l]
    }
    var e = Array(l.length);
    if (typeof h === "string") {
        for (g = e.length - 1; g !== -1; --g) {
            e[g] = numeric.ccsLUPSolve(numeric.ccsLUP(numeric.ccsScatter(f)), l[g]);
            e[g][c - 1] = e[g][0]
        }
    } else {
        for (g = e.length - 1; g !== -1; --g) {
            e[g] = numeric.cLUsolve(numeric.cLU(f), l[g])
        }
    }
    if (typeof j[0] === "number") {
        e = e[0]
    } else {
        e = numeric.transpose(e)
    }
    return new numeric.Spline(m, j, j, e, e)
};
numeric.fftpow2 = function fftpow2(o, m) {
    var b = o.length;
    if (b === 1) {
        return
    }
    var q = Math.cos,
        l = Math.sin,
        g, d;
    var p = Array(b / 2),
        h = Array(b / 2),
        f = Array(b / 2),
        a = Array(b / 2);
    d = b / 2;
    for (g = b - 1; g !== -1; --g) {
        --d;
        f[d] = o[g];
        a[d] = m[g];
        --g;
        p[d] = o[g];
        h[d] = m[g]
    }
    fftpow2(p, h);
    fftpow2(f, a);
    d = b / 2;
    var r, c = (-6.283185307179586 / b),
        s, e;
    for (g = b - 1; g !== -1; --g) {
        --d;
        if (d === -1) {
            d = b / 2 - 1
        }
        r = c * g;
        s = q(r);
        e = l(r);
        o[g] = p[d] + s * f[d] - e * a[d];
        m[g] = h[d] + s * a[d] + e * f[d]
    }
};
numeric._ifftpow2 = function _ifftpow2(o, m) {
    var b = o.length;
    if (b === 1) {
        return
    }
    var q = Math.cos,
        l = Math.sin,
        g, d;
    var p = Array(b / 2),
        h = Array(b / 2),
        f = Array(b / 2),
        a = Array(b / 2);
    d = b / 2;
    for (g = b - 1; g !== -1; --g) {
        --d;
        f[d] = o[g];
        a[d] = m[g];
        --g;
        p[d] = o[g];
        h[d] = m[g]
    }
    _ifftpow2(p, h);
    _ifftpow2(f, a);
    d = b / 2;
    var r, c = (6.283185307179586 / b),
        s, e;
    for (g = b - 1; g !== -1; --g) {
        --d;
        if (d === -1) {
            d = b / 2 - 1
        }
        r = c * g;
        s = q(r);
        e = l(r);
        o[g] = p[d] + s * f[d] - e * a[d];
        m[g] = h[d] + s * a[d] + e * f[d]
    }
};
numeric.ifftpow2 = function ifftpow2(a, b) {
    numeric._ifftpow2(a, b);
    numeric.diveq(a, a.length);
    numeric.diveq(b, b.length)
};
numeric.convpow2 = function convpow2(a, j, g, f) {
    numeric.fftpow2(a, j);
    numeric.fftpow2(g, f);
    var d, b = a.length,
        h, k, c, e;
    for (d = b - 1; d !== -1; --d) {
        h = a[d];
        c = j[d];
        k = g[d];
        e = f[d];
        a[d] = h * k - c * e;
        j[d] = h * e + c * k
    }
    numeric.ifftpow2(a, j)
};
numeric.T.prototype.fft = function fft() {
    var o = this.x,
        l = this.y;
    var v = o.length,
        j = Math.log,
        q = j(2),
        u = Math.ceil(j(2 * v - 1) / q),
        w = Math.pow(2, u);
    var i = numeric.rep([w], 0),
        h = numeric.rep([w], 0),
        f = Math.cos,
        d = Math.sin;
    var z, A = (-3.141592653589793 / v),
        r;
    var C = numeric.rep([w], 0),
        B = numeric.rep([w], 0),
        s = Math.floor(v / 2);
    for (z = 0; z < v; z++) {
        C[z] = o[z]
    }
    if (typeof l !== "undefined") {
        for (z = 0; z < v; z++) {
            B[z] = l[z]
        }
    }
    i[0] = 1;
    for (z = 1; z <= w / 2; z++) {
        r = A * z * z;
        i[z] = f(r);
        h[z] = d(r);
        i[w - z] = f(r);
        h[w - z] = d(r)
    }
    var g = new numeric.T(C, B),
        e = new numeric.T(i, h);
    g = g.mul(e);
    numeric.convpow2(g.x, g.y, numeric.clone(e.x), numeric.neg(e.y));
    g = g.mul(e);
    g.x.length = v;
    g.y.length = v;
    return g
};
numeric.T.prototype.ifft = function ifft() {
    var o = this.x,
        l = this.y;
    var v = o.length,
        j = Math.log,
        q = j(2),
        u = Math.ceil(j(2 * v - 1) / q),
        w = Math.pow(2, u);
    var i = numeric.rep([w], 0),
        h = numeric.rep([w], 0),
        f = Math.cos,
        d = Math.sin;
    var z, A = (3.141592653589793 / v),
        r;
    var C = numeric.rep([w], 0),
        B = numeric.rep([w], 0),
        s = Math.floor(v / 2);
    for (z = 0; z < v; z++) {
        C[z] = o[z]
    }
    if (typeof l !== "undefined") {
        for (z = 0; z < v; z++) {
            B[z] = l[z]
        }
    }
    i[0] = 1;
    for (z = 1; z <= w / 2; z++) {
        r = A * z * z;
        i[z] = f(r);
        h[z] = d(r);
        i[w - z] = f(r);
        h[w - z] = d(r)
    }
    var g = new numeric.T(C, B),
        e = new numeric.T(i, h);
    g = g.mul(e);
    numeric.convpow2(g.x, g.y, numeric.clone(e.x), numeric.neg(e.y));
    g = g.mul(e);
    g.x.length = v;
    g.y.length = v;
    return g.div(v)
};
numeric.gradient = function gradient(A, k) {
    var r = k.length;
    var u = A(k);
    if (isNaN(u)) {
        throw new Error("gradient: f(x) is a NaN!")
    }
    var w = Math.max;
    var y, B = numeric.clone(k),
        s, q, g = Array(r);
    var o = numeric.div,
        d = numeric.sub,
        a, C, w = Math.max,
        m = 0.001,
        p = Math.abs,
        v = Math.min;
    var l, j, e, b = 0,
        E, D, c;
    for (y = 0; y < r; y++) {
        var z = w(0.000001 * u, 1e-8);
        while (1) {
            ++b;
            if (b > 20) {
                throw new Error("Numerical gradient fails")
            }
            B[y] = k[y] + z;
            s = A(B);
            B[y] = k[y] - z;
            q = A(B);
            B[y] = k[y];
            if (isNaN(s) || isNaN(q)) {
                z /= 16;
                continue
            }
            g[y] = (s - q) / (2 * z);
            l = k[y] - z;
            j = k[y];
            e = k[y] + z;
            E = (s - u) / z;
            D = (u - q) / z;
            c = w(p(g[y]), p(u), p(s), p(q), p(l), p(j), p(e), 1e-8);
            a = v(w(p(E - g[y]), p(D - g[y]), p(E - D)) / c, z / c);
            if (a > m) {
                z /= 16
            } else {
                break
            }
        }
    }
    return g
};
numeric.uncmin = function uncmin(U, p, g, q, D, K, z) {
    var r = numeric.gradient;
    if (typeof z === "undefined") {
        z = {}
    }
    if (typeof g === "undefined") {
        g = 1e-8
    }
    if (typeof q === "undefined") {
        q = function (f) {
            return r(U, f)
        }
    }
    if (typeof D === "undefined") {
        D = 1000
    }
    p = numeric.clone(p);
    var O = p.length;
    var e = U(p),
        d, G;
    if (isNaN(e)) {
        throw new Error("uncmin: f(x0) is a NaN!")
    }
    var w = Math.max,
        c = numeric.norm2;
    g = w(g, numeric.epsilon);
    var H, Q, P, W = z.Hinv || numeric.identity(O);
    var V = numeric.dot,
        I = numeric.inv,
        x = numeric.sub,
        b = numeric.add,
        v = numeric.tensor,
        S = numeric.div,
        a = numeric.mul;
    var u = numeric.all,
        A = numeric.isFinite,
        h = numeric.neg;
    var B = 0,
        R, N, o, J, k, l, m, j, M, C, F, E;
    var L = "";
    Q = q(p);
    while (B < D) {
        if (typeof K === "function") {
            if (K(B, p, e, Q, W)) {
                L = "Callback returned true";
                break
            }
        }
        if (!u(A(Q))) {
            L = "Gradient has Infinity or NaN";
            break
        }
        H = h(V(W, Q));
        if (!u(A(H))) {
            L = "Search direction has Infinity or NaN";
            break
        }
        C = c(H);
        if (C < g) {
            L = "Newton step smaller than tol";
            break
        }
        M = 1;
        G = V(Q, H);
        o = p;
        while (B < D) {
            if (M * C < g) {
                break
            }
            N = a(H, M);
            o = b(p, N);
            d = U(o);
            if (d - e >= 0.1 * M * G || isNaN(d)) {
                M *= 0.5;
                ++B;
                continue
            }
            break
        }
        if (M * C < g) {
            L = "Line search step size smaller than tol";
            break
        }
        if (B === D) {
            L = "maxit reached during line search";
            break
        }
        P = q(o);
        J = x(P, Q);
        m = V(J, N);
        k = V(W, J);
        W = x(b(W, a((m + V(J, k)) / (m * m), v(N, N))), S(b(v(k, N), v(N, k)), m));
        p = o;
        e = d;
        Q = P;
        ++B
    }
    return {
        solution: p,
        f: e,
        gradient: Q,
        invHessian: W,
        iterations: B,
        message: L
    }
};
numeric.Dopri = function Dopri(a, h, e, b, d, g, c) {
    this.x = a;
    this.y = h;
    this.f = e;
    this.ymid = b;
    this.iterations = d;
    this.events = c;
    this.message = g
};
numeric.Dopri.prototype._at = function _at(o, x) {
    function s(c) {
        return c * c
    }
    var a = this;
    var g = a.x;
    var v = a.y;
    var f = a.f;
    var E = a.ymid;
    var u = g.length;
    var C, A, r, d, b, F, o;
    var y = Math.floor,
        z;
    var D = 0.5;
    var k = numeric.add,
        B = numeric.mul,
        e = numeric.sub,
        m, l, i;
    C = g[x];
    A = g[x + 1];
    d = v[x];
    b = v[x + 1];
    z = A - C;
    r = C + D * z;
    F = E[x];
    m = e(f[x], B(d, 1 / (C - r) + 2 / (C - A)));
    l = e(f[x + 1], B(b, 1 / (A - r) + 2 / (A - C)));
    i = [s(o - A) * (o - r) / s(C - A) / (C - r), s(o - C) * s(o - A) / s(C - r) / s(A - r), s(o - C) * (o - r) / s(A - C) / (A - r), (o - C) * s(o - A) * (o - r) / s(C - A) / (C - r), (o - A) * s(o - C) * (o - r) / s(C - A) / (A - r)];
    return k(k(k(k(B(d, i[0]), B(F, i[1])), B(b, i[2])), B(m, i[3])), B(l, i[4]))
};
numeric.Dopri.prototype.at = function at(a) {
    var f, d, b, g = Math.floor;
    if (typeof a !== "number") {
        var h = a.length,
            c = Array(h);
        for (f = h - 1; f !== -1; --f) {
            c[f] = this.at(a[f])
        }
        return c
    }
    var e = this.x;
    f = 0;
    d = e.length - 1;
    while (d - f > 1) {
        b = g(0.5 * (f + d));
        if (e[b] <= a) {
            f = b
        } else {
            d = b
        }
    }
    return this._at(a, f)
};
numeric.dopri = function dopri(w, u, a, ah, l, Q, ao) {
    if (typeof l === "undefined") {
        l = 0.000001
    }
    if (typeof Q === "undefined") {
        Q = 1000
    }
    var S = [w],
        s = [a],
        N = [ah(w, a)],
        M, K, J, G, D, C, X = [];
    var q = 1 / 5;
    var p = [3 / 40, 9 / 40];
    var o = [44 / 45, -56 / 15, 32 / 9];
    var n = [19372 / 6561, -25360 / 2187, 64448 / 6561, -212 / 729];
    var m = [9017 / 3168, -355 / 33, 46732 / 5247, 49 / 176, -5103 / 18656];
    var an = [35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84];
    var ac = [0.5 * 6025192743 / 30085553152, 0, 0.5 * 51252292925 / 65400821598, 0.5 * -2691868925 / 45128329728, 0.5 * 187940372067 / 1594534317056, 0.5 * -1776094331 / 19743644256, 0.5 * 11237099 / 235043384];
    var al = [1 / 5, 3 / 10, 4 / 5, 8 / 9, 1, 1];
    var aj = [-71 / 57600, 0, 71 / 16695, -71 / 1920, 17253 / 339200, -22 / 525, 1 / 40];
    var af = 0,
        ab, ae;
    var ag = (u - w) / 10;
    var E = 0;
    var k = numeric.add,
        g = numeric.mul,
        ap, d;
    var z = Math.max,
        ak = Math.min,
        O = Math.abs,
        am = numeric.norminf,
        L = Math.pow;
    var P = numeric.any,
        I = numeric.lt,
        aa = numeric.and,
        B = numeric.sub;
    var H, F, Z;
    var R = new numeric.Dopri(S, s, N, X, -1, "");
    if (typeof ao === "function") {
        H = ao(w, a)
    }
    while (w < u && E < Q) {
        ++E;
        if (w + ag > u) {
            ag = u - w
        }
        M = ah(w + al[0] * ag, k(a, g(q * ag, N[af])));
        K = ah(w + al[1] * ag, k(k(a, g(p[0] * ag, N[af])), g(p[1] * ag, M)));
        J = ah(w + al[2] * ag, k(k(k(a, g(o[0] * ag, N[af])), g(o[1] * ag, M)), g(o[2] * ag, K)));
        G = ah(w + al[3] * ag, k(k(k(k(a, g(n[0] * ag, N[af])), g(n[1] * ag, M)), g(n[2] * ag, K)), g(n[3] * ag, J)));
        D = ah(w + al[4] * ag, k(k(k(k(k(a, g(m[0] * ag, N[af])), g(m[1] * ag, M)), g(m[2] * ag, K)), g(m[3] * ag, J)), g(m[4] * ag, G)));
        ap = k(k(k(k(k(a, g(N[af], ag * an[0])), g(K, ag * an[2])), g(J, ag * an[3])), g(G, ag * an[4])), g(D, ag * an[5]));
        C = ah(w + ag, ap);
        ab = k(k(k(k(k(g(N[af], ag * aj[0]), g(K, ag * aj[2])), g(J, ag * aj[3])), g(G, ag * aj[4])), g(D, ag * aj[5])), g(C, ag * aj[6]));
        if (typeof ab === "number") {
            d = O(ab)
        } else {
            d = am(ab)
        }
        if (d > l) {
            ag = 0.2 * ag * L(l / d, 0.25);
            if (w + ag === w) {
                R.msg = "Step size became too small";
                break
            }
            continue
        }
        X[af] = k(k(k(k(k(k(a, g(N[af], ag * ac[0])), g(K, ag * ac[2])), g(J, ag * ac[3])), g(G, ag * ac[4])), g(D, ag * ac[5])), g(C, ag * ac[6]));
        ++af;
        S[af] = w + ag;
        s[af] = ap;
        N[af] = C;
        if (typeof ao === "function") {
            var y, V = w,
                U = w + 0.5 * ag,
                W;
            F = ao(U, X[af - 1]);
            Z = aa(I(H, 0), I(0, F));
            if (!P(Z)) {
                V = U;
                U = w + ag;
                H = F;
                F = ao(U, ap);
                Z = aa(I(H, 0), I(0, F))
            }
            if (P(Z)) {
                var Y, A, ad, ai;
                var x = 0,
                    v = 1,
                    r = 1;
                while (1) {
                    if (typeof H === "number") {
                        W = (r * F * V - v * H * U) / (r * F - v * H)
                    } else {
                        W = U;
                        for (ae = H.length - 1; ae !== -1; --ae) {
                            if (H[ae] < 0 && F[ae] > 0) {
                                W = ak(W, (r * F[ae] * V - v * H[ae] * U) / (r * F[ae] - v * H[ae]))
                            }
                        }
                    }
                    if (W <= V || W >= U) {
                        break
                    }
                    y = R._at(W, af - 1);
                    ai = ao(W, y);
                    ad = aa(I(H, 0), I(0, ai));
                    if (P(ad)) {
                        U = W;
                        F = ai;
                        Z = ad;
                        r = 1;
                        if (x === -1) {
                            v *= 0.5
                        } else {
                            v = 1
                        }
                        x = -1
                    } else {
                        V = W;
                        H = ai;
                        v = 1;
                        if (x === 1) {
                            r *= 0.5
                        } else {
                            r = 1
                        }
                        x = 1
                    }
                }
                ap = R._at(0.5 * (w + W), af - 1);
                R.f[af] = ah(W, y);
                R.x[af] = W;
                R.y[af] = y;
                R.ymid[af - 1] = ap;
                R.events = Z;
                R.iterations = E;
                return R
            }
        }
        w += ag;
        a = ap;
        H = F;
        ag = ak(0.8 * ag * L(l / d, 0.25), 4 * ag)
    }
    R.iterations = E;
    return R
};
numeric.LU = function (a, g) {
    g = g || false;
    var s = Math.abs;
    var f, e, d, r, c, p, l, q;
    var o;
    var b = a.length,
        m = b - 1;
    var h = new Array(b);
    if (!g) {
        a = numeric.clone(a)
    }
    for (d = 0; d < b; ++d) {
        l = d;
        p = a[d];
        o = s(p[d]);
        for (e = d + 1; e < b; ++e) {
            r = s(a[e][d]);
            if (o < r) {
                o = r;
                l = e
            }
        }
        h[d] = l;
        if (l != d) {
            a[d] = a[l];
            a[l] = p;
            p = a[d]
        }
        c = p[d];
        for (f = d + 1; f < b; ++f) {
            a[f][d] /= c
        }
        for (f = d + 1; f < b; ++f) {
            q = a[f];
            for (e = d + 1; e < m; ++e) {
                q[e] -= q[d] * p[e];
                ++e;
                q[e] -= q[d] * p[e]
            }
            if (e === m) {
                q[e] -= q[d] * p[e]
            }
        }
    }
    return {
        LU: a,
        P: h
    }
};
numeric.LUsolve = function LUsolve(g, m) {
    var f, d;
    var p = g.LU;
    var a = p.length;
    var o = numeric.clone(m);
    var h = g.P;
    var l, c, k, e;
    for (f = a - 1; f !== -1; --f) {
        o[f] = m[f]
    }
    for (f = 0; f < a; ++f) {
        l = h[f];
        if (h[f] !== f) {
            e = o[f];
            o[f] = o[l];
            o[l] = e
        }
        c = p[f];
        for (d = 0; d < f; ++d) {
            o[f] -= o[d] * c[d]
        }
    }
    for (f = a - 1; f >= 0; --f) {
        c = p[f];
        for (d = f + 1; d < a; ++d) {
            o[f] -= o[d] * c[d]
        }
        o[f] /= c[f]
    }
    return o
};
numeric.solve = function solve(c, a, d) {
    return numeric.LUsolve(numeric.LU(c, d), a)
};
numeric.echelonize = function echelonize(d) {
    var y = numeric.dim(d),
        f = y[0],
        e = y[1];
    var w = numeric.identity(f);
    var r = Array(f);
    var p, o, h, g, v, b, c, u;
    var x = Math.abs;
    var q = numeric.diveq;
    d = numeric.clone(d);
    for (p = 0; p < f; ++p) {
        h = 0;
        v = d[p];
        b = w[p];
        for (o = 1; o < e; ++o) {
            if (x(v[h]) < x(v[o])) {
                h = o
            }
        }
        r[p] = h;
        q(b, v[h]);
        q(v, v[h]);
        for (o = 0; o < f; ++o) {
            if (o !== p) {
                c = d[o];
                u = c[h];
                for (g = e - 1; g !== -1; --g) {
                    c[g] -= v[g] * u
                }
                c = w[o];
                for (g = f - 1; g !== -1; --g) {
                    c[g] -= b[g] * u
                }
            }
        }
    }
    return {
        I: w,
        A: d,
        P: r
    }
};
numeric.__solveLP = function __solveLP(ao, C, ar, r, O, Y, P) {
    var E = numeric.sum,
        o = numeric.log,
        f = numeric.mul,
        J = numeric.sub,
        au = numeric.dot,
        al = numeric.div,
        h = numeric.add;
    var af = ao.length,
        ae = ar.length,
        X;
    var K = false,
        S, u = 0;
    var ag = 1;
    var q, Q, aj = numeric.transpose(C),
        k = numeric.svd,
        I = numeric.transpose,
        D = numeric.leq,
        V = Math.sqrt,
        M = Math.abs;
    var L = numeric.muleq;
    var aq = numeric.norminf,
        N = numeric.any,
        ap = Math.min;
    var F = numeric.all,
        l = numeric.gt;
    var ac = Array(af),
        B = Array(ae),
        am = numeric.rep([ae], 1),
        v;
    var a = numeric.solve,
        W = J(ar, au(C, Y)),
        ab;
    var G = au(ao, ao);
    var ak;
    for (ab = u; ab < O; ++ab) {
        var ai, ah, an;
        for (ai = ae - 1; ai !== -1; --ai) {
            B[ai] = al(C[ai], W[ai])
        }
        var w = I(B);
        for (ai = af - 1; ai !== -1; --ai) {
            ac[ai] = (E(w[ai]))
        }
        ag = 0.25 * M(G / au(ao, ac));
        var ad = 100 * V(G / au(ac, ac));
        if (!isFinite(ag) || ag > ad) {
            ag = ad
        }
        ak = h(ao, f(ag, ac));
        v = au(w, B);
        for (ai = af - 1; ai !== -1; --ai) {
            v[ai][ai] += 1
        }
        an = a(v, al(ak, ag), true);
        var R = al(W, au(C, an));
        var Z = 1;
        for (ai = ae - 1; ai !== -1; --ai) {
            if (R[ai] < 0) {
                Z = ap(Z, -0.999 * R[ai])
            }
        }
        X = J(Y, f(an, Z));
        W = J(ar, au(C, X));
        if (!F(l(W, 0))) {
            return {
                solution: Y,
                message: "",
                iterations: ab
            }
        }
        Y = X;
        if (ag < r) {
            return {
                solution: X,
                message: "",
                iterations: ab
            }
        }
        if (P) {
            var aa = au(ao, ak),
                U = au(C, ak);
            K = true;
            for (ai = ae - 1; ai !== -1; --ai) {
                if (aa * U[ai] < 0) {
                    K = false;
                    break
                }
            }
        } else {
            if (Y[af - 1] >= 0) {
                K = false
            } else {
                K = true
            }
        }
        if (K) {
            return {
                solution: X,
                message: "Unbounded",
                iterations: ab
            }
        }
    }
    return {
        solution: Y,
        message: "maximum iteration count exceeded",
        iterations: ab
    }
};
numeric._solveLP = function _solveLP(C, p, D, r, g) {
    var v = C.length,
        s = D.length,
        j;
    var d = numeric.sum,
        f = numeric.log,
        z = numeric.mul,
        h = numeric.sub,
        q = numeric.dot,
        l = numeric.div,
        o = numeric.add;
    var u = numeric.rep([v], 0).concat([1]);
    var i = numeric.rep([s, 1], -1);
    var a = numeric.blockMatrix([
        [p, i]
    ]);
    var e = D;
    var j = numeric.rep([v], 0).concat(Math.max(0, numeric.sup(numeric.neg(D))) + 1);
    var w = numeric.__solveLP(u, a, e, r, g, j, false);
    var k = numeric.clone(w.solution);
    k.length = v;
    var B = numeric.inf(h(D, q(p, k)));
    if (B < 0) {
        return {
            solution: NaN,
            message: "Infeasible",
            iterations: w.iterations
        }
    }
    var E = numeric.__solveLP(C, p, D, r, g - w.iterations, k, true);
    E.iterations += w.iterations;
    return E
};
numeric.solveLP = function solveLP(U, C, V, W, h, H, s) {
    if (typeof s === "undefined") {
        s = 1000
    }
    if (typeof H === "undefined") {
        H = numeric.epsilon
    }
    if (typeof W === "undefined") {
        return numeric._solveLP(U, C, V, H, s)
    }
    var L = W.length,
        K = W[0].length,
        F = C.length;
    var z = numeric.echelonize(W);
    var q = numeric.rep([K], 0);
    var p = z.P;
    var l = [];
    var M;
    for (M = p.length - 1; M !== -1; --M) {
        q[p[M]] = 1
    }
    for (M = K - 1; M !== -1; --M) {
        if (q[M] === 0) {
            l.push(M)
        }
    }
    var R = numeric.getRange;
    var w = numeric.linspace(0, L - 1),
        u = numeric.linspace(0, F - 1);
    var X = R(W, w, l),
        f = R(C, u, p),
        e = R(C, u, l),
        E = numeric.dot,
        r = numeric.sub;
    var d = E(f, z.I);
    var a = r(e, E(d, X)),
        k = r(V, E(d, h));
    var G = Array(p.length),
        D = Array(l.length);
    for (M = p.length - 1; M !== -1; --M) {
        G[M] = U[p[M]]
    }
    for (M = l.length - 1; M !== -1; --M) {
        D[M] = U[l[M]]
    }
    var y = r(D, E(G, E(z.I, X)));
    var j = numeric._solveLP(y, a, k, H, s);
    var N = j.solution;
    if (N !== N) {
        return j
    }
    var O = E(z.I, r(h, E(X, N)));
    var v = Array(U.length);
    for (M = p.length - 1; M !== -1; --M) {
        v[p[M]] = O[M]
    }
    for (M = l.length - 1; M !== -1; --M) {
        v[l[M]] = N[M]
    }
    return {
        solution: v,
        message: j.message,
        iterations: j.iterations
    }
};
numeric.MPStoLP = function MPStoLP(a) {
    if (a instanceof String) {
        a.split("\n")
    }
    var d = 0;
    var f = ["Initial state", "NAME", "ROWS", "COLUMNS", "RHS", "BOUNDS", "ENDATA"];
    var x = a.length;
    var B, y, h, g = 0,
        k = {},
        F = [],
        o = 0,
        s = {},
        E = 0;
    var G;
    var C = [],
        v = [],
        D = [];

    function e(b) {
        throw new Error("MPStoLP: " + b + "\nLine " + B + ": " + a[B] + "\nCurrent state: " + f[d] + "\n")
    }
    for (B = 0; B < x; ++B) {
        h = a[B];
        var m = h.match(/\S*/g);
        var l = [];
        for (y = 0; y < m.length; ++y) {
            if (m[y] !== "") {
                l.push(m[y])
            }
        }
        if (l.length === 0) {
            continue
        }
        for (y = 0; y < f.length; ++y) {
            if (h.substr(0, f[y].length) === f[y]) {
                break
            }
        }
        if (y < f.length) {
            d = y;
            if (y === 1) {
                G = l[1]
            }
            if (y === 6) {
                return {
                    name: G,
                    c: C,
                    A: numeric.transpose(v),
                    b: D,
                    rows: k,
                    vars: s
                }
            }
            continue
        }
        switch (d) {
        case 0:
        case 1:
            e("Unexpected line");
        case 2:
            switch (l[0]) {
            case "N":
                if (g === 0) {
                    g = l[1]
                } else {
                    e("Two or more N rows")
                }
                break;
            case "L":
                k[l[1]] = o;
                F[o] = 1;
                D[o] = 0;
                ++o;
                break;
            case "G":
                k[l[1]] = o;
                F[o] = -1;
                D[o] = 0;
                ++o;
                break;
            case "E":
                k[l[1]] = o;
                F[o] = 0;
                D[o] = 0;
                ++o;
                break;
            default:
                e("Parse error " + numeric.prettyPrint(l))
            }
            break;
        case 3:
            if (!s.hasOwnProperty(l[0])) {
                s[l[0]] = E;
                C[E] = 0;
                v[E] = numeric.rep([o], 0);
                ++E
            }
            var u = s[l[0]];
            for (y = 1; y < l.length; y += 2) {
                if (l[y] === g) {
                    C[u] = parseFloat(l[y + 1]);
                    continue
                }
                var r = k[l[y]];
                v[u][r] = (F[r] < 0 ? -1 : 1) * parseFloat(l[y + 1])
            }
            break;
        case 4:
            for (y = 1; y < l.length; y += 2) {
                D[k[l[y]]] = (F[k[l[y]]] < 0 ? -1 : 1) * parseFloat(l[y + 1])
            }
            break;
        case 5:
            break;
        case 6:
            e("Internal error")
        }
    }
    e("Reached end of file without ENDATA")
};
numeric.seedrandom = {
    pow: Math.pow,
    random: Math.random
};
(function (i, j, c, h, l, f, b) {
    j.seedrandom = function g(m, q) {
        var o = [];
        var n;
        m = k(a(q ? [m, i] : arguments.length ? m : [new Date().getTime(), i, window], 3), o);
        n = new e(o);
        k(n.S, i);
        j.random = function p() {
            var u = n.g(h);
            var s = b;
            var r = 0;
            while (u < l) {
                u = (u + r) * c;
                s *= c;
                r = n.g(1)
            }
            while (u >= f) {
                u /= 2;
                s /= 2;
                r >>>= 1
            }
            return (u + r) / s
        };
        return m
    };

    function e(r) {
        var q, o, v = this,
            s = r.length;
        var p = 0,
            n = v.i = v.j = v.m = 0;
        v.S = [];
        v.c = [];
        if (!s) {
            r = [s++]
        }
        while (p < c) {
            v.S[p] = p++
        }
        for (p = 0; p < c; p++) {
            q = v.S[p];
            n = d(n + q + r[p % s]);
            o = v.S[n];
            v.S[p] = o;
            v.S[n] = q
        }
        v.g = function m(C) {
            var A = v.S;
            var z = d(v.i + 1);
            var y = A[z];
            var x = d(v.j + y);
            var w = A[x];
            A[z] = w;
            A[x] = y;
            var B = A[d(y + w)];
            while (--C) {
                z = d(z + 1);
                y = A[z];
                x = d(x + y);
                w = A[x];
                A[z] = w;
                A[x] = y;
                B = B * c + A[d(y + w)]
            }
            v.i = z;
            v.j = x;
            return B
        };
        v.g(c)
    }
    function a(p, q, m, r, n) {
        m = [];
        n = typeof(p);
        if (q && n == "object") {
            for (r in p) {
                if (r.indexOf("S") < 5) {
                    try {
                        m.push(a(p[r], q - 1))
                    } catch (o) {}
                }
            }
        }
        return (m.length ? m : p + (n != "string" ? "\0" : ""))
    }
    function k(m, o, p, n) {
        m += "";
        p = 0;
        for (n = 0; n < m.length; n++) {
            o[d(n)] = d((p ^= o[d(n)] * 19) + m.charCodeAt(n))
        }
        m = "";
        for (n in o) {
            m += String.fromCharCode(o[n])
        }
        return m
    }
    function d(m) {
        return m & (c - 1)
    }
    b = j.pow(c, h);
    l = j.pow(2, l);
    f = l * 2;
    k(j.random(), i)
}([], numeric.seedrandom, 256, 6, 52));
(function (b) {
    function h(j) {
        if (typeof j !== "object") {
            return j
        }
        var k = [],
            l, m = j.length;
        for (l = 0; l < m; l++) {
            k[l + 1] = h(j[l])
        }
        return k
    }
    function f(j) {
        if (typeof j !== "object") {
            return j
        }
        var k = [],
            l, m = j.length;
        for (l = 1; l < m; l++) {
            k[l - 1] = f(j[l])
        }
        return k
    }
    function g(m, l, u) {
        var r, p, o, s, q;
        for (o = 1; o <= u; o = o + 1) {
            m[o][o] = 1 / m[o][o];
            q = -m[o][o];
            for (r = 1; r < o; r = r + 1) {
                m[r][o] = q * m[r][o]
            }
            s = o + 1;
            if (u < s) {
                break
            }
            for (p = s; p <= u; p = p + 1) {
                q = m[o][p];
                m[o][p] = 0;
                for (r = 1; r <= o; r = r + 1) {
                    m[r][p] = m[r][p] + (q * m[r][o])
                }
            }
        }
    }
    function e(m, l, s, j) {
        var q, o, r, p;
        for (o = 1; o <= s; o = o + 1) {
            p = 0;
            for (q = 1; q < o; q = q + 1) {
                p = p + (m[q][o] * j[q])
            }
            j[o] = (j[o] - p) / m[o][o]
        }
        for (r = 1; r <= s; r = r + 1) {
            o = s + 1 - r;
            j[o] = j[o] / m[o][o];
            p = -j[o];
            for (q = 1; q < o; q = q + 1) {
                j[q] = j[q] + (p * m[q][o])
            }
        }
    }
    function c(u, r, l, m) {
        var q, p, x, o, v, w;
        for (p = 1; p <= l; p = p + 1) {
            m[1] = p;
            w = 0;
            x = p - 1;
            if (x < 1) {
                w = u[p][p] - w;
                if (w <= 0) {
                    break
                }
                u[p][p] = Math.sqrt(w)
            } else {
                for (o = 1; o <= x; o = o + 1) {
                    v = u[o][p];
                    for (q = 1; q < o; q = q + 1) {
                        v = v - (u[q][p] * u[q][o])
                    }
                    v = v / u[o][o];
                    u[o][p] = v;
                    w = w + v * v
                }
                w = u[p][p] - w;
                if (w <= 0) {
                    break
                }
                u[p][p] = Math.sqrt(w)
            }
            m[1] = 0
        }
    }
    function d(P, I, aa, ab, E, B, D, R, S, Z, y, G, J, N, W, k) {
        var ag, af, ac, A, ai, M, C, ae, ak, Q, ah, U, Y, u, w, H, V, aj, F, v, ad, z, X, O, L, K, x;
        Y = Math.min(ab, Z);
        ac = 2 * ab + (Y * (Y + 5)) / 2 + 2 * Z + 1;
        O = 1e-60;
        do {
            O = O + O;
            L = 1 + 0.1 * O;
            K = 1 + 0.2 * O
        } while (L <= 1 || K <= 1);
        for (ag = 1; ag <= ab; ag = ag + 1) {
            W[ag] = I[ag]
        }
        for (ag = ab + 1; ag <= ac; ag = ag + 1) {
            W[ag] = 0
        }
        for (ag = 1; ag <= Z; ag = ag + 1) {
            G[ag] = 0
        }
        ai = [];
        if (k[1] === 0) {
            c(P, aa, ab, ai);
            if (ai[1] !== 0) {
                k[1] = 2;
                return
            }
            e(P, aa, ab, I);
            g(P, aa, ab)
        } else {
            for (af = 1; af <= ab; af = af + 1) {
                E[af] = 0;
                for (ag = 1; ag <= af; ag = ag + 1) {
                    E[af] = E[af] + P[ag][af] * I[ag]
                }
            }
            for (af = 1; af <= ab; af = af + 1) {
                I[af] = 0;
                for (ag = af; ag <= ab; ag = ag + 1) {
                    I[af] = I[af] + P[af][ag] * E[ag]
                }
            }
        }
        B[1] = 0;
        for (af = 1; af <= ab; af = af + 1) {
            E[af] = I[af];
            B[1] = B[1] + W[af] * E[af];
            W[af] = 0;
            for (ag = af + 1; ag <= ab; ag = ag + 1) {
                P[ag][af] = 0
            }
        }
        B[1] = -B[1] / 2;
        k[1] = 0;
        C = ab;
        ae = C + ab;
        ah = ae + Y;
        ak = ah + Y + 1;
        Q = ak + (Y * (Y + 1)) / 2;
        u = Q + Z;
        for (ag = 1; ag <= Z; ag = ag + 1) {
            H = 0;
            for (af = 1; af <= ab; af = af + 1) {
                H = H + D[af][ag] * D[af][ag]
            }
            W[u + ag] = Math.sqrt(H)
        }
        J = 0;
        N[1] = 0;
        N[2] = 0;

        function m() {
            N[1] = N[1] + 1;
            ac = Q;
            for (ag = 1; ag <= Z; ag = ag + 1) {
                ac = ac + 1;
                H = -R[ag];
                for (af = 1; af <= ab; af = af + 1) {
                    H = H + D[af][ag] * E[af]
                }
                if (Math.abs(H) < O) {
                    H = 0
                }
                if (ag > y) {
                    W[ac] = H
                } else {
                    W[ac] = -Math.abs(H);
                    if (H > 0) {
                        for (af = 1; af <= ab; af = af + 1) {
                            D[af][ag] = -D[af][ag]
                        }
                        R[ag] = -R[ag]
                    }
                }
            }
            for (ag = 1; ag <= J; ag = ag + 1) {
                W[Q + G[ag]] = 0
            }
            U = 0;
            w = 0;
            for (ag = 1; ag <= Z; ag = ag + 1) {
                if (W[Q + ag] < w * W[u + ag]) {
                    U = ag;
                    w = W[Q + ag] / W[u + ag]
                }
            }
            if (U === 0) {
                return 999
            }
            return 0
        }
        function al() {
            for (ag = 1; ag <= ab; ag = ag + 1) {
                H = 0;
                for (af = 1; af <= ab; af = af + 1) {
                    H = H + P[af][ag] * D[af][U]
                }
                W[ag] = H
            }
            A = C;
            for (ag = 1; ag <= ab; ag = ag + 1) {
                W[A + ag] = 0
            }
            for (af = J + 1; af <= ab; af = af + 1) {
                for (ag = 1; ag <= ab; ag = ag + 1) {
                    W[A + ag] = W[A + ag] + P[ag][af] * W[af]
                }
            }
            z = true;
            for (ag = J; ag >= 1; ag = ag - 1) {
                H = W[ag];
                ac = ak + (ag * (ag + 3)) / 2;
                A = ac - ag;
                for (af = ag + 1; af <= J; af = af + 1) {
                    H = H - W[ac] * W[ae + af];
                    ac = ac + af
                }
                H = H / W[A];
                W[ae + ag] = H;
                if (G[ag] < y) {
                    break
                }
                if (H < 0) {
                    break
                }
                z = false;
                M = ag
            }
            if (!z) {
                V = W[ah + M] / W[ae + M];
                for (ag = 1; ag <= J; ag = ag + 1) {
                    if (G[ag] < y) {
                        break
                    }
                    if (W[ae + ag] < 0) {
                        break
                    }
                    w = W[ah + ag] / W[ae + ag];
                    if (w < V) {
                        V = w;
                        M = ag
                    }
                }
            }
            H = 0;
            for (ag = C + 1; ag <= C + ab; ag = ag + 1) {
                H = H + W[ag] * W[ag]
            }
            if (Math.abs(H) <= O) {
                if (z) {
                    k[1] = 1;
                    return 999
                } else {
                    for (ag = 1; ag <= J; ag = ag + 1) {
                        W[ah + ag] = W[ah + ag] - V * W[ae + ag]
                    }
                    W[ah + J + 1] = W[ah + J + 1] + V;
                    return 700
                }
            } else {
                H = 0;
                for (ag = 1; ag <= ab; ag = ag + 1) {
                    H = H + W[C + ag] * D[ag][U]
                }
                aj = -W[Q + U] / H;
                X = true;
                if (!z) {
                    if (V < aj) {
                        aj = V;
                        X = false
                    }
                }
                for (ag = 1; ag <= ab; ag = ag + 1) {
                    E[ag] = E[ag] + aj * W[C + ag];
                    if (Math.abs(E[ag]) < O) {
                        E[ag] = 0
                    }
                }
                B[1] = B[1] + aj * H * (aj / 2 + W[ah + J + 1]);
                for (ag = 1; ag <= J; ag = ag + 1) {
                    W[ah + ag] = W[ah + ag] - aj * W[ae + ag]
                }
                W[ah + J + 1] = W[ah + J + 1] + aj;
                if (X) {
                    J = J + 1;
                    G[J] = U;
                    ac = ak + ((J - 1) * J) / 2 + 1;
                    for (ag = 1; ag <= J - 1; ag = ag + 1) {
                        W[ac] = W[ag];
                        ac = ac + 1
                    }
                    if (J === ab) {
                        W[ac] = W[ab]
                    } else {
                        for (ag = ab; ag >= J + 1; ag = ag - 1) {
                            if (W[ag] === 0) {
                                break
                            }
                            F = Math.max(Math.abs(W[ag - 1]), Math.abs(W[ag]));
                            v = Math.min(Math.abs(W[ag - 1]), Math.abs(W[ag]));
                            if (W[ag - 1] >= 0) {
                                w = Math.abs(F * Math.sqrt(1 + v * v / (F * F)))
                            } else {
                                w = -Math.abs(F * Math.sqrt(1 + v * v / (F * F)))
                            }
                            F = W[ag - 1] / w;
                            v = W[ag] / w;
                            if (F === 1) {
                                break
                            }
                            if (F === 0) {
                                W[ag - 1] = v * w;
                                for (af = 1; af <= ab; af = af + 1) {
                                    w = P[af][ag - 1];
                                    P[af][ag - 1] = P[af][ag];
                                    P[af][ag] = w
                                }
                            } else {
                                W[ag - 1] = w;
                                ad = v / (1 + F);
                                for (af = 1; af <= ab; af = af + 1) {
                                    w = F * P[af][ag - 1] + v * P[af][ag];
                                    P[af][ag] = ad * (P[af][ag - 1] + w) - P[af][ag];
                                    P[af][ag - 1] = w
                                }
                            }
                        }
                        W[ac] = W[J]
                    }
                } else {
                    H = -R[U];
                    for (af = 1; af <= ab; af = af + 1) {
                        H = H + E[af] * D[af][U]
                    }
                    if (U > y) {
                        W[Q + U] = H
                    } else {
                        W[Q + U] = -Math.abs(H);
                        if (H > 0) {
                            for (af = 1; af <= ab; af = af + 1) {
                                D[af][U] = -D[af][U]
                            }
                            R[U] = -R[U]
                        }
                    }
                    return 700
                }
            }
            return 0
        }
        function s() {
            ac = ak + (M * (M + 1)) / 2 + 1;
            A = ac + M;
            if (W[A] === 0) {
                return 798
            }
            F = Math.max(Math.abs(W[A - 1]), Math.abs(W[A]));
            v = Math.min(Math.abs(W[A - 1]), Math.abs(W[A]));
            if (W[A - 1] >= 0) {
                w = Math.abs(F * Math.sqrt(1 + v * v / (F * F)))
            } else {
                w = -Math.abs(F * Math.sqrt(1 + v * v / (F * F)))
            }
            F = W[A - 1] / w;
            v = W[A] / w;
            if (F === 1) {
                return 798
            }
            if (F === 0) {
                for (ag = M + 1; ag <= J; ag = ag + 1) {
                    w = W[A - 1];
                    W[A - 1] = W[A];
                    W[A] = w;
                    A = A + ag
                }
                for (ag = 1; ag <= ab; ag = ag + 1) {
                    w = P[ag][M];
                    P[ag][M] = P[ag][M + 1];
                    P[ag][M + 1] = w
                }
            } else {
                ad = v / (1 + F);
                for (ag = M + 1; ag <= J; ag = ag + 1) {
                    w = F * W[A - 1] + v * W[A];
                    W[A] = ad * (W[A - 1] + w) - W[A];
                    W[A - 1] = w;
                    A = A + ag
                }
                for (ag = 1; ag <= ab; ag = ag + 1) {
                    w = F * P[ag][M] + v * P[ag][M + 1];
                    P[ag][M + 1] = ad * (P[ag][M] + w) - P[ag][M + 1];
                    P[ag][M] = w
                }
            }
            return 0
        }
        function p() {
            A = ac - M;
            for (ag = 1; ag <= M; ag = ag + 1) {
                W[A] = W[ac];
                ac = ac + 1;
                A = A + 1
            }
            W[ah + M] = W[ah + M + 1];
            G[M] = G[M + 1];
            M = M + 1;
            if (M < J) {
                return 797
            }
            return 0
        }
        function o() {
            W[ah + J] = W[ah + J + 1];
            W[ah + J + 1] = 0;
            G[J] = 0;
            J = J - 1;
            N[2] = N[2] + 1;
            return 0
        }
        x = 0;
        while (true) {
            x = m();
            if (x === 999) {
                return
            }
            while (true) {
                x = al();
                if (x === 0) {
                    break
                }
                if (x === 999) {
                    return
                }
                if (x === 700) {
                    if (M === J) {
                        o()
                    } else {
                        while (true) {
                            s();
                            x = p();
                            if (x !== 797) {
                                break
                            }
                        }
                        o()
                    }
                }
            }
        }
    }
    function a(m, l, C, u, v, y) {
        m = h(m);
        l = h(l);
        C = h(C);
        var s, p, k, B, j, A = [],
            o = [],
            w = [],
            z = [],
            x = [],
            D;
        v = v || 0;
        y = y ? h(y) : [undefined, 0];
        u = u ? h(u) : [];
        p = m.length - 1;
        k = C[1].length - 1;
        if (!u) {
            for (s = 1; s <= k; s = s + 1) {
                u[s] = 0
            }
        }
        for (s = 1; s <= k; s = s + 1) {
            o[s] = 0
        }
        B = 0;
        j = Math.min(p, k);
        for (s = 1; s <= p; s = s + 1) {
            w[s] = 0
        }
        A[1] = 0;
        for (s = 1; s <= (2 * p + (j * (j + 5)) / 2 + 2 * k + 1); s = s + 1) {
            z[s] = 0
        }
        for (s = 1; s <= 2; s = s + 1) {
            x[s] = 0
        }
        d(m, l, p, p, w, A, C, u, p, k, v, o, B, x, z, y);
        D = "";
        if (y[1] === 1) {
            D = "constraints are inconsistent, no solution!"
        }
        if (y[1] === 2) {
            D = "matrix D in quadratic function is not positive definite!"
        }
        return {
            solution: f(w),
            value: f(A),
            unconstrained_solution: f(l),
            iterations: f(x),
            iact: f(o),
            message: D
        }
    }
    b.solveQP = a
}(numeric));
numeric.svd = function svd(E) {
    var S;
    var a = numeric.epsilon;
    var N = 1e-64 / a;
    var Q = 50;
    var U = 0;
    var L = 0;
    var K = 0;
    var J = 0;
    var H = 0;
    var B = numeric.clone(E);
    var G = B.length;
    var F = B[0].length;
    if (G < F) {
        throw "Need more rows than columns"
    }
    var R = new Array(F);
    var D = new Array(F);
    for (L = 0; L < F; L++) {
        R[L] = D[L] = 0
    }
    var w = numeric.rep([F, F], 0);

    function d(e, c) {
        e = Math.abs(e);
        c = Math.abs(c);
        if (e > c) {
            return e * Math.sqrt(1 + (c * c / e / e))
        } else {
            if (c == 0) {
                return e
            }
        }
        return c * Math.sqrt(1 + (e * e / c / c))
    }
    var P = 0;
    var O = 0;
    var M = 0;
    var r = 0;
    var p = 0;
    var o = 0;
    var C = 0;
    for (L = 0; L < F; L++) {
        R[L] = O;
        C = 0;
        H = L + 1;
        for (K = L; K < G; K++) {
            C += (B[K][L] * B[K][L])
        }
        if (C <= N) {
            O = 0
        } else {
            P = B[L][L];
            O = Math.sqrt(C);
            if (P >= 0) {
                O = -O
            }
            M = P * O - C;
            B[L][L] = P - O;
            for (K = H; K < F; K++) {
                C = 0;
                for (J = L; J < G; J++) {
                    C += B[J][L] * B[J][K]
                }
                P = C / M;
                for (J = L; J < G; J++) {
                    B[J][K] += P * B[J][L]
                }
            }
        }
        D[L] = O;
        C = 0;
        for (K = H; K < F; K++) {
            C = C + B[L][K] * B[L][K]
        }
        if (C <= N) {
            O = 0
        } else {
            P = B[L][L + 1];
            O = Math.sqrt(C);
            if (P >= 0) {
                O = -O
            }
            M = P * O - C;
            B[L][L + 1] = P - O;
            for (K = H; K < F; K++) {
                R[K] = B[L][K] / M
            }
            for (K = H; K < G; K++) {
                C = 0;
                for (J = H; J < F; J++) {
                    C += (B[K][J] * B[L][J])
                }
                for (J = H; J < F; J++) {
                    B[K][J] += C * R[J]
                }
            }
        }
        p = Math.abs(D[L]) + Math.abs(R[L]);
        if (p > r) {
            r = p
        }
    }
    for (L = F - 1; L != -1; L += -1) {
        if (O != 0) {
            M = O * B[L][L + 1];
            for (K = H; K < F; K++) {
                w[K][L] = B[L][K] / M
            }
            for (K = H; K < F; K++) {
                C = 0;
                for (J = H; J < F; J++) {
                    C += B[L][J] * w[J][K]
                }
                for (J = H; J < F; J++) {
                    w[J][K] += (C * w[J][L])
                }
            }
        }
        for (K = H; K < F; K++) {
            w[L][K] = 0;
            w[K][L] = 0
        }
        w[L][L] = 1;
        O = R[L];
        H = L
    }
    for (L = F - 1; L != -1; L += -1) {
        H = L + 1;
        O = D[L];
        for (K = H; K < F; K++) {
            B[L][K] = 0
        }
        if (O != 0) {
            M = B[L][L] * O;
            for (K = H; K < F; K++) {
                C = 0;
                for (J = H; J < G; J++) {
                    C += B[J][L] * B[J][K]
                }
                P = C / M;
                for (J = L; J < G; J++) {
                    B[J][K] += P * B[J][L]
                }
            }
            for (K = L; K < G; K++) {
                B[K][L] = B[K][L] / O
            }
        } else {
            for (K = L; K < G; K++) {
                B[K][L] = 0
            }
        }
        B[L][L] += 1
    }
    a = a * r;
    for (J = F - 1; J != -1; J += -1) {
        for (var b = 0; b < Q; b++) {
            var V = false;
            for (H = J; H != -1; H += -1) {
                if (Math.abs(R[H]) <= a) {
                    V = true;
                    break
                }
                if (Math.abs(D[H - 1]) <= a) {
                    break
                }
            }
            if (!V) {
                U = 0;
                C = 1;
                var I = H - 1;
                for (L = H; L < J + 1; L++) {
                    P = C * R[L];
                    R[L] = U * R[L];
                    if (Math.abs(P) <= a) {
                        break
                    }
                    O = D[L];
                    M = d(P, O);
                    D[L] = M;
                    U = O / M;
                    C = -P / M;
                    for (K = 0; K < G; K++) {
                        p = B[K][I];
                        o = B[K][L];
                        B[K][I] = p * U + (o * C);
                        B[K][L] = -p * C + (o * U)
                    }
                }
            }
            o = D[J];
            if (H == J) {
                if (o < 0) {
                    D[J] = -o;
                    for (K = 0; K < F; K++) {
                        w[K][J] = -w[K][J]
                    }
                }
                break
            }
            if (b >= Q - 1) {
                throw "Error: no convergence."
            }
            r = D[H];
            p = D[J - 1];
            O = R[J - 1];
            M = R[J];
            P = ((p - o) * (p + o) + (O - M) * (O + M)) / (2 * M * p);
            O = d(P, 1);
            if (P < 0) {
                P = ((r - o) * (r + o) + M * (p / (P - O) - M)) / r
            } else {
                P = ((r - o) * (r + o) + M * (p / (P + O) - M)) / r
            }
            U = 1;
            C = 1;
            for (L = H + 1; L < J + 1; L++) {
                O = R[L];
                p = D[L];
                M = C * O;
                O = U * O;
                o = d(P, M);
                R[L - 1] = o;
                U = P / o;
                C = M / o;
                P = r * U + O * C;
                O = -r * C + O * U;
                M = p * C;
                p = p * U;
                for (K = 0; K < F; K++) {
                    r = w[K][L - 1];
                    o = w[K][L];
                    w[K][L - 1] = r * U + o * C;
                    w[K][L] = -r * C + o * U
                }
                o = d(P, M);
                D[L - 1] = o;
                U = P / o;
                C = M / o;
                P = U * O + C * p;
                r = -C * O + U * p;
                for (K = 0; K < G; K++) {
                    p = B[K][L - 1];
                    o = B[K][L];
                    B[K][L - 1] = p * U + o * C;
                    B[K][L] = -p * C + o * U
                }
            }
            R[H] = 0;
            R[J] = P;
            D[J] = r
        }
    }
    for (L = 0; L < D.length; L++) {
        if (D[L] < a) {
            D[L] = 0
        }
    }
    for (L = 0; L < F; L++) {
        for (K = L - 1; K >= 0; K--) {
            if (D[K] < D[L]) {
                U = D[K];
                D[K] = D[L];
                D[L] = U;
                for (J = 0; J < B.length; J++) {
                    S = B[J][L];
                    B[J][L] = B[J][K];
                    B[J][K] = S
                }
                for (J = 0; J < w.length; J++) {
                    S = w[J][L];
                    w[J][L] = w[J][K];
                    w[J][K] = S
                }
                L = K
            }
        }
    }
    return {
        U: B,
        S: D,
        V: w
    }
};
var BrowserDetect = {
    init: function () {
        this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
        this.version = this.searchVersion(navigator.userAgent) || this.searchVersion(navigator.appVersion) || "an unknown version";
        this.OS = this.searchString(this.dataOS) || "an unknown OS"
    },
    searchString: function (d) {
        for (var a = 0; a < d.length; a++) {
            var b = d[a].string;
            var c = d[a].prop;
            this.versionSearchString = d[a].versionSearch || d[a].identity;
            if (b) {
                if (b.indexOf(d[a].subString) != -1) {
                    return d[a].identity
                }
            } else {
                if (c) {
                    return d[a].identity
                }
            }
        }
    },
    searchVersion: function (b) {
        var a = b.indexOf(this.versionSearchString);
        if (a == -1) {
            return
        }
        return parseFloat(b.substring(a + this.versionSearchString.length + 1))
    },
    dataBrowser: [{
        string: navigator.userAgent,
        subString: "Chrome",
        identity: "Chrome"
    },
    {
        string: navigator.userAgent,
        subString: "OmniWeb",
        versionSearch: "OmniWeb/",
        identity: "OmniWeb"
    },
    {
        string: navigator.vendor,
        subString: "Apple",
        identity: "Safari",
        versionSearch: "Version"
    },
    {
        prop: window.opera,
        identity: "Opera",
        versionSearch: "Version"
    },
    {
        string: navigator.vendor,
        subString: "iCab",
        identity: "iCab"
    },
    {
        string: navigator.vendor,
        subString: "KDE",
        identity: "Konqueror"
    },
    {
        string: navigator.userAgent,
        subString: "Firefox",
        identity: "Firefox"
    },
    {
        string: navigator.vendor,
        subString: "Camino",
        identity: "Camino"
    },
    {
        string: navigator.userAgent,
        subString: "Netscape",
        identity: "Netscape"
    },
    {
        string: navigator.userAgent,
        subString: "MSIE",
        identity: "Explorer",
        versionSearch: "MSIE"
    },
    {
        string: navigator.userAgent,
        subString: "Gecko",
        identity: "Mozilla",
        versionSearch: "rv"
    },
    {
        string: navigator.userAgent,
        subString: "Mozilla",
        identity: "Netscape",
        versionSearch: "Mozilla"
    }],
    dataOS: [{
        string: navigator.platform,
        subString: "Win",
        identity: "Windows"
    },
    {
        string: navigator.platform,
        subString: "Mac",
        identity: "Mac"
    },
    {
        string: navigator.userAgent,
        subString: "iPhone",
        identity: "iPhone/iPod"
    },
    {
        string: navigator.platform,
        subString: "Linux",
        identity: "Linux"
    }]
};
BrowserDetect.init();
"use strict";
var BROWSER_MIN_FIREFOX = 7;
var BROWSER_MIN_CHROME = 7;
var BROWSER_MIN_SAFARI = 6;
var BROWSER_MIN_IE = 10;
var BROWSER_MIN_OPERA = 12;
var console = console || {};
console.log = console.log ||
function () {};
console.warn = console.warn ||
function () {};
console.error = console.error ||
function () {};
console.info = console.info ||
function () {};
var LAST_SCROLL_EVENT_TIMESTAMP = 0;
var OSName = "Unknown OS";
if (navigator.appVersion.indexOf("Win") !== -1) {
    OSName = "Windows"
}
if (navigator.appVersion.indexOf("Mac") !== -1) {
    OSName = "MacOS"
}
if (navigator.appVersion.indexOf("X11") !== -1) {
    OSName = "Linux"
}
if (navigator.appVersion.indexOf("Linux") !== -1) {
    OSName = "Linux"
}
var browserIsFirefox = false;
var browserIsSafari = false;
var browserIsOpera = false;
var browserIsChrome = false;
var browserIsIE = false;

function checkForBrowserCompatibility() {
    if (BrowserDetect.browser === "Firefox") {
        browserIsFirefox = true;
        if (BrowserDetect.version < BROWSER_MIN_FIREFOX) {
            return ("Papaya requires Firefox version " + BROWSER_MIN_FIREFOX + " or higher.")
        }
    } else {
        if (BrowserDetect.browser === "Chrome") {
            browserIsChrome = true;
            if (BrowserDetect.version < BROWSER_MIN_CHROME) {
                return ("Papaya requires Chrome version " + BROWSER_MIN_CHROME + " or higher.")
            }
        } else {
            if (BrowserDetect.browser === "Explorer") {
                browserIsIE = true;
                if (BrowserDetect.version < BROWSER_MIN_IE) {
                    return ("Papaya requires Internet Explorer version " + BROWSER_MIN_IE + " or higher.")
                }
            } else {
                if (BrowserDetect.browser === "Safari") {
                    browserIsSafari = true;
                    if (BrowserDetect.version < BROWSER_MIN_SAFARI) {
                        return ("Papaya requires Safari version " + BROWSER_MIN_SAFARI + " or higher.")
                    }
                } else {
                    if (BrowserDetect.browser === "Opera") {
                        browserIsOpera = true;
                        if (BrowserDetect.version < BROWSER_MIN_OPERA) {
                            return ("Papaya requires Opera version " + BROWSER_MIN_OPERA + " or higher.")
                        }
                    }
                }
            }
        }
    }
    return null
}
function getKeyCode(a) {
    return (a.keyCode || a.charCode)
}
function getMousePositionX(a) {
    var b;
    if (a.targetTouches) {
        if (a.targetTouches.length === 1) {
            b = a.targetTouches[0];
            if (b) {
                return b.pageX
            }
        }
    } else {
        if (a.changedTouches) {
            if (a.changedTouches.length === 1) {
                b = a.changedTouches[0];
                if (b) {
                    return b.pageX
                }
            }
        }
    }
    return a.pageX
}
function getMousePositionY(a) {
    var b;
    if (a.targetTouches) {
        if (a.targetTouches.length === 1) {
            b = a.targetTouches[0];
            if (b) {
                return b.pageY
            }
        }
    } else {
        if (a.changedTouches) {
            if (a.changedTouches.length === 1) {
                b = a.changedTouches[0];
                if (b) {
                    return b.pageY
                }
            }
        }
    }
    return a.pageY
}
function getScrollSign(b) {
    var a = Date.now();
    if ((a - LAST_SCROLL_EVENT_TIMESTAMP) > 50) {
        LAST_SCROLL_EVENT_TIMESTAMP = a;
        if (b.wheelDelta) {
            return b.wheelDelta > 0 ? 1 : -1
        }
        if (b.detail) {
            return b.detail < 0 ? 1 : -1
        }
    }
    return 0
}
var makeSlice = function (b, d, c) {
    var a = (typeof File);
    if (a === "undefined") {
        return function () {}
    }
    if (File.prototype.slice) {
        return b.slice(d, d + c)
    }
    if (File.prototype.mozSlice) {
        return b.mozSlice(d, c)
    }
    if (File.prototype.webkitSlice) {
        return b.webkitSlice(d, c)
    }
    return null
};

function isPlatformLittleEndian() {
    var a = new ArrayBuffer(2);
    new DataView(a).setInt16(0, 256, true);
    return new Int16Array(a)[0] === 256
}
function isInputRangeSupported() {
    var a = document.createElement("input");
    a.setAttribute("type", "range");
    return (a.type === "range")
}
var Base64Binary = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    decodeArrayBuffer: function (b) {
        var d = this._keyStr.indexOf(b.charAt(b.length - 1));
        var c = this._keyStr.indexOf(b.charAt(b.length - 2));
        var a = (b.length / 4) * 3;
        if (d == 64) {
            a--
        }
        if (c == 64) {
            a--
        }
        var e = new ArrayBuffer(a);
        this.decode(b, e, a);
        return e
    },
    decode: function (e, d, o) {
        var c;
        var n, l, h;
        var m, k, g, f;
        var b = 0;
        var a = 0;
        if (d) {
            c = new Uint8Array(d)
        } else {
            c = new Uint8Array(o)
        }
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        for (b = 0; b < o; b += 3) {
            m = this._keyStr.indexOf(e.charAt(a++));
            k = this._keyStr.indexOf(e.charAt(a++));
            g = this._keyStr.indexOf(e.charAt(a++));
            f = this._keyStr.indexOf(e.charAt(a++));
            n = (m << 2) | (k >> 4);
            l = ((k & 15) << 4) | (g >> 2);
            h = ((g & 3) << 6) | f;
            c[b] = n;
            if (g != 64) {
                c[b + 1] = l
            }
            if (f != 64) {
                c[b + 2] = h
            }
        }
        return c
    }
};
"use strict";
var papaya = papaya || {};
papaya.core = papaya.core || {};
papaya.core.Dimensions = papaya.core.Dimensions ||
function (b, a) {
    this.width = b;
    this.height = a;
    this.widthPadding = 0;
    this.heightPadding = 0
};
"use strict";
var papaya = papaya || {};
papaya.core = papaya.core || {};
papaya.core.Point = papaya.core.Point ||
function (b, a) {
    this.x = b;
    this.y = a
};
"use strict";
var papaya = papaya || {};
papaya.core = papaya.core || {};
papaya.core.Coordinate = papaya.core.Coordinate ||
function (c, b, a) {
    this.x = c;
    this.y = b;
    this.z = a
};
papaya.core.Coordinate.prototype.setCoordinate = function (d, c, b, a) {
    if (a) {
        this.x = Math.round(d);
        this.y = Math.round(c);
        this.z = Math.round(b)
    } else {
        this.x = d;
        this.y = c;
        this.z = b
    }
};
papaya.core.Coordinate.prototype.isAllZeros = function () {
    return ((this.x === 0) && (this.y === 0) && (this.z === 0))
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.Orientation = papaya.volume.Orientation ||
function (a) {
    this.orientation = a;
    this.orientMat = null;
    this.xIncrement = -1;
    this.yIncrement = -1;
    this.zIncrement = -1
};
papaya.volume.Orientation.DEFAULT = "XYZ+--";
papaya.volume.Orientation.prototype.convertIndexToOffset = function (e, d, c) {
    var b, a, f;
    b = roundFast((e * this.orientMat[0][0]) + (d * this.orientMat[0][1]) + (c * this.orientMat[0][2]) + (this.orientMat[0][3]));
    a = roundFast((e * this.orientMat[1][0]) + (d * this.orientMat[1][1]) + (c * this.orientMat[1][2]) + (this.orientMat[1][3]));
    f = roundFast((e * this.orientMat[2][0]) + (d * this.orientMat[2][1]) + (c * this.orientMat[2][2]) + (this.orientMat[2][3]));
    return (b * this.xIncrement) + (a * this.yIncrement) + (f * this.zIncrement)
};
papaya.volume.Orientation.prototype.convertCoordinate = function (b, a) {
    a.x = roundFast((b.x * this.orientMat[0][0]) + (b.y * this.orientMat[0][1]) + (b.z * this.orientMat[0][2]) + (this.orientMat[0][3]));
    a.y = roundFast((b.x * this.orientMat[1][0]) + (b.y * this.orientMat[1][1]) + (b.z * this.orientMat[1][2]) + (this.orientMat[1][3]));
    a.z = roundFast((b.x * this.orientMat[2][0]) + (b.y * this.orientMat[2][1]) + (b.z * this.orientMat[2][2]) + (this.orientMat[2][3]));
    return a
};
papaya.volume.Orientation.prototype.createInfo = function (k, g) {
    var n, e, m, r, l, q, i, b, p, h, d, j, o, c, a, f;
    h = k.cols;
    d = k.rows;
    j = k.slices;
    o = k.getNumVoxelsSlice();
    c = g.colSize;
    a = g.rowSize;
    f = g.sliceSize;
    i = (this.orientation.charAt(3) === "+");
    b = (this.orientation.charAt(4) === "+");
    p = (this.orientation.charAt(5) === "+");
    if (this.orientation.toUpperCase().indexOf("XYZ") !== -1) {
        k.xDim = h;
        k.yDim = d;
        k.zDim = j;
        g.xSize = c;
        g.ySize = a;
        g.zSize = f;
        this.xIncrement = 1;
        this.yIncrement = h;
        this.zIncrement = o;
        if (i) {
            n = 1;
            r = 0
        } else {
            n = -1;
            r = h - 1
        }
        if (b) {
            e = -1;
            l = d - 1
        } else {
            e = 1;
            l = 0
        }
        if (p) {
            m = -1;
            q = j - 1
        } else {
            m = 1;
            q = 0
        }
    } else {
        if (this.orientation.toUpperCase().indexOf("XZY") !== -1) {
            k.xDim = h;
            k.yDim = j;
            k.zDim = d;
            g.xSize = c;
            g.ySize = f;
            g.zSize = a;
            this.xIncrement = 1;
            this.yIncrement = o;
            this.zIncrement = h;
            if (i) {
                n = 1;
                r = 0
            } else {
                n = -1;
                r = h - 1
            }
            if (b) {
                m = -1;
                q = d - 1
            } else {
                m = 1;
                q = 0
            }
            if (p) {
                e = -1;
                l = j - 1
            } else {
                e = 1;
                l = 0
            }
        } else {
            if (this.orientation.toUpperCase().indexOf("YXZ") !== -1) {
                k.xDim = d;
                k.yDim = h;
                k.zDim = j;
                g.xSize = a;
                g.ySize = c;
                g.zSize = f;
                this.xIncrement = h;
                this.yIncrement = 1;
                this.zIncrement = o;
                if (i) {
                    e = -1;
                    l = h - 1
                } else {
                    e = 1;
                    l = 0
                }
                if (b) {
                    n = 1;
                    r = 0
                } else {
                    n = -1;
                    r = d - 1
                }
                if (p) {
                    m = -1;
                    q = j - 1
                } else {
                    m = 1;
                    q = 0
                }
            } else {
                if (this.orientation.toUpperCase().indexOf("YZX") !== -1) {
                    k.xDim = j;
                    k.yDim = h;
                    k.zDim = d;
                    g.xSize = f;
                    g.ySize = c;
                    g.zSize = a;
                    this.xIncrement = o;
                    this.yIncrement = 1;
                    this.zIncrement = h;
                    if (i) {
                        e = -1;
                        l = h - 1
                    } else {
                        e = 1;
                        l = 0
                    }
                    if (b) {
                        m = -1;
                        q = d - 1
                    } else {
                        m = 1;
                        q = 0
                    }
                    if (p) {
                        n = 1;
                        r = 0
                    } else {
                        n = -1;
                        r = j - 1
                    }
                } else {
                    if (this.orientation.toUpperCase().indexOf("ZXY") !== -1) {
                        k.xDim = d;
                        k.yDim = j;
                        k.zDim = h;
                        g.xSize = a;
                        g.ySize = f;
                        g.zSize = c;
                        this.xIncrement = h;
                        this.yIncrement = o;
                        this.zIncrement = 1;
                        if (i) {
                            m = -1;
                            q = h - 1
                        } else {
                            m = 1;
                            q = 0
                        }
                        if (b) {
                            n = 1;
                            r = 0
                        } else {
                            n = -1;
                            r = d - 1
                        }
                        if (p) {
                            e = -1;
                            l = j - 1
                        } else {
                            e = 1;
                            l = 0
                        }
                    } else {
                        if (this.orientation.toUpperCase().indexOf("ZYX") !== -1) {
                            k.xDim = j;
                            k.yDim = d;
                            k.zDim = h;
                            g.xSize = f;
                            g.ySize = a;
                            g.zSize = c;
                            this.xIncrement = o;
                            this.yIncrement = h;
                            this.zIncrement = 1;
                            if (i) {
                                m = -1;
                                q = h - 1
                            } else {
                                m = 1;
                                q = 0
                            }
                            if (b) {
                                e = -1;
                                l = d - 1
                            } else {
                                e = 1;
                                l = 0
                            }
                            if (p) {
                                n = 1;
                                r = 0
                            } else {
                                n = -1;
                                r = j - 1
                            }
                        }
                    }
                }
            }
        }
    }
    this.orientMat = [
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1]
    ];
    this.orientMat[0][0] = n;
    this.orientMat[0][1] = 0;
    this.orientMat[0][2] = 0;
    this.orientMat[0][3] = r;
    this.orientMat[1][0] = 0;
    this.orientMat[1][1] = e;
    this.orientMat[1][2] = 0;
    this.orientMat[1][3] = l;
    this.orientMat[2][0] = 0;
    this.orientMat[2][1] = 0;
    this.orientMat[2][2] = m;
    this.orientMat[2][3] = q;
    this.orientMat[3][0] = 0;
    this.orientMat[3][1] = 0;
    this.orientMat[3][2] = 0;
    this.orientMat[3][3] = 1
};
papaya.volume.Orientation.prototype.isValid = function () {
    return papaya.volume.Orientation.prototype.isValidOrientationString(this.orientation)
};
papaya.volume.Orientation.prototype.isValidOrientationString = function (c) {
    var a, b = true;
    if (c === null || (c.length !== 6)) {
        b = false
    }
    a = c.toUpperCase().indexOf("X");
    if (a === -1 || a > 2 || (c.toUpperCase().lastIndexOf("X") !== a)) {
        b = false
    }
    a = c.toUpperCase().indexOf("Y");
    if (a === -1 || a > 2 || (c.toUpperCase().lastIndexOf("Y") !== a)) {
        b = false
    }
    a = c.toUpperCase().indexOf("Z");
    if (a === -1 || a > 2 || (c.toUpperCase().lastIndexOf("Z") !== a)) {
        b = false
    }
    if ((c.charAt(3) !== "+") && (c.charAt(3) !== "-")) {
        b = false
    }
    if ((c.charAt(4) !== "+") && (c.charAt(4) !== "-")) {
        b = false
    }
    if ((c.charAt(5) !== "+") && (c.charAt(5) !== "-")) {
        b = false
    }
    return b
};
papaya.volume.Orientation.prototype.getOrientationDescription = function () {
    var a = this.orientation;
    return ("Cols (" + a.charAt(0) + a.charAt(3) + "), Rows (" + a.charAt(1) + a.charAt(4) + "), Slices (" + a.charAt(2) + a.charAt(5) + ")")
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.VoxelDimensions = papaya.volume.VoxelDimensions ||
function (d, a, b, c) {
    this.colSize = Math.abs(d);
    this.rowSize = Math.abs(a);
    this.sliceSize = Math.abs(b);
    this.xSize = 0;
    this.ySize = 0;
    this.zSize = 0;
    this.timeSize = c
};
papaya.volume.VoxelDimensions.prototype.isValid = function () {
    return ((this.colSize > 0) && (this.rowSize > 0) && (this.sliceSize > 0) && (this.timeSize >= 0))
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.ImageRange = papaya.volume.ImageRange ||
function (b, a) {
    this.displayMin = b;
    this.displayMax = a;
    this.imageMin = 0;
    this.imageMax = 0;
    this.globalScale = papaya.volume.ImageRange.DEFAULT_SCALE;
    this.globalIntercept = papaya.volume.ImageRange.DEFAULT_INTERCEPT
};
papaya.volume.ImageRange.DEFAULT_SCALE = 1;
papaya.volume.ImageRange.DEFAULT_INTERCEPT = 0;
papaya.volume.ImageRange.prototype.isValid = function () {
    return true
};
papaya.volume.ImageRange.prototype.setGlobalDataScale = function (b, a) {
    this.globalScale = b;
    this.globalIntercept = a
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.ImageData = papaya.volume.ImageData ||
function () {
    this.data = null
};
papaya.volume.ImageData.prototype.readData = function (f, e, a) {
    var d, b, c;
    if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED) && (f.imageType.numBytes === 1)) {
        this.data = new Int8Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
    } else {
        if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED) && (f.imageType.numBytes === 1)) {
            this.data = new Uint8Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
        } else {
            if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED) && (f.imageType.numBytes === 2)) {
                this.data = new Int16Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
            } else {
                if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED) && (f.imageType.numBytes === 2)) {
                    this.data = new Uint16Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
                } else {
                    if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED) && (f.imageType.numBytes === 4)) {
                        this.data = new Int32Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
                    } else {
                        if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED) && (f.imageType.numBytes === 4)) {
                            this.data = new Uint32Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
                        } else {
                            if ((f.imageType.datatype === papaya.volume.ImageType.DATATYPE_FLOAT) && (f.imageType.numBytes === 4)) {
                                if (f.imageType.swapped) {
                                    d = f.imageDimensions.getNumVoxelsSeries();
                                    b = new DataView(e, f.imageDimensions.offset);
                                    this.data = new Float32Array(d);
                                    for (c = 0; c < d; c += 1) {
                                        this.data[c] = b.getFloat32(c * Float32Array.BYTES_PER_ELEMENT)
                                    }
                                } else {
                                    this.data = new Float32Array(e, f.imageDimensions.offset, f.imageDimensions.getNumVoxelsSeries())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    a()
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.ImageDescription = papaya.volume.ImageDescription ||
function (a) {
    this.notes = "(none)";
    if (!isStringBlank(a)) {
        this.notes = a
    }
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.VoxelValue = papaya.volume.VoxelValue ||
function (e, c, b, d, a) {
    this.imageData = e;
    this.imageType = c;
    this.imageRange = d;
    this.orientation = a;
    this.swap16 = ((this.imageType.numBytes === 2) && this.imageType.swapped) && (this.imageType.datatype !== papaya.volume.ImageType.DATATYPE_FLOAT);
    this.swap32 = ((this.imageType.numBytes === 4) && this.imageType.swapped) && (this.imageType.datatype !== papaya.volume.ImageType.DATATYPE_FLOAT);
    this.xIncrement = a.xIncrement;
    this.yIncrement = a.yIncrement;
    this.zIncrement = a.zIncrement;
    this.xDim = b.xDim;
    this.yDim = b.yDim;
    this.zDim = b.zDim;
    this.dataScaleSlope = d.globalScale;
    this.dataScaleIntercept = d.globalIntercept;
    this.interpFirstPass = [
        [0, 0],
        [0, 0]
    ];
    this.interpSecondPass = [0, 0];
    this.volumeArraySize = this.xDim * this.yDim * this.zDim
};
papaya.volume.VoxelValue.prototype.getVoxelAtIndex = function (d, c, b, a, e) {
    if (e) {
        d = roundFast(d);
        c = roundFast(c);
        b = roundFast(b);
        return (this.getVoxelAtOffset(this.orientation.convertIndexToOffset(d, c, b), a) * this.dataScaleSlope) + this.dataScaleIntercept
    }
    return this.getVoxelAtIndexLinear(d, c, b, a)
};
papaya.volume.VoxelValue.prototype.getVoxelAtOffset = function (b, a) {
    return this.checkSwap(this.imageData.data[b + (this.volumeArraySize * a)])
};
papaya.volume.VoxelValue.prototype.getVoxelAtIndexLinear = function (k, n, s, c) {
    var l, i, h, f, b, a, e, d, g, j, p, o, m, r, q;
    l = b = a = 0;
    d = Math.floor(k);
    g = Math.floor(n);
    j = Math.floor(s);
    i = k - d;
    h = n - g;
    f = s - j;
    p = (i !== 0);
    o = (h !== 0);
    m = (f !== 0);
    if (p && o && m) {
        for (r = 0; r < 2; r += 1) {
            for (q = 0; q < 2; q += 1) {
                if (((r === 1) && (d === (this.xDim - 1))) || ((q === 1) && (g === (this.yDim - 1)))) {
                    e = -1
                } else {
                    e = this.orientation.convertIndexToOffset(d + r, g + q, j)
                }
                if (e !== -1) {
                    b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - f);
                    if (j === (this.zDim - 1)) {
                        a = 0
                    } else {
                        e = this.orientation.convertIndexToOffset(d + r, g + q, j + 1);
                        a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * f
                    }
                    this.interpFirstPass[r][q] = b + a
                } else {
                    this.interpFirstPass[r][q] = 0
                }
            }
        }
        this.interpSecondPass[0] = (this.interpFirstPass[0][0] * (1 - h)) + (this.interpFirstPass[0][1] * h);
        this.interpSecondPass[1] = (this.interpFirstPass[1][0] * (1 - h)) + (this.interpFirstPass[1][1] * h);
        l = (this.interpSecondPass[0] * (1 - i)) + (this.interpSecondPass[1] * i)
    } else {
        if (p && o && !m) {
            for (r = 0; r < 2; r += 1) {
                if ((r === 1) && (d === (this.xDim - 1))) {
                    e = -1
                } else {
                    e = this.orientation.convertIndexToOffset(d + r, g, j)
                }
                if (e !== -1) {
                    b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - h);
                    if (g === (this.yDim - 1)) {
                        a = 0
                    } else {
                        e = this.orientation.convertIndexToOffset(d + r, g + 1, j);
                        a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * h
                    }
                    this.interpSecondPass[r] = b + a
                } else {
                    this.interpSecondPass[r] = 0
                }
            }
            l = (this.interpSecondPass[0] * (1 - i)) + (this.interpSecondPass[1] * i)
        } else {
            if (p && !o && m) {
                for (r = 0; r < 2; r += 1) {
                    if ((r === 1) && (d === (this.xDim - 1))) {
                        e = -1
                    } else {
                        e = this.orientation.convertIndexToOffset(d + r, g, j)
                    }
                    if (e !== -1) {
                        b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - f);
                        if (j === (this.zDim - 1)) {
                            a = 0
                        } else {
                            e = this.orientation.convertIndexToOffset(d + r, g, j + 1);
                            a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * f
                        }
                        this.interpSecondPass[r] = b + a
                    } else {
                        this.interpSecondPass[r] = 0
                    }
                }
                l = (this.interpSecondPass[0] * (1 - i)) + (this.interpSecondPass[1] * i)
            } else {
                if (!p && o && m) {
                    for (q = 0; q < 2; q += 1) {
                        if ((q === 1) && (g === (this.yDim - 1))) {
                            e = -1
                        } else {
                            e = this.orientation.convertIndexToOffset(d, g + q, j)
                        }
                        if (e !== -1) {
                            b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - f);
                            if (j === (this.zDim - 1)) {
                                a = 0
                            } else {
                                e = this.orientation.convertIndexToOffset(d, g + q, j + 1);
                                a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * f
                            }
                            this.interpSecondPass[q] = b + a
                        } else {
                            this.interpSecondPass[q] = 0
                        }
                    }
                    l = (this.interpSecondPass[0] * (1 - h)) + (this.interpSecondPass[1] * h)
                } else {
                    if (!p && !o && m) {
                        e = this.orientation.convertIndexToOffset(d, g, j);
                        b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - f);
                        if (j === (this.zDim - 1)) {
                            a = 0
                        } else {
                            e = this.orientation.convertIndexToOffset(d, g, j + 1);
                            a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * f
                        }
                        l = b + a
                    } else {
                        if (!p && o && !m) {
                            e = this.orientation.convertIndexToOffset(d, g, j);
                            b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - h);
                            if (g === (this.yDim - 1)) {
                                a = 0
                            } else {
                                e = this.orientation.convertIndexToOffset(d, g + 1, j);
                                a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * h
                            }
                            l = b + a
                        } else {
                            if (p && !o && !m) {
                                e = this.orientation.convertIndexToOffset(d, g, j);
                                b = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * (1 - i);
                                if (d === (this.xDim - 1)) {
                                    a = 0
                                } else {
                                    e = this.orientation.convertIndexToOffset(d + 1, g, j);
                                    a = (((this.getVoxelAtOffset(e, c)) * this.dataScaleSlope) + this.dataScaleIntercept) * i
                                }
                                l = b + a
                            } else {
                                l = (this.getVoxelAtOffset(this.orientation.convertIndexToOffset(k, n, s), c) * this.dataScaleSlope) + this.dataScaleIntercept
                            }
                        }
                    }
                }
            }
        }
    }
    return l
};
papaya.volume.VoxelValue.prototype.checkSwap = function (a) {
    if (this.swap16) {
        return ((((a & 255) << 8) | ((a >> 8) & 255)) << 16) >> 16
    }
    if (this.swap32) {
        return ((a & 255) << 24) | ((a & 65280) << 8) | ((a >> 8) & 65280) | ((a >> 24) & 255)
    }
    return a
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.Header = papaya.volume.Header ||
function () {
    this.fileFormat = null;
    this.imageDimensions = null;
    this.voxelDimensions = null;
    this.imageDescription = null;
    this.imageType = null;
    this.orientation = null;
    this.imageRange = null;
    this.errorMessage = null;
    this.origin = null;
    this.orientationCertainty = papaya.volume.Header.ORIENTATION_CERTAINTY_UNKNOWN
};
papaya.volume.Header.ERROR_UNRECOGNIZED_FORMAT = "This format is not recognized!";
papaya.volume.Header.INVALID_IMAGE_DIMENSIONS = "Image dimensions are not valid!";
papaya.volume.Header.INVALID_VOXEL_DIMENSIONS = "Voxel dimensions are not valid!";
papaya.volume.Header.INVALID_DATATYPE = "Datatype is not valid or not supported!";
papaya.volume.Header.INVALID_IMAGE_RANGE = "Image range is not valid!";
papaya.volume.Header.ORIENTATION_CERTAINTY_UNKNOWN = 0;
papaya.volume.Header.ORIENTATION_CERTAINTY_LOW = 1;
papaya.volume.Header.ORIENTATION_CERTAINTY_HIGH = 2;
papaya.volume.Header.prototype.readData = function (a, c, b) {
    if (a === papaya.volume.Volume.TYPE_NIFTI) {
        this.fileFormat = new papaya.volume.nifti.HeaderNIFTI();
        this.fileFormat.readData(c, b);
        if (this.fileFormat.hasError()) {
            this.errorMessage = this.fileFormat.errorMessage
        }
    } else {
        this.errorMessage = papaya.volume.Header.ERROR_UNRECOGNIZED_FORMAT
    }
    if (!this.hasError()) {
        this.imageDimensions = this.fileFormat.getImageDimensions();
        if (!this.imageDimensions.isValid()) {
            this.errorMessage = papaya.volume.Header.INVALID_IMAGE_DIMENSIONS
        }
        this.voxelDimensions = this.fileFormat.getVoxelDimensions();
        if (!this.voxelDimensions.isValid()) {
            this.errorMessage = papaya.volume.Header.INVALID_VOXEL_DIMENSIONS
        }
        this.imageType = this.fileFormat.getImageType();
        if (!this.imageType.isValid()) {
            this.errorMessage = papaya.volume.Header.INVALID_DATATYPE
        }
        this.orientation = this.fileFormat.getOrientation();
        if (!this.orientation.isValid()) {
            this.orientation = new papaya.volume.Orientation(papaya.volume.Orientation.DEFAULT);
            this.orientationCertainty = papaya.volume.Header.ORIENTATION_CERTAINTY_UNKNOWN
        } else {
            this.orientationCertainty = this.fileFormat.getOrientationCertainty()
        }
        this.orientation.createInfo(this.imageDimensions, this.voxelDimensions);
        this.origin = this.orientation.convertCoordinate(this.fileFormat.getOrigin(), new papaya.core.Coordinate(0, 0, 0));
        this.imageRange = this.fileFormat.getImageRange();
        if (!this.imageRange.isValid()) {
            this.errorMessage = papaya.volume.Header.INVALID_IMAGE_RANGE
        }
        this.imageDescription = this.fileFormat.getImageDescription()
    }
};
papaya.volume.Header.prototype.hasError = function () {
    return (this.errorMessage !== null)
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.ImageDimensions = papaya.volume.ImageDimensions ||
function (c, a, d, b) {
    this.cols = c;
    this.rows = a;
    this.slices = d;
    this.xDim = -1;
    this.yDim = -1;
    this.zDim = -1;
    this.timepoints = b || 1;
    this.offset = 0
};
papaya.volume.ImageDimensions.prototype.getNumVoxelsSeries = function () {
    return this.cols * this.rows * this.slices * this.timepoints
};
papaya.volume.ImageDimensions.prototype.getNumVoxelsSlice = function () {
    return this.rows * this.cols
};
papaya.volume.ImageDimensions.prototype.isValid = function () {
    return ((this.cols > 0) && (this.rows > 0) && (this.slices > 0) && (this.timepoints > 0) && (this.offset >= 0))
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.ImageType = papaya.volume.ImageType ||
function (c, a, d, b) {
    this.datatype = c;
    this.numBytes = a;
    this.littleEndian = d;
    this.swapped = false;
    this.compressed = b
};
papaya.volume.ImageType.DATATYPE_UNKNOWN = 0;
papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED = 1;
papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED = 2;
papaya.volume.ImageType.DATATYPE_FLOAT = 3;
papaya.volume.ImageType.MAX_NUM_BYTES_SUPPORTED = 4;
papaya.volume.ImageType.prototype.isValid = function () {
    return ((this.datatype <= papaya.volume.ImageType.DATATYPE_FLOAT) && (this.datatype > papaya.volume.ImageType.DATATYPE_UNKNOWN) && (this.numBytes > 0) && (this.numBytes <= papaya.volume.ImageType.MAX_NUM_BYTES_SUPPORTED))
};
papaya.volume.ImageType.prototype.getTypeDescription = function () {
    if (this.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED) {
        return "Signed Integer"
    }
    if (this.datatype === papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED) {
        return "Unsigned Integer"
    }
    if (this.datatype === papaya.volume.ImageType.DATATYPE_FLOAT) {
        return "Float"
    }
    return "Unknown"
};
papaya.volume.ImageType.prototype.getOrderDescription = function () {
    if (this.numBytes > 1) {
        if (this.littleEndian) {
            return "Little Endian"
        }
        return "Big Endian"
    }
    return null
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.Transform = papaya.volume.Transform ||
function (a, b) {
    this.voxelValue = new papaya.volume.VoxelValue(b.imageData, b.header.imageType, b.header.imageDimensions, b.header.imageRange, b.header.orientation);
    this.voxelDimensions = b.header.voxelDimensions;
    this.imageDimensions = b.header.imageDimensions;
    this.volume = b;
    this.mat = papaya.volume.Transform.IDENTITY.clone();
    this.indexMat = papaya.volume.Transform.IDENTITY.clone();
    this.sizeMat = papaya.volume.Transform.IDENTITY.clone();
    this.sizeMatInverse = papaya.volume.Transform.IDENTITY.clone();
    this.mmMat = papaya.volume.Transform.IDENTITY.clone();
    this.worldMat = papaya.volume.Transform.IDENTITY.clone();
    this.originMat = papaya.volume.Transform.IDENTITY.clone();
    this.tempMat = papaya.volume.Transform.IDENTITY.clone();
    this.orientMat = papaya.volume.Transform.IDENTITY.clone();
    this.updateTransforms(a)
};
papaya.volume.Transform.IDENTITY = [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1]
];
papaya.volume.Transform.prototype.updateSizeMat = function () {
    this.sizeMat[0][0] = this.voxelDimensions.xSize;
    this.sizeMat[1][1] = this.voxelDimensions.ySize;
    this.sizeMat[2][2] = this.voxelDimensions.zSize;
    this.sizeMat[3][3] = 1;
    this.sizeMatInverse[0][0] = 1 / this.voxelDimensions.xSize;
    this.sizeMatInverse[1][1] = 1 / this.voxelDimensions.ySize;
    this.sizeMatInverse[2][2] = 1 / this.voxelDimensions.zSize;
    this.sizeMatInverse[3][3] = 1
};
papaya.volume.Transform.prototype.updateOrientMat = function () {};
papaya.volume.Transform.prototype.updateIndexTransform = function () {
    var b, a;
    for (b = 0; b < 4; b += 1) {
        for (a = 0; a < 4; a += 1) {
            this.indexMat[b][a] = (this.orientMat[b][0] * this.mat[0][a]) + (this.orientMat[b][1] * this.mat[1][a]) + (this.orientMat[b][2] * this.mat[2][a]) + (this.orientMat[b][3] * this.mat[3][a])
        }
    }
};
papaya.volume.Transform.prototype.updateMmTransform = function () {
    var b, a;
    for (b = 0; b < 4; b += 1) {
        for (a = 0; a < 4; a += 1) {
            this.mmMat[b][a] = (this.indexMat[b][0] * this.sizeMatInverse[0][a]) + (this.indexMat[b][1] * this.sizeMatInverse[1][a]) + (this.indexMat[b][2] * this.sizeMatInverse[2][a]) + (this.indexMat[b][3] * this.sizeMatInverse[3][a])
        }
    }
};
papaya.volume.Transform.prototype.updateOriginMat = function () {
    this.originMat[0][0] = 1;
    this.originMat[1][1] = -1;
    this.originMat[2][2] = -1;
    this.originMat[3][3] = 1;
    this.originMat[0][3] = this.volume.header.origin.x;
    this.originMat[1][3] = this.volume.header.origin.y;
    this.originMat[2][3] = this.volume.header.origin.z
};
papaya.volume.Transform.prototype.updateWorldMat = function () {
    var b, a;
    for (b = 0; b < 4; b += 1) {
        for (a = 0; a < 4; a += 1) {
            this.tempMat[b][a] = (this.indexMat[b][0] * this.originMat[0][a]) + (this.indexMat[b][1] * this.originMat[1][a]) + (this.indexMat[b][2] * this.originMat[2][a]) + (this.indexMat[b][3] * this.originMat[3][a])
        }
    }
    for (b = 0; b < 4; b += 1) {
        for (a = 0; a < 4; a += 1) {
            this.worldMat[b][a] = (this.tempMat[b][0] * this.sizeMatInverse[0][a]) + (this.tempMat[b][1] * this.sizeMatInverse[1][a]) + (this.tempMat[b][2] * this.sizeMatInverse[2][a]) + (this.tempMat[b][3] * this.sizeMatInverse[3][a])
        }
    }
};
papaya.volume.Transform.prototype.updateTransforms = function (a) {
    this.mat = a;
    this.updateSizeMat();
    this.updateOrientMat();
    this.updateOriginMat();
    this.updateIndexTransform();
    this.updateMmTransform();
    this.updateWorldMat()
};
papaya.volume.Transform.prototype.getVoxelAtIndex = function (d, c, b, a, e) {
    return this.voxelValue.getVoxelAtIndex(d, c, b, a, e)
};
papaya.volume.Transform.prototype.getVoxelAtCoordinate = function (h, f, d, e, g) {
    var c, b, a;
    c = ((h * this.worldMat[0][0]) + (f * this.worldMat[0][1]) + (d * this.worldMat[0][2]) + (this.worldMat[0][3]));
    b = ((h * this.worldMat[1][0]) + (f * this.worldMat[1][1]) + (d * this.worldMat[1][2]) + (this.worldMat[1][3]));
    a = ((h * this.worldMat[2][0]) + (f * this.worldMat[2][1]) + (d * this.worldMat[2][2]) + (this.worldMat[2][3]));
    if ((c < 0) || (c >= this.imageDimensions.xDim) || (b < 0) || (b >= this.imageDimensions.yDim) || (a < 0) || (a >= this.imageDimensions.zDim)) {
        return 0
    }
    return this.voxelValue.getVoxelAtIndex(c, b, a, e, g)
};
papaya.volume.Transform.prototype.getVoxelAtMM = function (h, f, d, e, g) {
    var c, b, a;
    c = ((h * this.mmMat[0][0]) + (f * this.mmMat[0][1]) + (d * this.mmMat[0][2]) + (this.mmMat[0][3]));
    b = ((h * this.mmMat[1][0]) + (f * this.mmMat[1][1]) + (d * this.mmMat[1][2]) + (this.mmMat[1][3]));
    a = ((h * this.mmMat[2][0]) + (f * this.mmMat[2][1]) + (d * this.mmMat[2][2]) + (this.mmMat[2][3]));
    if ((c < 0) || (c >= this.imageDimensions.xDim) || (b < 0) || (b >= this.imageDimensions.yDim) || (a < 0) || (a >= this.imageDimensions.zDim)) {
        return 0
    }
    return this.voxelValue.getVoxelAtIndex(c, b, a, e, g)
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.Volume = papaya.volume.Volume ||
function (a) {
    this.progressMeter = a;
    this.file = null;
    this.fileLength = 0;
    this.url = null;
    this.fileName = null;
    this.compressed = false;
    this.headerType = papaya.volume.Volume.TYPE_UNKNOWN;
    this.header = new papaya.volume.Header();
    this.imageData = new papaya.volume.ImageData();
    this.rawData = null;
    this.onFinishedRead = null;
    this.errorMessage = null;
    this.transform = null;
    this.isLoaded = false;
    this.numTimepoints = 1;
    this.loaded = false
};
papaya.volume.Volume.TYPE_UNKNOWN = 0;
papaya.volume.Volume.TYPE_NIFTI = 1;
papaya.volume.Volume.prototype.findFileType = function (a) {
    if (a.indexOf(".nii") !== -1) {
        return papaya.volume.Volume.TYPE_NIFTI
    }
    return papaya.volume.Volume.TYPE_UNKNOWN
};
papaya.volume.Volume.prototype.findFileTypeByMagicNumber = function (e) {
    var d, c, b, a;
    d = new DataView(e);
    c = d.getUint8(papaya.volume.nifti.MAGIC_NUMBER_LOCATION);
    b = d.getUint8(papaya.volume.nifti.MAGIC_NUMBER_LOCATION + 1);
    a = d.getUint8(papaya.volume.nifti.MAGIC_NUMBER_LOCATION + 2);
    if ((c === papaya.volume.nifti.MAGIC_NUMBER[0]) && (b === papaya.volume.nifti.MAGIC_NUMBER[1]) && (a === papaya.volume.nifti.MAGIC_NUMBER[2])) {
        return papaya.volume.Volume.TYPE_NIFTI
    }
    return papaya.volume.Volume.TYPE_UNKNOWN
};
papaya.volume.Volume.prototype.fileIsCompressed = function (b, e) {
    var d, c, a;
    if (b.indexOf(".gz") !== -1) {
        return true
    }
    if (e) {
        d = new DataView(e);
        c = d.getUint8(0);
        a = d.getUint8(1);
        if (c === GUNZIP_MAGIC_COOKIE1) {
            return true
        }
        if (a === GUNZIP_MAGIC_COOKIE2) {
            return true
        }
    }
    return false
};
papaya.volume.Volume.prototype.readFile = function (b, c) {
    this.file = b;
    this.fileName = b.name;
    this.onFinishedRead = c;
    this.headerType = this.findFileType(this.fileName);
    if (this.headerType === papaya.volume.Volume.TYPE_UNKNOWN) {
        this.errorMessage = "File type is not recognized!";
        this.finishedLoad()
    } else {
        this.compressed = this.fileIsCompressed(this.fileName);
        this.fileLength = this.file.size;
        var a = makeSlice(this.file, 0, this.file.size);
        this.readData(this, a)
    }
};
papaya.volume.Volume.prototype.readURL = function (b, f) {
    var c = null,
        a, e;
    try {
        this.url = b;
        this.fileName = b.substr(b.lastIndexOf("/") + 1, b.length);
        this.onFinishedRead = f;
        this.headerType = this.findFileType(this.fileName);
        this.compressed = this.fileIsCompressed(this.fileName);
        c = this;
        a = typeof new XMLHttpRequest().responseType === "string";
        if (a) {
            e = new XMLHttpRequest();
            e.open("GET", b, true);
            e.responseType = "arraybuffer";
            e.onreadystatechange = function () {
                if (e.readyState === 4) {
                    if (e.status === 200) {
                        c.rawData = e.response;
                        c.fileLength = c.rawData.byteLength;
                        c.decompress(c)
                    } else {
                        c.errorMessage = "There was a problem reading that file (" + c.fileName + "):\n\nResponse status = " + e.status;
                        c.finishedLoad()
                    }
                }
            };
            e.send(null)
        } else {
            c.errorMessage = "There was a problem reading that file (" + c.fileName + "):\n\nResponse type is not supported.";
            c.finishedLoad()
        }
    } catch (d) {
        if (c !== null) {
            c.errorMessage = "There was a problem reading that file (" + c.fileName + "):\n\n" + d.message;
            c.finishedLoad()
        }
    }
};
papaya.volume.Volume.prototype.readEncodedData = function (a, d) {
    var b = null;
    try {
        this.fileName = a;
        this.onFinishedRead = d;
        b = this;
        b.rawData = Base64Binary.decodeArrayBuffer(deref(a));
        this.headerType = this.findFileType(this.fileName);
        this.compressed = this.fileIsCompressed(this.fileName, b.rawData);
        this.fileLength = b.rawData.byteLength;
        b.decompress(b)
    } catch (c) {
        if (b) {
            b.errorMessage = "There was a problem reading that file:\n\n" + c.message;
            b.finishedLoad()
        }
    }
};
papaya.volume.Volume.prototype.getVoxelAtIndex = function (d, c, b, a, e) {
    return this.transform.getVoxelAtIndex(d, c, b, a, e)
};
papaya.volume.Volume.prototype.getVoxelAtCoordinate = function (e, c, a, b, d) {
    return this.transform.getVoxelAtCoordinate(e, c, a, b, d)
};
papaya.volume.Volume.prototype.getVoxelAtMM = function (e, c, a, b, d) {
    return this.transform.getVoxelAtMM(e, c, a, b, d)
};
papaya.volume.Volume.prototype.hasError = function () {
    return (this.errorMessage !== null)
};
papaya.volume.Volume.prototype.getXDim = function () {
    return this.header.imageDimensions.xDim
};
papaya.volume.Volume.prototype.getYDim = function () {
    return this.header.imageDimensions.yDim
};
papaya.volume.Volume.prototype.getZDim = function () {
    return this.header.imageDimensions.zDim
};
papaya.volume.Volume.prototype.getXSize = function () {
    return this.header.voxelDimensions.xSize
};
papaya.volume.Volume.prototype.getYSize = function () {
    return this.header.voxelDimensions.ySize
};
papaya.volume.Volume.prototype.getZSize = function () {
    return this.header.voxelDimensions.zSize
};
papaya.volume.Volume.prototype.readData = function (c, b) {
    try {
        var a = new FileReader();
        a.onloadend = bind(c, function (e) {
            if (e.target.readyState === FileReader.DONE) {
                c.rawData = e.target.result;
                setTimeout(function () {
                    c.decompress(c)
                }, 0)
            }
        });
        a.onerror = bind(c, function (e) {
            c.errorMessage = "There was a problem reading that file:\n\n" + e.getMessage();
            c.finishedLoad()
        });
        a.readAsArrayBuffer(b)
    } catch (d) {
        c.errorMessage = "There was a problem reading that file:\n\n" + d.message;
        c.finishedLoad()
    }
};
papaya.volume.Volume.prototype.decompress = function (b) {
    if (b.compressed) {
        var a = new Gunzip(this.progressMeter);
        a.gunzip(b.rawData, function (c) {
            b.finishedDecompress(b, c)
        });
        if (a.hasError()) {
            b.errorMessage = a.getError();
            b.finishedLoad()
        }
    } else {
        setTimeout(function () {
            b.finishedReadData(b)
        }, 0)
    }
};
papaya.volume.Volume.prototype.finishedDecompress = function (a, b) {
    a.rawData = b;
    if (this.headerType === papaya.volume.Volume.TYPE_UNKNOWN) {
        this.headerType = this.findFileTypeByMagicNumber(a.rawData)
    }
    setTimeout(function () {
        a.finishedReadData(a)
    }, 0)
};
papaya.volume.Volume.prototype.finishedReadData = function (a) {
    a.header.readData(a.headerType, a.rawData, this.compressed);
    a.header.imageType.swapped = (a.header.imageType.littleEndian !== isPlatformLittleEndian());
    if (a.header.hasError()) {
        a.errorMessage = a.header.errorMessage;
        a.onFinishedRead(a);
        return
    }
    a.imageData.readData(a.header, a.rawData, bind(a, a.finishedLoad))
};
papaya.volume.Volume.prototype.finishedLoad = function () {
    if (!this.loaded) {
        this.loaded = true;
        if (this.onFinishedRead) {
            if (!this.hasError()) {
                this.transform = new papaya.volume.Transform(papaya.volume.Transform.IDENTITY.clone(), this);
                this.numTimepoints = this.header.imageDimensions.timepoints || 1
            }
            this.isLoaded = true;
            this.rawData = null;
            this.onFinishedRead(this)
        }
    }
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.nifti = papaya.volume.nifti || {};
papaya.volume.nifti.HeaderNIFTI = papaya.volume.nifti.HeaderNIFTI ||
function () {
    this.nifti = null;
    this.compressed = false
};
papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT = "XYZ-++";
papaya.volume.nifti.HeaderNIFTI.prototype.readData = function (b, a) {
    this.nifti = new papaya.volume.nifti.NIFTI();
    this.compressed = a;
    this.nifti.readData(b)
};
papaya.volume.nifti.HeaderNIFTI.prototype.getImageDimensions = function () {
    var a = new papaya.volume.ImageDimensions(this.nifti.dims[1], this.nifti.dims[2], this.nifti.dims[3], this.nifti.dims[4]);
    a.offset = this.nifti.vox_offset;
    return a
};
papaya.volume.nifti.HeaderNIFTI.prototype.getVoxelDimensions = function () {
    return new papaya.volume.VoxelDimensions(this.nifti.pixDims[1], this.nifti.pixDims[2], this.nifti.pixDims[3], this.nifti.pixDims[4])
};
papaya.volume.nifti.HeaderNIFTI.prototype.getImageType = function () {
    var a = papaya.volume.ImageType.DATATYPE_UNKNOWN;
    if ((this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_UINT8) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_UINT16) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_UINT32) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_UINT64)) {
        a = papaya.volume.ImageType.DATATYPE_INTEGER_UNSIGNED
    } else {
        if ((this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_INT8) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_INT16) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_INT32) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_INT64)) {
            a = papaya.volume.ImageType.DATATYPE_INTEGER_SIGNED
        } else {
            if ((this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_FLOAT32) || (this.nifti.datatypeCode === papaya.volume.nifti.NIFTI_TYPE_FLOAT64)) {
                a = papaya.volume.ImageType.DATATYPE_FLOAT
            }
        }
    }
    return new papaya.volume.ImageType(a, this.nifti.numBitsPerVoxel / 8, this.nifti.littleEndian, this.compressed)
};
papaya.volume.nifti.HeaderNIFTI.prototype.getOrientation = function () {
    var a = null;
    if (this.nifti.qform_code > 0) {
        a = this.getOrientationQform()
    }
    if (this.nifti.sform_code > this.nifti.qform_code) {
        a = this.getOrientationSform()
    }
    if (a === null) {
        a = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
    }
    return new papaya.volume.Orientation(a)
};
papaya.volume.nifti.HeaderNIFTI.prototype.getOrientationQform = function () {
    var a = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT,
        b = this.nifti.convertNiftiQFormToNiftiSForm(this.nifti.quatern_b, this.nifti.quatern_c, this.nifti.quatern_d, this.nifti.qoffset_x, this.nifti.qoffset_y, this.nifti.qoffset_z, this.nifti.pixDims[1], this.nifti.pixDims[2], this.nifti.pixDims[3], this.nifti.pixDims[0]);
    if (this.nifti.qform_code > 0) {
        a = this.nifti.convertNiftiSFormToNEMA(b);
        if (!papaya.volume.Orientation.prototype.isValidOrientationString(a)) {
            a = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
        }
    } else {
        a = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
    }
    return a
};
papaya.volume.nifti.HeaderNIFTI.prototype.getOrientationSform = function () {
    var a = this.nifti.convertNiftiSFormToNEMA(this.nifti.affine);
    if (!papaya.volume.Orientation.prototype.isValidOrientationString(a)) {
        a = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
    }
    return a
};
papaya.volume.nifti.HeaderNIFTI.prototype.getOrigin = function () {
    var d = new papaya.core.Coordinate(0, 0, 0),
        f, c, e, g, b, a;
    if (this.nifti.qform_code > 0) {
        f = this.nifti.convertNiftiQFormToNiftiSForm(this.nifti.quatern_b, this.nifti.quatern_c, this.nifti.quatern_d, this.nifti.qoffset_x, this.nifti.qoffset_y, this.nifti.qoffset_z, this.nifti.pixDims[1], this.nifti.pixDims[2], this.nifti.pixDims[3], this.nifti.pixDims[0]);
        c = this.nifti.convertNiftiSFormToNEMA(f);
        if (!papaya.volume.Orientation.prototype.isValidOrientationString(c)) {
            c = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
        }
        e = this.nifti.qoffset_x * ((c.charAt(c.indexOf("X") + 3) === "+") ? -1 : 1);
        g = this.nifti.qoffset_y * ((c.charAt(c.indexOf("Y") + 3) === "+") ? 1 : -1);
        b = this.nifti.qoffset_z * ((c.charAt(c.indexOf("Z") + 3) === "+") ? 1 : -1);
        a = new Array(3);
        a[0] = e < 0 ? (this.nifti.dims[1] + (e / this.nifti.pixDims[1])) : (e / Math.abs(this.nifti.pixDims[1]));
        a[1] = g > 0 ? (this.nifti.dims[2] - (g / this.nifti.pixDims[2])) : (g / Math.abs(this.nifti.pixDims[2])) * -1;
        a[2] = b > 0 ? (this.nifti.dims[3] - (b / this.nifti.pixDims[3])) : (b / Math.abs(this.nifti.pixDims[3])) * -1;
        d.setCoordinate(a[0], a[1], a[2], true)
    } else {
        if (this.nifti.sform_code > 0) {
            c = this.nifti.convertNiftiSFormToNEMA(this.nifti.affine);
            if (!papaya.volume.Orientation.prototype.isValidOrientationString(c)) {
                c = papaya.volume.nifti.HeaderNIFTI.ORIENTATION_DEFAULT
            }
            e = this.nifti.affine[0][3] * ((c.charAt(c.indexOf("X") + 3) === "+") ? -1 : 1);
            g = this.nifti.affine[1][3] * ((c.charAt(c.indexOf("Y") + 3) === "+") ? 1 : -1);
            b = this.nifti.affine[2][3] * ((c.charAt(c.indexOf("Z") + 3) === "+") ? 1 : -1);
            a = new Array(3);
            a[0] = e < 0 ? (this.nifti.dims[1] + (e / this.nifti.pixDims[1])) : (e / Math.abs(this.nifti.pixDims[1]));
            a[1] = g > 0 ? (this.nifti.dims[2] - (g / this.nifti.pixDims[2])) : (g / Math.abs(this.nifti.pixDims[2])) * -1;
            a[2] = b > 0 ? (this.nifti.dims[3] - (b / this.nifti.pixDims[3])) : (b / Math.abs(this.nifti.pixDims[3])) * -1;
            d.setCoordinate(a[0], a[1], a[2], true)
        }
    }
    if (d.isAllZeros()) {
        d.setCoordinate(this.nifti.dims[1] / 2, this.nifti.dims[2] / 2, this.nifti.dims[3] / 2)
    }
    return d
};
papaya.volume.nifti.HeaderNIFTI.prototype.getImageRange = function () {
    var b = new papaya.volume.ImageRange(this.nifti.cal_min, this.nifti.cal_max),
        a = this.nifti.scl_slope;
    if (a === 0) {
        a = 1
    }
    b.setGlobalDataScale(a, this.nifti.scl_inter);
    return b
};
papaya.volume.nifti.HeaderNIFTI.prototype.hasError = function () {
    return this.nifti.hasError()
};
papaya.volume.nifti.HeaderNIFTI.prototype.getImageDescription = function () {
    return new papaya.volume.ImageDescription(this.nifti.description)
};
papaya.volume.nifti.HeaderNIFTI.prototype.getOrientationCertainty = function () {
    var b, a;
    b = papaya.volume.Header.ORIENTATION_CERTAINTY_UNKNOWN;
    if ((this.nifti.qform_code > 0) || (this.nifti.sform_code > 0)) {
        b = papaya.volume.Header.ORIENTATION_CERTAINTY_LOW;
        a = this.getOrigin();
        if ((a !== null) && !a.isAllZeros()) {
            b = papaya.volume.Header.ORIENTATION_CERTAINTY_HIGH
        }
    }
    return b
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.volume.nifti = papaya.volume.nifti || {};
papaya.volume.nifti.NIFTI = papaya.volume.nifti.NIFTI ||
function () {
    this.errorMessage = null;
    this.littleEndian = false;
    this.dim_info = 0;
    this.dims = [];
    this.intent_p1 = 0;
    this.intent_p2 = 0;
    this.intent_p3 = 0;
    this.intent_code = 0;
    this.datatypeCode = 0;
    this.numBitsPerVoxel = 0;
    this.slice_start = 0;
    this.slice_end = 0;
    this.slice_code = 0;
    this.pixDims = [];
    this.vox_offset = 0;
    this.scl_slope = 1;
    this.scl_inter = 0;
    this.xyzt_units = 0;
    this.cal_max = 0;
    this.cal_min = 0;
    this.slice_duration = 0;
    this.toffset = 0;
    this.description = "";
    this.aux_file = "";
    this.intent_name = "";
    this.qform_code = 0;
    this.sform_code = 0;
    this.quatern_b = 0;
    this.quatern_c = 0;
    this.quatern_d = 0;
    this.qoffset_x = 0;
    this.qoffset_y = 0;
    this.qoffset_z = 0;
    this.affine = [
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1]
    ];
    this.magic = 0
};
papaya.volume.nifti.MAGIC_COOKIE = 348;
papaya.volume.nifti.NII_HDR_SIZE = 352;
papaya.volume.nifti.DT_NONE = 0;
papaya.volume.nifti.DT_BINARY = 1;
papaya.volume.nifti.NIFTI_TYPE_UINT8 = 2;
papaya.volume.nifti.NIFTI_TYPE_INT16 = 4;
papaya.volume.nifti.NIFTI_TYPE_INT32 = 8;
papaya.volume.nifti.NIFTI_TYPE_FLOAT32 = 16;
papaya.volume.nifti.NIFTI_TYPE_COMPLEX64 = 32;
papaya.volume.nifti.NIFTI_TYPE_FLOAT64 = 64;
papaya.volume.nifti.NIFTI_TYPE_RGB24 = 128;
papaya.volume.nifti.DT_ALL = 255;
papaya.volume.nifti.NIFTI_TYPE_INT8 = 256;
papaya.volume.nifti.NIFTI_TYPE_UINT16 = 512;
papaya.volume.nifti.NIFTI_TYPE_UINT32 = 768;
papaya.volume.nifti.NIFTI_TYPE_INT64 = 1024;
papaya.volume.nifti.NIFTI_TYPE_UINT64 = 1280;
papaya.volume.nifti.NIFTI_TYPE_FLOAT128 = 1536;
papaya.volume.nifti.NIFTI_TYPE_COMPLEX128 = 1792;
papaya.volume.nifti.NIFTI_TYPE_COMPLEX256 = 2048;
papaya.volume.nifti.MAGIC_NUMBER_LOCATION = 344;
papaya.volume.nifti.MAGIC_NUMBER = [110, 43, 49];
papaya.volume.nifti.NIFTI.prototype.readData = function (f) {
    var g = new DataView(f),
        d = this.getIntAt(g, 0, this.littleEndian),
        e, c, a, b;
    if (d !== papaya.volume.nifti.MAGIC_COOKIE) {
        this.littleEndian = true;
        d = this.getIntAt(g, 0, this.littleEndian)
    }
    if (d !== papaya.volume.nifti.MAGIC_COOKIE) {
        this.errorMessage = "This does not appear to be a NIFTI file!";
        return
    }
    this.dim_info = this.getByteAt(g, 39);
    for (e = 0; e < 8; e += 1) {
        b = 40 + (e * 2);
        this.dims[e] = this.getShortAt(g, b, this.littleEndian)
    }
    this.intent_p1 = this.getFloatAt(g, 56, this.littleEndian);
    this.intent_p2 = this.getFloatAt(g, 60, this.littleEndian);
    this.intent_p3 = this.getFloatAt(g, 64, this.littleEndian);
    this.intent_code = this.getFloatAt(g, 68, this.littleEndian);
    this.datatypeCode = this.getShortAt(g, 70, this.littleEndian);
    this.numBitsPerVoxel = this.getShortAt(g, 72, this.littleEndian);
    this.slice_start = this.getShortAt(g, 74, this.littleEndian);
    for (e = 0; e < 8; e += 1) {
        b = 76 + (e * 4);
        this.pixDims[e] = this.getFloatAt(g, b, this.littleEndian)
    }
    this.vox_offset = this.getFloatAt(g, 108, this.littleEndian);
    this.scl_slope = this.getFloatAt(g, 112, this.littleEndian);
    this.scl_inter = this.getFloatAt(g, 116, this.littleEndian);
    this.slice_end = this.getShortAt(g, 120, this.littleEndian);
    this.slice_code = this.getByteAt(g, 122);
    this.xyzt_units = this.getByteAt(g, 123);
    this.cal_max = this.getFloatAt(g, 124, this.littleEndian);
    this.cal_min = this.getFloatAt(g, 128, this.littleEndian);
    this.slice_duration = this.getFloatAt(g, 132, this.littleEndian);
    this.toffset = this.getFloatAt(g, 136, this.littleEndian);
    this.description = this.getStringAt(g, 148, 228);
    this.qform_code = this.getShortAt(g, 252, this.littleEndian);
    this.sform_code = this.getShortAt(g, 254, this.littleEndian);
    this.quatern_b = this.getFloatAt(g, 256, this.littleEndian);
    this.quatern_c = this.getFloatAt(g, 260, this.littleEndian);
    this.quatern_d = this.getFloatAt(g, 264, this.littleEndian);
    this.qoffset_x = this.getFloatAt(g, 268, this.littleEndian);
    this.qoffset_y = this.getFloatAt(g, 272, this.littleEndian);
    this.qoffset_z = this.getFloatAt(g, 276, this.littleEndian);
    for (c = 0; c < 3; c += 1) {
        for (a = 0; a < 4; a += 1) {
            b = 280 + (((c * 4) + a) * 4);
            this.affine[c][a] = this.getFloatAt(g, b, this.littleEndian)
        }
    }
    this.affine[3][0] = 0;
    this.affine[3][1] = 0;
    this.affine[3][2] = 0;
    this.affine[3][3] = 1;
    this.intent_name = this.getStringAt(g, 328, 344);
    this.magic = this.getStringAt(g, 344, 348)
};
papaya.volume.nifti.NIFTI.prototype.convertNiftiQFormToNiftiSForm = function (j, i, h, v, s, q, n, m, l, f) {
    var g = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
    ],
        w, u = j,
        r = i,
        p = h,
        o, e, k;
    g[3][0] = g[3][1] = g[3][2] = 0;
    g[3][3] = 1;
    w = 1 - (u * u + r * r + p * p);
    if (w < 1e-7) {
        w = 1 / Math.sqrt(u * u + r * r + p * p);
        u *= w;
        r *= w;
        p *= w;
        w = 0
    } else {
        w = Math.sqrt(w)
    }
    o = (n > 0) ? n : 1;
    e = (m > 0) ? m : 1;
    k = (l > 0) ? l : 1;
    if (f < 0) {
        k = -k
    }
    g[0][0] = (w * w + u * u - r * r - p * p) * o;
    g[0][1] = 2 * (u * r - w * p) * e;
    g[0][2] = 2 * (u * p + w * r) * k;
    g[1][0] = 2 * (u * r + w * p) * o;
    g[1][1] = (w * w + r * r - u * u - p * p) * e;
    g[1][2] = 2 * (r * p - w * u) * k;
    g[2][0] = 2 * (u * p - w * r) * o;
    g[2][1] = 2 * (r * p + w * u) * e;
    g[2][2] = (w * w + p * p - r * r - u * u) * k;
    g[0][3] = v;
    g[1][3] = s;
    g[2][3] = q;
    return g
};
papaya.volume.nifti.NIFTI.prototype.convertNiftiSFormToNEMA = function (g) {
    var C, B, z, S, L, J, n, l, f, U, v, x, G, F, E, D, A, y, K, w, c, e, H, s, o, O, h, m, I, u, b, N, a, d;
    E = 0;
    h = [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0]
    ];
    m = [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0]
    ];
    C = g[0][0];
    B = g[0][1];
    z = g[0][2];
    S = g[1][0];
    L = g[1][1];
    J = g[1][2];
    n = g[2][0];
    l = g[2][1];
    f = g[2][2];
    U = Math.sqrt(C * C + S * S + n * n);
    if (U === 0) {
        return null
    }
    C /= U;
    S /= U;
    n /= U;
    U = Math.sqrt(B * B + L * L + l * l);
    if (U === 0) {
        return null
    }
    B /= U;
    L /= U;
    l /= U;
    U = C * B + S * L + n * l;
    if (Math.abs(U) > 0.0001) {
        B -= U * C;
        L -= U * S;
        l -= U * n;
        U = Math.sqrt(B * B + L * L + l * l);
        if (U === 0) {
            return null
        }
        B /= U;
        L /= U;
        l /= U
    }
    U = Math.sqrt(z * z + J * J + f * f);
    if (U === 0) {
        z = S * l - n * L;
        J = n * B - l * C;
        f = C * L - S * B
    } else {
        z /= U;
        J /= U;
        f /= U
    }
    U = C * z + S * J + n * f;
    if (Math.abs(U) > 0.0001) {
        z -= U * C;
        J -= U * S;
        f -= U * n;
        U = Math.sqrt(z * z + J * J + f * f);
        if (U === 0) {
            return null
        }
        z /= U;
        J /= U;
        f /= U
    }
    U = B * z + L * J + l * f;
    if (Math.abs(U) > 0.0001) {
        z -= U * B;
        J -= U * L;
        f -= U * l;
        U = Math.sqrt(z * z + J * J + f * f);
        if (U === 0) {
            return null
        }
        z /= U;
        J /= U;
        f /= U
    }
    h[0][0] = C;
    h[0][1] = B;
    h[0][2] = z;
    h[1][0] = S;
    h[1][1] = L;
    h[1][2] = J;
    h[2][0] = n;
    h[2][1] = l;
    h[2][2] = f;
    v = this.nifti_mat33_determ(h);
    if (v === 0) {
        return null
    }
    O = -666;
    K = e = H = s = 1;
    w = 2;
    c = 3;
    for (G = 1; G <= 3; G += 1) {
        for (F = 1; F <= 3; F += 1) {
            if (!(G === F)) {
                for (E = 1; E <= 3; E += 1) {
                    if (!(G === E || F === E)) {
                        m[0][0] = m[0][1] = m[0][2] = m[1][0] = m[1][1] = m[1][2] = m[2][0] = m[2][1] = m[2][2] = 0;
                        for (D = -1; D <= 1; D += 2) {
                            for (A = -1; A <= 1; A += 2) {
                                for (y = -1; y <= 1; y += 2) {
                                    m[0][G - 1] = D;
                                    m[1][F - 1] = A;
                                    m[2][E - 1] = y;
                                    x = this.nifti_mat33_determ(m);
                                    if (!(x * v <= 0)) {
                                        o = this.nifti_mat33_mul(m, h);
                                        U = o[0][0] + o[1][1] + o[2][2];
                                        if (U > O) {
                                            O = U;
                                            K = G;
                                            w = F;
                                            c = E;
                                            e = D;
                                            H = A;
                                            s = y
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    I = u = b = N = a = d = 0;
    switch (K * e) {
    case 1:
        I = "X";
        N = "+";
        break;
    case -1:
        I = "X";
        N = "-";
        break;
    case 2:
        I = "Y";
        N = "+";
        break;
    case -2:
        I = "Y";
        N = "-";
        break;
    case 3:
        I = "Z";
        N = "+";
        break;
    case -3:
        I = "Z";
        N = "-";
        break
    }
    switch (w * H) {
    case 1:
        u = "X";
        a = "+";
        break;
    case -1:
        u = "X";
        a = "-";
        break;
    case 2:
        u = "Y";
        a = "+";
        break;
    case -2:
        u = "Y";
        a = "-";
        break;
    case 3:
        u = "Z";
        a = "+";
        break;
    case -3:
        u = "Z";
        a = "-";
        break
    }
    switch (c * s) {
    case 1:
        b = "X";
        d = "+";
        break;
    case -1:
        b = "X";
        d = "-";
        break;
    case 2:
        b = "Y";
        d = "+";
        break;
    case -2:
        b = "Y";
        d = "-";
        break;
    case 3:
        b = "Z";
        d = "+";
        break;
    case -3:
        b = "Z";
        d = "-";
        break
    }
    return (I + u + b + N + a + d)
};
papaya.volume.nifti.NIFTI.prototype.nifti_mat33_mul = function (a, e) {
    var d = [
        [0, 0, 0],
        [0, 0, 0],
        [0, 0, 0]
    ],
        c, b;
    for (c = 0; c < 3; c += 1) {
        for (b = 0; b < 3; b += 1) {
            d[c][b] = a[c][0] * e[0][b] + a[c][1] * e[1][b] + a[c][2] * e[2][b]
        }
    }
    return d
};
papaya.volume.nifti.NIFTI.prototype.nifti_mat33_determ = function (d) {
    var g, f, e, c, b, a, j, i, h;
    g = d[0][0];
    f = d[0][1];
    e = d[0][2];
    c = d[1][0];
    b = d[1][1];
    a = d[1][2];
    j = d[2][0];
    i = d[2][1];
    h = d[2][2];
    return (g * b * h - g * i * a - c * f * h + c * i * e + j * f * a - j * b * e)
};
papaya.volume.nifti.NIFTI.prototype.getStringAt = function (d, f, a) {
    var e = "",
        c, b;
    for (c = f; c < a; c += 1) {
        b = d.getUint8(c);
        if (b !== 0) {
            e += String.fromCharCode(b)
        }
    }
    return e
};
papaya.volume.nifti.NIFTI.prototype.getByteAt = function (a, b) {
    return a.getInt8(b)
};
papaya.volume.nifti.NIFTI.prototype.getShortAt = function (a, c, b) {
    return a.getInt16(c, b)
};
papaya.volume.nifti.NIFTI.prototype.getIntAt = function (a, c, b) {
    return a.getInt32(c, b)
};
papaya.volume.nifti.NIFTI.prototype.getFloatAt = function (a, c, b) {
    return a.getFloat32(c, b)
};
papaya.volume.nifti.NIFTI.prototype.hasError = function () {
    return (this.errorMessage !== null)
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
papaya.viewer.Atlas = papaya.viewer.Atlas ||
function (c, b, d) {
    this.container = b;
    this.callback = d;
    this.name = null;
    this.transformedname = null;
    this.labels = [];
    this.atlasLabelData = c.labels;
    this.volume = new papaya.volume.Volume(b.display);
    this.displayColumns = null;
    this.returnLabels = null;
    this.transform = null;
    this.currentAtlas = null;
    this.maxLabels = 0;
    this.probabilistic = false;
    var a = b.findLoadableImage(c.labels.atlas.header.images.summaryimagefile);
    if ((a !== null) && (a.encode !== undefined)) {
        this.volume.readEncodedData(a.encode, bind(this, this.readFinished))
    } else {
        if ((a !== null) && (a.url !== undefined)) {
            this.volume.readURL(a.url, bind(this, this.readFinished))
        }
    }
};
papaya.viewer.Atlas.MAX_LABELS = 4;
papaya.viewer.Atlas.PROBABILISTIC = ["probabalistic", "probabilistic", "statistic"];
papaya.viewer.Atlas.LABEL_SPLIT_REGEX = /\.|:|,|\//;
papaya.viewer.Atlas.prototype.getLabelAtCoordinate = function (f, e, d) {
    var c, b, a, g;
    if (this.transform && (this.currentAtlas === this.transformedname)) {
        c = ((f * this.transform[0][0]) + (e * this.transform[0][1]) + (d * this.transform[0][2]) + (this.transform[0][3]));
        b = ((f * this.transform[1][0]) + (e * this.transform[1][1]) + (d * this.transform[1][2]) + (this.transform[1][3]));
        a = ((f * this.transform[2][0]) + (e * this.transform[2][1]) + (d * this.transform[2][2]) + (this.transform[2][3]))
    } else {
        c = f;
        b = e;
        a = d
    }
    g = (this.volume.getVoxelAtCoordinate(c, b, a, 0, true));
    if (this.probabilistic) {
        g -= 1
    }
    return this.formatLabels(this.labels[g], this.returnLabels)
};
papaya.viewer.Atlas.prototype.readFinished = function () {
    this.parseTransform();
    this.parseLabels();
    this.parseDisplayColumns();
    this.maxLabels = this.findMaxLabelParts();
    this.probabilistic = this.atlasLabelData.atlas.header.type && ((this.atlasLabelData.atlas.header.type.toLowerCase() === papaya.viewer.Atlas.PROBABILISTIC[0]) || (this.atlasLabelData.atlas.header.type.toLowerCase() === papaya.viewer.Atlas.PROBABILISTIC[1]) || (this.atlasLabelData.atlas.header.type.toLowerCase() === papaya.viewer.Atlas.PROBABILISTIC[2]));
    this.returnLabels = [];
    this.returnLabels.length = this.maxLabels;
    if (this.atlasLabelData.atlas.header.transformedname) {
        this.transformedname = this.atlasLabelData.atlas.header.transformedname
    }
    this.name = this.atlasLabelData.atlas.header.name;
    this.currentAtlas = this.name;
    var a = this.container.params.atlas;
    if (a) {
        if (a === this.transformedname) {
            this.currentAtlas = this.transformedname
        }
    }
    this.callback()
};
papaya.viewer.Atlas.prototype.parseDisplayColumns = function () {
    var a, b, c;
    if (this.atlasLabelData.atlas.header.display) {
        this.displayColumns = [];
        a = 0;
        b = this.atlasLabelData.atlas.header.display.split(papaya.viewer.Atlas.LABEL_SPLIT_REGEX);
        for (c = 0; c < b.length; c += 1) {
            if (b[c] === "*") {
                this.displayColumns[a] = c;
                a += 1
            }
        }
    }
};
papaya.viewer.Atlas.prototype.parseTransform = function () {
    var c, b, a;
    if (this.atlasLabelData.atlas.header.transform) {
        c = this.atlasLabelData.atlas.header.transform.split(" ");
        this.transform = papaya.volume.Transform.IDENTITY.clone();
        if (c.length === 16) {
            for (b = 0; b < 4; b += 1) {
                for (a = 0; a < 4; a += 1) {
                    this.transform[b][a] = parseFloat(c[(b * 4) + a])
                }
            }
        }
    }
};
papaya.viewer.Atlas.prototype.parseLabels = function () {
    var c, b, a;
    for (c = 0; c < this.atlasLabelData.atlas.data.label.length; c += 1) {
        a = this.atlasLabelData.atlas.data.label[c];
        if (a.index) {
            b = parseInt(a.index, 10)
        } else {
            b = c
        }
        if (a.content) {
            this.labels[b] = a.content
        } else {
            this.labels[b] = a
        }
    }
};
papaya.viewer.Atlas.prototype.formatLabels = function (b, c) {
    var d, f, a, e;
    if (b) {
        a = b.split(papaya.viewer.Atlas.LABEL_SPLIT_REGEX);
        if (this.displayColumns) {
            for (d = 0; d < a.length; d += 1) {
                if (d < this.displayColumns.length) {
                    c[d] = a[this.displayColumns[d]]
                }
            }
        } else {
            e = a.length;
            f = 0;
            if (e > papaya.viewer.Atlas.MAX_LABELS) {
                f = (e - papaya.viewer.Atlas.MAX_LABELS)
            }
            for (d = f; d < a.length; d += 1) {
                c[d] = a[d].trim()
            }
        }
    } else {
        for (d = 0; d < c.length; d += 1) {
            c[d] = ""
        }
    }
    return c
};
papaya.viewer.Atlas.prototype.findMaxLabelParts = function () {
    var a, b;
    if (this.displayColumns) {
        return this.displayColumns.length
    }
    b = [];
    for (a = 0; a < this.labels.length; a += 1) {
        this.formatLabels(this.labels[a], b)
    }
    return b.length
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
papaya.viewer.ScreenVolume = papaya.viewer.ScreenVolume ||
function (a, f, d, b, c) {
    this.volume = a;
    this.lutName = d;
    this.colorTable = new papaya.viewer.ColorTable(this.lutName, b, true);
    this.screenMin = this.volume.header.imageRange.displayMin;
    this.screenMax = this.volume.header.imageRange.displayMax;
    this.imageMin = this.volume.header.imageRange.imageMin;
    this.imageMax = this.volume.header.imageRange.imageMax;
    this.alpha = 1;
    this.currentTimepoint = 0;
    var e = f[this.volume.fileName];
    if (e) {
        if ((e.min !== undefined) && (e.max !== undefined)) {
            if (c) {
                this.screenMin = -1 * Math.abs(e.min);
                this.screenMax = -1 * Math.abs(e.max)
            } else {
                this.screenMin = e.min;
                this.screenMax = e.max
            }
        } else {
            this.findDisplayRange(c, e.symmetric)
        }
        if (c) {
            if (e.negative_lut !== undefined) {
                this.lutName = e.negative_lut;
                this.colorTable = new papaya.viewer.ColorTable(this.lutName, b, true)
            }
        } else {
            if (e.lut !== undefined) {
                this.lutName = e.lut;
                this.colorTable = new papaya.viewer.ColorTable(this.lutName, b, true)
            }
        }
        if ((e.alpha !== undefined) && !b) {
            this.alpha = e.alpha
        }
    } else {
        this.findDisplayRange(c, false)
    }
    this.negative = (this.screenMax < this.screenMin);
    this.updateScreenRange()
};
papaya.viewer.ScreenVolume.prototype.setScreenRange = function (b, a) {
    this.screenMin = b;
    this.screenMax = a;
    this.updateScreenRange()
};
papaya.viewer.ScreenVolume.prototype.updateScreenRange = function () {
    this.screenRatio = (papaya.viewer.ScreenSlice.SCREEN_PIXEL_MAX / (this.screenMax - this.screenMin))
};
papaya.viewer.ScreenVolume.prototype.isOverlay = function () {
    return !this.colorTable.isBaseImage
};
papaya.viewer.ScreenVolume.prototype.findImageRange = function () {
    var c, b, e, a, j, d, g, h, i, f;
    c = (this.volume.header.imageRange.imageMin !== this.volume.header.imageRange.imageMax);
    if (!c) {
        console.log("scanning image range of " + this.volume.fileName + "...");
        b = Number.MAX_VALUE;
        e = Number.MIN_VALUE;
        a = this.volume.header.imageDimensions.xDim;
        j = this.volume.header.imageDimensions.yDim;
        d = this.volume.header.imageDimensions.zDim;
        for (g = 0; g < d; g += 1) {
            for (h = 0; h < j; h += 1) {
                for (i = 0; i < a; i += 1) {
                    f = this.volume.getVoxelAtIndex(i, h, g, 0, true);
                    if (f > e) {
                        e = f
                    }
                    if (f < b) {
                        b = f
                    }
                }
            }
        }
        this.volume.header.imageRange.imageMin = this.imageMin = b;
        this.volume.header.imageRange.imageMax = this.imageMax = e
    }
};
papaya.viewer.ScreenVolume.prototype.findDisplayRange = function (e, f) {
    var c, d, a, b;
    c = (this.volume.header.imageRange.imageMin !== this.volume.header.imageRange.imageMax);
    d = this.screenMin;
    a = this.screenMax;
    if (e) {
        if (Math.abs(d) > Math.abs(a)) {
            b = a;
            a = d;
            d = b
        }
    }
    if (this.isOverlay()) {
        if ((d === a) || ((d < 0) && (a > 0)) || ((d > 0) && (a < 0)) || (e && ((d > 0) || (a > 0))) || f) {
            this.findImageRange();
            if (e) {
                if (f || (this.imageMin === 0)) {
                    d = -1 * (this.imageMax - (this.imageMax * 0.75));
                    a = -1 * (this.imageMax - (this.imageMax * 0.25))
                } else {
                    d = this.imageMin - (this.imageMin * 0.75);
                    a = this.imageMin - (this.imageMin * 0.25)
                }
            } else {
                d = this.imageMax - (this.imageMax * 0.75);
                a = this.imageMax - (this.imageMax * 0.25)
            }
        }
        if (!((d < 1) && (d > -1) && (a < 1) && (a > -1))) {
            d = Math.round(d);
            a = Math.round(a)
        }
    } else {
        if (!((d < 1) && (d > -1) && (a < 1) && (a > -1))) {
            d = Math.round(d);
            a = Math.round(a)
        }
        if ((d === 0) && (a === 0)) {
            this.findImageRange();
            d = this.imageMin;
            a = this.imageMax
        }
        if (!(a > d)) {
            this.findImageRange();
            d = this.imageMin;
            a = this.imageMax
        }
        if (c && (d < this.imageMin)) {
            this.findImageRange();
            d = this.imageMin
        }
        if (c && (a > this.imageMax)) {
            this.findImageRange();
            a = this.imageMax
        }
    }
    this.screenMin = d;
    this.screenMax = a
};
papaya.viewer.ScreenVolume.prototype.isUsingColorTable = function (a) {
    return (this.lutName === a)
};
papaya.viewer.ScreenVolume.prototype.changeColorTable = function (b, a) {
    this.colorTable = new papaya.viewer.ColorTable(a, !this.isOverlay(), true);
    this.lutName = a;
    b.drawViewer(true)
};
papaya.viewer.ScreenVolume.prototype.getRange = function () {
    var a = new Array(2);
    a[0] = ((this.colorTable.minLUT / (255 / (this.screenMax - this.screenMin))) + this.screenMin);
    a[1] = ((this.colorTable.maxLUT / (255 / (this.screenMax - this.screenMin))) + this.screenMin);
    return a
};
papaya.viewer.ScreenVolume.prototype.incrementTimepoint = function () {
    var a = this.volume.numTimepoints;
    this.currentTimepoint += 1;
    if (this.currentTimepoint >= a) {
        this.currentTimepoint = a - 1
    }
};
papaya.viewer.ScreenVolume.prototype.decrementTimepoint = function () {
    this.currentTimepoint -= 1;
    if (this.currentTimepoint < 0) {
        this.currentTimepoint = 0
    }
};
papaya.viewer.ScreenVolume.prototype.updateMinLUT = function (a) {
    this.colorTable.updateMinLUT(a)
};
papaya.viewer.ScreenVolume.prototype.updateMaxLUT = function (a) {
    this.colorTable.updateMaxLUT(a)
};
papaya.viewer.ScreenVolume.prototype.updateLUT = function (b, a) {
    this.colorTable.updateLUT(b, a)
};
papaya.viewer.ScreenVolume.prototype.resetDynamicRange = function () {
    this.colorTable.minLUT = 0;
    this.colorTable.maxLUT = papaya.viewer.ColorTable.LUT_MAX;
    this.updateLUT(this.colorTable.minLUT, this.colorTable.maxLUT);
    this.colorTable.updateColorBar()
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
papaya.viewer.ColorTable = papaya.viewer.ColorTable ||
function (b, a, c) {
    this.lut = papaya.viewer.ColorTable.findLUT(b);
    this.maxLUT = 0;
    this.minLUT = 0;
    this.knotThresholds = [];
    this.knotRangeRatios = [];
    this.LUTarrayG = new Array(256);
    this.LUTarrayR = new Array(256);
    this.LUTarrayB = new Array(256);
    this.isBaseImage = a;
    this.knotMin = this.lut[0];
    this.knotMax = this.lut[this.lut.length - 1];
    this.useGradation = c;
    this.canvasIcon = document.createElement("canvas");
    this.canvasIcon.width = papaya.viewer.ColorTable.ICON_SIZE;
    this.canvasIcon.height = papaya.viewer.ColorTable.ICON_SIZE;
    this.contextIcon = this.canvasIcon.getContext("2d");
    this.imageDataIcon = this.contextIcon.createImageData(papaya.viewer.ColorTable.ICON_SIZE, papaya.viewer.ColorTable.ICON_SIZE);
    this.icon = null;
    this.canvasBar = document.createElement("canvas");
    this.canvasBar.width = papaya.viewer.ColorTable.COLOR_BAR_WIDTH;
    this.canvasBar.height = papaya.viewer.ColorTable.COLOR_BAR_HEIGHT;
    this.contextBar = this.canvasBar.getContext("2d");
    this.imageDataBar = this.contextBar.createImageData(papaya.viewer.ColorTable.COLOR_BAR_WIDTH, papaya.viewer.ColorTable.COLOR_BAR_HEIGHT);
    this.colorBar = null;
    this.updateLUT(papaya.viewer.ColorTable.LUT_MIN, papaya.viewer.ColorTable.LUT_MAX);
    this.updateIcon();
    this.updateColorBar()
};
papaya.viewer.ColorTable.TABLE_GRAYSCALE = {
    name: "Grayscale",
    data: [
        [0, 0, 0, 0],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.TABLE_SPECTRUM = {
    name: "Spectrum",
    data: [
        [0, 0, 0, 0],
        [0.1, 0, 0, 1],
        [0.33, 0, 1, 1],
        [0.5, 0, 1, 0],
        [0.66, 1, 1, 0],
        [0.9, 1, 0, 0],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.TABLE_RED2YELLOW = {
    name: "Red-to-Yellow",
    data: [
        [0, 1, 0, 0],
        [1, 1, 1, 0]
    ]
};
papaya.viewer.ColorTable.TABLE_BLUE2GREEN = {
    name: "Blue-to-Green",
    data: [
        [0, 0, 0, 1],
        [1, 0, 1, 0]
    ]
};
papaya.viewer.ColorTable.TABLE_HOTANDCOLD = {
    name: "Hot-and-Cold",
    data: [
        [0, 0, 0, 1],
        [0.15, 0, 1, 1],
        [0.3, 0, 1, 0],
        [0.45, 0, 0, 0],
        [0.5, 0, 0, 0],
        [0.55, 0, 0, 0],
        [0.7, 1, 1, 0],
        [0.85, 1, 0, 0],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.TABLE_GOLD = {
    name: "Gold",
    data: [
        [0, 0, 0, 0],
        [0.13, 0.19, 0.03, 0],
        [0.25, 0.39, 0.12, 0],
        [0.38, 0.59, 0.26, 0],
        [0.5, 0.8, 0.46, 0.08],
        [0.63, 0.99, 0.71, 0.21],
        [0.75, 0.99, 0.88, 0.34],
        [0.88, 0.99, 0.99, 0.48],
        [1, 0.9, 0.95, 0.61]
    ]
};
papaya.viewer.ColorTable.TABLE_RED2WHITE = {
    name: "Red Overlay",
    data: [
        [0, 0.75, 0, 0],
        [0.5, 1, 0.5, 0],
        [0.95, 1, 1, 0],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.TABLE_GREEN2WHITE = {
    name: "Green Overlay",
    data: [
        [0, 0, 0.75, 0],
        [0.5, 0.5, 1, 0],
        [0.95, 1, 1, 0],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.TABLE_BLUE2WHITE = {
    name: "Blue Overlay",
    data: [
        [0, 0, 0, 1],
        [0.5, 0, 0.5, 1],
        [0.95, 0, 1, 1],
        [1, 1, 1, 1]
    ]
};
papaya.viewer.ColorTable.ARROW_ICON = "data:image/gif;base64,R0lGODlhCwARAPfGMf//////zP//mf//Zv//M///AP/M///MzP/Mmf/MZv/MM//MAP+Z//+ZzP+Zmf+ZZv+ZM/+ZAP9m//9mzP9mmf9mZv9mM/9mAP8z//8zzP8zmf8zZv8zM/8zAP8A//8AzP8Amf8AZv8AM/8AAMz//8z/zMz/mcz/Zsz/M8z/AMzM/8zMzMzMmczMZszMM8zMAMyZ/8yZzMyZmcyZZsyZM8yZAMxm/8xmzMxmmcxmZsxmM8xmAMwz/8wzzMwzmcwzZswzM8wzAMwA/8wAzMwAmcwAZswAM8wAAJn//5n/zJn/mZn/Zpn/M5n/AJnM/5nMzJnMmZnMZpnMM5nMAJmZ/5mZzJmZmZmZZpmZM5mZAJlm/5lmzJlmmZlmZplmM5lmAJkz/5kzzJkzmZkzZpkzM5kzAJkA/5kAzJkAmZkAZpkAM5kAAGb//2b/zGb/mWb/Zmb/M2b/AGbM/2bMzGbMmWbMZmbMM2bMAGaZ/2aZzGaZmWaZZmaZM2aZAGZm/2ZmzGZmmWZmZmZmM2ZmAGYz/2YzzGYzmWYzZmYzM2YzAGYA/2YAzGYAmWYAZmYAM2YAADP//zP/zDP/mTP/ZjP/MzP/ADPM/zPMzDPMmTPMZjPMMzPMADOZ/zOZzDOZmTOZZjOZMzOZADNm/zNmzDNmmTNmZjNmMzNmADMz/zMzzDMzmTMzZjMzMzMzADMA/zMAzDMAmTMAZjMAMzMAAAD//wD/zAD/mQD/ZgD/MwD/AADM/wDMzADMmQDMZgDMMwDMAACZ/wCZzACZmQCZZgCZMwCZAABm/wBmzABmmQBmZgBmMwBmAAAz/wAzzAAzmQAzZgAzMwAzAAAA/wAAzAAAmQAAZgAAM+4AAN0AALsAAKoAAIgAAHcAAFUAAEQAACIAABEAAADuAADdAAC7AACqAACIAAB3AABVAABEAAAiAAARAAAA7gAA3QAAuwAAqgAAiAAAdwAAVQAARAAAIgAAEe7u7t3d3bu7u6qqqoiIiHd3d1VVVURERCIiIhEREQAAACH5BAEAAMYALAAAAAALABEAAAg/AI0JFGhvoEGC+vodRKgv4UF7DSMqZBixoUKIFSv2w5jRIseOGztK/JgxpMiEJDWmHHkSZUuTIvvt60ezps2AADs=";
papaya.viewer.ColorTable.ARROW_ICON_WIDTH = 11;
papaya.viewer.ColorTable.DEFAULT_COLOR_TABLE = papaya.viewer.ColorTable.TABLE_GRAYSCALE;
papaya.viewer.ColorTable.PARAMETRIC_COLOR_TABLES = [papaya.viewer.ColorTable.TABLE_RED2YELLOW, papaya.viewer.ColorTable.TABLE_BLUE2GREEN];
papaya.viewer.ColorTable.OVERLAY_COLOR_TABLES = [papaya.viewer.ColorTable.TABLE_RED2WHITE, papaya.viewer.ColorTable.TABLE_GREEN2WHITE, papaya.viewer.ColorTable.TABLE_BLUE2WHITE];
papaya.viewer.ColorTable.TABLE_ALL = [papaya.viewer.ColorTable.TABLE_GRAYSCALE, papaya.viewer.ColorTable.TABLE_SPECTRUM, papaya.viewer.ColorTable.TABLE_RED2YELLOW, papaya.viewer.ColorTable.TABLE_BLUE2GREEN, papaya.viewer.ColorTable.TABLE_HOTANDCOLD, papaya.viewer.ColorTable.TABLE_GOLD, papaya.viewer.ColorTable.TABLE_RED2WHITE, papaya.viewer.ColorTable.TABLE_GREEN2WHITE, papaya.viewer.ColorTable.TABLE_BLUE2WHITE];
papaya.viewer.ColorTable.LUT_MIN = 0;
papaya.viewer.ColorTable.LUT_MAX = 255;
papaya.viewer.ColorTable.ICON_SIZE = 18;
papaya.viewer.ColorTable.COLOR_BAR_WIDTH = 100;
papaya.viewer.ColorTable.COLOR_BAR_HEIGHT = 15;
papaya.viewer.ColorTable.findLUT = function (a) {
    var b;
    for (b = 0; b < papaya.viewer.ColorTable.TABLE_ALL.length; b += 1) {
        if (papaya.viewer.ColorTable.TABLE_ALL[b].name === a) {
            return papaya.viewer.ColorTable.TABLE_ALL[b].data
        }
    }
    return null
};
papaya.viewer.ColorTable.addCustomLUT = function (a) {
    if (papaya.viewer.ColorTable.findLUT(a.name) === null) {
        papaya.viewer.ColorTable.TABLE_ALL.push(a)
    }
};
papaya.viewer.ColorTable.prototype.updateMinLUT = function (a) {
    this.updateLUT(a, this.maxLUT)
};
papaya.viewer.ColorTable.prototype.updateMaxLUT = function (a) {
    this.updateLUT(this.minLUT, a)
};
papaya.viewer.ColorTable.prototype.updateLUT = function (f, e) {
    var a, d, b, c;
    this.maxLUT = e;
    this.minLUT = f;
    a = this.maxLUT - this.minLUT;
    for (d = 0; d < this.lut.length; d += 1) {
        this.knotThresholds[d] = (this.lut[d][0] * a) + this.minLUT
    }
    for (d = 0; d < (this.lut.length - 1); d += 1) {
        this.knotRangeRatios[d] = papaya.viewer.ColorTable.LUT_MAX / (this.knotThresholds[d + 1] - this.knotThresholds[d])
    }
    for (d = 0; d < 256; d += 1) {
        if (d <= this.minLUT) {
            this.LUTarrayR[d] = this.knotMin[1] * papaya.viewer.ColorTable.LUT_MAX;
            this.LUTarrayG[d] = this.knotMin[2] * papaya.viewer.ColorTable.LUT_MAX;
            this.LUTarrayB[d] = this.knotMin[3] * papaya.viewer.ColorTable.LUT_MAX
        } else {
            if (d > this.maxLUT) {
                this.LUTarrayR[d] = this.knotMax[1] * papaya.viewer.ColorTable.LUT_MAX;
                this.LUTarrayG[d] = this.knotMax[2] * papaya.viewer.ColorTable.LUT_MAX;
                this.LUTarrayB[d] = this.knotMax[3] * papaya.viewer.ColorTable.LUT_MAX
            } else {
                for (b = 0; b < (this.lut.length - 1); b += 1) {
                    if ((d > this.knotThresholds[b]) && (d <= this.knotThresholds[b + 1])) {
                        if (this.useGradation) {
                            c = (((d - this.knotThresholds[b]) * this.knotRangeRatios[b]) + 0.5) / papaya.viewer.ColorTable.LUT_MAX;
                            this.LUTarrayR[d] = (((1 - c) * this.lut[b][1]) + (c * this.lut[b + 1][1])) * papaya.viewer.ColorTable.LUT_MAX;
                            this.LUTarrayG[d] = (((1 - c) * this.lut[b][2]) + (c * this.lut[b + 1][2])) * papaya.viewer.ColorTable.LUT_MAX;
                            this.LUTarrayB[d] = (((1 - c) * this.lut[b][3]) + (c * this.lut[b + 1][3])) * papaya.viewer.ColorTable.LUT_MAX
                        } else {
                            this.LUTarrayR[d] = (this.lut[b][1]) * papaya.viewer.ColorTable.LUT_MAX;
                            this.LUTarrayG[d] = (this.lut[b][2]) * papaya.viewer.ColorTable.LUT_MAX;
                            this.LUTarrayB[d] = (this.lut[b][3]) * papaya.viewer.ColorTable.LUT_MAX
                        }
                    }
                }
            }
        }
    }
};
papaya.viewer.ColorTable.prototype.lookupRed = function (a) {
    if ((a >= 0) && (a < 256)) {
        return (this.LUTarrayR[a] & 255)
    }
    return 0
};
papaya.viewer.ColorTable.prototype.lookupGreen = function (a) {
    if ((a >= 0) && (a < 256)) {
        return (this.LUTarrayG[a] & 255)
    }
    return 0
};
papaya.viewer.ColorTable.prototype.lookupBlue = function (a) {
    if ((a >= 0) && (a < 256)) {
        return (this.LUTarrayB[a] & 255)
    }
    return 0
};
papaya.viewer.ColorTable.prototype.updateIcon = function () {
    var d, b, c, a, e;
    d = papaya.viewer.ColorTable.LUT_MAX / papaya.viewer.ColorTable.ICON_SIZE;
    for (b = 0; b < papaya.viewer.ColorTable.ICON_SIZE; b += 1) {
        for (c = 0; c < papaya.viewer.ColorTable.ICON_SIZE; c += 1) {
            a = ((b * papaya.viewer.ColorTable.ICON_SIZE) + c) * 4;
            e = Math.round(c * d);
            this.imageDataIcon.data[a] = this.lookupRed(e);
            this.imageDataIcon.data[a + 1] = this.lookupGreen(e);
            this.imageDataIcon.data[a + 2] = this.lookupBlue(e);
            this.imageDataIcon.data[a + 3] = 255
        }
    }
    this.contextIcon.putImageData(this.imageDataIcon, 0, 0);
    this.icon = this.canvasIcon.toDataURL()
};
papaya.viewer.ColorTable.prototype.updateColorBar = function () {
    var d, b, c, a, e;
    d = papaya.viewer.ColorTable.LUT_MAX / papaya.viewer.ColorTable.COLOR_BAR_WIDTH;
    for (b = 0; b < papaya.viewer.ColorTable.COLOR_BAR_HEIGHT; b += 1) {
        for (c = 0; c < papaya.viewer.ColorTable.COLOR_BAR_WIDTH; c += 1) {
            a = ((b * papaya.viewer.ColorTable.COLOR_BAR_WIDTH) + c) * 4;
            e = Math.round(c * d);
            this.imageDataBar.data[a] = this.lookupRed(e);
            this.imageDataBar.data[a + 1] = this.lookupGreen(e);
            this.imageDataBar.data[a + 2] = this.lookupBlue(e);
            this.imageDataBar.data[a + 3] = 255
        }
    }
    this.contextBar.putImageData(this.imageDataBar, 0, 0);
    this.colorBar = this.canvasBar.toDataURL()
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
papaya.viewer.Display = papaya.viewer.Display ||
function (a, b) {
    this.container = a;
    this.viewer = a.viewer;
    this.canvas = document.createElement("canvas");
    this.canvas.width = b;
    this.canvas.height = PAPAYA_SECTION_HEIGHT;
    this.context = this.canvas.getContext("2d");
    this.canvas.style.padding = 0;
    this.canvas.style.margin = 0;
    this.canvas.style.border = "none";
    this.canvas.style.cursor = "default";
    this.tempCoord = new papaya.core.Coordinate(0, 0, 0);
    this.drawingError = false;
    this.progress = 0;
    this.progressTimeout = null;
    this.drawingProgress = false;
    this.errorMessage = "";
    this.drawUninitializedDisplay()
};
papaya.viewer.Display.MINI_LABELS_THRESH = 700;
papaya.viewer.Display.PADDING = 8;
papaya.viewer.Display.FONT_COLOR_WHITE = "white";
papaya.viewer.Display.FONT_COLOR_ORANGE = "rgb(182, 59, 0)";
papaya.viewer.Display.FONT_SIZE_COORDINATE_LABEL = 12;
papaya.viewer.Display.FONT_COLOR_COORDINATE_LABEL = papaya.viewer.Display.FONT_COLOR_WHITE;
papaya.viewer.Display.FONT_TYPE_COORDINATE_LABEL = "Arial";
papaya.viewer.Display.FONT_SIZE_COORDINATE_VALUE = 18;
papaya.viewer.Display.FONT_COLOR_COORDINATE_VALUE = papaya.viewer.Display.FONT_COLOR_ORANGE;
papaya.viewer.Display.FONT_TYPE_COORDINATE_VALUE = "Arial";
papaya.viewer.Display.PRECISON_COORDINATE_VALUE = 5;
papaya.viewer.Display.FONT_SIZE_IMAGE_VALUE = 20;
papaya.viewer.Display.FONT_COLOR_IMAGE_VALUE = papaya.viewer.Display.FONT_COLOR_WHITE;
papaya.viewer.Display.FONT_TYPE_IMAGE_VALUE = "Arial";
papaya.viewer.Display.PRECIOSN_IMAGE_VALUE = 9;
papaya.viewer.Display.FONT_SIZE_ATLAS_MINI = 14;
papaya.viewer.Display.FONT_SIZE_ATLAS = 20;
papaya.viewer.Display.FONT_TYPE_ATLAS = "Arial";
papaya.viewer.Display.prototype.drawUninitializedDisplay = function () {
    this.context.fillStyle = "#000000";
    this.context.fillRect(0, 0, this.canvas.width, this.canvas.height)
};
papaya.viewer.Display.prototype.canDraw = function () {
    return !(this.drawingError || this.drawingProgress)
};
papaya.viewer.Display.prototype.drawEmptyDisplay = function () {
    if (this.canDraw()) {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.context.fillStyle = "#000000";
        this.context.fillRect(0, 0, this.canvas.width, this.canvas.height)
    } else {
        if (this.drawError) {
            this.drawError(this.errorMessage)
        }
    }
};
papaya.viewer.Display.prototype.drawDisplay = function (j, l, q) {
    var c, r, g, i, m, a, h, o, n, d, f, k, e, p, b;
    if (this.canDraw()) {
        d = this.viewer.canvas.width / 800;
        e = this.viewer.canvas.width / 2;
        p = e / 5;
        i = this.canvas.height;
        b = (e < 300);
        if (this.container.preferences.atlasLocks !== "Mouse") {
            j = this.viewer.currentCoord.x;
            l = this.viewer.currentCoord.y;
            q = this.viewer.currentCoord.z
        }
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.context.fillStyle = "#000000";
        this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
        this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_COORDINATE_LABEL;
        this.context.font = papaya.viewer.Display.FONT_SIZE_COORDINATE_LABEL + "px " + papaya.viewer.Display.FONT_TYPE_COORDINATE_LABEL;
        c = papaya.viewer.Display.FONT_SIZE_COORDINATE_LABEL + papaya.viewer.Display.PADDING * 0.75;
        this.context.fillText("x", 1.5 * papaya.viewer.Display.PADDING, c);
        this.context.fillText("y", 1.5 * papaya.viewer.Display.PADDING + p, c);
        this.context.fillText("z", 1.5 * papaya.viewer.Display.PADDING + (2 * p), c);
        c += papaya.viewer.Display.FONT_SIZE_COORDINATE_VALUE + papaya.viewer.Display.PADDING / 2;
        this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_COORDINATE_VALUE;
        this.context.font = (papaya.viewer.Display.FONT_SIZE_COORDINATE_VALUE - (b ? 2 : 0)) + "px " + papaya.viewer.Display.FONT_TYPE_COORDINATE_VALUE;
        if (this.viewer.worldSpace) {
            g = this.viewer.screenVolumes[0].volume.header.origin;
            f = this.viewer.screenVolumes[0].volume.header.voxelDimensions;
            this.context.fillText(parseFloat(((j - g.x) * f.xSize).toPrecision(Math.round(papaya.viewer.Display.PRECISON_COORDINATE_VALUE * d))), 1.5 * papaya.viewer.Display.PADDING, c);
            this.context.fillText(parseFloat(((g.y - l) * f.ySize).toPrecision(Math.round(papaya.viewer.Display.PRECISON_COORDINATE_VALUE * d))), 1.5 * papaya.viewer.Display.PADDING + p, c);
            this.context.fillText(parseFloat(((g.z - q) * f.zSize).toPrecision(Math.round(papaya.viewer.Display.PRECISON_COORDINATE_VALUE * d))), 1.5 * papaya.viewer.Display.PADDING + (2 * p), c)
        } else {
            this.context.fillText(Math.round(j).toString(), 1.5 * papaya.viewer.Display.PADDING, c);
            this.context.fillText(Math.round(l).toString(), 1.5 * papaya.viewer.Display.PADDING + p, c);
            this.context.fillText(Math.round(q).toString(), 1.5 * papaya.viewer.Display.PADDING + (2 * p), c)
        }
        r = this.viewer.getCurrentValueAt(j, l, q);
        c = (i / 2) + (papaya.viewer.Display.FONT_SIZE_IMAGE_VALUE / 2) - (papaya.viewer.Display.PADDING / 2);
        this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_IMAGE_VALUE;
        this.context.font = (papaya.viewer.Display.FONT_SIZE_IMAGE_VALUE - (b ? 2 : 0)) + "px " + papaya.viewer.Display.FONT_TYPE_IMAGE_VALUE;
        this.context.fillText(parseFloat(r.toPrecision(Math.round(papaya.viewer.Display.PRECIOSN_IMAGE_VALUE * d))), (2 * papaya.viewer.Display.PADDING) + (3 * p), c);
        if (this.viewer.atlas && this.viewer.atlas.volume.isLoaded) {
            this.viewer.getWorldCoordinateAtIndex(j, l, q, this.tempCoord);
            h = this.viewer.atlas.getLabelAtCoordinate(this.tempCoord.x, this.tempCoord.y, this.tempCoord.z);
            m = h.length;
            k = Math.ceil(this.viewer.atlas.maxLabels / 2);
            if ((e < 300) && (m >= 2)) {
                a = e * 0.75;
                for (o = m - 1; o >= 0; o -= 1) {
                    if (o === (m - 2)) {
                        this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_ORANGE;
                        this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                    } else {
                        this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_WHITE;
                        this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                    }
                    n = this.context.measureText(h[o]);
                    if (n.width > (a - 2 * papaya.viewer.Display.PADDING)) {
                        h[o] = (h[o].substr(0, Math.round(h[o].length / 3)) + " ... " + h[o].substr(h[o].length - 3, 3))
                    }
                    if (o === (m - 2)) {
                        this.context.fillText(h[o], e + (e * 0.25), papaya.viewer.Display.PADDING * 1.5 + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                    } else {
                        if (o === (m - 1)) {
                            this.context.fillText(h[o], e + (e * 0.25), papaya.viewer.Display.PADDING + (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                        }
                    }
                }
            } else {
                if ((e < 600) && (m > 2)) {
                    a = e / 2;
                    for (o = m - 1; o >= 0; o -= 1) {
                        if (o < k) {
                            this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_ORANGE;
                            this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                        } else {
                            this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_WHITE;
                            this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                        }
                        n = this.context.measureText(h[o]);
                        if (n.width > (a - papaya.viewer.Display.PADDING * 6)) {
                            h[o] = (h[o].substr(0, Math.round(h[o].length / 3)) + " ... " + h[o].substr(h[o].length - 3, 3))
                        }
                        if (o === 0) {
                            this.context.fillText(h[o], e + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING * 1.5 + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                        } else {
                            if (o === 1) {
                                this.context.fillText(h[o], e + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING + (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                            } else {
                                if (o === 2) {
                                    this.context.fillText(h[o], e * 1.5 + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING * 1.5 + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                } else {
                                    if (o === 3) {
                                        this.context.fillText(h[o], e * 1.5 + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING + (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if ((e < 800) && (m > 3)) {
                        a = e / 3;
                        for (o = 0; o < 4; o += 1) {
                            if (o < 2) {
                                if (o < k) {
                                    this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_ORANGE;
                                    this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                                } else {
                                    this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_WHITE;
                                    this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS_MINI + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                                }
                                n = this.context.measureText(h[o]);
                                if (n.width > (a - papaya.viewer.Display.PADDING * 6)) {
                                    h[o] = (h[o].substr(0, Math.round(h[o].length / 3)) + " ... " + h[o].substr(h[o].length - 3, 3))
                                }
                                if (o === 0) {
                                    this.context.fillText(h[o], e + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING * 1.5 + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                } else {
                                    if (o === 1) {
                                        this.context.fillText(h[o], e + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING + (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                    } else {
                                        if (o === 2) {
                                            this.context.fillText(h[o], e * 1.5 + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING * 1.5 + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                        } else {
                                            if (o === 3) {
                                                this.context.fillText(h[o], e * 1.5 + papaya.viewer.Display.PADDING * 5, papaya.viewer.Display.PADDING + (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS_MINI / 2))
                                            }
                                        }
                                    }
                                }
                            } else {
                                c = (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS / 2) - (papaya.viewer.Display.PADDING / 2);
                                if (o < k) {
                                    this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_ORANGE;
                                    this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                                } else {
                                    this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_WHITE;
                                    this.context.font = papaya.viewer.Display.FONT_SIZE_ATLAS + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                                }
                                n = this.context.measureText(h[o]);
                                if (n.width > (a - (2 * papaya.viewer.Display.PADDING))) {
                                    h[o] = (h[o].substr(0, Math.round(h[o].length / 3)) + " ... " + h[o].substr(h[o].length - 3, 3))
                                }
                                if (o === 2) {
                                    this.context.fillText(h[o], e + papaya.viewer.Display.PADDING + a, c)
                                } else {
                                    if (o === 3) {
                                        this.context.fillText(h[o], e + papaya.viewer.Display.PADDING + (2 * a), c)
                                    }
                                }
                            }
                        }
                    } else {
                        a = e / m;
                        c = (i / 2) + (papaya.viewer.Display.FONT_SIZE_ATLAS / 2) - (papaya.viewer.Display.PADDING / 2);
                        for (o = 0; o < m; o += 1) {
                            if (o < k) {
                                this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_ORANGE;
                                this.context.font = (papaya.viewer.Display.FONT_SIZE_ATLAS - (b ? 4 : 0)) + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                            } else {
                                this.context.fillStyle = papaya.viewer.Display.FONT_COLOR_WHITE;
                                this.context.font = (papaya.viewer.Display.FONT_SIZE_ATLAS - (b ? 4 : 0)) + "px " + papaya.viewer.Display.FONT_TYPE_ATLAS
                            }
                            n = this.context.measureText(h[o]);
                            if (n.width > (a - (2 * papaya.viewer.Display.PADDING)) - (e * 0.05 * Math.max(0, 3 - m))) {
                                h[o] = (h[o].substr(0, Math.round(h[o].length / 3)) + " ... " + h[o].substr(h[o].length - 3, 3))
                            }
                            this.context.fillText(h[o], e + papaya.viewer.Display.PADDING + (e * 0.05 * Math.max(0, 3 - m)) + (o * a), c)
                        }
                    }
                }
            }
        }
    } else {
        if (this.drawError) {
            this.drawError(this.errorMessage)
        }
    }
};
papaya.viewer.Display.prototype.drawError = function (b) {
    var a, c;
    this.errorMessage = b;
    this.drawingError = true;
    c = this;
    window.setTimeout(bind(c, function () {
        c.drawingError = false
    }), 3000);
    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.context.fillStyle = "#000000";
    this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
    this.context.fillStyle = "red";
    this.context.font = papaya.viewer.Display.TEXT_CORRD_VALUE_SIZE + "px Arial";
    a = papaya.viewer.Display.FONT_SIZE_COORDINATE_LABEL + papaya.viewer.Display.PADDING + 1.5 * papaya.viewer.Display.PADDING;
    this.context.fillText(b, papaya.viewer.Display.PADDING, a)
};
papaya.viewer.Display.prototype.drawProgress = function (a) {
    var d, c, b;
    d = Math.round(a * 1000);
    if (d > this.progress) {
        this.progress = d;
        if (this.progress >= 990) {
            this.drawingProgress = false;
            this.progress = 0;
            this.drawEmptyDisplay()
        } else {
            if (this.progressTimeout) {
                window.clearTimeout(this.progressTimeout)
            }
            b = this;
            this.progressTimeout = window.setTimeout(bind(b, function () {
                b.drawingProgress = false
            }), 3000);
            this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
            this.context.fillStyle = "#000000";
            this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
            c = Math.round(255 * a);
            this.context.fillStyle = "rgb(" + c + ", " + c + ", " + c + ")";
            this.context.fillRect(0, 0, this.canvas.width * a, this.canvas.height)
        }
    }
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
var PAPAYA_VERSION_ID = PAPAYA_VERSION_ID || "0.0";
var PAPAYA_BUILD_NUM = PAPAYA_BUILD_NUM || "0";
papaya.viewer.Viewer = papaya.viewer.Viewer ||
function (b, c, a, d) {
    this.container = b;
    this.canvas = document.createElement("canvas");
    this.canvas.width = c;
    this.canvas.height = a;
    this.context = this.canvas.getContext("2d");
    this.canvas.style.padding = 0;
    this.canvas.style.margin = 0;
    this.canvas.style.border = "none";
    this.atlas = null;
    this.initialized = false;
    this.loadingVolume = null;
    this.volume = new papaya.volume.Volume(this.container.display);
    this.screenVolumes = [];
    this.currentScreenVolume = null;
    this.axialSlice = null;
    this.coronalSlice = null;
    this.sagittalSlice = null;
    this.selectedSlice = null;
    this.mainImage = null;
    this.lowerImageBot = null;
    this.lowerImageTop = null;
    this.viewerDim = 0;
    this.worldSpace = false;
    this.currentCoord = new papaya.core.Coordinate(0, 0, 0);
    this.longestDim = 0;
    this.longestDimSize = 0;
    this.draggingSliceDir = 0;
    this.isDragging = false;
    this.isWindowControl = false;
    this.isZoomMode = false;
    this.isPanning = false;
    this.zoomFactor = papaya.viewer.Viewer.ZOOM_FACTOR_MIN;
    this.zoomFactorPrevious = papaya.viewer.Viewer.ZOOM_FACTOR_MIN;
    this.zoomLocX = 0;
    this.zoomLocY = 0;
    this.zoomLocZ = 0;
    this.panLocX = 0;
    this.panLocY = 0;
    this.panLocZ = 0;
    this.panAmountX = 0;
    this.panAmountY = 0;
    this.panAmountZ = 0;
    this.keyPressIgnored = false;
    this.previousMousePosition = new papaya.core.Point();
    this.isControlKeyDown = false;
    this.isAltKeyDown = false;
    this.isShiftKeyDown = false;
    this.toggleMainCrosshairs = true;
    this.sliceSliderControl = null;
    this.bgColor = null;
    this.listenerMouseMove = bind(this, this.mouseMoveEvent);
    this.listenerMouseDown = bind(this, this.mouseDownEvent);
    this.listenerMouseOut = bind(this, this.mouseOutEvent);
    this.listenerMouseUp = bind(this, this.mouseUpEvent);
    this.listenerMouseDoubleClick = bind(this, this.mouseDoubleClickEvent);
    this.listenerKeyDown = bind(this, this.keyDownEvent);
    this.listenerKeyUp = bind(this, this.keyUpEvent);
    this.listenerTouchMove = bind(this, this.touchMoveEvent);
    this.initialCoordinate = null;
    this.listenerScroll = bind(this, this.scrolled);
    this.updateTimer = null;
    this.updateTimerEvent = null;
    this.listenerContextMenu = function (f) {
        f.preventDefault();
        return false
    };
    this.drawEmptyViewer();
    this.processParams(d)
};
papaya.viewer.Viewer.GAP = PAPAYA_SPACING;
papaya.viewer.Viewer.BACKGROUND_COLOR = "rgba(0, 0, 0, 255)";
papaya.viewer.Viewer.CROSSHAIRS_COLOR = "rgba(28, 134, 238, 255)";
papaya.viewer.Viewer.KEYCODE_ROTATE_VIEWS = 32;
papaya.viewer.Viewer.KEYCODE_CENTER = 67;
papaya.viewer.Viewer.KEYCODE_ORIGIN = 79;
papaya.viewer.Viewer.KEYCODE_ARROW_UP = 38;
papaya.viewer.Viewer.KEYCODE_ARROW_DOWN = 40;
papaya.viewer.Viewer.KEYCODE_ARROW_RIGHT = 39;
papaya.viewer.Viewer.KEYCODE_ARROW_LEFT = 37;
papaya.viewer.Viewer.KEYCODE_PAGE_UP = 33;
papaya.viewer.Viewer.KEYCODE_PAGE_DOWN = 34;
papaya.viewer.Viewer.KEYCODE_SINGLE_QUOTE = 222;
papaya.viewer.Viewer.KEYCODE_FORWARD_SLASH = 191;
papaya.viewer.Viewer.KEYCODE_INCREMENT_MAIN = 71;
papaya.viewer.Viewer.KEYCODE_DECREMENT_MAIN = 86;
papaya.viewer.Viewer.KEYCODE_TOGGLE_CROSSHAIRS = 65;
papaya.viewer.Viewer.KEYCODE_SERIES_BACK = 188;
papaya.viewer.Viewer.KEYCODE_SERIES_FORWARD = 190;
papaya.viewer.Viewer.MAX_OVERLAYS = 8;
papaya.viewer.Viewer.ORIENTATION_MARKER_SUPERIOR = "S";
papaya.viewer.Viewer.ORIENTATION_MARKER_INFERIOR = "I";
papaya.viewer.Viewer.ORIENTATION_MARKER_ANTERIOR = "A";
papaya.viewer.Viewer.ORIENTATION_MARKER_POSTERIOR = "P";
papaya.viewer.Viewer.ORIENTATION_MARKER_LEFT = "L";
papaya.viewer.Viewer.ORIENTATION_MARKER_RIGHT = "R";
papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE = 16;
papaya.viewer.Viewer.ORIENTATION_CERTAINTY_UNKNOWN_COLOR = "red";
papaya.viewer.Viewer.ORIENTATION_CERTAINTY_LOW_COLOR = "yellow";
papaya.viewer.Viewer.ORIENTATION_CERTAINTY_HIGH_COLOR = "white";
papaya.viewer.Viewer.UPDATE_TIMER_INTERVAL = 250;
papaya.viewer.Viewer.ZOOM_FACTOR_MAX = 10;
papaya.viewer.Viewer.ZOOM_FACTOR_MIN = 1;
papaya.viewer.Viewer.MOUSE_SCROLL_THRESHLD = 0.25;
papaya.viewer.Viewer.TITLE_MAX_LENGTH = 30;
papaya.viewer.Viewer.prototype.loadImage = function (b, a, c) {
    if (this.screenVolumes.length === 0) {
        this.loadBaseImage(b, a, c)
    } else {
        this.loadOverlay(b, a, c);
        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //console.log("loading");
        //console.log(this);
        //console.log(this.screenVolumes)
//        var vol = this.screenVolumes;
//        //var CRONORData = this.screenVolumes;
//        window.setTimeout(function(){
////            console.log(vol[1].volume.imageData)
////            vol[1].volume.imageData.data.forEach(function(currentData){
////               currentData=1; 
////            });
//            console.log(ROISelectedForTim.length)
//            if (ROISelectedForTim.length !=0){
//            for(var i = 0; i<vol[1].volume.imageData.data.length; i++){
//               // console.log(vol[1].volume.imageData.data[i])
//               var affiche = true;
//               for(var j = 0; j<ROISelectedForTim.length; j++){
//                if (vol[1].volume.imageData.data[i] == ROISelectedForTim[j]  ){
//                   affiche = false;    
//                }               
//               }
//               if (affiche){
//                   vol[1].volume.imageData.data[i]=-100;  
//                }       
//            }     
//            }
//        }, 5000);
//        
////        for (i in vol){
////        console.log(vol[i]);
////        }
        
    }
};
papaya.viewer.Viewer.prototype.loadBaseImage = function (c, b, d) {
    var a = this.container.findLoadableImage(c, b, d);
    this.volume = new papaya.volume.Volume(this.container.display);
    if (d) {
        this.volume.readEncodedData(c, bind(this, this.initializeViewer))
    } else {
        if ((a !== null) && (a.encode !== undefined)) {
            this.volume.readEncodedData(a.encode, bind(this, this.initializeViewer))
        } else {
            if (b) {
                this.volume.readURL(c, bind(this, this.initializeViewer))
            } else {
                if ((a !== null) && (a.url !== undefined)) {
                    this.volume.readURL(a.url, bind(this, this.initializeViewer))
                } else {
                    this.volume.readFile(c, bind(this, this.initializeViewer))
                }
            }
        }
    }
};
papaya.viewer.Viewer.prototype.loadOverlay = function (c, b, d) {
    var a = this.container.findLoadableImage(c);
    this.loadingVolume = new papaya.volume.Volume(this.container.display);
    if (this.screenVolumes.length > papaya.viewer.Viewer.MAX_OVERLAYS) {
        this.loadingVolume.errorMessage = "Maximum number of overlays (" + papaya.viewer.Viewer.MAX_OVERLAYS + ") has been reached!";
        this.initializeOverlay()
    } else {
        if (d) {
            this.loadingVolume.readEncodedData(c, bind(this, this.initializeOverlay))
        } else {
            if ((a !== null) && (a.encode !== undefined)) {
                this.loadingVolume.readEncodedData(a.encode, bind(this, this.initializeOverlay))
            } else {
                if (b) {
                    this.loadingVolume.readURL(c, bind(this, this.initializeOverlay))
                } else {
                    if ((a !== null) && (a.url !== undefined)) {
                        this.loadingVolume.readURL(a.url, bind(this, this.initializeOverlay))
                    } else {
                        this.loadingVolume.readFile(c, bind(this, this.initializeOverlay))
                    }
                }
            }
        }
    }
            var vol = this.screenVolumes;
            console.log("vol");
            console.log(vol);
        //var CRONORData = this.screenVolumes;
        window.setTimeout(function(){
//            console.log(vol[1].volume.imageData)
//            vol[1].volume.imageData.data.forEach(function(currentData){
//               currentData=1; 
//            });
            console.log(ROISelectedForTim.length)
            if (ROISelectedForTim.length !=0){
            for(var i = 0; i<vol[1].volume.imageData.data.length; i++){
               // console.log(vol[1].volume.imageData.data[i])
               var affiche = true;
               for(var j = 0; j<ROISelectedForTim.length; j++){
                if (vol[1].volume.imageData.data[i] == ROISelectedForTim[j]  ){
                   affiche = false;    
                }               
               }
               if (affiche){
                   vol[1].volume.imageData.data[i]=0;  
                }       
            }     
            }
        }, 5000);
};
papaya.viewer.Viewer.prototype.atlasLoaded = function () {
    this.goToInitialCoordinate()
};
papaya.viewer.Viewer.prototype.initializeViewer = function () {
    var a, b;
    b = this;
    if (this.volume.hasError()) {
        a = this.volume.errorMessage;
        this.resetViewer();
        this.container.clearParams();
        this.container.display.drawError(a)
    } else {
        this.screenVolumes[0] = new papaya.viewer.ScreenVolume(this.volume, this.container.params, papaya.viewer.ColorTable.DEFAULT_COLOR_TABLE.name, true);
        this.setCurrentScreenVol(0);
        this.axialSlice = new papaya.viewer.ScreenSlice(this.volume, papaya.viewer.ScreenSlice.DIRECTION_AXIAL, this.volume.getXDim(), this.volume.getYDim(), this.volume.getXSize(), this.volume.getYSize(), this.screenVolumes);
        this.coronalSlice = new papaya.viewer.ScreenSlice(this.volume, papaya.viewer.ScreenSlice.DIRECTION_CORONAL, this.volume.getXDim(), this.volume.getZDim(), this.volume.getXSize(), this.volume.getZSize(), this.screenVolumes);
        this.sagittalSlice = new papaya.viewer.ScreenSlice(this.volume, papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL, this.volume.getYDim(), this.volume.getZDim(), this.volume.getYSize(), this.volume.getZSize(), this.screenVolumes);
        if ((this.container.params.mainView === undefined) || (this.container.params.mainView.toLowerCase() === "axial")) {
            this.mainImage = this.axialSlice;
            this.lowerImageTop = this.sagittalSlice;
            this.lowerImageBot = this.coronalSlice
        } else {
            if (this.container.params.mainView.toLowerCase() === "coronal") {
                this.mainImage = this.coronalSlice;
                this.lowerImageTop = this.axialSlice;
                this.lowerImageBot = this.sagittalSlice
            } else {
                if (this.container.params.mainView.toLowerCase() === "sagittal") {
                    this.mainImage = this.sagittalSlice;
                    this.lowerImageTop = this.coronalSlice;
                    this.lowerImageBot = this.axialSlice
                } else {
                    this.mainImage = this.axialSlice;
                    this.lowerImageTop = this.sagittalSlice;
                    this.lowerImageBot = this.coronalSlice
                }
            }
        }
        this.canvas.addEventListener("mousemove", this.listenerMouseMove, false);
        this.canvas.addEventListener("mousedown", this.listenerMouseDown, false);
        this.canvas.addEventListener("mouseout", this.listenerMouseOut, false);
        this.canvas.addEventListener("mouseup", this.listenerMouseUp, false);
        document.addEventListener("keydown", this.listenerKeyDown, true);
        document.addEventListener("keyup", this.listenerKeyUp, true);
        this.canvas.addEventListener("contextmenu", this.listenerContextMenu, false);
        this.canvas.addEventListener("touchmove", this.listenerTouchMove, false);
        this.canvas.addEventListener("touchstart", this.listenerMouseDown, false);
        this.canvas.addEventListener("touchend", this.listenerMouseUp, false);
        this.canvas.addEventListener("dblclick", this.listenerMouseDoubleClick, false);
        if (!this.container.orthogonal) {
            this.sliceSliderControl = $(this.container.sliderControlHtml.find("input"));
            this.sliceSliderControl.on("input change", function () {
                b.sliceSliderControlChanged()
            })
        }
        this.addScroll();
        this.setLongestDim(this.volume);
        this.calculateScreenSliceTransforms(this);
        this.currentCoord.setCoordinate(floorFast(this.volume.getXDim() / 2), floorFast(this.volume.getYDim() / 2), floorFast(this.volume.getZDim() / 2));
        this.updateOffsetRect();
        this.bgColor = $("body").css("background-color");
        if ((this.bgColor === "rgba(0, 0, 0, 0)") || ((this.bgColor === "transparent"))) {
            this.bgColor = "rgba(255, 255, 255, 255)"
        }
        this.context.fillStyle = this.bgColor;
        this.context.fillRect(0, 0, this.canvas.offsetWidth, this.canvas.offsetHeight);
        this.initialized = true;
        this.drawViewer();
        this.container.toolbar.buildToolbar();
        this.container.toolbar.updateImageButtons();
        this.updateWindowTitle();
        this.goToInitialCoordinate();
        if (!this.container.loadNext()) {
            this.loadAtlas()
        }
        this.updateSliceSliderControl()
    }
};
papaya.viewer.Viewer.prototype.addScroll = function () {
    if (!this.container.nestedViewer) {
        if (window.addEventListener) {
            window.addEventListener("DOMMouseScroll", this.listenerScroll, false)
        }
        window.onmousewheel = document.onmousewheel = this.listenerScroll
    }
};
papaya.viewer.Viewer.prototype.removeScroll = function () {
    window.removeEventListener("DOMMouseScroll", this.listenerScroll, false);
    window.onmousewheel = document.onmousewheel = null
};
papaya.viewer.Viewer.prototype.updateOffsetRect = function () {
    this.canvasRect = getOffsetRect(this.canvas)
};
papaya.viewer.Viewer.prototype.initializeOverlay = function () {
    var b, a;
    if (this.loadingVolume.hasError()) {
        this.container.display.drawError(this.loadingVolume.errorMessage);
        this.container.clearParams();
        this.loadingVolume = null
    } else {
        b = this.container.params[this.loadingVolume.fileName];
        a = (b && b.parametric);
        this.screenVolumes[this.screenVolumes.length] = new papaya.viewer.ScreenVolume(this.loadingVolume, this.container.params, (a ? papaya.viewer.ColorTable.PARAMETRIC_COLOR_TABLES[0].name : this.getNextColorTable()), false);
        this.setCurrentScreenVol(this.screenVolumes.length - 1);
        this.drawViewer(true);
        this.container.toolbar.buildToolbar();
        this.container.toolbar.updateImageButtons();
        if (a) {
            this.screenVolumes[this.screenVolumes.length - 1].findImageRange();
            if (this.screenVolumes[this.screenVolumes.length - 1].volume.header.imageRange.imageMin < 0) {
                this.screenVolumes[this.screenVolumes.length] = new papaya.viewer.ScreenVolume(this.loadingVolume, this.container.params, papaya.viewer.ColorTable.PARAMETRIC_COLOR_TABLES[1].name, false, true);
                this.setCurrentScreenVol(this.screenVolumes.length - 1);
                this.drawViewer(true);
                this.container.toolbar.buildToolbar();
                this.container.toolbar.updateImageButtons()
            }
        }
        this.updateWindowTitle();
        this.goToInitialCoordinate();
        this.loadingVolume = null;
        if (!this.container.loadNext()) {
            this.loadAtlas()
        }
    }
};
papaya.viewer.Viewer.prototype.loadAtlas = function () {
    var a, b;
    a = (typeof papaya.data);
    if (a !== "undefined") {
        b = (typeof papaya.data.Atlas);
        if (b !== "undefined") {
            this.atlas = new papaya.viewer.Atlas(papaya.data.Atlas, this.container, bind(this, papaya.viewer.Viewer.prototype.atlasLoaded))
        }
    }
};
papaya.viewer.Viewer.prototype.updatePosition = function (g, f, e, b) {
    var d, c, a;
    f = f - this.canvasRect.left;
    e = e - this.canvasRect.top;
    if (this.insideScreenSlice(g.axialSlice, f, e, g.volume.getXDim(), g.volume.getYDim())) {
        if (!this.isDragging || (this.draggingSliceDir === papaya.viewer.ScreenSlice.DIRECTION_AXIAL)) {
            d = this.convertScreenToImageCoordinateX(f, g.axialSlice);
            c = this.convertScreenToImageCoordinateY(e, g.axialSlice);
            if ((d !== g.currentCoord.x) || (c !== g.currentCoord.y)) {
                g.currentCoord.x = d;
                g.currentCoord.y = c;
                this.draggingSliceDir = papaya.viewer.ScreenSlice.DIRECTION_AXIAL
            }
        }
    } else {
        if (this.insideScreenSlice(g.coronalSlice, f, e, g.volume.getXDim(), g.volume.getZDim())) {
            if (!this.isDragging || (this.draggingSliceDir === papaya.viewer.ScreenSlice.DIRECTION_CORONAL)) {
                d = this.convertScreenToImageCoordinateX(f, g.coronalSlice);
                c = this.convertScreenToImageCoordinateY(e, g.coronalSlice);
                if ((d !== g.currentCoord.x) || (c !== g.currentCoord.y)) {
                    g.currentCoord.x = d;
                    g.currentCoord.z = c;
                    this.draggingSliceDir = papaya.viewer.ScreenSlice.DIRECTION_CORONAL
                }
            }
        } else {
            if (this.insideScreenSlice(g.sagittalSlice, f, e, g.volume.getYDim(), g.volume.getZDim())) {
                if (!this.isDragging || (this.draggingSliceDir === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL)) {
                    d = this.convertScreenToImageCoordinateX(f, g.sagittalSlice);
                    c = this.convertScreenToImageCoordinateY(e, g.sagittalSlice);
                    if ((d !== g.currentCoord.x) || (c !== g.currentCoord.y)) {
                        a = d;
                        g.currentCoord.y = a;
                        g.currentCoord.z = c;
                        this.draggingSliceDir = papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL
                    }
                }
            }
        }
    }
    g.drawViewer(false, b)
};
papaya.viewer.Viewer.prototype.convertScreenToImageCoordinateX = function (b, a) {
    return validDimBounds(floorFast((b - a.finalTransform[0][2]) / a.finalTransform[0][0]), a.xDim)
};
papaya.viewer.Viewer.prototype.convertScreenToImageCoordinateY = function (b, a) {
    return validDimBounds(floorFast((b - a.finalTransform[1][2]) / a.finalTransform[1][1]), a.yDim)
};
papaya.viewer.Viewer.prototype.updateCursorPosition = function (g, f, d) {
    var c, b, a, e;
    if (this.container.display) {
        f = f - this.canvasRect.left;
        d = d - this.canvasRect.top;
        if (this.insideScreenSlice(g.axialSlice, f, d, g.volume.getXDim(), g.volume.getYDim())) {
            c = this.convertScreenToImageCoordinateX(f, g.axialSlice);
            b = this.convertScreenToImageCoordinateY(d, g.axialSlice);
            a = g.axialSlice.currentSlice;
            e = true
        } else {
            if (this.insideScreenSlice(g.coronalSlice, f, d, g.volume.getXDim(), g.volume.getZDim())) {
                c = this.convertScreenToImageCoordinateX(f, g.coronalSlice);
                a = this.convertScreenToImageCoordinateY(d, g.coronalSlice);
                b = g.coronalSlice.currentSlice;
                e = true
            } else {
                if (this.insideScreenSlice(g.sagittalSlice, f, d, g.volume.getYDim(), g.volume.getZDim())) {
                    b = this.convertScreenToImageCoordinateX(f, g.sagittalSlice);
                    a = this.convertScreenToImageCoordinateY(d, g.sagittalSlice);
                    c = g.sagittalSlice.currentSlice;
                    e = true
                }
            }
        }
        if (e) {
            this.container.display.drawDisplay(c, b, a)
        } else {
            this.container.display.drawEmptyDisplay()
        }
    }
};
papaya.viewer.Viewer.prototype.insideScreenSlice = function (f, d, a, h, c) {
    var e, b, i, g;
    e = roundFast(f.screenTransform[0][2]);
    b = roundFast(f.screenTransform[0][2] + h * f.screenTransform[0][0]);
    i = roundFast(f.screenTransform[1][2]);
    g = roundFast(f.screenTransform[1][2] + c * f.screenTransform[1][1]);
    return ((d >= e) && (d < b) && (a >= i) && (a < g))
};
papaya.viewer.Viewer.prototype.drawEmptyViewer = function () {
    var a, c, e, b, d;
    this.context.fillStyle = "#000000";
    this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
    this.context.fillStyle = "#AAAAAA";
    c = 18;
    this.context.font = c + "px Arial";
    a = this.canvas.height - 22;
    e = "Bienvenue dans l'atlas CRONOR ORL par Timothee RUEF";
    b = this.context.measureText(e);
    d = b.width;
    this.context.fillText(e, (this.canvas.width / 2) - (d / 2), a);
    if (this.canvas.width > 900) {
        c = 14;
        this.context.font = c + "px Arial";
        a = this.canvas.height - 20;
        e = "Supported formats: NIFTI (.nii, .nii.gz)";
        this.context.fillText(e, 20, a);
        c = 14;
        this.context.font = c + "px Arial";
        a = this.canvas.height - 20;
        e = "Papaya v" + (PAPAYA_VERSION_ID || "Dev") + " (build " + (PAPAYA_BUILD_NUM !== undefined ? PAPAYA_BUILD_NUM : "Dev") + ")";
        b = this.context.measureText(e);
        d = b.width;
        this.context.fillText(e, this.canvas.width - d - 20, a)
    }
};
papaya.viewer.Viewer.prototype.drawViewer = function (c, b) {
    var e, n, j, d, l, h, i, g, k, a, f, m;
    if (!this.initialized) {
        this.drawEmptyViewer();
        return
    }
    this.context.save();
    if (b) {
        this.axialSlice.repaint(this.currentCoord.z, c, this.worldSpace);
        this.coronalSlice.repaint(this.currentCoord.y, c, this.worldSpace);
        this.sagittalSlice.repaint(this.currentCoord.x, c, this.worldSpace)
    } else {
        if (c || (this.draggingSliceDir !== papaya.viewer.ScreenSlice.DIRECTION_AXIAL)) {
            this.axialSlice.updateSlice(this.currentCoord.z, c, this.worldSpace)
        }
        if (c || (this.draggingSliceDir !== papaya.viewer.ScreenSlice.DIRECTION_CORONAL)) {
            this.coronalSlice.updateSlice(this.currentCoord.y, c, this.worldSpace)
        }
        if (c || (this.draggingSliceDir !== papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL)) {
            this.sagittalSlice.updateSlice(this.currentCoord.x, c, this.worldSpace)
        }
    }
    this.context.fillStyle = papaya.viewer.Viewer.BACKGROUND_COLOR;
    this.context.setTransform(1, 0, 0, 1, 0, 0);
    this.context.fillRect(this.mainImage.screenOffsetX, this.mainImage.screenOffsetY, this.mainImage.screenDim, this.mainImage.screenDim);
    this.context.save();
    this.context.beginPath();
    this.context.rect(this.mainImage.screenOffsetX, this.mainImage.screenOffsetY, this.mainImage.screenDim, this.mainImage.screenDim);
    this.context.clip();
    this.context.setTransform(this.mainImage.finalTransform[0][0], 0, 0, this.mainImage.finalTransform[1][1], this.mainImage.finalTransform[0][2], this.mainImage.finalTransform[1][2]);
    this.context.drawImage(this.mainImage.canvasMain, 0, 0);
    this.context.restore();
    if (this.container.orthogonal) {
        this.context.setTransform(1, 0, 0, 1, 0, 0);
        this.context.fillRect(this.lowerImageBot.screenOffsetX, this.lowerImageBot.screenOffsetY, this.lowerImageBot.screenDim, this.lowerImageBot.screenDim);
        this.context.save();
        this.context.beginPath();
        this.context.rect(this.lowerImageBot.screenOffsetX, this.lowerImageBot.screenOffsetY, this.lowerImageBot.screenDim, this.lowerImageBot.screenDim);
        this.context.clip();
        this.context.setTransform(this.lowerImageBot.finalTransform[0][0], 0, 0, this.lowerImageBot.finalTransform[1][1], this.lowerImageBot.finalTransform[0][2], this.lowerImageBot.finalTransform[1][2]);
        this.context.drawImage(this.lowerImageBot.canvasMain, 0, 0);
        this.context.restore();
        this.context.setTransform(1, 0, 0, 1, 0, 0);
        this.context.fillRect(this.lowerImageTop.screenOffsetX, this.lowerImageTop.screenOffsetY, this.lowerImageTop.screenDim, this.lowerImageTop.screenDim);
        this.context.save();
        this.context.beginPath();
        this.context.rect(this.lowerImageTop.screenOffsetX, this.lowerImageTop.screenOffsetY, this.lowerImageTop.screenDim, this.lowerImageTop.screenDim);
        this.context.clip();
        this.context.setTransform(this.lowerImageTop.finalTransform[0][0], 0, 0, this.lowerImageTop.finalTransform[1][1], this.lowerImageTop.finalTransform[0][2], this.lowerImageTop.finalTransform[1][2]);
        this.context.drawImage(this.lowerImageTop.canvasMain, 0, 0);
        this.context.restore()
    }
    if (this.container.preferences.showOrientation === "Yes") {
        this.context.setTransform(1, 0, 0, 1, 0, 0);
        this.context.fillStyle = this.getOrientationCertaintyColor();
        this.context.font = papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE + "px Arial";
        i = this.context.measureText("X");
        g = i.width;
        if (this.mainImage === this.axialSlice) {
            k = papaya.viewer.Viewer.ORIENTATION_MARKER_ANTERIOR;
            a = papaya.viewer.Viewer.ORIENTATION_MARKER_POSTERIOR;
            f = papaya.viewer.Viewer.ORIENTATION_MARKER_LEFT;
            m = papaya.viewer.Viewer.ORIENTATION_MARKER_RIGHT
        } else {
            if (this.mainImage === this.coronalSlice) {
                k = papaya.viewer.Viewer.ORIENTATION_MARKER_SUPERIOR;
                a = papaya.viewer.Viewer.ORIENTATION_MARKER_INFERIOR;
                f = papaya.viewer.Viewer.ORIENTATION_MARKER_LEFT;
                m = papaya.viewer.Viewer.ORIENTATION_MARKER_RIGHT
            } else {
                if (this.mainImage === this.sagittalSlice) {
                    k = papaya.viewer.Viewer.ORIENTATION_MARKER_SUPERIOR;
                    a = papaya.viewer.Viewer.ORIENTATION_MARKER_INFERIOR;
                    f = papaya.viewer.Viewer.ORIENTATION_MARKER_ANTERIOR;
                    m = papaya.viewer.Viewer.ORIENTATION_MARKER_POSTERIOR
                }
            }
        }
        e = this.mainImage.screenOffsetX;
        console.log(this);
        n = this.mainImage.screenOffsetX + this.mainImage.screenDim;
        j = Math.round(n / 2);
        d = this.mainImage.screenOffsetY;
        l = this.mainImage.screenOffsetY + this.mainImage.screenDim;
        h = Math.round(l / 2);
        this.context.fillText(k, j - (g / 2), d + papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE * 1.5);
        this.context.fillText(a, j - (g / 2), l - papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE);
        this.context.fillText(f, e + papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE, h + (papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE * 0.5));
        this.context.fillText(m, n - 1.5 * papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE, h + (papaya.viewer.Viewer.ORIENTATION_MARKER_SIZE * 0.5))
    }
    if (this.container.preferences.showCrosshairs !== "None") {
        this.drawCrosshairs()
    }
    if (this.container.display) {
        this.container.display.drawDisplay(this.currentCoord.x, this.currentCoord.y, this.currentCoord.z, this.getCurrentValueAt(this.currentCoord.x, this.currentCoord.y, this.currentCoord.z))
    }
};
papaya.viewer.Viewer.prototype.drawCrosshairs = function () {
    var f, c, e, b, d, a;
    this.context.setTransform(1, 0, 0, 1, 0, 0);
    this.context.strokeStyle = papaya.viewer.Viewer.CROSSHAIRS_COLOR;
    this.context.lineWidth = 1;
    if ((((this.mainImage !== this.axialSlice) && (this.container.preferences.showCrosshairs !== "Main")) || ((this.mainImage === this.axialSlice) && (this.container.preferences.showCrosshairs !== "Lower") && this.toggleMainCrosshairs)) && (this.container.orthogonal || (this.axialSlice === this.mainImage))) {
        this.context.save();
        this.context.beginPath();
        this.context.rect(this.axialSlice.screenOffsetX, this.axialSlice.screenOffsetY, this.axialSlice.screenDim, this.axialSlice.screenDim);
        this.context.closePath();
        this.context.clip();
        this.context.beginPath();
        f = (this.axialSlice.finalTransform[0][2] + (this.currentCoord.x + 0.5) * this.axialSlice.finalTransform[0][0]);
        c = (this.axialSlice.finalTransform[1][2]);
        e = (this.axialSlice.finalTransform[1][2] + this.axialSlice.yDim * this.axialSlice.finalTransform[1][1]);
        this.context.moveTo(f, c);
        this.context.lineTo(f, e);
        b = (this.axialSlice.finalTransform[1][2] + (this.currentCoord.y + 0.5) * this.axialSlice.finalTransform[1][1]);
        d = (this.axialSlice.finalTransform[0][2]);
        a = (this.axialSlice.finalTransform[0][2] + this.axialSlice.xDim * this.axialSlice.finalTransform[0][0]);
        this.context.moveTo(d, b);
        this.context.lineTo(a, b);
        this.context.closePath();
        this.context.stroke();
        this.context.restore()
    }
    if ((((this.mainImage !== this.coronalSlice) && (this.container.preferences.showCrosshairs !== "Main")) || ((this.mainImage === this.coronalSlice) && (this.container.preferences.showCrosshairs !== "Lower") && this.toggleMainCrosshairs)) && (this.container.orthogonal || (this.coronalSlice === this.mainImage))) {
        this.context.save();
        this.context.beginPath();
        this.context.rect(this.coronalSlice.screenOffsetX, this.coronalSlice.screenOffsetY, this.coronalSlice.screenDim, this.coronalSlice.screenDim);
        this.context.closePath();
        this.context.clip();
        this.context.beginPath();
        f = (this.coronalSlice.finalTransform[0][2] + (this.currentCoord.x + 0.5) * this.coronalSlice.finalTransform[0][0]);
        c = (this.coronalSlice.finalTransform[1][2]);
        e = (this.coronalSlice.finalTransform[1][2] + this.coronalSlice.yDim * this.coronalSlice.finalTransform[1][1]);
        this.context.moveTo(f, c);
        this.context.lineTo(f, e);
        b = (this.coronalSlice.finalTransform[1][2] + (this.currentCoord.z + 0.5) * this.coronalSlice.finalTransform[1][1]);
        d = (this.coronalSlice.finalTransform[0][2]);
        a = (this.coronalSlice.finalTransform[0][2] + this.coronalSlice.xDim * this.coronalSlice.finalTransform[0][0]);
        this.context.moveTo(d, b);
        this.context.lineTo(a, b);
        this.context.closePath();
        this.context.stroke();
        this.context.restore()
    }
    if ((((this.mainImage !== this.sagittalSlice) && (this.container.preferences.showCrosshairs !== "Main")) || ((this.mainImage === this.sagittalSlice) && (this.container.preferences.showCrosshairs !== "Lower") && this.toggleMainCrosshairs)) && (this.container.orthogonal || (this.sagittalSlice === this.mainImage))) {
        this.context.save();
        this.context.beginPath();
        this.context.rect(this.sagittalSlice.screenOffsetX, this.sagittalSlice.screenOffsetY, this.sagittalSlice.screenDim, this.sagittalSlice.screenDim);
        this.context.closePath();
        this.context.clip();
        this.context.beginPath();
        f = (this.sagittalSlice.finalTransform[0][2] + (this.currentCoord.y + 0.5) * this.sagittalSlice.finalTransform[0][0]);
        c = (this.sagittalSlice.finalTransform[1][2]);
        e = (this.sagittalSlice.finalTransform[1][2] + this.sagittalSlice.yDim * this.sagittalSlice.finalTransform[1][1]);
        this.context.moveTo(f, c);
        this.context.lineTo(f, e);
        b = (this.sagittalSlice.finalTransform[1][2] + (this.currentCoord.z + 0.5) * this.sagittalSlice.finalTransform[1][1]);
        d = (this.sagittalSlice.finalTransform[0][2]);
        a = (this.sagittalSlice.finalTransform[0][2] + this.sagittalSlice.xDim * this.sagittalSlice.finalTransform[0][0]);
        this.context.moveTo(d, b);
        this.context.lineTo(a, b);
        this.context.closePath();
        this.context.stroke();
        this.context.restore()
    }
};
papaya.viewer.Viewer.prototype.calculateScreenSliceTransforms = function () {
    this.viewerDim = this.canvas.height;
    this.getTransformParameters(this.mainImage, this.viewerDim, false);
    this.mainImage.screenTransform[0][2] += this.mainImage.screenOffsetX = 0;
    this.mainImage.screenTransform[1][2] += this.mainImage.screenOffsetY = 0;
    this.getTransformParameters(this.lowerImageBot, this.viewerDim, true);
    this.lowerImageBot.screenTransform[0][2] += this.lowerImageBot.screenOffsetX = (this.viewerDim + (papaya.viewer.Viewer.GAP));
    this.lowerImageBot.screenTransform[1][2] += this.lowerImageBot.screenOffsetY = (((this.viewerDim - papaya.viewer.Viewer.GAP) / 2) + (papaya.viewer.Viewer.GAP));
    this.getTransformParameters(this.lowerImageTop, this.viewerDim, true);
    this.lowerImageTop.screenTransform[0][2] += this.lowerImageTop.screenOffsetX = (this.viewerDim + (papaya.viewer.Viewer.GAP));
    this.lowerImageTop.screenTransform[1][2] += this.lowerImageTop.screenOffsetY = 0;
    this.axialSlice.updateFinalTransform();
    this.coronalSlice.updateFinalTransform();
    this.sagittalSlice.updateFinalTransform()
};
papaya.viewer.Viewer.prototype.getTransformParameters = function (g, a, f) {
    var h, e, d, c, b;
    h = f ? 2 : 1;
    if (g.getRealWidth() > g.getRealHeight()) {
        e = (((f ? a - papaya.viewer.Viewer.GAP : a) / this.longestDim) / h) * (g.getXSize() / this.longestDimSize);
        d = ((((f ? a - papaya.viewer.Viewer.GAP : a) / this.longestDim) * g.getYXratio()) / h) * (g.getXSize() / this.longestDimSize)
    } else {
        e = ((((f ? a - papaya.viewer.Viewer.GAP : a) / this.longestDim) * g.getXYratio()) / h) * (g.getYSize() / this.longestDimSize);
        d = (((f ? a - papaya.viewer.Viewer.GAP : a) / this.longestDim) / h) * (g.getYSize() / this.longestDimSize)
    }
    c = (((f ? a - papaya.viewer.Viewer.GAP : a) / h) - (g.getXDim() * e)) / 2;
    b = (((f ? a - papaya.viewer.Viewer.GAP : a) / h) - (g.getYDim() * d)) / 2;
    g.screenDim = (f ? (a - papaya.viewer.Viewer.GAP) / 2 : a);
    g.screenTransform[0][0] = e;
    g.screenTransform[1][1] = d;
    g.screenTransform[0][2] = c;
    g.screenTransform[1][2] = b
};
papaya.viewer.Viewer.prototype.setLongestDim = function (a) {
    this.longestDim = a.getXDim();
    this.longestDimSize = a.getXSize();
    if ((a.getYDim() * a.getYSize()) > (this.longestDim * this.longestDimSize)) {
        this.longestDim = a.getYDim();
        this.longestDimSize = a.getYSize()
    }
    if ((a.getZDim() * a.getZSize()) > (this.longestDim * this.longestDimSize)) {
        this.longestDim = a.getZDim();
        this.longestDimSize = a.getZSize()
    }
};
papaya.viewer.Viewer.prototype.keyDownEvent = function (b) {
    var c, a;
    this.keyPressIgnored = false;
    if (this.container.toolbar.isShowingMenus()) {
        return
    }
    if (((papayaContainers.length > 1) || papayaContainers[0].nestedViewer) && (papayaLastHoveredViewer !== this)) {
        return
    }
    c = getKeyCode(b);
    if (isControlKey(b)) {
        this.isControlKeyDown = true
    } else {
        if (isAltKey(b)) {
            this.isAltKeyDown = true
        } else {
            if (isShiftKey(b)) {
                this.isShiftKeyDown = true
            } else {
                if (c === papaya.viewer.Viewer.KEYCODE_ROTATE_VIEWS) {
                    this.rotateViews()
                } else {
                    if (c === papaya.viewer.Viewer.KEYCODE_CENTER) {
                        a = new papaya.core.Coordinate(Math.floor(this.volume.header.imageDimensions.xDim / 2), Math.floor(this.volume.header.imageDimensions.yDim / 2), Math.floor(this.volume.header.imageDimensions.zDim / 2));
                        this.gotoCoordinate(a)
                    } else {
                        if (c === papaya.viewer.Viewer.KEYCODE_ORIGIN) {
                            this.gotoCoordinate(this.volume.header.origin)
                        } else {
                            if (c === papaya.viewer.Viewer.KEYCODE_ARROW_UP) {
                                this.incrementCoronal(false)
                            } else {
                                if (c === papaya.viewer.Viewer.KEYCODE_ARROW_DOWN) {
                                    this.incrementCoronal(true)
                                } else {
                                    if (c === papaya.viewer.Viewer.KEYCODE_ARROW_LEFT) {
                                        this.incrementSagittal(true)
                                    } else {
                                        if (c === papaya.viewer.Viewer.KEYCODE_ARROW_RIGHT) {
                                            this.incrementSagittal(false)
                                        } else {
                                            if ((c === papaya.viewer.Viewer.KEYCODE_PAGE_DOWN) || (c === papaya.viewer.Viewer.KEYCODE_FORWARD_SLASH)) {
                                                this.incrementAxial(true)
                                            } else {
                                                if ((c === papaya.viewer.Viewer.KEYCODE_PAGE_UP) || (c === papaya.viewer.Viewer.KEYCODE_SINGLE_QUOTE)) {
                                                    this.incrementAxial(false)
                                                } else {
                                                    if (c === papaya.viewer.Viewer.KEYCODE_INCREMENT_MAIN) {
                                                        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                                                            this.incrementAxial(false)
                                                        } else {
                                                            if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                                                                this.incrementCoronal(false)
                                                            } else {
                                                                if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                                                    this.incrementSagittal(true)
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if (c === papaya.viewer.Viewer.KEYCODE_DECREMENT_MAIN) {
                                                            if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                                                                this.incrementAxial(true)
                                                            } else {
                                                                if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                                                                    this.incrementCoronal(true)
                                                                } else {
                                                                    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                                                        this.incrementSagittal(false)
                                                                    }
                                                                }
                                                            }
                                                        } else {
                                                            if (c === papaya.viewer.Viewer.KEYCODE_TOGGLE_CROSSHAIRS) {
                                                                if ((this.container.preferences.showCrosshairs === "All") || (this.container.preferences.showCrosshairs === "Main")) {
                                                                    this.toggleMainCrosshairs = !this.toggleMainCrosshairs;
                                                                    this.drawViewer(true)
                                                                }
                                                            } else {
                                                                if (c === papaya.viewer.Viewer.KEYCODE_SERIES_FORWARD) {
                                                                    this.currentScreenVolume.incrementTimepoint();
                                                                    this.timepointChanged()
                                                                } else {
                                                                    if (c === papaya.viewer.Viewer.KEYCODE_SERIES_BACK) {
                                                                        this.currentScreenVolume.decrementTimepoint();
                                                                        this.timepointChanged()
                                                                    } else {
                                                                        this.keyPressIgnored = true
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (!this.keyPressIgnored) {
        b.handled = true;
        b.preventDefault()
    }
};
papaya.viewer.Viewer.prototype.keyUpEvent = function (a) {
    if ((papayaContainers.length > 1) && (papayaLastHoveredViewer !== this)) {
        return
    }
    this.isControlKeyDown = false;
    this.isAltKeyDown = false;
    this.isShiftKeyDown = false;
    if (!this.keyPressIgnored) {
        a.handled = true;
        a.preventDefault()
    }
};
papaya.viewer.Viewer.prototype.rotateViews = function () {
    var a;
    a = this.lowerImageBot;
    this.lowerImageBot = this.lowerImageTop;
    this.lowerImageTop = this.mainImage;
    this.mainImage = a;
    this.calculateScreenSliceTransforms();
    this.drawViewer();
    this.updateSliceSliderControl()
};
papaya.viewer.Viewer.prototype.timepointChanged = function () {
    this.drawViewer(true);
    this.updateWindowTitle()
};
papaya.viewer.Viewer.prototype.resetUpdateTimer = function (a) {
    var b = this;
    if (this.updateTimer !== null) {
        window.clearTimeout(this.updateTimer);
        this.updateTimer = null;
        this.updateTimerEvent = null
    }
    if (a !== null) {
        this.updateTimerEvent = a;
        this.updateTimer = window.setTimeout(bind(b, function () {
            this.updatePosition(this, getMousePositionX(b.updateTimerEvent), getMousePositionY(b.updateTimerEvent))
        }), papaya.viewer.Viewer.UPDATE_TIMER_INTERVAL)
    }
};
papaya.viewer.Viewer.prototype.mouseDownEvent = function (a) {
    a.stopPropagation();
    a.preventDefault();
    console.log("down");
    if ((a.target.nodeName === "IMG") || (a.target.nodeName === "CANVAS")) {
        if (a.handled !== true) {
            this.container.toolbar.closeAllMenus();
            this.previousMousePosition.x = getMousePositionX(a);
            this.previousMousePosition.y = getMousePositionY(a);
            this.findClickedSlice(this, this.previousMousePosition.x, this.previousMousePosition.y);
            if ((a.which === 3) || this.isControlKeyDown) {
                this.isWindowControl = true;
                this.container.toolbar.showImageMenu(this.getCurrentScreenVolIndex())
            } else {
                if (this.isAltKeyDown && this.selectedSlice) {
                    this.isZoomMode = true;
                    if (this.isZooming() && this.isShiftKeyDown) {
                        this.isPanning = true;
                        this.setStartPanLocation(this.convertScreenToImageCoordinateX(this.previousMousePosition.x, this.selectedSlice), this.convertScreenToImageCoordinateY(this.previousMousePosition.y, this.selectedSlice), this.selectedSlice.sliceDirection)
                    } else {
                        this.setZoomLocation()
                    }
                } else {
                    this.updatePosition(this, getMousePositionX(a), getMousePositionY(a), false);
                    this.resetUpdateTimer(a)
                }
            }
            this.isDragging = true;
            a.handled = true
        }
    }
};
papaya.viewer.Viewer.prototype.mouseUpEvent = function (a) {
    a.stopPropagation();
    a.preventDefault();
    if ((a.target.nodeName === "IMG") || (a.target.nodeName === "CANVAS")) {
        if (a.handled !== true) {
            if (!this.isWindowControl && !this.isZoomMode) {
                this.updatePosition(this, getMousePositionX(a), getMousePositionY(a))
            }
            this.zoomFactorPrevious = this.zoomFactor;
            this.isDragging = false;
            this.isWindowControl = false;
            this.isZoomMode = false;
            this.isPanning = false;
            this.selectedSlice = null;
            a.handled = true
        }
    }
    this.updateWindowTitle();
    this.container.toolbar.closeAllMenus()
};
papaya.viewer.Viewer.prototype.findClickedSlice = function (c, b, a) {
    b = b - this.canvasRect.left;
    a = a - this.canvasRect.top;
    if (this.insideScreenSlice(c.axialSlice, b, a, c.volume.getXDim(), c.volume.getYDim())) {
        this.selectedSlice = this.axialSlice
    } else {
        if (this.insideScreenSlice(c.coronalSlice, b, a, c.volume.getXDim(), c.volume.getZDim())) {
            this.selectedSlice = this.coronalSlice
        } else {
            if (this.insideScreenSlice(c.sagittalSlice, b, a, c.volume.getYDim(), c.volume.getZDim())) {
                this.selectedSlice = this.sagittalSlice
            } else {
                this.selectedSlice = null
            }
        }
    }
};
papaya.viewer.Viewer.prototype.mouseMoveEvent = function (d) {
    d.preventDefault();
    var c, a, b;
    papayaLastHoveredViewer = this;
    c = getMousePositionX(d);
    a = getMousePositionY(d);
    if (this.isDragging) {
        if (this.isWindowControl) {
            this.windowLevelChanged(this.previousMousePosition.x - c, this.previousMousePosition.y - a);
            this.previousMousePosition.x = c;
            this.previousMousePosition.y = a
        } else {
            if (this.isPanning) {
                this.setCurrentPanLocation(this.convertScreenToImageCoordinateX(c, this.selectedSlice), this.convertScreenToImageCoordinateY(a, this.selectedSlice), this.selectedSlice.sliceDirection)
            } else {
                if (this.isZoomMode) {
                    b = ((this.previousMousePosition.y - a) * 0.05);
                    this.setZoomFactor(this.zoomFactorPrevious - b);
                    this.axialSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocY, this.panAmountX, this.panAmountY, this);
                    this.coronalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocZ, this.panAmountX, this.panAmountZ, this);
                    this.sagittalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocY, this.zoomLocZ, this.panAmountY, this.panAmountZ, this);
                    this.drawViewer(true)
                } else {
                    this.resetUpdateTimer(null);
                    this.updatePosition(this, getMousePositionX(d), getMousePositionY(d))
                }
            }
        }
    } else {
        this.updateCursorPosition(this, getMousePositionX(d), getMousePositionY(d));
        this.isZoomMode = false
    }
};
papaya.viewer.Viewer.prototype.mouseDoubleClickEvent = function () {
    if (this.isAltKeyDown) {
        this.zoomFactorPrevious = 1;
        this.setZoomFactor(1)
    }
};
papaya.viewer.Viewer.prototype.mouseOutEvent = function () {
    papayaLastHoveredViewer = null;
    if (this.container.display) {
        this.container.display.drawEmptyDisplay()
    }
};
papaya.viewer.Viewer.prototype.touchMoveEvent = function (a) {
    this.updatePosition(this, getMousePositionX(a), getMousePositionY(a), true);
    this.resetUpdateTimer(a);
    a.preventDefault()
};
papaya.viewer.Viewer.prototype.windowLevelChanged = function (a, c) {
    var b, d, e, f;
    b = this.currentScreenVolume.screenMax - this.currentScreenVolume.screenMin;
    d = b * 0.025;
    if (Math.abs(a) > Math.abs(c)) {
        e = this.currentScreenVolume.screenMin + (d * signum(a));
        f = this.currentScreenVolume.screenMax + (-1 * d * signum(a));
        if (f <= e) {
            e = this.currentScreenVolume.screenMin;
            f = this.currentScreenVolume.screenMin
        }
    } else {
        e = this.currentScreenVolume.screenMin + (d * signum(c));
        f = this.currentScreenVolume.screenMax + (d * signum(c))
    }
    this.currentScreenVolume.setScreenRange(e, f);
    this.container.toolbar.updateImageMenuRange(this.getCurrentScreenVolIndex(), parseFloat(e.toPrecision(7)), parseFloat(f.toPrecision(7)));
    this.drawViewer(true)
};
papaya.viewer.Viewer.prototype.gotoCoordinate = function (a) {
    this.currentCoord.x = a.x;
    this.currentCoord.y = a.y;
    this.currentCoord.z = a.z;
    this.drawViewer(true);
    this.updateSliceSliderControl()
};
papaya.viewer.Viewer.prototype.resizeViewer = function (a) {
    this.canvas.width = a.width;
    this.canvas.height = a.height;
    if (this.initialized) {
        this.calculateScreenSliceTransforms();
        this.canvasRect = this.canvas.getBoundingClientRect();
        this.drawViewer(true)
    }
};
papaya.viewer.Viewer.prototype.getWorldCoordinateAtIndex = function (c, b, a, d) {
    d.setCoordinate((c - this.volume.header.origin.x) * this.volume.header.voxelDimensions.xSize, (this.volume.header.origin.y - b) * this.volume.header.voxelDimensions.ySize, (this.volume.header.origin.z - a) * this.volume.header.voxelDimensions.zSize);
    return d
};
papaya.viewer.Viewer.prototype.getIndexCoordinateAtWorld = function (c, b, a, d) {
    d.setCoordinate((c / this.volume.header.voxelDimensions.xSize) + this.volume.header.origin.x, -1 * ((b / this.volume.header.voxelDimensions.ySize) - this.volume.header.origin.y), -1 * ((a / this.volume.header.voxelDimensions.zSize) - this.volume.header.origin.z), true);
    return d
};
papaya.viewer.Viewer.prototype.getNextColorTable = function () {
    var a = (this.screenVolumes.length - 1) % papaya.viewer.ColorTable.OVERLAY_COLOR_TABLES.length;
    return papaya.viewer.ColorTable.OVERLAY_COLOR_TABLES[a].name
};
papaya.viewer.Viewer.prototype.getCurrentValueAt = function (c, b, a) {
    if (this.currentScreenVolume.isOverlay()) {
        return this.currentScreenVolume.volume.getVoxelAtCoordinate((c - this.volume.header.origin.x) * this.volume.header.voxelDimensions.xSize, (this.volume.header.origin.y - b) * this.volume.header.voxelDimensions.ySize, (this.volume.header.origin.z - a) * this.volume.header.voxelDimensions.zSize, this.currentScreenVolume.currentTimepoint, false)
    }
    return this.currentScreenVolume.volume.getVoxelAtIndex(c, b, a, this.currentScreenVolume.currentTimepoint, true)
};
papaya.viewer.Viewer.prototype.resetViewer = function () {
    this.initialized = false;
    this.loadingVolume = null;
    this.volume = new papaya.volume.Volume(this.container.display);
    this.screenVolumes = [];
    this.currentScreenVolume = null;
    this.axialSlice = null;
    this.coronalSlice = null;
    this.sagittalSlice = null;
    this.mainImage = null;
    this.lowerImageBot = null;
    this.lowerImageTop = null;
    this.viewerDim = 0;
    this.currentCoord = new papaya.core.Coordinate(0, 0, 0);
    this.longestDim = 0;
    this.longestDimSize = 0;
    this.draggingSliceDir = 0;
    this.isDragging = false;
    this.isWindowControl = false;
    this.previousMousePosition = new papaya.core.Point();
    this.canvas.removeEventListener("mousemove", this.listenerMouseMove, false);
    this.canvas.removeEventListener("mousedown", this.listenerMouseDown, false);
    this.canvas.removeEventListener("mouseout", this.listenerMouseOut, false);
    this.canvas.removeEventListener("mouseup", this.listenerMouseUp, false);
    document.removeEventListener("keydown", this.listenerKeyDown, true);
    document.removeEventListener("keyup", this.listenerKeyUp, true);
    this.canvas.removeEventListener("contextmenu", this.listenerContextMenu, false);
    this.canvas.removeEventListener("touchmove", this.listenerTouchMove, false);
    this.canvas.removeEventListener("touchstart", this.listenerMouseDown, false);
    this.canvas.removeEventListener("touchend", this.listenerMouseUp, false);
    this.canvas.removeEventListener("dblclick", this.listenerMouseDoubleClick, false);
    this.removeScroll();
    this.updateTimer = null;
    this.updateTimerEvent = null;
    this.drawEmptyViewer();
    if (this.container.display) {
        this.container.display.drawEmptyDisplay()
    }
    this.updateSliceSliderControl();
    this.container.toolbar.buildToolbar()
};
papaya.viewer.Viewer.prototype.getImageDimensionsDescription = function (b) {
    var c, a;
    c = this.screenVolumes[b].volume.header.orientation.orientation;
    a = this.screenVolumes[b].volume.header.imageDimensions;
    return ("(" + c.charAt(0) + ", " + c.charAt(1) + ", " + c.charAt(2) + ") " + a.cols + " x " + a.rows + " x " + a.slices)
};
papaya.viewer.Viewer.prototype.getVoxelDimensionsDescription = function (b) {
    var c, a;
    c = this.screenVolumes[b].volume.header.orientation.orientation;
    a = this.screenVolumes[b].volume.header.voxelDimensions;
    return ("(" + c.charAt(0) + ", " + c.charAt(1) + ", " + c.charAt(2) + ") " + formatNumber(a.colSize, true) + " x " + formatNumber(a.rowSize, true) + " x " + formatNumber(a.sliceSize, true))
};
papaya.viewer.Viewer.prototype.getFilename = function (a) {
    return wordwrap(this.screenVolumes[a].volume.fileName, 25, "<br />", true)
};
papaya.viewer.Viewer.prototype.getNiceFilename = function (b) {
    var c, a;
    c = "...";
    a = this.screenVolumes[b].volume.fileName.replace(".nii", "").replace(".gz", "");
    if (a.length > papaya.viewer.Viewer.TITLE_MAX_LENGTH) {
        a = a.substr(0, papaya.viewer.Viewer.TITLE_MAX_LENGTH - c.length) + c
    }
    return a
};
papaya.viewer.Viewer.prototype.getFileLength = function (a) {
    return getSizeString(this.screenVolumes[a].volume.fileLength)
};
papaya.viewer.Viewer.prototype.getByteTypeDescription = function (a) {
    return (this.screenVolumes[a].volume.header.imageType.numBytes + "-Byte " + this.screenVolumes[a].volume.header.imageType.getTypeDescription())
};
papaya.viewer.Viewer.prototype.getByteOrderDescription = function (a) {
    return this.screenVolumes[a].volume.header.imageType.getOrderDescription()
};
papaya.viewer.Viewer.prototype.getCompressedDescription = function (a) {
    if (this.screenVolumes[a].volume.header.imageType.compressed) {
        return "Yes"
    }
    return "No"
};
papaya.viewer.Viewer.prototype.getOrientationDescription = function (a) {
    return this.screenVolumes[a].volume.header.orientation.getOrientationDescription()
};
papaya.viewer.Viewer.prototype.getImageDescription = function (a) {
    return wordwrap(this.screenVolumes[a].volume.header.imageDescription.notes, 25, "<br />", true)
};
papaya.viewer.Viewer.prototype.setCurrentScreenVol = function (a) {
    this.currentScreenVolume = this.screenVolumes[a];
    this.updateWindowTitle()
};
papaya.viewer.Viewer.prototype.updateWindowTitle = function () {
    var a;
    a = this.getNiceFilename(this.getCurrentScreenVolIndex());
    if (this.currentScreenVolume.volume.numTimepoints > 1) {
        a = (a + " (" + (this.currentScreenVolume.currentTimepoint + 1) + " of " + this.currentScreenVolume.volume.numTimepoints + ")")
    }
    if (this.isZooming()) {
        a = (a + " " + this.getZoomString())
    }
    this.container.toolbar.updateTitleBar(a)
};
papaya.viewer.Viewer.prototype.getCurrentScreenVolIndex = function () {
    var a;
    for (a = 0; a < this.screenVolumes.length; a += 1) {
        if (this.screenVolumes[a] === this.currentScreenVolume) {
            return a
        }
    }
    return -1
};
papaya.viewer.Viewer.prototype.toggleWorldSpace = function () {
    this.worldSpace = !this.worldSpace
};
papaya.viewer.Viewer.prototype.isSelected = function (a) {
    return (this.isSelectable() && (a === this.getCurrentScreenVolIndex()))
};
papaya.viewer.Viewer.prototype.isSelectable = function () {
    return (this.screenVolumes.length > 1)
};
papaya.viewer.Viewer.prototype.processParams = function (a) {
    if (a.worldSpace) {
        this.worldSpace = true
    }
    if (a.showOrientation) {
        this.container.preferences.showOrientation = "Yes"
    }
    if (a.coordinate) {
        this.initialCoordinate = a.coordinate
    }
};
papaya.viewer.Viewer.prototype.goToInitialCoordinate = function () {
    var a;
    if (this.initialCoordinate) {
        a = new papaya.core.Coordinate();
        if (this.worldSpace) {
            this.getIndexCoordinateAtWorld(this.initialCoordinate[0], this.initialCoordinate[1], this.initialCoordinate[2], a)
        } else {
            a.setCoordinate(this.initialCoordinate[0], this.initialCoordinate[1], this.initialCoordinate[2], true)
        }
        this.gotoCoordinate(a);
        if (this.container.display) {
            this.container.display.drawDisplay(this.currentCoord.x, this.currentCoord.y, this.currentCoord.z, this.getCurrentValueAt(this.currentCoord.x, this.currentCoord.y, this.currentCoord.z))
        }
    }
    globalCoord = this.currentCoord;
    console.log("globalCoord");
    console.log(globalCoord);
    canvasready = true;
};
papaya.viewer.Viewer.prototype.getOrientationCertaintyColor = function () {
    var a = this.screenVolumes[0].volume.header.orientationCertainty;
    if (a === papaya.volume.Header.ORIENTATION_CERTAINTY_LOW) {
        return papaya.viewer.Viewer.ORIENTATION_CERTAINTY_LOW_COLOR
    }
    if (a === papaya.volume.Header.ORIENTATION_CERTAINTY_HIGH) {
        return papaya.viewer.Viewer.ORIENTATION_CERTAINTY_HIGH_COLOR
    }
    return papaya.viewer.Viewer.ORIENTATION_CERTAINTY_UNKNOWN_COLOR
};
papaya.viewer.Viewer.prototype.isUsingAtlas = function (a) {
    return (a === this.atlas.currentAtlas)
};
papaya.viewer.Viewer.prototype.scrolled = function (b) {
    var a;
    if (!this.nestedViewer) {
        b = b || window.event;
        if (b.preventDefault) {
            b.preventDefault()
        }
        b.returnValue = false;
        a = getScrollSign(b);



        //######################
        //console.log("scrollé!");
        globalCoord=this.currentCoord;
        //console.log(globalCoord);
        //console.log(this);
        //console.log(this.currentCoord);
        
        
        
        //console.log(this.mainImage);

        //console.log(b);
        
        //######################


        if (this.container.preferences.scrollBehavior === "Increment Slice") {
            if (a < 0) {
                if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                    this.incrementAxial(false)
                } else {
                    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                        this.incrementCoronal(false)
                    } else {
                        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                            this.incrementSagittal(false)
                        }
                    }
                }
                this.gotoCoordinate(this.currentCoord);
                //console.log(this);
                //console.log(this.currentCoord);


            } else {
                if (a > 0) {
                    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                        this.incrementAxial(true)
                    } else {
                        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                            this.incrementCoronal(true)
                        } else {
                            if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                this.incrementSagittal(true)
                            }
                        }
                    }
                    this.gotoCoordinate(this.currentCoord)
                }
            }
        } else {
            if (a !== 0) {
                this.isZoomMode = true;
                if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                    this.setZoomLocation(this.currentCoord.x, this.currentCoord.y, this.mainImage.sliceDirection)
                } else {
                    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                        this.setZoomLocation(this.currentCoord.x, this.currentCoord.z, this.mainImage.sliceDirection)
                    } else {
                        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                            this.setZoomLocation(this.currentCoord.y, this.currentCoord.z, this.mainImage.sliceDirection)
                        }
                    }
                }
                this.setZoomFactor(this.zoomFactorPrevious + (a * 0.1 * this.zoomFactorPrevious));
                this.zoomFactorPrevious = this.zoomFactor
            }
        }
    }
};
papaya.viewer.Viewer.prototype.incrementAxial = function (b) {
    var a = this.volume.header.imageDimensions.zDim;
    if (b) {
        this.currentCoord.z += 1;
        if (this.currentCoord.z >= a) {
            this.currentCoord.z = a - 1
        }
    } else {
        this.currentCoord.z -= 1;
        if (this.currentCoord.z < 0) {
            this.currentCoord.z = 0
        }
    }
    this.gotoCoordinate(this.currentCoord)
};
papaya.viewer.Viewer.prototype.incrementCoronal = function (b) {
    var a = this.volume.header.imageDimensions.yDim;
    if (b) {
        this.currentCoord.y += 1;
        if (this.currentCoord.y >= a) {
            this.currentCoord.y = a - 1
        }
    } else {
        this.currentCoord.y -= 1;
        if (this.currentCoord.y < 0) {
            this.currentCoord.y = 0
        }
    }
    this.gotoCoordinate(this.currentCoord)
};
papaya.viewer.Viewer.prototype.incrementSagittal = function (b) {
    var a = this.volume.header.imageDimensions.xDim;
    if (b) {
        this.currentCoord.x -= 1;
        if (this.currentCoord.x < 0) {
            this.currentCoord.x = 0
        }
    } else {
        this.currentCoord.x += 1;
        if (this.currentCoord.x >= a) {
            this.currentCoord.x = a - 1
        }
    }
    this.gotoCoordinate(this.currentCoord)
};
papaya.viewer.Viewer.prototype.setZoomFactor = function (a) {
    if (a > papaya.viewer.Viewer.ZOOM_FACTOR_MAX) {
        a = papaya.viewer.Viewer.ZOOM_FACTOR_MAX
    } else {
        if (a < papaya.viewer.Viewer.ZOOM_FACTOR_MIN) {
            a = papaya.viewer.Viewer.ZOOM_FACTOR_MIN
        }
    }
    this.zoomFactor = a;
    if (this.zoomFactor === 1) {
        this.panAmountX = this.panAmountY = this.panAmountZ = 0
    }
    this.axialSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocY, this.panAmountX, this.panAmountY, this);
    this.coronalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocZ, this.panAmountX, this.panAmountZ, this);
    this.sagittalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocY, this.zoomLocZ, this.panAmountY, this.panAmountZ, this);
    this.drawViewer(false, true);
    this.updateWindowTitle()
};
papaya.viewer.Viewer.prototype.getZoomString = function () {
    return (parseInt(this.zoomFactor * 100, 10) + "%")
};
papaya.viewer.Viewer.prototype.isZooming = function () {
    return (this.zoomFactor > 1)
};
papaya.viewer.Viewer.prototype.setZoomLocation = function () {
    if (this.zoomFactor === 1) {
        this.zoomLocX = this.currentCoord.x;
        this.zoomLocY = this.currentCoord.y;
        this.zoomLocZ = this.currentCoord.z;
        this.axialSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocY, this.panAmountX, this.panAmountY, this);
        this.coronalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocZ, this.panAmountX, this.panAmountZ, this);
        this.sagittalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocY, this.zoomLocZ, this.panAmountY, this.panAmountZ, this);
        this.drawViewer(false, true)
    }
};
papaya.viewer.Viewer.prototype.setStartPanLocation = function (d, b, c) {
    var a;
    if (this.zoomFactor > 1) {
        if (c === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
            this.panLocX = d;
            this.panLocY = b;
            this.panLocZ = this.axialSlice.currentSlice
        } else {
            if (c === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                this.panLocX = d;
                this.panLocY = this.coronalSlice.currentSlice;
                this.panLocZ = b
            } else {
                if (c === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                    this.panLocX = this.sagittalSlice.currentSlice;
                    a = d;
                    this.panLocY = a;
                    this.panLocZ = b
                }
            }
        }
    }
};
papaya.viewer.Viewer.prototype.setCurrentPanLocation = function (c, a, b) {
    if (this.zoomFactor > 1) {
        if (b === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
            this.panAmountX += (c - this.panLocX);
            this.panAmountY += (a - this.panLocY);
            this.panAmountZ = 0
        } else {
            if (b === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                this.panAmountX += (c - this.panLocX);
                this.panAmountY = 0;
                this.panAmountZ += (a - this.panLocZ)
            } else {
                if (b === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                    this.panAmountX = 0;
                    this.panAmountY += (c - this.panLocY);
                    this.panAmountZ += (a - this.panLocZ)
                }
            }
        }
        this.axialSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocY, this.panAmountX, this.panAmountY, this);
        this.coronalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocX, this.zoomLocZ, this.panAmountX, this.panAmountZ, this);
        this.sagittalSlice.updateZoomTransform(this.zoomFactor, this.zoomLocY, this.zoomLocZ, this.panAmountY, this.panAmountZ, this);
        this.drawViewer(false, true)
    }
};
papaya.viewer.Viewer.prototype.isWorldMode = function () {
    return this.worldSpace
};
papaya.viewer.Viewer.prototype.isCollapsable = function () {
    return this.container.collapsable
};
papaya.viewer.Viewer.prototype.sliceSliderControlChanged = function () {
    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
        this.currentCoord.z = parseInt(this.sliceSliderControl.val(), 10)
    } else {
        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
            this.currentCoord.y = parseInt(this.sliceSliderControl.val(), 10)
        } else {
            if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                this.currentCoord.x = parseInt(this.sliceSliderControl.val(), 10)
            }
        }
    }
    this.gotoCoordinate(this.currentCoord)
};
papaya.viewer.Viewer.prototype.updateSliceSliderControl = function () {
    if (this.sliceSliderControl) {
        if (this.initialized) {
            this.sliceSliderControl.prop("disabled", false);
            this.sliceSliderControl.prop("min", "0");
            this.sliceSliderControl.prop("step", "1");
            if (this.sliceSliderControl) {
                if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                    this.sliceSliderControl.prop("max", (this.volume.header.imageDimensions.zDim - 1).toString());
                    this.sliceSliderControl.val(this.currentCoord.z)
                } else {
                    if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                        this.sliceSliderControl.prop("max", (this.volume.header.imageDimensions.yDim - 1).toString());
                        this.sliceSliderControl.val(this.currentCoord.y)
                    } else {
                        if (this.mainImage.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                            this.sliceSliderControl.prop("max", (this.volume.header.imageDimensions.xDim - 1).toString());
                            this.sliceSliderControl.val(this.currentCoord.x)
                        }
                    }
                }
            }
        } else {
            this.sliceSliderControl.prop("disabled", true);
            this.sliceSliderControl.prop("min", "0");
            this.sliceSliderControl.prop("step", "1");
            this.sliceSliderControl.prop("max", "1");
            this.sliceSliderControl.val(0)
        }
    }
};
"use strict";
var papaya = papaya || {};
papaya.viewer = papaya.viewer || {};
papaya.viewer.ScreenSlice = papaya.viewer.ScreenSlice ||
function (e, c, f, a, b, d, g) {
    this.screenVolumes = g;
    this.sliceDirection = c;
    this.currentSlice = -1;
    this.xDim = f;
    this.yDim = a;
    this.xSize = b;
    this.ySize = d;
    this.canvasMain = document.createElement("canvas");
    this.canvasMain.width = this.xDim;
    this.canvasMain.height = this.yDim;
    this.contextMain = this.canvasMain.getContext("2d");
    this.imageDataDraw = this.contextMain.createImageData(this.xDim, this.yDim);
    this.screenOffsetX = 0;
    this.screenOffsetY = 0;
    this.screenDim = 0;
    this.screenTransform = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1]
    ];
    this.zoomTransform = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1]
    ];
    this.finalTransform = [
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1]
    ];
    this.imageData = []
};
papaya.viewer.ScreenSlice.DIRECTION_UNKNOWN = 0;
papaya.viewer.ScreenSlice.DIRECTION_AXIAL = 1;
papaya.viewer.ScreenSlice.DIRECTION_CORONAL = 2;
papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL = 3;
papaya.viewer.ScreenSlice.SCREEN_PIXEL_MAX = 255;
papaya.viewer.ScreenSlice.SCREEN_PIXEL_MIN = 0;
papaya.viewer.ScreenSlice.prototype.updateSlice = function (i, a, f) {
    var j, m, b, k, l, h, g, e, d, c;
    i = Math.round(i);
    if (a || (this.currentSlice !== i)) {
        this.currentSlice = i;
        j = this.screenVolumes[0].volume.header.origin;
        m = this.screenVolumes[0].volume.header.voxelDimensions;
        this.contextMain.clearRect(0, 0, this.canvasMain.width, this.canvasMain.height);
        if (this.imageData.length < this.screenVolumes.length) {
            this.imageData = createArray(this.screenVolumes.length, this.xDim * this.yDim)
        }
        for (b = 0; b < this.screenVolumes.length; b += 1) {
            c = this.screenVolumes[b].currentTimepoint;
            for (k = 0; k < this.yDim; k += 1) {
                for (l = 0; l < this.xDim; l += 1) {
                    h = 0;
                    g = 255;
                    d = this.screenVolumes[b].alpha;
                    if (b === 0) {
                        if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                            h = this.screenVolumes[b].volume.getVoxelAtIndex(l, k, i, c, true)
                        } else {
                            if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                                h = this.screenVolumes[b].volume.getVoxelAtIndex(l, i, k, c, true)
                            } else {
                                if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                    h = this.screenVolumes[b].volume.getVoxelAtIndex(i, l, k, c, true)
                                }
                            }
                        }
                    } else {
                        if (f) {
                            if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                                h = this.screenVolumes[b].volume.getVoxelAtCoordinate((l - j.x) * m.xSize, (j.y - k) * m.ySize, (j.z - i) * m.zSize, c, false)
                            } else {
                                if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                                    h = this.screenVolumes[b].volume.getVoxelAtCoordinate((l - j.x) * m.xSize, (j.y - i) * m.ySize, (j.z - k) * m.zSize, c, false)
                                } else {
                                    if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                        h = this.screenVolumes[b].volume.getVoxelAtCoordinate((i - j.x) * m.xSize, (j.y - l) * m.ySize, (j.z - k) * m.zSize, c, false)
                                    }
                                }
                            }
                        } else {
                            if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
                                h = this.screenVolumes[b].volume.getVoxelAtMM(l * m.xSize, k * m.ySize, i * m.zSize, c, false)
                            } else {
                                if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                                    h = this.screenVolumes[b].volume.getVoxelAtMM(l * m.xSize, i * m.ySize, k * m.zSize, c, false)
                                } else {
                                    if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                                        h = this.screenVolumes[b].volume.getVoxelAtMM(i * m.xSize, l * m.ySize, k * m.zSize, c, false)
                                    }
                                }
                            }
                        }
                    }
                    e = ((k * this.xDim) + l) * 4;
                    this.imageData[b][e] = h;
                    if ((!this.screenVolumes[b].negative && (h <= this.screenVolumes[b].screenMin)) || (this.screenVolumes[b].negative && (h >= this.screenVolumes[b].screenMin)) || isNaN(h)) {
                        h = papaya.viewer.ScreenSlice.SCREEN_PIXEL_MIN;
                        g = this.screenVolumes[b].isOverlay() ? 0 : 255
                    } else {
                        if ((!this.screenVolumes[b].negative && (h >= this.screenVolumes[b].screenMax)) || (this.screenVolumes[b].negative && (h <= this.screenVolumes[b].screenMax))) {
                            h = papaya.viewer.ScreenSlice.SCREEN_PIXEL_MAX
                        } else {
                            h = roundFast(((h - this.screenVolumes[b].screenMin) * this.screenVolumes[b].screenRatio) + 0.5)
                        }
                    }
                    if ((g > 0) || (b === 0)) {
                        this.imageDataDraw.data[e] = (this.imageDataDraw.data[e] * (1 - d) + this.screenVolumes[b].colorTable.lookupRed(h) * d);
                        this.imageDataDraw.data[e + 1] = (this.imageDataDraw.data[e + 1] * (1 - d) + this.screenVolumes[b].colorTable.lookupGreen(h) * d);
                        this.imageDataDraw.data[e + 2] = (this.imageDataDraw.data[e + 2] * (1 - d) + this.screenVolumes[b].colorTable.lookupBlue(h) * d);
                        this.imageDataDraw.data[e + 3] = g
                    }
                }
            }
        }
        this.contextMain.putImageData(this.imageDataDraw, 0, 0)
    }
};
papaya.viewer.ScreenSlice.prototype.repaint = function (g, a, e) {
    var b, i, j, h, f, d, c;
    g = Math.round(g);
    this.currentSlice = g;
    this.contextMain.clearRect(0, 0, this.canvasMain.width, this.canvasMain.height);
    if (this.imageData.length === this.screenVolumes.length) {
        for (b = 0; b < this.screenVolumes.length; b += 1) {
            for (i = 0; i < this.yDim; i += 1) {
                for (j = 0; j < this.xDim; j += 1) {
                    h = 0;
                    f = 255;
                    c = this.screenVolumes[b].alpha;
                    d = ((i * this.xDim) + j) * 4;
                    h = this.imageData[b][d];
                    if ((!this.screenVolumes[b].negative && (h <= this.screenVolumes[b].screenMin)) || (this.screenVolumes[b].negative && (h >= this.screenVolumes[b].screenMin)) || isNaN(h)) {
                        h = papaya.viewer.ScreenSlice.SCREEN_PIXEL_MIN;
                        f = this.screenVolumes[b].isOverlay() ? 0 : 255
                    } else {
                        if ((!this.screenVolumes[b].negative && (h >= this.screenVolumes[b].screenMax)) || (this.screenVolumes[b].negative && (h <= this.screenVolumes[b].screenMax))) {
                            h = papaya.viewer.ScreenSlice.SCREEN_PIXEL_MAX
                        } else {
                            h = roundFast(((h - this.screenVolumes[b].screenMin) * this.screenVolumes[b].screenRatio) + 0.5)
                        }
                    }
                    if ((f > 0) || (b === 0)) {
                        this.imageDataDraw.data[d] = (this.imageDataDraw.data[d] * (1 - c) + this.screenVolumes[b].colorTable.lookupRed(h) * c);
                        this.imageDataDraw.data[d + 1] = (this.imageDataDraw.data[d + 1] * (1 - c) + this.screenVolumes[b].colorTable.lookupGreen(h) * c);
                        this.imageDataDraw.data[d + 2] = (this.imageDataDraw.data[d + 2] * (1 - c) + this.screenVolumes[b].colorTable.lookupBlue(h) * c);
                        this.imageDataDraw.data[d + 3] = f
                    }
                }
            }
            this.contextMain.putImageData(this.imageDataDraw, 0, 0)
        }
    } else {
        this.updateSlice(g, a, e)
    }
};
papaya.viewer.ScreenSlice.prototype.getRealWidth = function () {
    return this.xDim * this.xSize
};
papaya.viewer.ScreenSlice.prototype.getRealHeight = function () {
    return this.yDim * this.ySize
};
papaya.viewer.ScreenSlice.prototype.getXYratio = function () {
    return this.xSize / this.ySize
};
papaya.viewer.ScreenSlice.prototype.getYXratio = function () {
    return this.ySize / this.xSize
};
papaya.viewer.ScreenSlice.prototype.getXSize = function () {
    return this.xSize
};
papaya.viewer.ScreenSlice.prototype.getYSize = function () {
    return this.ySize
};
papaya.viewer.ScreenSlice.prototype.getXDim = function () {
    return this.xDim
};
papaya.viewer.ScreenSlice.prototype.getYDim = function () {
    return this.yDim
};
papaya.viewer.ScreenSlice.prototype.updateZoomTransform = function (c, i, b, h, a, d) {
    var f, j, g, e;
    i = (i + 0.5) * (c - 1) * -1;
    b = (b + 0.5) * (c - 1) * -1;
    h = h * (c - 1);
    a = a * (c - 1);
    f = i + h;
    g = -1 * (c - 1) * this.xDim;
    if (f > 0) {
        f = 0
    } else {
        if (f < g) {
            f = g
        }
    }
    j = b + a;
    e = -1 * (c - 1) * this.yDim;
    if (j > 0) {
        j = 0
    } else {
        if (j < e) {
            j = e
        }
    }
    if (c > 1) {
        if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_AXIAL) {
            d.panAmountX = (Math.round((f - i) / (c - 1)));
            d.panAmountY = (Math.round((j - b) / (c - 1)))
        } else {
            if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_CORONAL) {
                d.panAmountX = (Math.round((f - i) / (c - 1)));
                d.panAmountZ = (Math.round((j - b) / (c - 1)))
            } else {
                if (this.sliceDirection === papaya.viewer.ScreenSlice.DIRECTION_SAGITTAL) {
                    d.panAmountY = (Math.round((f - i) / (c - 1)));
                    d.panAmountZ = (Math.round((j - b) / (c - 1)))
                }
            }
        }
    }
    this.zoomTransform[0][0] = c;
    this.zoomTransform[0][1] = 0;
    this.zoomTransform[0][2] = f;
    this.zoomTransform[1][0] = 0;
    this.zoomTransform[1][1] = c;
    this.zoomTransform[1][2] = j;
    this.updateFinalTransform()
};
papaya.viewer.ScreenSlice.prototype.updateFinalTransform = function () {
    var b, a;
    for (b = 0; b < 3; b += 1) {
        for (a = 0; a < 3; a += 1) {
            this.finalTransform[b][a] = (this.screenTransform[b][0] * this.zoomTransform[0][a]) + (this.screenTransform[b][1] * this.zoomTransform[1][a]) + (this.screenTransform[b][2] * this.zoomTransform[2][a])
        }
    }
};
"use strict";
var papaya = papaya || {};
papaya.volume = papaya.volume || {};
papaya.viewer.Preferences = papaya.viewer.Preferences ||
function () {
    this.viewer = null;
    this.showCrosshairs = papaya.viewer.Preferences.DEFAULT_SHOW_CROSSHAIRS;
    this.atlasLocks = papaya.viewer.Preferences.DEFAULT_ATLAS_LOCKS;
    this.showOrientation = papaya.viewer.Preferences.DEFAULT_SHOW_ORIENTATION;
    this.scrollBehavior = papaya.viewer.Preferences.DEFAULT_SCROLL;
    this.readPreferences()
};
papaya.viewer.Preferences.COOKIE_PREFIX = "papaya-";
papaya.viewer.Preferences.COOKIE_EXPIRY_DAYS = 365;
papaya.viewer.Preferences.DEFAULT_SHOW_CROSSHAIRS = "All";
papaya.viewer.Preferences.DEFAULT_ATLAS_LOCKS = "Mouse";
papaya.viewer.Preferences.DEFAULT_SHOW_ORIENTATION = "Yes";
papaya.viewer.Preferences.DEFAULT_SCROLL = "Increment Slice";
papaya.viewer.Preferences.prototype.updatePreference = function (b, a) {
    this[b] = a;
    this.viewer.drawViewer(true);
    createCookie(papaya.viewer.Preferences.COOKIE_PREFIX + b, a, papaya.viewer.Preferences.COOKIE_EXPIRY_DAYS)
};
papaya.viewer.Preferences.prototype.readPreferences = function () {
    var b, a;
    for (b = 0; b < papaya.ui.Toolbar.PREFERENCES_DATA.items.length; b += 1) {
        a = readCookie(papaya.viewer.Preferences.COOKIE_PREFIX + papaya.ui.Toolbar.PREFERENCES_DATA.items[b].field);
        if (a) {
            this[papaya.ui.Toolbar.PREFERENCES_DATA.items[b].field] = a
        }
    }
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItemFileChooser = papaya.ui.MenuItemFileChooser ||
function (c, a, b, d) {
    this.viewer = c;
    this.label = a;
    this.action = b;
    this.id = this.action.replace(/ /g, "_") + this.viewer.container.containerIndex;
    this.fileChooserId = "fileChooser" + this.viewer.container.containerIndex;
    this.callback = d
};
papaya.ui.MenuItemFileChooser.prototype.buildHTML = function (c) {
    var a, b;
    a = this;
    b = "<li id='" + this.id + "'><span class='" + PAPAYA_MENU_UNSELECTABLE + "'><label class='" + PAPAYA_MENU_FILECHOOSER + "' for='" + this.fileChooserId + "'>" + this.label + "</label><input type='file' id='" + this.fileChooserId + "' name='files' /></span></li>";
    $("#" + c).append(b);
    $("#" + this.fileChooserId)[0].onchange = bind(a, function () {
        a.callback(a.action, document.getElementById(a.fileChooserId).files[0])
    });
    $("#" + this.id).hover(function () {
        $(this).toggleClass(PAPAYA_MENU_HOVERING_CSS)
    })
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItemSlider = papaya.ui.MenuItemSlider ||
function (e, b, c, g, d, f, a) {
    this.viewer = e;
    this.label = b;
    this.index = a;
    this.modifier = "";
    if (!isStringBlank(a)) {
        this.modifier = "-" + a
    }
    this.dataSource = d;
    this.method = f;
    this.action = c + this.modifier;
    this.id = this.action.replace(/ /g, "_") + this.viewer.container.containerIndex;
    this.callback = g;
    this.screenVol = this.viewer.screenVolumes[this.index]
};
papaya.ui.MenuItemSlider.prototype.buildHTML = function (f) {
    var d, c, a, b, e;
    a = this.id + "Slider";
    d = "<li id='" + this.id + "'><span style='padding-right:5px;' class='" + PAPAYA_MENU_UNSELECTABLE + "'>" + this.label + ":</span><input min='0' max='100' value='" + parseInt((1 - this.screenVol.alpha) * 100, 10) + "' id='" + a + "' style='vertical-align:middle;text-align:center;width:125px;padding:0;margin:0;' type='range' /></li>";
    $("#" + f).append(d);
    c = $("#" + this.id);
    c.hover(function () {
        $(this).toggleClass(PAPAYA_MENU_HOVERING_CSS)
    });
    b = $("#" + a);
    e = this;
    $("#" + this.id + "Slider").change(function () {
        e.screenVol.alpha = 1 - (b.val() / 100);
        e.viewer.drawViewer(false, true)
    })
};
papaya.ui.MenuItemSlider.prototype.doAction = function () {
    this.callback(this.action)
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
var papayaLoadableImages = papayaLoadableImages || [];
papaya.ui.Toolbar = papaya.ui.Toolbar ||
function (a) {
    this.container = a;
    this.viewer = a.viewer;
    this.imageMenus = null;
    this.spaceMenu = null
};
papaya.ui.Toolbar.SIZE = 22;
papaya.ui.Toolbar.ICON_IMAGESPACE = "data:image/gif;base64,R0lGODlhFAAUAPcAMf//////GP///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////2f/ZNbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1qWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpVpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWlpaWkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACoALAAAAAAUABQAAAipAFUIHEiwoMB/A1coXLiwisOHVf4hVLFCosWLGC9SzMgR48Z/VEJSUVjFj0mTESdWBCmS5EmU/6oIXCly5IqSLx/OlFjT5Us/DneybIkzp8yPDElChCjwj8Q/UKOqmkqVatOnUaGqmsaVq1UVTv+lGjv2z9SuXlVdFUs2ldmtaKeubev2bFy1YCXSfYt2mty8/6CS5XtXRcasVRMftJj1beK/hicanKwiIAA7";
papaya.ui.Toolbar.ICON_WORLDSPACE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAplJREFUeNqM1H1ozVEcx/Hr3p+7O08jQzbzMErznEItK0+Fv0Ye/tki20ia//wn+YMSaXkoEiKkkCVKZhOipsnDstnFagzlrmGMNfeO6/Nd71unu2s59bq7O517ft/z/X7Pz+dLPUbLJrkqX+SbdEubfJZK2cC6PiOQYm61HJcpkintEpcmCcpryZV5spaHhvvbdJ9slsPyU67wgPlEli0X5aiMkMeyXSbKnVRRVxDRRtkm5czbZrv5vkgu8z1P9stWfleRHGkhT3xCLu1YzZIjpfKWnA6VEn43mwcWEaWlo1Ve2YZj5Jms53iP5BjFsFz9lg/yDj0U7JbslFpZQyBP2a83khoiLiWPA/h/OVGOk+GwnJ5y1iyRS5Im1VLm18cKOc+CYrlGjnxUuZPIOlAn0yWdNXdlrMyRE7LM00eBjBT7niFVTvHsKJ8k6sw1yC4ZIl0EUMOcRT/X44v14xEZSBWfk+d8NpzKujgPGiYrOXI+XTGeGtjpewtjm16Qh3JT3sgvickfNo4yF6V4PVyE2wQUZvP7FmmIa/iDIpwkHRPkrC2iEIlhEZ2mtarIsz3sOoX0PPrP7nAWPRYjj51E85JiJEYO0VsfR5hL5wZal3T7aZl10kLiEyNEHtOSbt4g/gaduRjzC+S9RwtZ332XBxQpzGZ+p72SR5BumUYHLaaDSiySUXKPig6Wj+SmjX5s4BQB0pFBQVo4dhenspfKC1kaYLKVa9pOAW5Q2Ww2qeU92kHbzZRDvK2sBSfLDLtNUp/82rOj7nDm9tJi7lhoeWNzG7Pkqxz8R5p8ByhcGVd0CzkOOWv28KBJvNGa+V2/Y5U08vQm8mgvmTNyjpxHSFUj6/9rZPKerGSTuCPCi7qIdX3GXwEGAPFYt+/OgAXDAAAAAElFTkSuQmCC";
papaya.ui.Toolbar.ICON_EXPAND = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAE00lEQVR42u2djW3UQBCFJx3QAemAdJBQAVABTgekAqCC0EGOCoAKWDqADkIHKQGPfKdEh3Nr7493Z977pJWQwtk7+77ETs6zdyYEmrPWEyBtoQDgUABwKAA4FAAcCgAOBQCHAoBDAcChAOBQAHAoADgUABwKAE6uALfjuGg094dx7Mbxo9H5D7wZxzCOF43O/3scN6kvzhXg5ziuGhV+4K20k0DD/964/jCO16kv9iCABvCu0bm/ySRgS4KAC7Abx3Wjc9/J9OO/JUGABXjYn/9Po/O/kimAVtd/EQMC6E1Krevkbhx/Kx17KSpBrcuAHjd2kx2kcwGUYRxfy60LBO9lEjxGEAMCKINQgqUsDV8JYkQAZRBKEGNN+EqQzgTQa/6p69YglOA5YuHPrW2QzgT4NI77SCGDUIJjYuEP4ziXaX2fEqRDAT4vLIgSTCxdq49iSIA1hSGzZo3MCbC2QDTWro1JAVIKRSBlTcwKkFqwV1LXwrQAOYV7ImcNzAuQuwDWya3dhQAlFsIiJWp2I0CpBbFCqVpdCVByYXqmZI3uBCi9QL1RujaXAigeJahRk1sBFE8S1KrFtQCKBwlq1uBeAMWyBLXnDiGAYlGCLeYMI4BiSYKt5golgGJBgi3nCCeA0rMEW88NUgClRwlazKk7AeaaI3WCpQVQepKg1VzmBMhqjs0V4Lg9unavXg8StJzDS5keDX/ai5jVHl9ih5DDBgka/hep36jZMoAeBNRexA8ySaBzydobweoWMS2C6CH84lgVQNkyEJfhK5YFULYIxm34inUBlFhA55K+h8DcTddTBjEcvuJBAOWUBIOkh3Qp0+/ZpY/bDV4EUJ6T4GocvxKP+ZwAgzgIX/EkgKIS6K+ihx/ZQTL+Srbn+K+dgzgJX/EmgKLX7fP9v1O/84+53B8zSPs9iYriUQCyAgoADgUAhwKAQwHAoQDgUABwKAA4FAAcCgAOBQCHAoBDAcChAOB4FEDfDr6Sacfykm8Hy/6YfDu4Y46fCgpS9oEQ7X3QZ/L5QEiH8JGwBLwIcOqh0CtJF6DWw6bd4EGAUyHpj2z9iJWcx8LvT3x9EOMSWBeAjSGZWBaArWEFsCoAm0MLwfZwO+c+0FV7+NwGETk3XTF6CKDlHOY+rLrpBhHcImbbuXS3RQw3idp2Tt1tEsVt4rhNHDeK3HCOUAJYCH/rucIIYCn8LecMIYDF8Leau3sBLIe/RQ2uBfAQfu1a3ArgKfyaNbkUwGP4tWpzJ4Dn8GvU6EoAhPBL1+pGAKTwS9bsQgDE8EvVbl4A5PBLrIFpARj+I6lrYVYAhv8/KWtiUgCG/zxr18acAAw/zpo1MiUAw1/O0rUyI8D9woLII0skOBcDAuhHrFxECmH488QkmFvbIJ0JcIpBGH6MmATHBDEiwCAMfylrJAhiQIBBGP5alkoQpHMB9Lr1PX6oJPS4tXsRY+geAkOlY2vX1UXk/wTpXICa1P6w6hhzvXpbo+eHFUDZjeO60bnvpN53/1KCgAuQ1RyZyVxz7NYEARcgqz06k+P2+BYEaSjArcRvUmqh1/+dtAv/wGGDjFb3AXqTfZP6YqtbxJBCUABwKAA4FAAcCgAOBQCHAoBDAcChAOBQAHAoADgUABwKAA4FAIcCgPMPvdAfn3qMP2kAAAAASUVORK5CYII=";
papaya.ui.Toolbar.ICON_COLLAPSE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAEJGlDQ1BJQ0MgUHJvZmlsZQAAOBGFVd9v21QUPolvUqQWPyBYR4eKxa9VU1u5GxqtxgZJk6XtShal6dgqJOQ6N4mpGwfb6baqT3uBNwb8AUDZAw9IPCENBmJ72fbAtElThyqqSUh76MQPISbtBVXhu3ZiJ1PEXPX6yznfOec7517bRD1fabWaGVWIlquunc8klZOnFpSeTYrSs9RLA9Sr6U4tkcvNEi7BFffO6+EdigjL7ZHu/k72I796i9zRiSJPwG4VHX0Z+AxRzNRrtksUvwf7+Gm3BtzzHPDTNgQCqwKXfZwSeNHHJz1OIT8JjtAq6xWtCLwGPLzYZi+3YV8DGMiT4VVuG7oiZpGzrZJhcs/hL49xtzH/Dy6bdfTsXYNY+5yluWO4D4neK/ZUvok/17X0HPBLsF+vuUlhfwX4j/rSfAJ4H1H0qZJ9dN7nR19frRTeBt4Fe9FwpwtN+2p1MXscGLHR9SXrmMgjONd1ZxKzpBeA71b4tNhj6JGoyFNp4GHgwUp9qplfmnFW5oTdy7NamcwCI49kv6fN5IAHgD+0rbyoBc3SOjczohbyS1drbq6pQdqumllRC/0ymTtej8gpbbuVwpQfyw66dqEZyxZKxtHpJn+tZnpnEdrYBbueF9qQn93S7HQGGHnYP7w6L+YGHNtd1FJitqPAR+hERCNOFi1i1alKO6RQnjKUxL1GNjwlMsiEhcPLYTEiT9ISbN15OY/jx4SMshe9LaJRpTvHr3C/ybFYP1PZAfwfYrPsMBtnE6SwN9ib7AhLwTrBDgUKcm06FSrTfSj187xPdVQWOk5Q8vxAfSiIUc7Z7xr6zY/+hpqwSyv0I0/QMTRb7RMgBxNodTfSPqdraz/sDjzKBrv4zu2+a2t0/HHzjd2Lbcc2sG7GtsL42K+xLfxtUgI7YHqKlqHK8HbCCXgjHT1cAdMlDetv4FnQ2lLasaOl6vmB0CMmwT/IPszSueHQqv6i/qluqF+oF9TfO2qEGTumJH0qfSv9KH0nfS/9TIp0Wboi/SRdlb6RLgU5u++9nyXYe69fYRPdil1o1WufNSdTTsp75BfllPy8/LI8G7AUuV8ek6fkvfDsCfbNDP0dvRh0CrNqTbV7LfEEGDQPJQadBtfGVMWEq3QWWdufk6ZSNsjG2PQjp3ZcnOWWing6noonSInvi0/Ex+IzAreevPhe+CawpgP1/pMTMDo64G0sTCXIM+KdOnFWRfQKdJvQzV1+Bt8OokmrdtY2yhVX2a+qrykJfMq4Ml3VR4cVzTQVz+UoNne4vcKLoyS+gyKO6EHe+75Fdt0Mbe5bRIf/wjvrVmhbqBN97RD1vxrahvBOfOYzoosH9bq94uejSOQGkVM6sN/7HelL4t10t9F4gPdVzydEOx83Gv+uNxo7XyL/FtFl8z9ZAHF4bBsrEwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAeJJREFUOBG1lU1KA0EQhTP5c5MggkvFvQfQjS4iIcled3qBrDyCHsFsvEBcegBBkEBA0VuIW0UFBX8w4/c6VUMbAhoYG16qquvVm05Nd0+SpmlBI0mSogzxV5iY8Yf6EiWUp6NQasJFWfPL7lucQIzzvoDAn6xxrsRDEXYVrE0S44dM86kJC1GtNKxeDy+ULFDiAbQsrpqtMFeXb3GNuDLBaVmtL6zkZH+qCPegGQm1iftR3CduR3HTanxBY62I4OIiPoGOcoxdMIh4A81ZroMvblgINmiEnBcY0f++Cl6B2rMBzp0n3+aUE8cXEGqdVyaRDSY/FGDP2D4N3B64Bs/Ah/wdsA4acG+U8Fr5GuHtIaItpb1cAW2gv18FEt0HC8CHfM0pVxXXavSSpRG0fMUK1NA5sAeWwSfQ6i7AEPhwf4mJAyDBO3AJVBO0dNLw8x+hFfnLsj0kSlt0+kbYOuExiFuhng7JH2LFld0Ej2AeeCu6cF5cy3vs/XiDeAIWwS3Q298G8ZDoFuiBI7ACdKjegcZYSz2eBgjap1dAxafOkW9zyoUj7LnY/hCFmNsByYQRzf9IR6L5XUKI/uXarHn/4Gvn/H5tQvqfi14rcXHzs6vPYh3RmT9N2ZHWxkYgt4/pN/LAOfka/AG9AAAAAElFTkSuQmCC";
papaya.ui.Toolbar.MENU_DATA = {
    menus: [{
        label: "File",
        icons: null,
        items: [{
            label: "Add Image...",
            action: "OpenImage",
            type: "button"
        },
        {
            type: "spacer"
        },
        {
            type: "spacer"
        },
        {
            label: "Close All",
            action: "CloseAllImages"
        }]
    },
    {
        label: "Options",
        icons: null,
        items: [{
            label: "Preferences",
            action: "Preferences"
        }]
    },
    {
        label: "",
        icons: null,
        titleBar: "true"
    },
    {
        label: "EXPAND",
        icons: [papaya.ui.Toolbar.ICON_EXPAND, papaya.ui.Toolbar.ICON_COLLAPSE],
        items: [],
        method: "isCollapsable",
        required: "isNestedViewer"
    },
    {
        label: "SPACE",
        icons: [papaya.ui.Toolbar.ICON_IMAGESPACE, papaya.ui.Toolbar.ICON_WORLDSPACE],
        items: [],
        method: "isWorldMode",
        menuOnHover: true
    }]
};
papaya.ui.Toolbar.OVERLAY_IMAGE_MENU_DATA = {
    items: [{
        label: "Image Info",
        action: "ImageInfo"
    },
    {
        label: "DisplayRange",
        action: "ChangeRange",
        type: "displayrange",
        method: "getRange"
    },
    {
        label: "Transparency",
        action: "ChangeAlpha",
        type: "range",
        method: "getAlpha"
    },
    {
        label: "Color Table...",
        action: "ColorTable",
        items: []
    }]
};
papaya.ui.Toolbar.BASE_IMAGE_MENU_DATA = {
    items: [{
        label: "Image Info",
        action: "ImageInfo"
    },
    {
        label: "DisplayRange",
        action: "ChangeRange",
        type: "displayrange",
        method: "getRange"
    },
    papaya.ui.Toolbar.OVERLAY_IMAGE_MENU_DATA.items[3]]
};
papaya.ui.Toolbar.PREFERENCES_DATA = {
    items: [{
        label: "Coordinate display of:",
        field: "atlasLocks",
        options: ["Mouse", "Crosshairs"]
    },
    {
        label: "Show crosshairs:",
        field: "showCrosshairs",
        options: ["All", "Main", "Lower", "None"]
    },
    {
        label: "Show orientation:",
        field: "showOrientation",
        options: ["Yes", "No"]
    },
    {
        label: "Scroll wheel behavior:",
        field: "scrollBehavior",
        options: ["Zoom", "Increment Slice"],
        disabled: "container.nestedViewer"
    }]
};
papaya.ui.Toolbar.IMAGE_INFO_DATA = {
    items: [{
        label: "Filename:",
        field: "getFilename",
        readonly: "true"
    },
    {
        label: "File Length:",
        field: "getFileLength",
        readonly: "true"
    },
    {
        spacer: "true"
    },
    {
        label: "Image Dims:",
        field: "getImageDimensionsDescription",
        readonly: "true"
    },
    {
        label: "Voxel Dims:",
        field: "getVoxelDimensionsDescription",
        readonly: "true"
    },
    {
        spacer: "true"
    },
    {
        label: "Byte Type:",
        field: "getByteTypeDescription",
        readonly: "true"
    },
    {
        label: "Byte Order:",
        field: "getByteOrderDescription",
        readonly: "true"
    },
    {
        label: "Compressed:",
        field: "getCompressedDescription",
        readonly: "true"
    },
    {
        spacer: "true"
    },
    {
        label: "Orientation:",
        field: "getOrientationDescription",
        readonly: "true"
    },
    {
        spacer: "true"
    },
    {
        label: "Notes:",
        field: "getImageDescription",
        readonly: "true"
    }]
};
papaya.ui.Toolbar.prototype.buildToolbar = function () {
    var a;
    this.imageMenus = null;
    this.spaceMenu = null;
    this.container.toolbarHtml.find("." + PAPAYA_MENU_ICON_CSS).remove();
    this.container.toolbarHtml.find("." + PAPAYA_MENU_LABEL_CSS).remove();
    this.container.toolbarHtml.find("." + PAPAYA_TITLEBAR_CSS).remove();
    this.buildOpenMenuItems();
    for (a = 0; a < papaya.ui.Toolbar.MENU_DATA.menus.length; a += 1) {
        this.buildMenu(papaya.ui.Toolbar.MENU_DATA.menus[a], null, this.viewer, null)
    }
    this.buildAtlasMenu();
    this.buildColorMenuItems();
    this.container.titlebarHtml = this.container.containerHtml.find("." + PAPAYA_TITLEBAR_CSS)
};
papaya.ui.Toolbar.prototype.buildAtlasMenu = function () {
    if (papaya.data) {
        if (papaya.data.Atlas) {
            var a = this.spaceMenu.items;
            a[0] = {
                label: papaya.data.Atlas.labels.atlas.header.name,
                action: "AtlasChanged-" + papaya.data.Atlas.labels.atlas.header.name,
                type: "checkbox",
                method: "isUsingAtlas"
            };
            if (papaya.data.Atlas.labels.atlas.header.transformedname) {
                a[1] = {
                    label: papaya.data.Atlas.labels.atlas.header.transformedname,
                    action: "AtlasChanged-" + papaya.data.Atlas.labels.atlas.header.transformedname,
                    type: "checkbox",
                    method: "isUsingAtlas"
                }
            }
        }
    }
};
papaya.ui.Toolbar.prototype.buildColorMenuItems = function () {
    var a, c, e, b, d;
    d = this.container.params.luts;
    if (d) {
        for (c = 0; c < d.length; c += 1) {
            papaya.viewer.ColorTable.addCustomLUT(d[c])
        }
    }
    e = papaya.viewer.ColorTable.TABLE_ALL;
    a = papaya.ui.Toolbar.OVERLAY_IMAGE_MENU_DATA.items;
    for (c = 0; c < a.length; c += 1) {
        if (a[c].label === "Color Table...") {
            a = a[c].items;
            break
        }
    }
    for (c = 0; c < e.length; c += 1) {
        b = {
            label: e[c].name,
            action: "ColorTable-" + e[c].name,
            type: "checkbox",
            method: "isUsingColorTable"
        };
        a[c] = b
    }
};
papaya.ui.Toolbar.prototype.buildOpenMenuItems = function () {
    var c, b, a;
    for (c = 0; c < papaya.ui.Toolbar.MENU_DATA.menus.length; c += 1) {
        if (papaya.ui.Toolbar.MENU_DATA.menus[c].label === "File") {
            b = papaya.ui.Toolbar.MENU_DATA.menus[c].items;
            break
        }
    }
    for (c = 0; c < papayaLoadableImages.length; c += 1) {
        if (!papayaLoadableImages[c].hide) {
            a = "Add " + papayaLoadableImages[c].nicename;
            if (!this.menuContains(b, a)) {
                b.splice(2, 0, {
                    label: a,
                    action: "Open-" + papayaLoadableImages[c].name
                })
            }
        }
    }
};
papaya.ui.Toolbar.prototype.menuContains = function (b, a) {
    var c;
    for (c = 0; c < b.length; c += 1) {
        if (b[c].label === a) {
            return true
        }
    }
    return false
};
papaya.ui.Toolbar.prototype.buildMenu = function (c, d, f, a) {
    var e = null,
        b;
    if (!c.required || ((bind(this.container, derefIn(this.container, c.required)))() === true)) {
        e = new papaya.ui.Menu(this.viewer, c, bind(this, this.doAction), this.viewer, a);
        if (c.label === "SPACE") {
            this.spaceMenu = c
        }
        if (d) {
            e.setMenuButton(d)
        } else {
            d = e.buildMenuButton()
        }
        b = c.items;
        if (b) {
            this.buildMenuItems(e, b, d, f, a)
        }
    }
    return e
};
papaya.ui.Toolbar.prototype.buildMenuItems = function (g, b, e, f, a) {
    var h, d, c;
    if (a === undefined) {
        a = ""
    }
    for (h = 0; h < b.length; h += 1) {
        d = null;
        if (b[h].type === "spacer") {
            d = new papaya.ui.MenuItemSpacer()
        } else {
            if (b[h].type === "checkbox") {
                d = new papaya.ui.MenuItemCheckBox(this.viewer, b[h].label, b[h].action, bind(this, this.doAction), f, b[h].method, a)
            } else {
                if (b[h].type === "button") {
                    d = new papaya.ui.MenuItemFileChooser(this.viewer, b[h].label, b[h].action, bind(this, this.doAction))
                } else {
                    if (b[h].type === "displayrange") {
                        d = new papaya.ui.MenuItemRange(this.viewer, b[h].label, b[h].action, bind(this, this.doAction), f, b[h].method, a)
                    } else {
                        if (b[h].type === "range") {
                            if (isInputRangeSupported()) {
                                d = new papaya.ui.MenuItemSlider(this.viewer, b[h].label, b[h].action, bind(this, this.doAction), f, b[h].method, a)
                            }
                        } else {
                            d = new papaya.ui.MenuItem(this.viewer, b[h].label, b[h].action, bind(this, this.doAction), a)
                        }
                    }
                }
            }
        }
        if (d) {
            g.addMenuItem(d);
            if (b[h].items) {
                c = this.buildMenu(b[h], e, f, a);
                d.callback = bind(c, c.showMenu)
            }
        }
    }
};
papaya.ui.Toolbar.prototype.updateImageButtons = function () {
    var b, d, c, a;
    this.container.toolbarHtml.find("." + PAPAYA_MENU_BUTTON_CSS).remove();
    this.imageMenus = [];
    for (b = this.viewer.screenVolumes.length - 1; b >= 0; b -= 1) {
        d = this.viewer.screenVolumes[b];
        c = d.colorTable.icon;
        a = {
            menus: [{
                label: "ImageButton",
                icons: [c],
                items: null,
                imageButton: true
            }]
        };
        if (b === 0) {
            a.menus[0].items = papaya.ui.Toolbar.BASE_IMAGE_MENU_DATA.items
        } else {
            a.menus[0].items = papaya.ui.Toolbar.OVERLAY_IMAGE_MENU_DATA.items
        }
        this.imageMenus[b] = (this.buildMenu(a.menus[0], null, d, b.toString()))
    }
};
papaya.ui.Toolbar.prototype.closeAllMenus = function () {
    var b, a, c;
    b = this.container.toolbarHtml.find("." + PAPAYA_MENU_CSS);
    b.hide(100);
    b.remove();
    a = this.container.toolbarHtml.find("." + PAPAYA_DIALOG_CSS);
    a.hide(100);
    a.remove();
    c = this.container.toolbarHtml.find("." + PAPAYA_DIALOG_BACKGROUND);
    c.hide(100);
    c.remove()
};
papaya.ui.Toolbar.prototype.isShowingMenus = function () {
    var a, b;
    a = this.container.toolbarHtml.find("." + PAPAYA_MENU_CSS).is(":visible");
    b = this.container.toolbarHtml.find("." + PAPAYA_DIALOG_CSS).is(":visible");
    return (a || b)
};
papaya.ui.Toolbar.prototype.doAction = function (g, d, f) {
    var a, b, c, h, e;
    if (!f) {
        this.closeAllMenus()
    }
    if (g) {
        if (g.startsWith("ImageButton")) {
            a = parseInt(g.substr(g.length - 2, 1), 10);
            this.viewer.setCurrentScreenVol(a);
            this.updateImageButtons()
        } else {
            if (g.startsWith("Open-")) {
                e = g.substring(g.indexOf("-") + 1);
                this.viewer.loadImage(e)
            } else {
                if (g === "OpenImage") {
                    this.viewer.loadImage(d)
                } else {
                    if (g.startsWith("ColorTable")) {
                        b = g.substring(g.indexOf("-") + 1, g.lastIndexOf("-"));
                        a = g.substring(g.lastIndexOf("-") + 1);
                        this.viewer.screenVolumes[a].changeColorTable(this.viewer, b);
                        this.updateImageButtons()
                    } else {
                        if (g.startsWith("CloseAllImages")) {
                            this.viewer.resetViewer();
                            console.log("image fermée"+this);
                            console.log(this);
                            this.updateImageButtons();
                            
                        } else {
                            if (g === "Preferences") {
                                c = new papaya.ui.Dialog(this.container, "Preferences", papaya.ui.Toolbar.PREFERENCES_DATA, this.container.preferences, bind(this.container.preferences, this.container.preferences.updatePreference));
                                c.showDialog()
                            } else {
                                if (g.startsWith("ImageInfo")) {
                                    a = g.substring(g.lastIndexOf("-") + 1);
                                    c = new papaya.ui.Dialog(this.container, "Image Info", papaya.ui.Toolbar.IMAGE_INFO_DATA, this.viewer, null, a.toString());
                                    c.showDialog()
                                } else {
                                    if (g.startsWith("SPACE")) {
                                        this.viewer.toggleWorldSpace();
                                        this.viewer.drawViewer(true)
                                    } else {
                                        if (g.startsWith("AtlasChanged")) {
                                            h = g.substring(g.lastIndexOf("-") + 1);
                                            this.viewer.atlas.currentAtlas = h;
                                            this.viewer.drawViewer(true)
                                        } else {
                                            if (g.startsWith("EXPAND")) {
                                                if (this.container.collapsable) {
                                                    this.container.collapseViewer()
                                                } else {
                                                    this.container.expandViewer()
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
};
papaya.ui.Toolbar.prototype.updateTitleBar = function (b) {
    var a = this.container.titlebarHtml[0];
    if (a) {
        a.innerHTML = b
    }
    this.container.titlebarHtml.css({
        top: (this.container.viewerHtml.position().top - 1.25 * papaya.ui.Toolbar.SIZE)
    })
};
papaya.ui.Toolbar.prototype.showImageMenu = function (a) {
    this.viewer.screenVolumes[a].resetDynamicRange();
    this.imageMenus[a].showMenu()
};
papaya.ui.Toolbar.prototype.updateImageMenuRange = function (b, c, a) {
    this.imageMenus[b].updateRangeItem(c, a)
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItemSpacer = papaya.ui.MenuItemSpacer ||
function () {};
papaya.ui.MenuItemSpacer.prototype.buildHTML = function (b) {
    var a;
    a = "<div class='" + PAPAYA_MENU_SPACER_CSS + " " + PAPAYA_MENU_UNSELECTABLE + "'></div>";
    $("#" + b).append(a)
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItemCheckBox = papaya.ui.MenuItemCheckBox ||
function (e, b, c, g, d, f, a) {
    this.viewer = e;
    this.label = b;
    this.modifier = "";
    if ((a !== undefined) && (a !== null)) {
        this.modifier = "-" + a
    }
    this.action = c + this.modifier;
    this.method = f;
    this.id = this.action.replace(/ /g, "_").replace(/\(/g, "").replace(/\)/g, "") + this.viewer.container.containerIndex;
    this.callback = g;
    this.dataSource = d
};
papaya.ui.MenuItemCheckBox.CHECKBOX_UNSELECTED_CODE = "&#9744;";
papaya.ui.MenuItemCheckBox.CHECKBOX_SELECTED_CODE = "&#9745;";
papaya.ui.MenuItemCheckBox.prototype.buildHTML = function (e) {
    var c, d, b, a;
    c = this.dataSource[this.method](this.label);
    d = "";
    if (c) {
        d = "checked='checked'"
    }
    b = "<li id='" + this.id + "'><input type='radio' class='" + PAPAYA_MENU_COLORTABLE_CSS + "' name='" + PAPAYA_MENU_COLORTABLE_CSS + "' id='" + this.id + "' value='" + this.id + "' " + d + "><span class='" + PAPAYA_MENU_UNSELECTABLE + "'>&nbsp;" + this.label + "</span></li>";
    $("#" + e).append(b);
    a = $("#" + this.id);
    a.click(bind(this, this.doAction));
    a.hover(function () {
        $(this).toggleClass(PAPAYA_MENU_HOVERING_CSS)
    })
};
papaya.ui.MenuItemCheckBox.prototype.doAction = function () {
    $("." + PAPAYA_MENU_COLORTABLE_CSS).removeAttr("checked");
    $("#" + this.id + " > input")[0].checked = true;
    this.callback(this.action, null, true)
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.Menu = papaya.ui.Menu ||
function (d, b, e, c, a) {
    this.viewer = d;
    this.method = b.method;
    this.isTitleBar = b.titleBar;
    this.label = b.label;
    this.icons = b.icons;
    this.callback = e;
    this.dataSource = c;
    this.items = [];
    this.rangeItem = null;
    this.menuOnHover = b.menuOnHover;
    if ((a === undefined) || (a === null)) {
        this.imageIndex = -1;
        this.modifier = this.viewer.container.containerIndex
    } else {
        this.imageIndex = a;
        this.modifier = a + this.viewer.container.containerIndex
    }
    this.buttonId = this.label.replace(/ /g, "_").replace("...", "_") + (this.modifier || "");
    this.menuId = (this.label + "Menu").replace(/ /g, "_").replace("...", "_") + (this.modifier || "");
    this.isRight = (b.icons !== null);
    this.isImageButton = b.imageButton
};
papaya.ui.Menu.prototype.buildMenuButton = function () {
    var d, f, b, g, a, c, e;
    g = "#" + this.buttonId;
    b = $(g);
    b.remove();
    e = this.viewer.container.toolbarHtml;
    d = null;
    if (this.icons) {
        d = "<span id='" + this.buttonId + "' class='" + PAPAYA_MENU_UNSELECTABLE + " " + PAPAYA_MENU_ICON_CSS + " " + (this.isImageButton ? PAPAYA_MENU_BUTTON_CSS : "") + "'" + (this.isRight ? " style='float:right'" : "") + "><img class='" + PAPAYA_MENU_UNSELECTABLE + "' style='width:" + papaya.viewer.ColorTable.ICON_SIZE + "px; height:" + papaya.viewer.ColorTable.ICON_SIZE + "px; vertical-align:bottom; ";
        if (this.dataSource.isSelected(parseInt(this.imageIndex, 10))) {
            d += "border:2px solid #FF5A3D;background-color:#eeeeee;padding:1px;"
        } else {
            d += "border:2px outset lightgray;background-color:#eeeeee;padding:1px;"
        }
        if (this.method) {
            d += ("' src='" + this.icons[bind(this.viewer, derefIn(this.viewer, this.method))() ? 1 : 0] + "' /></span>")
        } else {
            d += ("' src='" + this.icons[0] + "' /></span>")
        }
    } else {
        if (this.isTitleBar) {
            d = "<div class='" + PAPAYA_MENU_UNSELECTABLE + " " + PAPAYA_MENU_TITLEBAR_CSS + " " + PAPAYA_TITLEBAR_CSS + "' style='z-index:-1;position:absolute;top:" + (this.viewer.container.viewerHtml.position().top - 1.25 * papaya.ui.Toolbar.SIZE) + "px;width:" + e.width() + "px;text-align:center;color:" + getNiceForegroundColor(this.viewer.bgColor) + "'>" + this.label + "</div>"
        } else {
            d = "<span id='" + this.buttonId + "' class='" + PAPAYA_MENU_UNSELECTABLE + " " + PAPAYA_MENU_LABEL_CSS + "'>" + this.label + "</span>"
        }
    }
    e.append(d);
    if (!this.isTitleBar) {
        b = $(g);
        c = "#" + this.buttonId + " > img";
        a = $(c);
        f = this;
        if (this.menuOnHover) {
            a.mouseenter(function () {
                f.showHoverMenuTimeout = setTimeout(bind(f, f.showMenu), 500)
            });
            a.mouseleave(function () {
                clearTimeout(f.showHoverMenuTimeout);
                f.showHoverMenuTimeout = null
            })
        }
        b.click(bind(this, this.doClick));
        if (this.icons) {
            a.hover(function () {
                if (f.icons.length > 1) {
                    $(this).css({
                        "border-color": "gray"
                    })
                } else {
                    $(this).css({
                        "border-color": "#FF5A3D"
                    })
                }
            }, bind(f, function () {
                if (f.dataSource.isSelected(parseInt(f.imageIndex, 10)) && f.dataSource.isSelectable()) {
                    $("#" + f.buttonId + " > img").css({
                        border: "2px solid #FF5A3D"
                    })
                } else {
                    $("#" + f.buttonId + " > img").css({
                        border: "2px outset lightgray"
                    })
                }
            }));
            a.mousedown(function () {
                $(this).css({
                    border: "2px inset lightgray"
                })
            });
            a.mouseup(function () {
                $(this).css({
                    border: "2px outset lightgray"
                })
            })
        } else {
            if (!this.isTitleBar) {
                b.hover(function () {
                    $(this).toggleClass(PAPAYA_MENU_BUTTON_HOVERING_CSS)
                })
            }
        }
    }
    return this.buttonId
};
papaya.ui.Menu.prototype.setMenuButton = function (a) {
    this.buttonId = a
};
papaya.ui.Menu.prototype.buildMenu = function () {
    var c, b, a;
    b = "<ul id='" + this.menuId + "' class='" + PAPAYA_MENU_CSS + "'></ul>";
    this.viewer.container.toolbarHtml.append(b);
    for (c = 0; c < this.items.length; c += 1) {
        a = this.items[c].buildHTML(this.menuId)
    }
};
papaya.ui.Menu.prototype.addMenuItem = function (a) {
    if (a instanceof papaya.ui.MenuItemRange) {
        this.rangeItem = a
    }
    this.items.push(a)
};
papaya.ui.Menu.prototype.showMenu = function () {
    var b, d, c, a;
    if (this.items.length > 0) {
        a = "#" + this.menuId;
        c = $(a);
        b = c.is(":visible");
        c.remove();
        if (!b) {
            d = $("#" + this.buttonId);
            this.buildMenu();
            c = $(a);
            c.hide();
            showMenu(this.viewer, d[0], c[0], this.isRight)
        }
    }
};
papaya.ui.Menu.prototype.doClick = function () {
    var b, c, a;
    a = "#" + this.menuId;
    c = $(a);
    b = c.is(":visible");
    this.callback(this.buttonId);
    if (this.icons) {
        if (this.method) {
            $("#" + this.buttonId + " > img").attr("src", this.icons[bind(this.viewer, derefIn(this.viewer, this.method))() ? 1 : 0])
        } else {
            $("#" + this.buttonId + " > img").attr("src", this.icons[0])
        }
    }
    if (!this.menuOnHover && !b) {
        this.showMenu()
    }
};
papaya.ui.Menu.prototype.updateRangeItem = function (b, a) {
    if (this.rangeItem) {
        $("#" + this.rangeItem.minId).val(b);
        $("#" + this.rangeItem.maxId).val(a)
    }
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.Dialog = papaya.ui.Dialog ||
function (b, e, c, d, f, a) {
    this.container = b;
    this.viewer = b.viewer;
    this.title = e;
    this.modifier = "";
    if (!isStringBlank(a)) {
        this.modifier = a
    }
    this.id = this.title.replace(/ /g, "_");
    this.content = c;
    this.dataSource = d;
    this.callback = f
};
papaya.ui.Dialog.prototype.showDialog = function () {
    var b, h, e, a, i, g, d, c, f;
    d = "#" + this.id;
    g = $(d);
    g.remove();
    f = $("body");
    e = "<div id='" + this.id + "' class='" + PAPAYA_DIALOG_CSS + "'><span class='" + PAPAYA_DIALOG_TITLE_CSS + "'>" + this.title + "</span>";
    if (this.content) {
        e += "<div class='" + PAPAYA_DIALOG_CONTENT_CSS + "'><table>";
        for (b = 0; b < this.content.items.length; b += 1) {
            if (this.content.items[b].spacer) {
                e += "<tr><td class='" + PAPAYA_DIALOG_CONTENT_LABEL_CSS + "'>&nbsp;</td><td class='" + PAPAYA_DIALOG_CONTENT_CONTROL_CSS + "'>&nbsp;</td></tr>"
            } else {
                if (this.content.items[b].readonly) {
                    e += "<tr><td class='" + PAPAYA_DIALOG_CONTENT_LABEL_CSS + "'>" + this.content.items[b].label + "</td><td class='" + PAPAYA_DIALOG_CONTENT_CONTROL_CSS + "' id='" + this.content.items[b].field + "'></td></tr>"
                } else {
                    if (this.content.items[b].disabled && (derefIn(this, this.content.items[b].disabled)) === true) {
                        c = "disabled='disabled'"
                    } else {
                        c = ""
                    }
                    e += "<tr><td class='" + PAPAYA_DIALOG_CONTENT_LABEL_CSS + "'>" + this.content.items[b].label + "</td><td class='" + PAPAYA_DIALOG_CONTENT_CONTROL_CSS + "'><select " + c + " id='" + this.content.items[b].field + "'>";
                    for (h = 0; h < this.content.items[b].options.length; h += 1) {
                        e += "<option value='" + this.content.items[b].options[h] + "'>" + this.content.items[b].options[h] + "</option>"
                    }
                    e += "</select></td></tr>"
                }
            }
        }
        e += "</table></div>"
    }
    e += "<div class='" + PAPAYA_DIALOG_BUTTON_CSS + "'><button type='button' id='" + this.id + "-Ok'>Ok</button></div></div>";
    f.append('<div class="' + PAPAYA_DIALOG_BACKGROUND + '"></div>');
    f.append(e);
    for (b = 0; b < this.content.items.length; b += 1) {
        if (this.content.items[b].readonly) {
            a = this.dataSource[this.content.items[b].field](this.modifier);
            if (a !== null) {
                $("#" + this.content.items[b].field).html(a)
            } else {
                $("#" + this.content.items[b].field).parent().remove()
            }
        } else {
            if (!this.content.items[b].spacer) {
                i = $("#" + this.content.items[b].field);
                i.val(this.dataSource[this.content.items[b].field]);
                i.change(bind(this, this.doAction, [this.content.items[b].field]))
            }
        }
    }
    $("#" + this.id + "-Ok").click(bind(this, this.doOk));
    g = $(d);
    showModalDialog(this.viewer, g[0]);
    f.addClass(PAPAYA_DIALOG_STOPSCROLL)
};
papaya.ui.Dialog.prototype.doOk = function () {
    var a, b;
    a = $("." + PAPAYA_DIALOG_CSS);
    b = $("." + PAPAYA_DIALOG_BACKGROUND);
    a.hide(100);
    b.hide(100);
    a.remove();
    b.remove();
    $("body").removeClass(PAPAYA_DIALOG_STOPSCROLL)
};
papaya.ui.Dialog.prototype.doAction = function (a) {
    this.callback(a, $("#" + a).val())
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItemRange = papaya.ui.MenuItemRange ||
function (e, b, c, g, d, f, a) {
    this.viewer = e;
    this.label = b;
    this.index = a;
    this.modifier = "";
    if (a !== undefined) {
        this.modifier = "-" + a
    }
    this.action = c + this.modifier;
    this.minId = this.action.replace(/ /g, "_") + "Min" + this.viewer.container.containerIndex;
    this.maxId = this.action.replace(/ /g, "_") + "Max" + this.viewer.container.containerIndex;
    this.callback = g;
    this.dataSource = d;
    this.method = f;
    this.id = b + this.modifier + this.viewer.container.containerIndex;
    this.grabOffset = 0;
    this.screenVol = this.viewer.screenVolumes[this.index]
};
papaya.ui.MenuItemRange.prototype.buildHTML = function (h) {
    var j, i, c, k, f, d, g, b, l, a, e;
    d = this.id + "SliderMin";
    b = this.id + "SliderMax";
    a = this.id + "Slider";
    j = this.dataSource[this.method]();
    c = this;
    i = "<li id='" + this.id + "'><span class='" + PAPAYA_MENU_UNSELECTABLE + "' style=''><input type='text' size='4' style='width:40px;margin-right:5px;' id='" + this.minId + "' value='" + j[0] + "' /><div style='display:inline-block;position:relative;width:" + (papaya.viewer.ColorTable.COLOR_BAR_WIDTH + papaya.viewer.ColorTable.ARROW_ICON_WIDTH) + "px;top:-12px;'><img id='" + d + "' class='" + PAPAYA_MENU_UNSELECTABLE + "' style='position:absolute;top:5px;left:" + (c.screenVol.colorTable.minLUT / papaya.viewer.ColorTable.LUT_MAX) * (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1) + "px;z-index:99' src='" + papaya.viewer.ColorTable.ARROW_ICON + "' /><img id='" + b + "' class='" + PAPAYA_MENU_UNSELECTABLE + "' style='position:absolute;top:5px;left:" + (c.screenVol.colorTable.maxLUT / papaya.viewer.ColorTable.LUT_MAX) * (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1) + "px;z-index:99' src='" + papaya.viewer.ColorTable.ARROW_ICON + "' /><img id='" + a + "' class='" + PAPAYA_MENU_UNSELECTABLE + "' style='position:absolute;top:0;left:" + (parseInt(papaya.viewer.ColorTable.ARROW_ICON_WIDTH / 2, 10)) + "px;' src='" + this.viewer.screenVolumes[parseInt(this.index, 10)].colorTable.colorBar + "' /></div><input type='text' size='4' style='width:40px;margin-left:5px;' id='" + this.maxId + "' value='" + j[1] + "' /></span></li>";
    $("#" + h).append(i);
    k = $("#" + this.minId);
    f = $("#" + this.maxId);
    g = $("#" + d);
    l = $("#" + b);
    e = $("#" + a);
    g.mousedown(function (m) {
        c.grabOffset = getRelativeMousePositionX(g, m);
        $(window).mousemove(function (n) {
            var o, p;
            p = (c.screenVol.colorTable.maxLUT / papaya.viewer.ColorTable.LUT_MAX) * (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1);
            o = (getRelativeMousePositionFromParentX(g, n) - c.grabOffset);
            if (o < 0) {
                o = 0
            } else {
                if (o >= papaya.viewer.ColorTable.COLOR_BAR_WIDTH) {
                    o = (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1)
                } else {
                    if (o > p) {
                        o = p
                    }
                }
            }
            c.screenVol.updateMinLUT(Math.round((o / (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1)) * papaya.viewer.ColorTable.LUT_MAX));
            g.css({
                left: o + "px"
            });
            c.viewer.drawViewer(false, true);
            k.val(c.dataSource[c.method]()[0]);
            c.screenVol.colorTable.updateColorBar();
            e.attr("src", c.screenVol.colorTable.colorBar)
        });
        return false
    });
    l.mousedown(function (m) {
        c.grabOffset = getRelativeMousePositionX(l, m);
        $(window).mousemove(function (o) {
            var p, n;
            n = (c.screenVol.colorTable.minLUT / papaya.viewer.ColorTable.LUT_MAX) * (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1);
            p = (getRelativeMousePositionFromParentX(l, o) - c.grabOffset);
            if (p < 0) {
                p = 0
            } else {
                if (p >= papaya.viewer.ColorTable.COLOR_BAR_WIDTH) {
                    p = (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1)
                } else {
                    if (p < n) {
                        p = n
                    }
                }
            }
            c.screenVol.updateMaxLUT(Math.round((p / (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1)) * papaya.viewer.ColorTable.LUT_MAX));
            l.css({
                left: p + "px"
            });
            c.viewer.drawViewer(false, true);
            f.val(c.dataSource[c.method]()[1]);
            c.screenVol.colorTable.updateColorBar();
            e.attr("src", c.screenVol.colorTable.colorBar)
        });
        return false
    });
    $(window).mouseup(function () {
        $(window).unbind("mousemove")
    });
    $("#" + this.id).hover(function () {
        $(this).toggleClass(PAPAYA_MENU_HOVERING_CSS)
    });
    k.change(bind(this, function () {
        c.rangeChanged(true)
    }));
    f.change(bind(this, function () {
        c.rangeChanged(false)
    }));
    k.keyup(bind(this, function (m) {
        if (m.keyCode === 13) {
            c.rangeChanged(false);
            c.viewer.container.toolbar.closeAllMenus()
        }
    }));
    f.keyup(bind(this, function (m) {
        if (m.keyCode === 13) {
            c.rangeChanged(false);
            c.viewer.container.toolbar.closeAllMenus()
        }
    }));
    setTimeout(function () {
        k.focus();
        k.select()
    }, 10)
};
papaya.ui.MenuItemRange.prototype.rangeChanged = function (a) {
    this.updateDataSource(a);
    this.viewer.drawViewer(true);
    this.resetSlider()
};
papaya.ui.MenuItemRange.prototype.updateDataSource = function (c) {
    var a, b, e, d;
    d = $("#" + this.minId);
    e = $("#" + this.maxId);
    b = parseFloat(d.val());
    if (isNaN(b)) {
        b = this.dataSource.screenMin
    }
    a = parseFloat(e.val());
    if (isNaN(a)) {
        a = this.dataSource.screenMax
    }
    d.val(b);
    e.val(a);
    this.dataSource.setScreenRange(b, a);
    if (c) {
        e.focus();
        e.select()
    }
};
papaya.ui.MenuItemRange.prototype.resetSlider = function () {
    var e, b, f, a, c, d;
    e = this.id + "SliderMin";
    f = this.id + "SliderMax";
    c = this.id + "Slider";
    b = $("#" + e);
    a = $("#" + f);
    d = $("#" + c);
    b.css({
        left: 0
    });
    a.css({
        left: (papaya.viewer.ColorTable.COLOR_BAR_WIDTH - 1) + "px"
    });
    this.screenVol.resetDynamicRange();
    d.attr("src", this.screenVol.colorTable.colorBar)
};
"use strict";
var papaya = papaya || {};
papaya.ui = papaya.ui || {};
papaya.ui.MenuItem = papaya.ui.MenuItem ||
function (d, b, c, e, a) {
    this.viewer = d;
    this.label = b;
    this.modifier = "";
    if (!isStringBlank(a)) {
        this.modifier = "-" + a
    }
    this.action = c + this.modifier;
    this.id = this.action.replace(/ /g, "_") + this.viewer.container.containerIndex;
    this.callback = e
};
papaya.ui.MenuItem.prototype.buildHTML = function (c) {
    var b, a;
    b = "<li id='" + this.id + "'><span class='" + PAPAYA_MENU_UNSELECTABLE + "'>" + this.label + "</span></li>";
    $("#" + c).append(b);
    a = $("#" + this.id);
    a.click(bind(this, function () {
        this.doAction()
    }));
    a.hover(function () {
        $(this).toggleClass(PAPAYA_MENU_HOVERING_CSS)
    })
};
papaya.ui.MenuItem.prototype.doAction = function () {
    this.callback(this.action)
};
"use strict";
var papaya = papaya || {};
var papayaContainers = [];
var papayaLoadableImages = papayaLoadableImages || [];
var papayaLastHoveredViewer = null;
papaya.Container = papaya.Container ||
function (a) {
    this.containerHtml = a;
    this.containerIndex = null;
    this.toolbarHtml = null;
    this.viewerHtml = null;
    this.displayHtml = null;
    this.titlebarHtml = null;
    this.sliderControlHtml = null;
    this.viewer = null;
    this.display = null;
    this.toolbar = null;
    this.preferences = null;
    this.params = [];
    this.loadingImageIndex = 0;
    this.nestedViewer = false;
    this.collapsable = false;
    this.orthogonal = true;
    this.resetComponents()
};
papaya.Container.prototype.resetComponents = function () {
    this.containerHtml.css({
        height: "auto"
    });
    this.containerHtml.css({
        width: "auto"
    });
    this.containerHtml.css({
        margin: "auto"
    });
    $("head").append("<style>div#papayaViewer:before{ content:'' }</style>")
};
papaya.Container.prototype.getViewerDimensions = function () {
    var h = 2,
        b = PAPAYA_MINIMUM_SIZE,
        e = PAPAYA_MINIMUM_SIZE,
        a, d, f, g, c;
    if (!this.kioskMode) {
        h += 1
    }
    if (this.nestedViewer) {
        b = this.containerHtml.parent().height();
        e = this.containerHtml.parent().width()
    } else {
        b = window.innerHeight;
        e = window.innerWidth
    }
    if (b < PAPAYA_MINIMUM_SIZE) {
        b = PAPAYA_MINIMUM_SIZE;
        if (this.kioskMode) {
            this.containerHtml.parent().height(PAPAYA_MINIMUM_SIZE * 0.8)
        } else {
            this.containerHtml.parent().height(PAPAYA_MINIMUM_SIZE * 0.9)
        }
    } else {
        if (!this.nestedViewer) {
            this.containerHtml.parent().height("100%")
        }
    }
    if (e < PAPAYA_MINIMUM_SIZE) {
        e = PAPAYA_MINIMUM_SIZE;
        this.containerHtml.parent().width(PAPAYA_MINIMUM_SIZE)
    } else {
        if (!this.nestedViewer) {
            this.containerHtml.parent().width("100%")
        }
    }
    c = (this.orthogonal ? 1.5 : 1);
    a = b - PAPAYA_SECTION_HEIGHT * h;
    d = a * c;
    if (d > e) {
        d = e - PAPAYA_SPACING * 2;
        a = Math.ceil(d / c)
    }
    f = (e - d) / 2;
    g = new papaya.core.Dimensions(d, a);
    g.widthPadding = f;
    g.heightPadding = PAPAYA_CONTAINER_PADDING_TOP;
    return g
};
papaya.Container.prototype.resizeViewerComponents = function (a) {
    this.toolbar.closeAllMenus();
    var b = this.getViewerDimensions();
    this.toolbarHtml.css({
        paddingLeft: b.widthPadding + "px"
    });
    this.toolbarHtml.css({
        paddingBottom: PAPAYA_SPACING + "px"
    });
    this.toolbarHtml.css({
        width: b.width + "px"
    });
    this.toolbarHtml.css({
        height: papaya.ui.Toolbar.SIZE + "px"
    });
    this.viewerHtml.css({
        height: "100%"
    });
    this.viewerHtml.css({
        width: b.width + "px"
    });
    this.viewerHtml.css({
        paddingLeft: b.widthPadding + "px"
    });
    if (a) {
        this.viewer.resizeViewer(b)
    }
    this.displayHtml.css({
        height: PAPAYA_SECTION_HEIGHT + "px"
    });
    this.displayHtml.css({
        paddingLeft: b.widthPadding + "px"
    });
    this.display.canvas.width = b.width;
    if (this.sliderControlHtml) {
        this.sliderControlHtml.css({
            width: b.width + "px"
        })
    }
    this.containerHtml.css({
        paddingTop: b.heightPadding + "px"
    });
    if (this.viewer.initialized) {
        this.viewer.drawViewer(false, true)
    } else {
        this.viewer.drawEmptyViewer();
        this.display.drawEmptyDisplay()
    }
    this.titlebarHtml.css({
        width: b.width + "px",
        top: (this.viewerHtml.position().top - 1.25 * papaya.ui.Toolbar.SIZE)
    })
};
papaya.Container.prototype.updateViewerSize = function () {
    this.toolbar.closeAllMenus();
    this.viewer.resizeViewer(this.getViewerDimensions());
    this.viewer.updateOffsetRect()
};

function removeCheckForJSClasses(b, a) {
    a.removeClass(PAPAYA_CONTAINER_CLASS_NAME);
    a.removeClass(PAPAYA_UTILS_CHECKFORJS_CSS);
    b.removeClass(PAPAYA_CONTAINER_CLASS_NAME);
    b.removeClass(PAPAYA_UTILS_CHECKFORJS_CSS)
}
papaya.Container.prototype.buildViewer = function (b) {
    var a;
    this.viewerHtml = this.containerHtml.find("." + PAPAYA_VIEWER_CSS);
    removeCheckForJSClasses(this.containerHtml, this.viewerHtml);
    this.viewerHtml.html("");
    a = this.getViewerDimensions();
    this.viewer = new papaya.viewer.Viewer(this, a.width, a.height, b);
    this.viewerHtml.append($(this.viewer.canvas));
    this.preferences.viewer = this.viewer
};
papaya.Container.prototype.buildDisplay = function () {
    var a;
    this.displayHtml = this.containerHtml.find("." + PAPAYA_DISPLAY_CSS);
    a = this.getViewerDimensions();
    this.display = new papaya.viewer.Display(this, a.width);
    this.displayHtml.append($(this.display.canvas))
};
papaya.Container.prototype.buildSliderControl = function () {
    this.sliderControlHtml = this.containerHtml.find("." + PAPAYA_SLIDER_CSS)
};
papaya.Container.prototype.buildToolbar = function () {
    this.toolbarHtml = this.containerHtml.find("." + PAPAYA_TOOLBAR_CSS);
    this.toolbar = new papaya.ui.Toolbar(this);
    this.toolbar.buildToolbar();
    this.toolbar.updateImageButtons()
};
papaya.Container.prototype.setUpDnD = function () {
    var a = this;
    this.containerHtml[0].ondragover = function () {
        a.viewer.draggingOver = true;
        if (!a.viewer.initialized) {
            a.viewer.drawEmptyViewer()
        }
        return false
    };
    this.containerHtml[0].ondragleave = function () {
        a.viewer.draggingOver = false;
        if (!a.viewer.initialized) {
            a.viewer.drawEmptyViewer()
        }
        return false
    };
    this.containerHtml[0].ondragend = function () {
        a.viewer.draggingOver = false;
        if (!a.viewer.initialized) {
            a.viewer.drawEmptyViewer()
        }
        return false
    };
    this.containerHtml[0].ondrop = function (b) {
        b.preventDefault();
        if (b.dataTransfer.files.length > 1) {
            a.display.drawError("Please drop one file at a time.")
        } else {
            a.viewer.loadImage(b.dataTransfer.files[0])
        }
        return false
    }
};
papaya.Container.prototype.clearParams = function () {
    this.params = []
};
papaya.Container.prototype.loadNext = function () {
    var a = false;
    this.loadingImageIndex += 1;
    if (this.params.images) {
        if (this.loadingImageIndex < this.params.images.length) {
            a = true;
            this.viewer.loadImage(this.params.images[this.loadingImageIndex], true, false)
        }
    } else {
        if (this.params.encodedImages) {
            if (this.loadingImageIndex < this.params.encodedImages.length) {
                a = true;
                this.viewer.loadImage(this.params.encodedImages[this.loadingImageIndex], false, true)
            }
        }
    }
    return a
};
papaya.Container.prototype.findLoadableImage = function (a) {
    var b;
    for (b = 0; b < papayaLoadableImages.length; b += 1) {
        if (papayaLoadableImages[b].name === a) {
            return papayaLoadableImages[b]
        }
    }
    return null
};

function setToFullPage() {
    document.body.style.marginTop = 0;
    document.body.style.marginBottom = 0;
    document.body.style.marginLeft = "auto";
    document.body.style.marginRight = "auto";
    document.body.style.padding = 0;
    document.body.style.overflow = "hidden";
    document.body.style.width = "100%";
    document.body.style.height = "100%"
}
papaya.Container.prototype.expandViewer = function () {
    var a = this;
    if (this.nestedViewer) {
        this.nestedViewer = false;
        this.collapsable = true;
        this.tempScrollTop = $(window).scrollTop();
        $(":hidden").addClass(PAPAYA_CONTAINER_COLLAPSABLE_EXEMPT);
        $(document.body).children().hide();
        this.containerHtml.show();
        this.originalStyle = {};
        this.originalStyle.width = document.body.style.width;
        this.originalStyle.height = document.body.style.height;
        this.originalStyle.marginTop = document.body.style.marginTop;
        this.originalStyle.marginRight = document.body.style.marginRight;
        this.originalStyle.marginBottom = document.body.style.marginBottom;
        this.originalStyle.marginLeft = document.body.style.marginLeft;
        this.originalStyle.paddingTop = document.body.style.paddingTop;
        this.originalStyle.paddingRight = document.body.style.paddingRight;
        this.originalStyle.paddingBottom = document.body.style.paddingBottom;
        this.originalStyle.paddingLeft = document.body.style.paddingLeft;
        this.originalStyle.overflow = document.body.style.overflow;
        setToFullPage();
        this.containerHtml.after('<div style="display:none" class="' + PAPAYA_CONTAINER_COLLAPSABLE + '"></div>');
        $(document.body).prepend(this.containerHtml);
        this.resizeViewerComponents(true);
        this.viewer.updateOffsetRect();
        setTimeout(function () {
            window.scrollTo(0, 0);
            a.viewer.addScroll()
        }, 0)
    }
};
papaya.Container.prototype.collapseViewer = function () {
    var b, a;
    a = this;
    if (this.collapsable) {
        this.nestedViewer = true;
        this.collapsable = false;
        document.body.style.width = this.originalStyle.width;
        document.body.style.height = this.originalStyle.height;
        document.body.style.marginTop = this.originalStyle.marginTop;
        document.body.style.marginRight = this.originalStyle.marginRight;
        document.body.style.marginBottom = this.originalStyle.marginBottom;
        document.body.style.marginLeft = this.originalStyle.marginLeft;
        document.body.style.paddingTop = this.originalStyle.paddingTop;
        document.body.style.paddingRight = this.originalStyle.paddingRight;
        document.body.style.paddingBottom = this.originalStyle.paddingBottom;
        document.body.style.paddingLeft = this.originalStyle.paddingLeft;
        document.body.style.overflow = this.originalStyle.overflow;
        $("." + PAPAYA_CONTAINER_COLLAPSABLE).replaceWith(this.containerHtml);
        $(document.body).children(":not(." + PAPAYA_CONTAINER_COLLAPSABLE_EXEMPT + ")").show();
        $("." + PAPAYA_CONTAINER_COLLAPSABLE_EXEMPT).removeClass(PAPAYA_CONTAINER_COLLAPSABLE_EXEMPT);
        this.resizeViewerComponents(true);
        for (b = 0; b < papayaContainers.length; b += 1) {
            papayaContainers[b].updateViewerSize();
            papayaContainers[b].viewer.drawViewer(true)
        }
        setTimeout(function () {
            $(window).scrollTop(a.tempScrollTop);
            a.viewer.removeScroll()
        }, 0)
    }
};
papaya.Container.prototype.isNestedViewer = function () {
    return (this.nestedViewer || this.collapsable)
};

function findParameters(c) {
    var b, a, d = null;
    a = c.data("params");
    if (!a) {
        b = c.find("." + PAPAYA_VIEWER_CSS);
        if (b) {
            a = b.data("params")
        }
    }
    if (a) {
        d = window[a]
    }
    getQueryParams(d);
    return d
}
function fillContainerHTML(c, d, e) {
    var a, b, f;
    if (d) {
        a = c.find("#" + PAPAYA_DEFAULT_TOOLBAR_ID);
        b = c.find("#" + PAPAYA_DEFAULT_VIEWER_ID);
        f = c.find("#" + PAPAYA_DEFAULT_DISPLAY_ID);
        if (a) {
            a.addClass(PAPAYA_TOOLBAR_CSS)
        } else {
            c.prepend("<div class='" + PAPAYA_TOOLBAR_CSS + "' id='" + PAPAYA_DEFAULT_TOOLBAR_ID + "'></div>")
        }
        if (b) {
            b.addClass(PAPAYA_VIEWER_CSS)
        } else {
            $("<div class='" + PAPAYA_VIEWER_CSS + "' id='" + PAPAYA_DEFAULT_VIEWER_ID + "'></div>").insertAfter($("#" + PAPAYA_DEFAULT_TOOLBAR_ID))
        }
        if (f) {
            f.addClass(PAPAYA_DISPLAY_CSS)
        } else {
            $("<div class='" + PAPAYA_DISPLAY_CSS + "' id='" + PAPAYA_DEFAULT_DISPLAY_ID + "'></div>").insertAfter($("#" + PAPAYA_DEFAULT_VIEWER_ID))
        }
        console.log("This method of adding a Papaya container is deprecated.  Try simply <div class='papaya' data-params='params'></div> instead...")
    } else {
        c.attr("id", PAPAYA_DEFAULT_CONTAINER_ID + papayaContainers.length);
        if (!e || (e.kioskMode === undefined) || !e.kioskMode) {
            c.append("<div id='" + (PAPAYA_DEFAULT_TOOLBAR_ID + papayaContainers.length) + "' class='" + PAPAYA_TOOLBAR_CSS + "'></div>")
        }
        c.append("<div id='" + (PAPAYA_DEFAULT_VIEWER_ID + papayaContainers.length) + "' class='" + PAPAYA_VIEWER_CSS + "'></div>");
        c.append("<div id='" + (PAPAYA_DEFAULT_DISPLAY_ID + papayaContainers.length) + "' class='" + PAPAYA_DISPLAY_CSS + "'></div>");
        if (e && (e.orthogonal !== undefined) && !e.orthogonal) {
            if (isInputRangeSupported()) {
                c.append("<div id='" + (PAPAYA_DEFAULT_SLIDER_ID + papayaContainers.length) + "' class='" + PAPAYA_SLIDER_CSS + "'><input type='range' /></div>")
            }
        }
    }
    return b
}
function buildContainer(d, f) {
    var a, c, e, b;
    c = checkForBrowserCompatibility();
    e = d.find("." + PAPAYA_VIEWER_CSS);
    if (c !== null) {
        removeCheckForJSClasses(d, e);
        d.addClass(PAPAYA_UTILS_UNSUPPORTED_CSS);
        e.addClass(PAPAYA_UTILS_UNSUPPORTED_MESSAGE_CSS);
        e.html(c)
    } else {
        a = new papaya.Container(d);
        a.containerIndex = papayaContainers.length;
        a.preferences = new papaya.viewer.Preferences();
        removeCheckForJSClasses(d, e);
        if (f) {
            a.params = $.extend(a.params, f)
        }
        a.nestedViewer = (d.parent()[0].tagName.toUpperCase() !== "BODY");
        a.kioskMode = (a.params.kioskMode === true);
        if (a.params.orthogonal !== undefined) {
            a.orthogonal = a.params.orthogonal
        }
        a.buildViewer(a.params);
        a.buildDisplay();
        a.buildToolbar();
        if (!a.orthogonal) {
            a.buildSliderControl()
        }
        a.setUpDnD();
        b = e.data("load-url");
        if (b) {
            a.viewer.loadImage(b, true, false)
        } else {
            if (a.params.images) {
                a.viewer.loadImage(a.params.images[0], true, false)
            } else {
                if (a.params.encodedImages) {
                    a.viewer.loadImage(a.params.encodedImages[0], false, true)
                }
            }
        }
        a.resizeViewerComponents(false);
        papayaContainers.push(a)
    }
}
function buildAllContainers() {
    var a, b;
    a = $("#" + PAPAYA_DEFAULT_CONTAINER_ID);
    if (a.length > 0) {
        fillContainerHTML(a, true);
        b = findParameters(a);
        buildContainer(a, b)
    } else {
        $("." + PAPAYA_CONTAINER_CLASS_NAME).each(function () {
            b = findParameters($(this));
            fillContainerHTML($(this), false, b);
            buildContainer($(this), b)
        })
    }
    if ((papayaContainers.length === 0) || ((papayaContainers.length === 1) && !papayaContainers[0].nestedViewer)) {
        $("html").addClass(PAPAYA_CONTAINER_FULLSCREEN);
        $("body").addClass(PAPAYA_CONTAINER_FULLSCREEN);
        setToFullPage();
        if (papayaContainers.length > 0) {
            papayaContainers[0].resizeViewerComponents(false)
        }
    }
}
function addViewer(c, d, e) {
    var a, b;
    b = $("#" + c);
    a = $('<div class="papaya"></div>');
    b.html(a);
    b[0].onclick = "";
    b.off("click");
    fillContainerHTML(a, false, d);
    buildContainer(a, d);
    if (e) {
        e()
    }
}
function main() {
    setTimeout(function () {
        window.scrollTo(0, 0)
    }, 0);
    buildAllContainers()
}
window.onload = main;
window.onresize = function () {
    if ((papayaContainers.length === 1) && !papayaContainers[0].nestedViewer) {
        papayaContainers[0].resizeViewerComponents(true)
    } else {
        var a;
        for (a = 0; a < papayaContainers.length; a += 1) {
            if (papayaContainers[a].collapsable) {
                papayaContainers[a].resizeViewerComponents(true)
            } else {
                papayaContainers[a].updateViewerSize()
            }
        }
    }
};



//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################
//##################################################################################################################################################################################

/*Parse une chaine de caractère représentant l'intégralité d'un FICHIER RTSTRUCT et renvoi un tableau des ROI(s) détectées, sous forme de chaine de caractères
* @data : la chaine de caractère à parser
* @return : un tableau contenant toutes les ROIs détectées
*/
function parseROIs(data) {
    var tableau = new Array();
    var fin = data.indexOf("0x30060080");
    var debut = data.indexOf("0x30060039");
    var string = data.slice(debut,fin);
    while (debut<string.length-5) {
        debut = string.indexOf(" >BEGIN ITEM");
        fin = string.indexOf(" >END ITEM")+13;
        tableau.push(string.slice(debut,fin));
        string = string.slice(fin);
        debut = 0;
    }
    return tableau;
}

/*Parse une chaine de caractère représentant un ROI et renvoi un tableau des coupes présentes dans ce ROI, sous forme de chaine de caractères.
*@roidata : le roi à parser
*@return :  un tableau contenant l'ensemble des coupes associées au ROI voulu, contenues dans @roidata
*/
function parseCUTs(roidata) {
    var tableau = new Array();
    var fin = 0,
            debut = 0;
    var string = roidata;
    while (debut<string.length-5) {
        debut = string.indexOf(" >>BEGIN ITEM");
        fin = string.indexOf(" >>END ITEM")+13;
        tableau.push(string.slice(debut,fin));
        string = string.slice(fin);
        debut = 0;
    }
    return tableau;
}


/*Parse une chaine de caractère représentant une COUPE et renvoi un tableau de triplets présentant l'ensemble des coordonnées des points trouvées au sein de la coupe en paramètre, sous forme de chaine de caractères.
*@roidata : la coupe
*@return :  un tableau contenant l'ensemble des coordonnées, contenues dans @cutdata
*/
function parsePOINTs(cutdata) {
    var debut = cutdata.indexOf("DS,")+3;
    var fin =  cutdata.indexOf("#",debut)-1;
    var string = cutdata.slice(debut,fin).trim();
    var split = string.split("\\");
    var tableau = new Array();
    var i;
    for (i=0;i<split.length-1;i+=3) {
        var coord = new Array(split[i],split[i+1],split[i+2]);
        tableau.push(coord);
    }
    return tableau;
}

/*Parse une chaine de caractère représentant l'intégralité d'un FICHIER RTSTRUCT et renvoi un tableau contenant tous les noms des ROIs trouvées
*@data :  la chaine de caractère à parser
*@return :  un tableau contenant l'ensemble des noms des ROIs trouvées
*/
function getRoiNames(data) {
    var pt=0;
    var roiNames = new Array();
    while (pt<(data.length-9)) {
        var index = data.indexOf("30060026", pt); 
        if (index!=-1) {
            var roiName = data.slice(index+13,data.indexOf("#",index)-1).trim();
            roiNames.push(roiName); 
            pt=index+1
        } else break;
    }
    return roiNames;
}

/*
function clickROI(titre) {
    $(titre).next().slideToggle();
    $('body').animate({
        scrollTop: $(titre).offset().top
    }, 1000);
}

function clickCUT(titre) {
    $(titre).next().slideToggle();
    $('body').animate({
        scrollTop: $(titre).offset().top
    }, 1000);
}

function displayRTstruct(pathtotxtfile) {
    $.get( pathtotxtfile, function(data) {
        //Segmenter les ROIs
        var i,j,k;
        var toprint = "";
        var roiNames = getRoiNames(data);
        var roiTable = parseROIs(data);
        var cutsTable = parseCUTs(roiTable[0]);
        // parsePOINTs(tableCUTs[0]);
        toprint += "<div class='roi'>";
        for (i=0;i<roiNames.length;i++) {
            console.log("traitement roi n°"+(i+1));
            toprint += "<h2 onClick='javascript:clickROI(this)'>"+(roiNames[i])+"</h2>";
            toprint += "<div class='cuts'>";
            var cuts = parseCUTs(roiTable[i]);
            for (j=0;j<cuts.length;j++) {
                toprint += "<h3 onClick='javascript:clickCUT(this)'>Coupe n°"+(j+1)+"</h3>";
                toprint += "<table class='points'>";
                toprint += "<thead><th>X</th><th>Y</th><th>Z</th></thead>";
                var points = parsePOINTs(cuts[j]);
                for (k=0;k<points.length;k++) {
                    points[k][0] = Math.round(parseFloat(points[k][0])*0.788+256);
                    points[k][1] = Math.round(parseFloat(points[k][1])*0.788+259);
                    points[k][2] = Math.round((parseFloat(points[k][2])+479)/2.5);
                    toprint += "<tr>";
                    toprint += "<td>"+points[k][0]+"</td><td>"+points[k][1]+"</td><td>"+points[k][2]+"</td>";
                    toprint += "</tr>";
                    
                }
                toprint += "</table>";
            }
            toprint +="</div>";
        }
        toprint += "</div>";
        // console.log(toprint);
        $("body").html(toprint);
    });
}
*/


function sleep (ms){
    var start = new Date().getTime();
    while (new Date().getTime() < start+ms);
}

function checkChange (idROI){
//    console.log("idROI : "+idROI);
//    ROISelectedForTim=[];
//    $.each(ROISelected, function(index, value){
//       if(index == idROI){
//           console.log("index : "+(index));
//           value.isSelected = !value.isSelected;
//           
//       } 
//       if(value.isSelected){
//           ROISelectedForTim=ROISelectedForTim.concat(value.tableau);
//       }
//       
//    });
//    $("#File").click();
//    $("#CloseAllImages0").click();
//    canvasready = false;
//    $("#File").click();
//        $("#Open-ATLAS40").click();
//
////    while (!canvasready) sleep(1000);
////        $("#File").click();
////        $("#Open-CRONOR0").click();
//
//    
//    
//        setTimeout(function(){
//        $("#File").click();
//        $("#Open-CRONOR0").click();
//    }, 5000);


    buildRTstruct("RTStruct.txt");
    DeleteDoublon("mystruct");
    //    var tab = buildRTMatrix("RTStruct.txt");
    //console.log("ready");
    globalCoordTmp=0;
    params["images"] = ["ATLAS.nii", "CRONOR.nii"];
    params["CRONOR.nii"] = {"min": 1, "max": 106, "lut": "Spectrum", "alpha": 0.5};
    params["ATLAS.nii"] = {"min": -100, "max": 300};
//    params["CRONOR.nii"] = {"min": 1, "max": 100, "lut": "Spectrum", "alpha": 0.5};

//
//    $("#File").click();
//    
//    $("#Open-CRONOR0").click();

    
    
//    $('#papayaDiv').remove();
 //   $('body').append("<div id='papayaDiv' class='papaya' data-params='params'></div>");
    console.log(ROISelected);
    
}


function test(){
    //console.log(event);
    $('#localisation').slideToggle(500);
}

/*Prend un fichier RTstruct au format ".txt" et affecte la variable globale mystruct avec notre structure fonctionnelle 
*@pathtotxtfile :  une chaine de caractère représentant le chemin absolu ou relatif vers le fichier en question
*@return : VOID
*/
function buildRTstruct(pathtotxtfile) {
    var rois;
    $.get( pathtotxtfile, function(data) {
        //Segmenter les ROIs
        var i,j,k;
        rois = new Array();
        var roiNames = getRoiNames(data);
        var roiTable = parseROIs(data);
        
        for (i=0;i<roiNames.length;i++) {
//            console.log("traitement roi n°"+(i+1));
            
            var roicuts = new Array();
            var cuts = parseCUTs(roiTable[i]);
            
            for (j=0;j<cuts.length;j++) {
                var points = parsePOINTs(cuts[j]);
                
                for (k=0;k<points.length;k++) {
                    
                    points[k][0] = Math.round(parseFloat(points[k][0])*(-1/0.512)+255.5);
                    points[k][1] = Math.round(parseFloat(points[k][1])*(1/0.512)+255.5);
                    points[k][2] = Math.round((parseFloat(points[k][2])*(-1)/2)+49);
                    
                    
//                    points[k][0] = Math.round(parseFloat(points[k][0])*(-1.966)+256);
//                    points[k][1] = Math.round(parseFloat(points[k][1])*(1.966)+256);
//                    points[k][2] = Math.round((parseFloat(points[k][2])*(-1)/2)+49);
//                    points[k] = papaya.volume.getIndexCoordinateAtWorld(points[k][0],points[k][1],points[k][2], true);

                    
                    if (typeof(roicuts[points[k][2]])=="object") {
                        roicuts[points[k][2]].push(new Array(points[k][0],points[k][1]));
                    } else {
                        roicuts[points[k][2]] = new Array(new Array(points[k][0],points[k][1]));
                    }
                }
            }
            rois[i]=roicuts;
        }
        mystruct = rois;
    }).complete(function() {
        console.log("Structure built");
    });
    
}
/*
    function buildRTMatrix(pathtotxtfile) {
    var table;
    $.get( pathtotxtfile, function(data) {
        //Création de tableau
        table = new Array();
        for (i=0;i<20;i++) {
            console.log("building roi table"+i);
            var plan = new Array();
            for (j=0;j<512;j++) {
                var line = new Array();
                for (k=0;k<512;k++) {
                    var cell = "00000000000000000000";
                    line.push(cell);
                }
                plan.push(line);
            }
            table.push(plan);
        }
    }).complete(function() {
        return table;
        
    });
}
*/

function getCoord(){
	console.log(globalCoord);
	//console.log(papaya);
}

function toggleroi(boutton){
	var idint;
	if ($("#check1")[0].checked) {
		idint = setInterval(drawPlan,100);
		$("#check1").attr("intervalID", idint);
			} else {
		clearInterval($("#check1").attr("intervalID"));
	}
}

function toggleroi2(boutton){
	var idint2;
	if ($("#check2")[0].checked) {
                idint2 = setInterval(drawPlan2,100);
		$("#check2").attr("intervalID", idint2);
			} else {
		clearInterval($("#check2").attr("intervalID"));
	}
}

function evenement(){
	setInterval(function(){
//		console.log(globalCoord);
		if(globalCoordTmp!=globalCoord){
			console.log("changé");
			globalCoordTmp=0;
			globalCoordTmp=globalCoord;
		}
		//console.log(globalCoord);
	}, 1000)
}

/*Dessine le contour de la ROI voulu, si il existe, dans le canvas papaya
*@roi : un objet roi de notre structure
*@x , @y, @z : coordonnées du contexte actuelle
*@coeff : le coefficient permettant d'adapter la résolution initiale de notre structure (512*512)
*/
function drawRoi(roi,x,y,z,coeff) {
    //console.log("start drawing roi");
    //console.log(z);
    //console.log(roi[z]);
    if (typeof(roi[z])!="undefined") {
        console.log(roi[z]);
        //console.log("drawing roi");
        /*var tmp;*/
        for (i=0;i<roi[z].length-1;i++) {
            /*if (i==0) {
                tmp = new Array(roi[z][i][0],roi[z][i][1]);
            } else {*/
            //console.log("drawing line");
                jQuery('canvas').first().drawLine({
                    strokeStyle: 'red',
                    strokeWidth: 1.5,
                    rounded: true,
                    x1: coeff*roi[z][i][0], y1: coeff*roi[z][i][1],
                    x2: coeff*roi[z][i+1][0], y2: coeff*roi[z][i+1][1]
                    

                    
                });
                
                
               /* tmp = new Array(roi[z][i][0],roi[z][i][1]);*/
           /* }*/
                    
        }
        /*$('canvas').first().drawLine({
                    strokeStyle: 'red',
                    strokeWidth: 1.5,
                    rounded: true,
                    x1: coeff*roi[z][roi[z].length-1][0], y1: coeff*roi[z][roi[z].length-1][1],
                    x2: coeff*roi[z][0][0], y2: coeff*roi[z][0][1]
                }); */
    }
}



function drawRoi2(roi,x,y,z,coeff) {
 if (typeof(roi[z])!="undefined") {

        for (i=0;i<roi[x].length-1;i++) {
            /*if (i==0) {
                tmp = new Array(roi[z][i][0],roi[z][i][1]);
            } else {*/
            //console.log("drawing line");
                jQuery('canvas').first().drawLine({
                    strokeStyle: 'red',
                    strokeWidth: 1.5,
                    rounded: true,
                    x1: coeff*roi[z][i][0], y1: coeff*roi[z][i][1],
                    x2: coeff*roi[z][i+1][0], y2: coeff*roi[z][i+1][1]
                    

                    
                });
                
                
               /* tmp = new Array(roi[z][i][0],roi[z][i][1]);*/
           /* }*/
                    
        }
        /*$('canvas').first().drawLine({
                    strokeStyle: 'red',
                    strokeWidth: 1.5,
                    rounded: true,
                    x1: coeff*roi[z][roi[z].length-1][0], y1: coeff*roi[z][roi[z].length-1][1],
                    x2: coeff*roi[z][0][0], y2: coeff*roi[z][0][1]
                }); */
    }
}		

/*Dessine les contour des ROIs connues et dessine selon le contexte actuelle
*
*
*/
function drawPlan() {
    var coeff = jQuery("canvas").first().height()/512;
    var x = globalCoord.x;
    var y = globalCoord.y;
    var z = globalCoord.z;
    var i =1;
    console.log("drawing plan");
    while (i<104) {
    	drawRoi(mystruct[i],x,y,z,coeff);
    	i=i+1;
//        drawRoi(mystruct[0],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[2],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[4],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[6],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[5],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[10],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[12],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[14],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[16],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[18],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[10],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[11],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[12],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[13],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[14],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[15],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[16],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[17],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[18],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[19],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
    
    }
    //console.log("plan done");
}

function drawPlan2() {
    var coeff = $("canvas").first().height()/512;
    //var x = globalCoord.x;
    //var y = globalCoord.y;
   // var z = globalCoord.z;
    var i =1;
    //while (i<mystruct.length) {
    	//drawRoi2(mystruct[i],x,y,z,coeff);
    	//i=i+2;
//        drawRoi(mystruct[0],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[1],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[2],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[3],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[4],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[5],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[6],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[7],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[8],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
//        drawRoi(mystruct[9],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[1],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[3],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[5],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[7],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[9],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[11],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[13],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[15],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[17],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
        drawRoi2(mystruct[19],globalCoord.x,globalCoord.y,globalCoord.z,coeff);
    //}
    //console.log("plan done");
}

function DeleteDoublon(mystruct){
	for (k=0;k<mystruct.length;k++)	{
		for (i=0;i<mystruct[k].length;i++){
			if (typeof(mystruct[k][i])=='object'){
				for (j=0;j<mystruct[k][i].length;j++){
					while ( (j<mystruct[k][i].length-1) && (mystruct[k][i][j].join() == mystruct[k][i][j+1].join())){
						mystruct[k][i].splice(j+1,1);
					}
				}

			}
		}
	}	
//params["images"] = ["C:/wamp/www/build/Nouveau dossier/ATLAS.nii.gz"];

}

function eteindreroi() {
        console.log(this);
//        var vol = papaya.viewer.ScreenVolume;
        window.setTimeout(function(){
            console.log(vol[1].volume.imageData)
//            vol[1].volume.imageData.data.forEach(function(currentData){
//               currentData=1; 
//            });
            for(var i = 0; i<vol[1].volume.imageData.data.length; i++){
                if (vol[1].volume.imageData.data[i] != 5){
                   vol[1].volume.imageData.data[i]=-100; 
                }
                
            }
        }, 5000);
    }



jQuery(document).ready(function() {
    buildRTstruct("RTStruct.txt");
    DeleteDoublon("mystruct");

    globalCoordTmp=0;
    params["images"] = ["ATLAS.nii", "CRONOR.nii"];
    params["CRONOR.nii"] = {"min": 1, "max": 106, "lut": "Spectrum", "alpha": 0.5};
    params["ATLAS.nii"] = {"min": -100, "max": 300};
    
    var ROIsSelected = [
         true,
         false
    ];
    
    if (ROIsSelected[0]){
        params["images"].push("Amygdale-T1T2T3T4-N0-envPANT.nii");
        params["Amygdale-T1T2T3T4-N0-envPANT.nii"] = {"min": 1, "max": 106, "lut": "Spectrum", "alpha": 0.5};
//        params["ATLAS-4.nii"] = {"min": -100, "max": 300};
    }
    if (ROIsSelected[1]){
        params["images"].push("ATLAS-radio.nii");
//        params["ATLAS-radio.nii"] = {"min": -100, "max": 300};
    }
  
    
    //params["atlas"] = "CRONORA.xml";
    
        //    var tab = buildRTMatrix("RTStruct.txt");
    //console.log("ready");
    
 //   eteindreroi();
    
    //params["atlas"] = "CRONOR1.xml";
    //params["kioskMode"] = [1];
    //evenement();
//    setTimeout(function() { jQuery("canvas").click(function(){
//    	console.log("wheeeel");
//    });
//},"2000");
});
/*
papaya.viewer.Viewer.prototype.updateCursorPosition = function (g, f, d) {
    var c, b, a, e;
    if (this.container.display) {
        f = f - this.canvasRect.left;
        d = d - this.canvasRect.top;
        if (this.insideScreenSlice(g.axialSlice, f, d, g.volume.getXDim(), g.volume.getYDim())) {
            c = this.convertScreenToImageCoordinateX(f, g.axialSlice);
            b = this.convertScreenToImageCoordinateY(d, g.axialSlice);
            a = g.axialSlice.currentSlice;
            e = true
        } else {
            if (this.insideScreenSlice(g.coronalSlice, f, d, g.volume.getXDim(), g.volume.getZDim())) {
                c = this.convertScreenToImageCoordinateX(f, g.coronalSlice);
                a = this.convertScreenToImageCoordinateY(d, g.coronalSlice);
                b = g.coronalSlice.currentSlice;
                e = true
            } else {
                if (this.insideScreenSlice(g.sagittalSlice, f, d, g.volume.getYDim(), g.volume.getZDim())) {
                    b = this.convertScreenToImageCoordinateX(f, g.sagittalSlice);
                    a = this.convertScreenToImageCoordinateY(d, g.sagittalSlice);
                    c = g.sagittalSlice.currentSlice;
                    e = true
                }
            }
        }
        if (e) {
            this.container.display.drawDisplay(c, b, a)
        } else {
            this.container.display.drawEmptyDisplay()
        }
    }
};

papaya.viewer.Viewer.prototype.gotoCoordinate = function (a) {
    this.currentCoord.x = a.x;
    this.currentCoord.y = a.y;
    this.currentCoord.z = a.z;
    this.drawViewer(true);
    this.updateSliceSliderControl()
};
papaya.viewer.Viewer.prototype.resizeViewer = function (a) {
    this.canvas.width = a.width;
    this.canvas.height = a.height;
    if (this.initialized) {
        this.calculateScreenSliceTransforms();
        this.canvasRect = this.canvas.getBoundingClientRect();
        this.drawViewer(true)
    }
};
papaya.viewer.Viewer.prototype.getWorldCoordinateAtIndex = function (c, b, a, d) {
    d.setCoordinate((c - this.volume.header.origin.x) * this.volume.header.voxelDimensions.xSize, (this.volume.header.origin.y - b) * this.volume.header.voxelDimensions.ySize, (this.volume.header.origin.z - a) * this.volume.header.voxelDimensions.zSize);
    return d
};
papaya.viewer.Viewer.prototype.getIndexCoordinateAtWorld = function (c, b, a, d) {
    d.setCoordinate((c / this.volume.header.voxelDimensions.xSize) + this.volume.header.origin.x, -1 * ((b / this.volume.header.voxelDimensions.ySize) - this.volume.header.origin.y), -1 * ((a / this.volume.header.voxelDimensions.zSize) - this.volume.header.origin.z), true);
    return d
};

var papaya = papaya || {};
papaya.data = papaya.data || {};
papaya.data.Atlas = papaya.data.Atlas || {};
papaya.data.Atlas.labels = {
    atlas: {
        data: {
            label: [": : : :", "Right Cerebellum:Posterior Lobe:Inf Semi-Lunar Lob:Gray Matter:", "Left Cerebellum:Posterior Lobe:Inf Semi-Lunar Lob:Gray Matter:", "Left Cerebellum:Posterior Lobe:Cerebellar Tonsil:Gray Matter:", "Right Cerebellum:Posterior Lobe:Cerebellar Tonsil:Gray Matter:", "Right Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 20", "Right Cerebrum:Frontal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 20", "Left Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 20", "Right Cerebrum:Limbic Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 20", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 20", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 20", "Left Cerebrum:Limbic Lobe: :Gray Matter:Brodmann area 20", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 38", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 38", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 38", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 38", "Right Cerebrum:Limbic Lobe: :Gray Matter:Brodmann area 20", "Left Cerebrum:Limbic Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 20", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 20", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 20", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 38", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 38", "Right Cerebrum:Temporal Lobe: :Gray Matter:Brodmann area 38", "Left Cerebrum:Temporal Lobe: :Gray Matter:Brodmann area 38", "Left Cerebellum:Posterior Lobe:Uvula:Gray Matter:", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 36", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 36", "Right Cerebellum:Posterior Lobe:Pyramis:Gray Matter:", "Left Cerebellum:Posterior Lobe:Pyramis:Gray Matter:", "Right Cerebellum:Posterior Lobe:Uvula:Gray Matter:", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 21", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 21", "Right Cerebrum:Limbic Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 38", "Right Cerebellum: : :Gray Matter:", "Left Cerebrum:Limbic Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 38", "Left Cerebellum: : :Gray Matter:", "Left Cerebellum:Posterior Lobe:Uvula of Vermis:Gray Matter:", "Left Cerebellum:Posterior Lobe:Tuber:Gray Matter:", "Right Cerebellum:Posterior Lobe:Uvula of Vermis:Gray Matter:", "Right Cerebellum:Posterior Lobe:Tuber:Gray Matter:", "Left Cerebellum:Anterior Lobe:Culmen:Gray Matter:", "Right Cerebellum:Anterior Lobe: :Gray Matter:", "Left Cerebellum:Anterior Lobe: :Gray Matter:", "Right Cerebellum:Anterior Lobe:Culmen:Gray Matter:", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 28", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 28", "Left Cerebrum: :Sup Temporal Gyr:Gray Matter:Brodmann area 38", "Right Cerebrum: :Orbital Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Frontal Lobe:Orbital Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Frontal Lobe:Orbital Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 21", "Right Cerebellum:Anterior Lobe:Nodule:Gray Matter:", "Left Cerebellum:Anterior Lobe:Nodule:Gray Matter:", "Left Cerebrum:Frontal Lobe:Rectal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebellum:Posterior Lobe:Pyramis of Vermis:Gray Matter:", "Right Cerebellum:Posterior Lobe:Pyramis of Vermis:Gray Matter:", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 36", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 36", "Right Cerebrum:Frontal Lobe:Rectal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 20", "Left Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 20", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 35", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 35", "Right Cerebrum:Frontal Lobe:Orbital Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Orbital Gyrus:Gray Matter:Brodmann area 47", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 21", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 28", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 28", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 34", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 34", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 34", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Brodmann area 34", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 47", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebellum:Posterior Lobe:Tuber of Vermis:Gray Matter:", "Left Cerebellum:Posterior Lobe:Tuber of Vermis:Gray Matter:", "Right Cerebellum:Anterior Lobe: :Gray Matter:Dentate", "Right Cerebellum:Anterior Lobe:Pyramis:Gray Matter:", "Left Cerebellum:Anterior Lobe:Pyramis:Gray Matter:", "Left Cerebellum:Anterior Lobe: :Gray Matter:Dentate", "Left Cerebellum:Posterior Lobe:Culmen:Gray Matter:", "Right Cerebrum:Limbic Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 20", "Left Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 36", "Right Cerebrum:Limbic Lobe:Uncus:Gray Matter:Amygdala", "Left Cerebrum:Limbic Lobe:Uncus:Gray Matter:Amygdala", "Right Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 36", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Hippocampus", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 20", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 20", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Hippocampus", "Right Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 18", "Left Cerebellum:Posterior Lobe:Declive:Gray Matter:", "Right Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 37", "Right Cerebrum: :Fusiform Gyrus:Gray Matter:Brodmann area 20", "Left Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 37", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Amygdala", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Amygdala", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 25", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 25", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 11", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebellum:Posterior Lobe:Declive:Gray Matter:", "Right Cerebellum:Posterior Lobe:Declive of Vermis:Gray Matter:", "Left Cerebellum:Posterior Lobe:Declive of Vermis:Gray Matter:", "Right Cerebellum:Posterior Lobe: :Gray Matter:Dentate", "Right Cerebellum:Anterior Lobe:Fastigium:Gray Matter:", "Left Cerebellum:Posterior Lobe:Fastigium:Gray Matter:", "Left Cerebellum:Posterior Lobe: :Gray Matter:Dentate", "Left Cerebellum:Anterior Lobe:Fastigium:Gray Matter:", "Left Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 37", "Left Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 18", "Right Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 18", "Right Cerebellum:Anterior Lobe:Cerebellar Lingual:Gray Matter:", "Left Cerebellum:Anterior Lobe:Cerebellar Lingual:Gray Matter:", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 20", "Right Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 17", "Left Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 17", "Right Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 18", ": : :Gray Matter:Hypothalamus", "Right Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 34", "Left Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 34", "Right Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 25", "Left Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 25", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 20", "Right Cerebrum:Limbic Lobe: :Gray Matter:Brodmann area 35", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 38", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 38", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 25", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 25", "Right Brainstem:Midbrain: :Gray Matter:Substania Nigra", "Left Brainstem:Midbrain: :Gray Matter:Substania Nigra", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 21", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 21", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 13", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 13", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 10", "Right Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 17", "Left Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 17", "Right Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 19", "Left Cerebrum:Temporal Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 19", "Left Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 37", "Left Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 37", "Right Brainstem:Midbrain: :Gray Matter:Red Nucleus", "Left Brainstem:Midbrain: :Gray Matter:Red Nucleus", "Right Brainstem:Midbrain: :Gray Matter:Mammillary Body", "Left Brainstem:Midbrain: :Gray Matter:Mammillary Body", "Right Cerebrum:Sub-lobar: :Gray Matter:Hypothalamus", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 21", "Right Cerebrum:Temporal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 13", "Left Cerebrum:Temporal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 13", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 47", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 10", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 10", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 10", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 10", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 10", "Right Cerebrum:Occipital Lobe: :Gray Matter:Brodmann area 19", "Left Cerebrum:Occipital Lobe: :Gray Matter:Brodmann area 19", "Left Cerebrum:Temporal Lobe: :Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe: :Gray Matter:Brodmann area 37", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 37", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 37", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe:Caudate:Gray Matter:Caudate Tail", "Left Cerebrum:Sub-lobar: :Gray Matter:Hypothalamus", "Right Cerebrum:Limbic Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 34", "Left Cerebrum:Limbic Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 34", "Left Cerebrum:Temporal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 34", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 21", "Left Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 13", "Right Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 13", "Right Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Frontal Lobe:Subcallosal Gyrus:Gray Matter:Brodmann area 11", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 32", "Left Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 18", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Hippocampus", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Hippocampus", "Left Cerebrum:Temporal Lobe:Caudate:Gray Matter:Caudate Tail", "Right Cerebrum:Sub-lobar:Extra-Nuclear:Gray Matter:Brodmann area 13", "Left Cerebrum:Sub-lobar:Extra-Nuclear:Gray Matter:Brodmann area 13", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 13", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 32", "Right Cerebrum: : :Gray Matter:Brodmann area 18", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 37", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 37", "Right Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 37", "Left Cerebrum:Occipital Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 22", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 28", "Right Cerebrum:Sub-lobar: :Gray Matter:Amygdala", "Left Cerebrum:Sub-lobar: :Gray Matter:Amygdala", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 13", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 13", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 13", "Right Cerebrum:Sub-lobar: :Gray Matter:", "Left Cerebrum:Sub-lobar: :Gray Matter:", "Left Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Putamen", "Right Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Putamen", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 25", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 25", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 47", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 10", "Left Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Inf Occipital Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Hippocampus", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 22", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 13", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 13", "Right Cerebrum:Sub-lobar:Claustrum:Gray Matter:", "Left Cerebrum:Sub-lobar:Claustrum:Gray Matter:", "Right Cerebellum:Anterior Lobe:Culmen of Vermis:Gray Matter:", "Left Cerebellum:Anterior Lobe:Culmen of Vermis:Gray Matter:", "Right Cerebrum:Occipital Lobe:Parahippocampus:Gray Matter:Brodmann area 37", "Right Cerebrum:Limbic Lobe:Fusiform Gyrus:Gray Matter:Brodmann area 37", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Hippocampus", "Right Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Tail", "Left Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Tail", "Left Cerebrum:Temporal Lobe: :Gray Matter:Caudate Tail", "Left Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Lat Glob Pallidus", "Left Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Med Glob Pallidus", "Right Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Med Glob Pallidus", "Right Cerebrum:Frontal Lobe:Extra-Nuclear:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Extra-Nuclear:Gray Matter:Brodmann area 47", "Left Cerebrum:Frontal Lobe:Extra-Nuclear:Gray Matter:Brodmann area 13", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 47", "Right Cerebrum:Sub-lobar:Extra-Nuclear:Gray Matter:Brodmann area 47", "Right Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Head", "Left Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Head", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 10", "Right Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:Lat Glob Pallidus", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 22", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 22", "Left Brainstem:Midbrain: :Gray Matter:Subthalamic Nuc", "Right Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 19", "Left Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 19", "Left Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 19", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 27", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 27", "Right Brainstem:Midbrain:Thalamus:Gray Matter:Med Geniculum Body", "Left Brainstem:Midbrain:Thalamus:Gray Matter:Med Geniculum Body", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 22", "Right Brainstem:Midbrain: :Gray Matter:Subthalamic Nuc", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 24", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 24", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 10", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 10", "Right Cerebrum:Frontal Lobe: :Gray Matter:Brodmann area 10", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 30", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 30", "Right Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 17", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 17", ": : :Gray Matter:", "Right Cerebrum: : :Gray Matter:", "Right Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 37", "Left Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 19", "Left Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 37", "Right Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 19", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 30", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 22", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 47", "Right Cerebrum:Sub-lobar:Inf Frontal Gyrus:Gray Matter:Brodmann area 47", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 47", "Right Cerebrum:Sub-lobar:Caudate:Gray Matter:", "Left Cerebrum:Occipital Lobe:Mid Occipital Gyr:Gray Matter:", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:", "Right Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:", "Left Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 37", "Right Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 37", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:", "Right Brainstem:Midbrain: :Gray Matter:Med Geniculum Body", "Left Brainstem:Midbrain: :Gray Matter:Med Geniculum Body", "Right Cerebrum:Sub-lobar: :Gray Matter:Lat Geniculum Body", "Left Cerebrum:Sub-lobar: :Gray Matter:Lat Geniculum Body", "Left Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:", "Left Cerebrum:Sub-lobar:Extra-Nuclear:Gray Matter:Brodmann area 47", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 45", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 45", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 10", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 10", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 46", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 18", "Right Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 30", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:", "Left Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:", "Right Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:", "Left Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:", "Left Cerebrum:Occipital Lobe:Sub-Gyral:Gray Matter:", "Left Cerebrum:Occipital Lobe:Lingual Gyrus:Gray Matter:Brodmann area 30", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Pulvinar", "Left Cerebrum:Sub-lobar:Caudate:Gray Matter:", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Pos Lat Nuc", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Pos Lat Nuc", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Mammillary Body", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 46", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:", "Right Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Inf Temporal Gyrus:Gray Matter:Brodmann area 18", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Pulvinar", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Mammillary Body", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Pos Med Nuc", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:", "Inter-Hemispheric:Occipital Lobe: :Gray Matter:", "Left Cerebrum:Occipital Lobe: :Gray Matter:", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:", ": :Mid Occipital Gyr:Gray Matter:", "Left Cerebrum:Limbic Lobe:Lingual Gyrus:Gray Matter:", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:", ": :Mid Temporal Gyr:Gray Matter:", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Pos Med Nuc", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:", "Right Cerebrum:Frontal Lobe: :Gray Matter:", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:", "Right Cerebrum: :Cuneus:Gray Matter:", "Inter-Hemispheric:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 18", "Right Cerebrum:Occipital Lobe: :Gray Matter:", "Inter-Hemispheric:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 17", "Right Cerebrum: :Mid Occipital Gyr:Gray Matter:", "Inter-Hemispheric:Occipital Lobe:Cuneus:Gray Matter:", "Inter-Hemispheric:Occipital Lobe:Lingual Gyrus:Gray Matter:", "Right Cerebrum: :Inf Temporal Gyrus:Gray Matter:", ": :Inf Temporal Gyrus:Gray Matter:", "Right Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:", "Left Cerebrum:Temporal Lobe:Inf Temporal Gyrus:Gray Matter:", "Left Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:", "Right Cerebellum:Anterior Lobe:Culmen:Gray Matter:Brodmann area 19", "Right Cerebrum:Temporal Lobe:Lingual Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:", "Left Cerebrum:Temporal Lobe:Lingual Gyrus:Gray Matter:Brodmann area 19", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 41", "Right Cerebrum:Temporal Lobe:Insula:Gray Matter:", "Left Cerebrum:Temporal Lobe:Insula:Gray Matter:", "Right Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 22", "Left Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 22", "Right Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 13", "Left Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 13", "Left Cerebrum:Sub-lobar:Inf Frontal Gyrus:Gray Matter:Brodmann area 47", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 32", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 32", "Right Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 18", "Left Cerebrum:Limbic Lobe:Parahippocampus:Gray Matter:Brodmann area 18", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 41", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Med Dorsal Nucleus", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Ant Nucleus", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Ant Nucleus", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 44", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 46", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 46", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Med Dorsal Nucleus", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 44", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 45", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 46", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 30", "Right Cerebrum:Temporal Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 37", "Left Cerebrum:Temporal Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 37", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 30", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 30", "Right Cerebrum:Sub-lobar:Sup Temporal Gyr:Gray Matter:Brodmann area 22", "Right Cerebrum:Sub-lobar:Lentiform Nucleus:Gray Matter:", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Lat Nucleus", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Ven Lat Nucleus", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 42", "Right Cerebrum: :Thalamus:Gray Matter:", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Anterior Nucleus", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 6", "Right Cerebrum:Sub-lobar:Inf Frontal Gyrus:Gray Matter:Brodmann area 45", "Right Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Body", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 45", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 30", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Temporal Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 42", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 29", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 29", "Left Cerebrum:Sub-lobar:Caudate:Gray Matter:Caudate Body", "Right Cerebrum:Occipital Lobe:Pos Cingulate:Gray Matter:Brodmann area 30", "Right Cerebrum:Temporal Lobe:Transverse Tem Gyr:Gray Matter:Brodmann area 41", "Left Cerebrum:Temporal Lobe:Transverse Tem Gyr:Gray Matter:Brodmann area 41", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Anterior Nucleus", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 44", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 23", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 23", "Right Cerebrum:Temporal Lobe:Transverse Tem Gyr:Gray Matter:Brodmann area 42", "Left Cerebrum:Temporal Lobe:Transverse Tem Gyr:Gray Matter:Brodmann area 42", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 44", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 44", "Left Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 41", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 41", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 31", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 13", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 13", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 43", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 43", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 31", "Right Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 22", "Left Cerebrum:Occipital Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 22", "Left Cerebrum:Sub-lobar:Transverse Tem Gyr:Gray Matter:Brodmann area 41", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Lat Pos Nucleus", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Lat Pos Nucleus", "Left Cerebrum:Sub-lobar:Precentral Gyrus:Gray Matter:Brodmann area 13", "Left Cerebrum:Temporal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 43", "Right Cerebrum:Temporal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 42", "Left Cerebrum:Temporal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 42", "Right Cerebrum: : :Gray Matter:Brodmann area 10", "Inter-Hemispheric:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 10", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 23", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 41", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 23", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 43", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 43", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 4", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 4", "Right Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 31", "Left Cerebrum: :Sup Temporal Gyr:Gray Matter:Brodmann area 22", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 40", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 40", "Right Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 40", "Left Cerebrum:Sub-lobar:Insula:Gray Matter:Brodmann area 40", "Left Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 31", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 18", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:", "Right Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:Brodmann area 18", "Left Cerebrum:Limbic Lobe:Pos Cingulate:Gray Matter:", "Left Cerebrum:Occipital Lobe:Sup Temporal Gyr:Gray Matter:Brodmann area 22", "Right Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 41", "Left Cerebrum:Temporal Lobe:Insula:Gray Matter:Brodmann area 41", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Lat Dorsal Nucleus", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Lat Dorsal Nucleus", "Right Cerebrum:Sub-lobar:Thalamus:Gray Matter:Midline Nucleus", "Left Cerebrum:Sub-lobar:Thalamus:Gray Matter:Midline Nucleus", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:", "Right Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 43", "Right Cerebrum:Parietal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 4", "Left Cerebrum:Parietal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 4", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 6", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 33", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 33", "Right Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 9", "Left Cerebrum:Limbic Lobe:Anterior Cingulate:Gray Matter:Brodmann area 9", "Left Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Temporal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 23", "Left Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 40", "Right Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Frontal Lobe:Inf Frontal Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Temporal Lobe:Mid Occipital Gyr:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 18", "Left Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 23", "Right Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 31", "Left Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 31", "Right Cerebrum:Temporal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 40", "Left Cerebrum:Temporal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 40", "Right Cerebrum:Frontal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 4", "Left Cerebrum:Frontal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 4", "Left Cerebrum:Frontal Lobe:Anterior Cingulate:Gray Matter:Brodmann area 9", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 40", "Left Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 3", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 19", "Right Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 31", "Right Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 23", "Left Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 23", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 2", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Frontal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 3", "Left Cerebrum:Frontal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Occipital Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 19", "Left Cerebrum:Occipital Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 19", ":Frontal Lobe:Mid Temporal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Occipital Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 2", "Right Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 24", "Left Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 24", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 32", "Left Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 32", "Right Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 18", "Left Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 18", "Right Cerebrum:Temporal Lobe:Precuneus:Gray Matter:Brodmann area 31", "Right Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 39", "Left Cerebrum:Temporal Lobe:Sub-Gyral:Gray Matter:Brodmann area 39", "Left Cerebrum:Temporal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 40", "Right Cerebrum:Temporal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 40", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 1", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 1", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Parietal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 40", "Left Cerebrum:Parietal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 40", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 7", "Right Cerebrum:Limbic Lobe:Precuneus:Gray Matter:Brodmann area 31", "Left Cerebrum:Limbic Lobe:Precuneus:Gray Matter:Brodmann area 31", "Right Cerebrum:Temporal Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Temporal Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 31", "Left Cerebrum:Occipital Lobe:Sup Occipital Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Parietal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Limbic Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 32", "Left Cerebrum:Limbic Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 32", "Right Cerebrum:Temporal Lobe:Angular Gyrus:Gray Matter:Brodmann area 39", "Left Cerebrum:Temporal Lobe:Angular Gyrus:Gray Matter:Brodmann area 39", "Right Cerebrum:Parietal Lobe:Angular Gyrus:Gray Matter:Brodmann area 39", "Left Cerebrum:Parietal Lobe:Angular Gyrus:Gray Matter:Brodmann area 39", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 9", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 9", "Right Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 19", "Left Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 19", "Right Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 7", "Left Cerebrum:Occipital Lobe:Cuneus:Gray Matter:Brodmann area 7", "Right Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 7", "Right Cerebrum:Parietal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 39", "Left Cerebrum:Parietal Lobe:Supramarginal Gyr:Gray Matter:Brodmann area 39", "Right Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 39", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 40", "Left Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 40", "Left Cerebrum:Frontal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 32", "Right Cerebrum:Frontal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 32", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 8", "Right Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 39", "Left Cerebrum:Parietal Lobe:Precuneus:Gray Matter:Brodmann area 39", "Left Cerebrum:Occipital Lobe:Precuneus:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 2", "Left Cerebrum:Frontal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 9", "Left Cerebrum:Limbic Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 9", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 6", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 8", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 8", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 2", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 24", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 24", "Right Cerebrum:Parietal Lobe:Angular Gyrus:Gray Matter:Brodmann area 40", "Left Cerebrum:Parietal Lobe:Angular Gyrus:Gray Matter:Brodmann area 40", "Right Cerebrum:Parietal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 31", "Left Cerebrum:Parietal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 31", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 4", "Right Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 6", "Right Cerebrum:Frontal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Cingulate Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 8", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 8", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 8", "Right Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 39", "Left Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 39", "Left Cerebrum:Frontal Lobe:Mid Frontal Gyrus:Gray Matter:Brodmann area 6", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 8", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 8", "Right Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 7", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 6", "Left Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 7", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 31", "Left Cerebrum:Frontal Lobe:Precuneus:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Precentral Gyrus:Gray Matter:Brodmann area 3", "Right Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 32", "Left Cerebrum:Limbic Lobe:Sub-Gyral:Gray Matter:Brodmann area 32", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 32", "Left Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 32", "Right Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 7", "Right Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 31", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 31", "Left Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 31", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 5", "Left Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 5", "Left Cerebrum:Limbic Lobe:Paracentral Lobule:Gray Matter:Brodmann area 31", "Right Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 5", "Right Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Sup Frontal Gyrus:Gray Matter:Brodmann area 6", "Left Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 5", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 6", "Left Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 6", "Right Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 40", "Left Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 40", "Right Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 7", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 6", "Right Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Sub-Gyral:Gray Matter:Brodmann area 7", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 4", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 3", "Left Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 3", "Right Cerebrum:Frontal Lobe:Sub-Gyral:Gray Matter:Brodmann area 3", "Right Cerebrum:Frontal Lobe:Inf Parietal Lob:Gray Matter:Brodmann area 40", "Right Cerebrum:Frontal Lobe:Precuneus:Gray Matter:Brodmann area 5", "Left Cerebrum:Frontal Lobe:Precuneus:Gray Matter:Brodmann area 5", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 7", "Right Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 4", "Left Cerebrum:Frontal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 4", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 5", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 5", "Right Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 5", "Left Cerebrum:Parietal Lobe:Sup Parietal Lob:Gray Matter:Brodmann area 5", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 4", "Right Cerebrum:Frontal Lobe:Med Frontal Gyrus:Gray Matter:Brodmann area 4", "Right Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Postcentral Gyrus:Gray Matter:Brodmann area 7", "Left Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 4", "Right Cerebrum:Parietal Lobe:Paracentral Lobule:Gray Matter:Brodmann area 4"]
        },
        header: {
            transform: "0.9357 0.0029 -0.0072 -1.0423 -0.0065 0.9396 -0.0726 -1.3940 0.0103 0.0752 0.8967 3.6475 0.0000 0.0000 0.0000 1.0000",
            name: "Talairach (Nearest Grey Matter)",
            images: {
                summaryimagefile: "Talairach_labels_1mm"
            },
            display: "*.*.*. .*",
            transformedname: "MNI (Nearest Grey Matter)",
            type: "Label"
        },
        version: 1
    }
};

papaya.viewer.Display.prototype.drawDisplay = function (j, l, q) {

papaya.viewer.Viewer.prototype.loadOverlay = function (c, b, d) {

papaya.viewer.Viewer.prototype.initializeViewer = function () {

papaya.viewer.Viewer.prototype.initializeOverlay = function () {

papaya.viewer.Viewer.prototype.drawViewer = function (c, b) {

papaya.viewer.Viewer.prototype.calculateScreenSliceTransforms = function () {

papaya.viewer.Viewer.prototype.getTransformParameters = function (g, a, f) {

papaya.viewer.Viewer.prototype.updatePosition = function (g, f, e, b) {

papaya.viewer.Viewer.prototype.getCurrentScreenVolIndex = function () {

papaya.viewer.Viewer.prototype.loadImage = function (b, a, c) {
fonction modifiée dedans.                                                                                                                                                                                                                                

*/